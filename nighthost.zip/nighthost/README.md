<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/afe01df6-f343-4cba-b2ee-1417b85d672d

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## NIGHTHOST deployment notes (Cloudflare + Render + Backblaze B2)

Primary domain: `nighthostcloud.dpdns.org` (already set in `.env.example`).

### Backblaze B2
- Existing bucket configured for this project: `nighthost-vault-01`.
- The Admin Panel Backblaze B2 form now defaults to this exact bucket name.
- Enter the Backblaze Application Key ID and Application Key only in the authenticated Owner Admin Panel or Render Environment; never commit secrets to GitHub or send them in screenshots/chat.
- Set the pool quota to `10240` MB only if that is the quota you intend to allocate. It is an application-side allocation, not a guarantee of provider storage entitlement.
- Use a bucket-scoped application key with only the permissions required by the application.

### Cloudflare DNS and Worker
- Keep the existing proxied wildcard CNAME record (`*`) unchanged until the Render origin hostname is available.
- The Worker source at `cloudflare-worker.js` intentionally contains `YOUR-APP-NAME.onrender.com`; replace it only after the Render service has been created and its actual `onrender.com` hostname is known.
- Then configure the apex/root DNS record and wildcard DNS/Worker route according to the actual Render origin. Do not invent an origin hostname.
- Confirm Cloudflare SSL/TLS mode is Full (strict) when the Render origin certificate is valid; verify both the apex and wildcard hostnames after deployment.

### Render deployment
- Deploy the existing GitHub repository as a Node web service. Use the repository's existing start/build scripts (`npm install`, `npm run build`, `npm start`).
- Add environment variables from `.env.example` in Render's Environment page. Do not add secrets to the repository.
- At minimum, set `NIGHTHOST_PRIMARY_DOMAIN=nighthostcloud.dpdns.org`; add B2 credentials using the exact bucket `nighthost-vault-01` when ready.
- Persistent state must be backed by a connected cloud storage pool; Render's local filesystem on a free instance must not be treated as durable storage. Test restore after a redeploy before accepting real user sites.

### Important operational limits
Free provider tiers have quotas, sleeping/compute limits, bandwidth limits, and policy restrictions. Multiple buckets/accounts can increase aggregate capacity only within each provider's terms; they do not provide unlimited storage or unlimited compute.
