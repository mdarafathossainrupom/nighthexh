/**
 * NIGHTHOST Wildcard Subdomain Router — Cloudflare Worker
 *
 * Route pattern in Cloudflare Workers & Pages -> Triggers -> Routes:
 *   - nighthostcloud.dpdns.org/*
 *   - *.nighthostcloud.dpdns.org/*
 *
 * Replace ORIGIN_HOST below with your live Render web service domain
 * (e.g., "nighthost-app.onrender.com") before clicking Deploy.
 */

const ORIGIN_HOST = 'YOUR-APP-NAME.onrender.com';

export default {
  async fetch(request) {
    const incomingUrl = new URL(request.url);
    const originalHost = request.headers.get('Host') || incomingUrl.hostname;

    const targetUrl = new URL(request.url);
    targetUrl.hostname = ORIGIN_HOST;
    targetUrl.protocol = 'https:';

    const headers = new Headers(request.headers);
    headers.set('X-Forwarded-Host', originalHost);
    headers.set('X-Forwarded-Proto', incomingUrl.protocol.replace(':', '') || 'https');
    headers.set('Host', ORIGIN_HOST);

    const upstreamReq = new Request(targetUrl.toString(), {
      method: request.method,
      headers,
      body: ['GET', 'HEAD'].includes(request.method.toUpperCase()) ? undefined : request.body,
      redirect: 'manual',
    });

    const response = await fetch(upstreamReq);
    const cleanHeaders = new Headers(response.headers);
    cleanHeaders.set('X-Nighthost-Edge', 'cloudflare-wildcard');

    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers: cleanHeaders,
    });
  },
};
