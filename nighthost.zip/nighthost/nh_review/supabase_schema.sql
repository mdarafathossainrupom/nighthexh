-- ============================================================
-- VELOCLOUD HOSTING PLATFORM - SUPABASE PRODUCTION SCHEMA
-- Ready for Render Cloud + Supabase PostgreSQL
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Profiles Table (Users & Admins)
-- Note: No email confirmation required; Admin approval controls authentication!
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'subadmin', 'user')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'suspended', 'expired')),
  approved_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  approval_duration_label TEXT DEFAULT 'স্থায়ী',
  storage_limit_mb INTEGER NOT NULL DEFAULT 100,
  storage_used_mb NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  last_login_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now())
);

-- 2. Hosted Sites Table
CREATE TABLE IF NOT EXISTS public.hosted_sites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  username TEXT NOT NULL,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  custom_path TEXT,
  description TEXT,
  type TEXT NOT NULL CHECK (type IN ('folder', 'single-file', 'github')),
  status TEXT NOT NULL DEFAULT 'online' CHECK (status IN ('online', 'building', 'error', 'paused')),
  root_file TEXT NOT NULL DEFAULT 'index.html',
  total_files INTEGER NOT NULL DEFAULT 1,
  total_size_kb INTEGER NOT NULL DEFAULT 0,
  hidden_files_count INTEGER NOT NULL DEFAULT 0,
  files_payload JSONB DEFAULT '{}'::jsonb,
  github_config JSONB,
  single_file_config JSONB,
  visits_count INTEGER NOT NULL DEFAULT 0,
  bandwidth_mb NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 3. Sub-Admins Table
CREATE TABLE IF NOT EXISTS public.subadmins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  active BOOLEAN NOT NULL DEFAULT true,
  can_approve_users BOOLEAN NOT NULL DEFAULT true,
  can_set_quota BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  last_active TIMESTAMPTZ DEFAULT timezone('utc'::text, now())
);

-- 4. Enable Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hosted_sites ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subadmins ENABLE ROW LEVEL SECURITY;

-- 5. Policies
CREATE POLICY "Public read for live sites" ON public.hosted_sites
  FOR SELECT USING (status = 'online');

CREATE POLICY "Allow service role full access to profiles" ON public.profiles
  FOR ALL USING (true);

CREATE POLICY "Allow service role full access to sites" ON public.hosted_sites
  FOR ALL USING (true);

-- 6. Seed Default Accounts
INSERT INTO public.profiles (username, full_name, email, role, status, storage_limit_mb, approval_duration_label)
VALUES 
  ('admin', 'Master Administrator', 'admin@velocloud.net', 'admin', 'approved', 5000, 'স্থায়ী'),
  ('subadmin', 'Platform Moderator', 'mod@velocloud.net', 'subadmin', 'approved', 1000, 'স্থায়ী')
ON CONFLICT (username) DO NOTHING;
