import express from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import zlib from 'zlib';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import {
  User,
  SubAdmin,
  HostedSite,
  PlatformConfig,
  AuditLogEntry,
  SiteFile,
  ServerStorageStats,
  UserPopupMessage,
  SupabasePoolNode,
  B2PoolNode,
  AdminActivityReport,
} from './src/types';
import { transform as esbuildTransform } from 'esbuild';
import {
  auditFolderFiles,
  autoRepairSiteFiles,
  detectProjectRuntime,
  diagnoseRuntimeError,
  getFileType,
  getMimeType,
  isBinaryFile,
  isPathHidden,
  prepareStandaloneHtmlForServer,
  resolveHostedFile,
  rewriteCssUrls,
  rewriteHtmlForSiteProxy,
  slugify,
} from './src/services/siteEngine';
import {
  calculatePoolCapacitySummary,
  deleteSiteBundleFromSupabase,
  fetchCoreStateFromSupabase,
  fetchSiteBundleFromSupabase,
  fetchSupabaseBucketUsageMb,
  mergeSupabaseNodes,
  normalizeSupabaseUrl,
  parseSupabaseEnvNodes,
  sanitizeSupabaseNodeForClient,
  syncCoreStateToSupabase,
  syncSiteToSupabasePool,
  verifyAndEnsureSupabaseBucket,
} from './src/services/supabaseStorage';
import {
  calculateB2PoolSummary,
  deleteSiteBundleFromB2,
  fetchB2BucketUsageMb,
  fetchCoreStateFromB2,
  fetchSiteBundleFromB2,
  generateCombinedRenderEnvVariables,
  mergeB2Nodes,
  normalizeB2BucketName,
  parseB2EnvNodes,
  sanitizeB2NodeForClient,
  syncCoreStateToB2,
  syncSiteToB2Pool,
  verifyAndEnsureB2Bucket,
} from './src/services/b2Storage';
import { runSiteAutoHeal } from './src/services/aiHealer';
import {
  computePoolAllocationSummary,
  DEFAULT_PRIMARY_DOMAIN,
  isReservedSubdomain,
  normalizeCustomDomain,
  normalizePrimaryDomain,
  normalizeUserSubdomain,
  renderSiteUnavailableHtml,
  sanitizeExternalLinkUrl,
} from './src/services/format';
import { executePhpCode, isSafePublicUrl } from './src/services/phpRuntime';
import { siteRuntime } from './src/services/siteRuntime';
import { buildZipBuffer, extractZipEntries } from './src/services/zip';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, 'data');
const SITES_BLOB_DIR = path.join(DATA_DIR, 'sites_blobs');
const DB_FILE = path.join(DATA_DIR, 'nighthost-db.json');
const SESSION_SECRET_FILE = path.join(DATA_DIR, '.session-secret');

function getSessionSecret(): string {
  const envSecret = String(process.env.NIGHTHOST_SESSION_SECRET || '').trim();
  if (envSecret.length >= 16) return envSecret;

  // Deterministic seed derived from stable Render/Supabase env vars so sessions survive container restarts on Render Free Tier
  const deterministicSeed = [
    process.env.SUPABASE_SERVICE_ROLE_KEY,
    process.env.SUPABASE_SERVICE_ROLE_KEY_1,
    process.env.SUPABASE_URL_1,
    process.env.SUPABASE_POOL_JSON,
    process.env.NIGHTHOST_OWNER_PASSWORD,
    process.env.NIGHTHOST_ADMIN_KEY,
    process.env.GITHUB_TOKEN,
  ]
    .map(v => String(v || '').trim())
    .filter(Boolean)
    .join('|');

  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (deterministicSeed.length >= 8) {
      const derived = crypto
        .createHash('sha256')
        .update(`NIGHTHOST_PERSISTENT_SESSION_V1:${deterministicSeed}`)
        .digest('hex');
      if (!fs.existsSync(SESSION_SECRET_FILE)) {
        try {
          fs.writeFileSync(SESSION_SECRET_FILE, derived, { encoding: 'utf-8', mode: 0o600 });
        } catch {
          // ignore write glitch
        }
      }
      return derived;
    }
    if (fs.existsSync(SESSION_SECRET_FILE)) {
      const existing = fs.readFileSync(SESSION_SECRET_FILE, 'utf-8').trim();
      if (existing.length >= 32) return existing;
    }
    const generated = crypto.randomBytes(32).toString('hex');
    fs.writeFileSync(SESSION_SECRET_FILE, generated, { encoding: 'utf-8', mode: 0o600 });
    return generated;
  } catch {
    if (deterministicSeed.length >= 8) {
      return crypto
        .createHash('sha256')
        .update(`NIGHTHOST_PERSISTENT_SESSION_V1:${deterministicSeed}`)
        .digest('hex');
    }
    return crypto.randomBytes(32).toString('hex');
  }
}

function hashPassword(plain: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(plain, salt, 64).toString('hex');
  return `scrypt$${salt}$${derived}`;
}

function isHashedPassword(stored?: string): boolean {
  return typeof stored === 'string' && stored.startsWith('scrypt$') && stored.split('$').length === 3;
}

function verifyPassword(candidate: string, stored?: string): boolean {
  if (!stored || !candidate) return false;
  if (isHashedPassword(stored)) {
    const parts = stored.split('$');
    const salt = parts[1];
    const hashHex = parts[2];
    if (!salt || !hashHex) return false;
    try {
      const expected = Buffer.from(hashHex, 'hex');
      const actual = crypto.scryptSync(candidate, salt, 64);
      if (expected.length !== actual.length) return false;
      return crypto.timingSafeEqual(expected, actual);
    } catch {
      return false;
    }
  }
  // Legacy plaintext check with constant-time compare (auto-upgraded on load/login)
  const a = Buffer.from(candidate, 'utf-8');
  const b = Buffer.from(stored, 'utf-8');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

const SESSION_MAX_AGE_MS = 30 * 24 * 3600 * 1000;

function signSessionToken(userId: string): string {
  const payload = `${userId}.${Date.now()}`;
  const sig = crypto.createHmac('sha256', getSessionSecret()).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

function verifySessionToken(token?: string): string | null {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [userId, issuedRaw, sig] = parts;
  if (!userId || !issuedRaw || !sig) return null;
  const issuedMs = Number(issuedRaw);
  if (!Number.isFinite(issuedMs) || Date.now() - issuedMs > SESSION_MAX_AGE_MS || issuedMs > Date.now() + 60000) {
    return null;
  }
  const payload = `${userId}.${issuedRaw}`;
  const expectedSig = crypto.createHmac('sha256', getSessionSecret()).update(payload).digest('base64url');
  const a = Buffer.from(sig, 'utf-8');
  const b = Buffer.from(expectedSig, 'utf-8');
  if (a.length !== b.length) return null;
  return crypto.timingSafeEqual(a, b) ? userId : null;
}

const authRateBuckets = new Map<string, { count: number; resetAt: number }>();

function checkAuthRateLimit(ip: string, limit = 25, windowMs = 5 * 60 * 1000): boolean {
  const now = Date.now();
  const entry = authRateBuckets.get(ip);
  if (!entry || entry.resetAt <= now) {
    authRateBuckets.set(ip, { count: 1, resetAt: now + windowMs });
    return true;
  }
  entry.count += 1;
  return entry.count <= limit;
}

interface NighthostDatabase {
  config: PlatformConfig;
  users: User[];
  subAdmins: SubAdmin[];
  sites: HostedSite[];
  auditLogs: AuditLogEntry[];
  popupMessages: UserPopupMessage[];
  supabaseNodes?: SupabasePoolNode[];
  b2Nodes?: B2PoolNode[];
}

const DEFAULT_CONFIG: PlatformConfig = {
  brandName: 'NIGHTHOST',
  tagline: 'High Speed Cloud Web & Microservice Hosting Platform',
  heroSubtitle: '',
  footerNote: '',
  allowRegistration: true,
  serverStorageCapacityMb: 1024,
  masterAdminName: 'NIGHT HEX',
  masterAdminTelegram: 'https://t.me/NightHex_X',
  masterAdminTelegramHandle: '@NightHex_X',
  secretAdminSlug: 'admin',
  defaultStorageMb: 100,
  broadcastMessage: '',
  primaryDomain: DEFAULT_PRIMARY_DOMAIN,
};

function createInitialDb(): NighthostDatabase {
  return {
    config: { ...DEFAULT_CONFIG },
    users: [],
    subAdmins: [],
    sites: [],
    auditLogs: [
      {
        id: 'log_init',
        timestamp: new Date().toISOString(),
        actor: 'system',
        action: 'SYSTEM_BOOT',
        target: 'NIGHTHOST Core',
        details: 'Platform booted cleanly.',
        category: 'config',
      },
    ],
    popupMessages: [],
    supabaseNodes: [],
    b2Nodes: [],
  };
}

function buildEnvOwnerIfConfigured(): User | null {
  const envOwnerUsername = String(process.env.NIGHTHOST_OWNER_USERNAME || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_.-]/g, '');
  const envOwnerPassword = String(process.env.NIGHTHOST_OWNER_PASSWORD || '').trim();
  const envOwnerEmail = String(process.env.NIGHTHOST_OWNER_EMAIL || '').trim().toLowerCase();

  if (envOwnerUsername.length < 2 || envOwnerPassword.length < 4) {
    return null;
  }

  return {
    id: 'user_owner',
    username: envOwnerUsername,
    fullName: String(process.env.NIGHTHOST_OWNER_NAME || DEFAULT_CONFIG.masterAdminName || 'Platform Owner').trim(),
    email: envOwnerEmail && envOwnerEmail.includes('@') ? envOwnerEmail : `${envOwnerUsername}@nighthost.cloud`,
    password: hashPassword(envOwnerPassword),
    role: 'admin',
    status: 'approved',
    storageLimitMb: 5000,
    storageUsedMb: 0,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
    approvalDurationLabel: 'স্থায়ী (Permanent)',
  };
}

function loadDb(): NighthostDatabase {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(DB_FILE)) {
      const initial = createInitialDb();
      const envOwner = buildEnvOwnerIfConfigured();
      if (envOwner) {
        initial.users.push(envOwner);
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(initial), 'utf-8');
      return initial;
    }
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as Partial<NighthostDatabase>;
    const cfg: PlatformConfig = { ...DEFAULT_CONFIG, ...(parsed.config || {}) };
    if (cfg.masterAdminName === 'নাইটহেক্স (NightHex)') {
      cfg.masterAdminName = 'NIGHT HEX';
    }
    if (cfg.masterAdminTelegram === 'https://t.me/nighthex_admin') {
      cfg.masterAdminTelegram = 'https://t.me/NightHex_X';
    }
    if (cfg.masterAdminTelegramHandle === '@nighthex_admin') {
      cfg.masterAdminTelegramHandle = '@NightHex_X';
    }
    if (cfg.serverStorageCapacityMb === 10240) {
      cfg.serverStorageCapacityMb = 1024;
    }

    const users = Array.isArray(parsed.users) ? parsed.users : [];
    for (const u of users) {
      if (u.role === 'admin' && u.fullName === 'নাইটহেক্স (NightHex)') {
        u.fullName = 'NIGHT HEX';
      }
    }

    const rawSites = Array.isArray(parsed.sites) ? parsed.sites : [];
    const migratedSites: HostedSite[] = rawSites.map(s => {
      const hasInlineContent = Object.values(s.files || {}).some(f => Boolean(f?.content));
      if (hasInlineContent) {
        persistSiteBlob(s);
        return stripSiteFileContents(s);
      }
      return s;
    });

    const db: NighthostDatabase = {
      config: cfg,
      users,
      subAdmins: Array.isArray(parsed.subAdmins) ? parsed.subAdmins : [],
      sites: migratedSites,
      auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : [],
      popupMessages: Array.isArray(parsed.popupMessages) ? parsed.popupMessages : [],
      supabaseNodes: Array.isArray(parsed.supabaseNodes) ? parsed.supabaseNodes : [],
      b2Nodes: Array.isArray(parsed.b2Nodes) ? parsed.b2Nodes : [],
    };

    const envOwnerUsername = String(process.env.NIGHTHOST_OWNER_USERNAME || '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9_.-]/g, '');
    const envOwnerPassword = String(process.env.NIGHTHOST_OWNER_PASSWORD || '').trim();
    const envOwnerEmail = String(process.env.NIGHTHOST_OWNER_EMAIL || '').trim().toLowerCase();

    let owner = db.users.find(u => u.role === 'admin');
    let dbMutated = false;

    if (!owner) {
      const envOwner = buildEnvOwnerIfConfigured();
      if (envOwner) {
        db.users.unshift(envOwner);
        owner = envOwner;
        dbMutated = true;
      }
    }

    if (owner) {
      if (envOwnerUsername && envOwnerUsername.length >= 2 && owner.username !== envOwnerUsername) {
        owner.username = envOwnerUsername;
        dbMutated = true;
      }
      if (envOwnerEmail && envOwnerEmail.includes('@') && owner.email !== envOwnerEmail) {
        owner.email = envOwnerEmail;
        dbMutated = true;
      }
      if (envOwnerPassword && envOwnerPassword.length >= 4 && !verifyPassword(envOwnerPassword, owner.password)) {
        owner.password = hashPassword(envOwnerPassword);
        dbMutated = true;
      }
    }

    // Auto-upgrade any legacy plaintext passwords on startup to scrypt hashes
    for (const u of db.users) {
      if (u.password && !isHashedPassword(u.password)) {
        u.password = hashPassword(u.password);
        dbMutated = true;
      }
    }

    if (dbMutated || rawSites.some(s => Object.values(s.files || {}).some(f => Boolean(f?.content)))) {
      try {
        writeDbToDisk(db);
      } catch {
        // ignore startup write glitch
      }
    }
    return db;
  } catch (err) {
    console.error('Failed to load DB, creating fresh:', err);
    const fresh = createInitialDb();
    const envOwner = buildEnvOwnerIfConfigured();
    if (envOwner) fresh.users.push(envOwner);
    saveDb(fresh);
    return fresh;
  }
}

interface SseClientEntry {
  res: express.Response;
  userId: string | null;
}

const sseClients = new Set<SseClientEntry>();
let siteBySlugCache = new Map<string, HostedSite>();
let siteByDomainCache = new Map<string, HostedSite>();
let bootstrapPayloadCache: ReturnType<typeof buildFullBootstrapPayloadUncached> | null = null;
let bootstrapJsonCache: string | null = null;
const envNodeRuntimeStatus = new Map<
  string,
  { status: 'connected' | 'error'; lastCheckedAt: string; errorMessage?: string; usedMb?: number }
>();
const envB2RuntimeStatus = new Map<
  string,
  { status: 'connected' | 'error'; lastCheckedAt: string; errorMessage?: string; usedMb?: number }
>();
const autoHealAttemptedKeys = new Set<string>();
let cachedDiskStats: { diskTotalMb: number | null; diskFreeMb: number | null; fetchedAt: number } | null = null;
let deferredSaveTimer: NodeJS.Timeout | null = null;
let supabaseCoreSyncTimer: NodeJS.Timeout | null = null;

// LRU in-memory blob cache so Render 512MB RAM stays lean while keeping hot sites instant
const MAX_CACHED_SITE_BLOBS = 8;
const MAX_CACHED_BLOB_BYTES = 24 * 1024 * 1024;
const siteFilesLruCache = new Map<string, { files: Record<string, SiteFile>; bytes: number; updatedAt: string }>();

function stripSiteFileContents(site: HostedSite): HostedSite {
  const strippedFiles: Record<string, SiteFile> = {};
  for (const [k, f] of Object.entries(site.files || {})) {
    if (!f || typeof f !== 'object') continue;
    strippedFiles[k] = {
      path: f.path,
      content: '',
      size: f.size,
      isHidden: f.isHidden,
      isBinary: f.isBinary,
      mimeType: f.mimeType,
      type: f.type,
    };
  }
  const slimSingle = site.singleFileConfig
    ? {
        ...site.singleFileConfig,
        rawContent: '',
      }
    : undefined;
  return {
    ...site,
    files: strippedFiles,
    ...(slimSingle ? { singleFileConfig: slimSingle } : {}),
  };
}

function getSiteBlobPath(siteId: string): string {
  const safeId = String(siteId || '').replace(/[^a-zA-Z0-9_-]/g, '');
  return path.join(SITES_BLOB_DIR, `${safeId}.json`);
}

function setSiteLruCache(siteId: string, files: Record<string, SiteFile>, updatedAt: string) {
  const bytes = Object.values(files).reduce((acc, f) => acc + (f.content ? Buffer.byteLength(f.content, 'utf-8') : 0), 0);
  if (bytes > 10 * 1024 * 1024) return;
  if (siteFilesLruCache.has(siteId)) {
    siteFilesLruCache.delete(siteId);
  }
  siteFilesLruCache.set(siteId, { files, bytes, updatedAt });

  let totalBytes = 0;
  for (const entry of siteFilesLruCache.values()) {
    totalBytes += entry.bytes;
  }
  while (siteFilesLruCache.size > MAX_CACHED_SITE_BLOBS || totalBytes > MAX_CACHED_BLOB_BYTES) {
    const oldestKey = siteFilesLruCache.keys().next().value;
    if (!oldestKey || oldestKey === siteId) break;
    const evicted = siteFilesLruCache.get(oldestKey);
    siteFilesLruCache.delete(oldestKey);
    totalBytes -= evicted?.bytes || 0;
  }
}

function persistSiteBlob(site: HostedSite) {
  try {
    if (!fs.existsSync(SITES_BLOB_DIR)) {
      fs.mkdirSync(SITES_BLOB_DIR, { recursive: true });
    }
    const blobFile = getSiteBlobPath(site.id);
    const tmpFile = `${blobFile}.tmp`;
    fs.writeFileSync(tmpFile, JSON.stringify(site.files || {}), 'utf-8');
    fs.renameSync(tmpFile, blobFile);
    setSiteLruCache(site.id, site.files || {}, site.updatedAt || '');
  } catch (err) {
    console.error('Failed to persist site blob:', err);
  }
}

function deleteSiteBlob(siteId: string) {
  siteFilesLruCache.delete(siteId);
  try {
    const blobFile = getSiteBlobPath(siteId);
    if (fs.existsSync(blobFile)) {
      fs.unlinkSync(blobFile);
    }
  } catch {
    // ignore cleanup error
  }
}

function hydrateSiteFilesSync(site: HostedSite): HostedSite {
  const inlineFiles = site.files || {};
  const hasInlineContent = Object.values(inlineFiles).some(f => Boolean(f?.content));
  if (hasInlineContent) {
    return site;
  }

  const cached = siteFilesLruCache.get(site.id);
  if (cached && cached.updatedAt === (site.updatedAt || '')) {
    siteFilesLruCache.delete(site.id);
    siteFilesLruCache.set(site.id, cached);
    const rootRaw =
      site.singleFileConfig && site.rootFile && cached.files[site.rootFile]
        ? cached.files[site.rootFile].content
        : site.singleFileConfig?.rawContent || '';
    return {
      ...site,
      files: cached.files,
      ...(site.singleFileConfig ? { singleFileConfig: { ...site.singleFileConfig, rawContent: rootRaw } } : {}),
    };
  }

  try {
    const blobFile = getSiteBlobPath(site.id);
    if (fs.existsSync(blobFile)) {
      const parsed = JSON.parse(fs.readFileSync(blobFile, 'utf-8')) as Record<string, SiteFile>;
      if (parsed && typeof parsed === 'object' && Object.keys(parsed).length > 0) {
        setSiteLruCache(site.id, parsed, site.updatedAt || '');
        const rootRaw =
          site.singleFileConfig && site.rootFile && parsed[site.rootFile]
            ? parsed[site.rootFile].content
            : site.singleFileConfig?.rawContent || '';
        return {
          ...site,
          files: parsed,
          ...(site.singleFileConfig ? { singleFileConfig: { ...site.singleFileConfig, rawContent: rootRaw } } : {}),
        };
      }
    }
  } catch {
    // fall through to async Supabase hydration if available
  }
  return site;
}

async function hydrateSiteFilesAsync(site: HostedSite): Promise<HostedSite> {
  const localHydrated = hydrateSiteFilesSync(site);
  const hasContent = Object.values(localHydrated.files || {}).some(f => Boolean(f?.content) || Number(f?.size || 0) === 0);
  if (hasContent && Object.keys(localHydrated.files || {}).length > 0) {
    return localHydrated;
  }

  // Try Backblaze B2 Pool first (primary 10GB+ persistent layer), then fallback to Supabase Pool
  const b2Files = await fetchSiteBundleFromB2(getAllMergedB2Nodes(), site.id);
  const remoteFiles =
    b2Files && Object.keys(b2Files).length > 0
      ? b2Files
      : await fetchSiteBundleFromSupabase(getAllMergedSupabaseNodes(), site.slug, site.id);

  if (remoteFiles && Object.keys(remoteFiles).length > 0) {
    const restored: HostedSite = {
      ...site,
      files: remoteFiles,
      ...(site.singleFileConfig && site.rootFile && remoteFiles[site.rootFile]
        ? { singleFileConfig: { ...site.singleFileConfig, rawContent: remoteFiles[site.rootFile].content } }
        : {}),
    };
    persistSiteBlob(restored);
    return restored;
  }
  return localHydrated;
}

function invalidateBootstrapCache() {
  bootstrapPayloadCache = null;
  bootstrapJsonCache = null;
}

function rebuildSiteIndex(database: NighthostDatabase = db) {
  const next = new Map<string, HostedSite>();
  const nextDomains = new Map<string, HostedSite>();
  for (const s of database.sites) {
    if (s.slug) next.set(s.slug.toLowerCase(), s);
    if (s.customPath) next.set(s.customPath.toLowerCase(), s);
    if (s.customDomain) {
      const cleanDom = normalizeCustomDomain(s.customDomain);
      if (cleanDom) nextDomains.set(cleanDom.toLowerCase(), s);
    }
  }
  siteBySlugCache = next;
  siteByDomainCache = nextDomains;
  invalidateBootstrapCache();
}

function getAllMergedSupabaseNodes(): SupabasePoolNode[] {
  const envNodes = parseSupabaseEnvNodes(process.env).map(n => {
    const rt = envNodeRuntimeStatus.get(n.id);
    return rt ? { ...n, ...rt } : n;
  });
  const manualNodes = Array.isArray(db.supabaseNodes) ? db.supabaseNodes : [];
  return mergeSupabaseNodes(envNodes, manualNodes);
}

function getAllMergedB2Nodes(): B2PoolNode[] {
  const envNodes = parseB2EnvNodes(process.env).map(n => {
    const rt = envB2RuntimeStatus.get(n.id);
    return rt ? { ...n, ...rt } : n;
  });
  const manualNodes = Array.isArray(db.b2Nodes) ? db.b2Nodes : [];
  return mergeB2Nodes(envNodes, manualNodes);
}

function getOwnerAvatarDataUrl(): string | undefined {
  const owner = db.users.find(u => u.role === 'admin');
  return owner?.avatarDataUrl;
}

function getEnrichedConfig(): PlatformConfig {
  const ownerAvatar = getOwnerAvatarDataUrl();
  const primaryDomain =
    normalizePrimaryDomain(process.env.NIGHTHOST_PRIMARY_DOMAIN) ||
    normalizePrimaryDomain(db.config.primaryDomain) ||
    DEFAULT_PRIMARY_DOMAIN;
  return {
    ...db.config,
    primaryDomain,
    ...(ownerAvatar ? { masterAdminAvatarDataUrl: ownerAvatar } : {}),
  };
}

function enrichSubAdmins(list: SubAdmin[] = db.subAdmins): SubAdmin[] {
  return list.map(sub => {
    const matchedUser = db.users.find(
      u => u.id === sub.id || u.username.toLowerCase() === sub.username.toLowerCase()
    );
    return {
      ...sub,
      avatarDataUrl: matchedUser?.avatarDataUrl || sub.avatarDataUrl,
    };
  });
}

function broadcastSync() {
  if (sseClients.size === 0) return;
  for (const client of sseClients) {
    try {
      const viewer = client.userId ? db.users.find(u => u.id === client.userId) || null : null;
      const payload = `data: ${JSON.stringify({ type: 'sync', payload: buildScopedBootstrapPayload(viewer) })}\n\n`;
      client.res.write(payload);
    } catch {
      sseClients.delete(client);
    }
  }
}

function scheduleSupabaseCoreSync(database: NighthostDatabase = db) {
  const sbNodes = getAllMergedSupabaseNodes().filter(n => n.status === 'connected' && n.serviceRoleKey);
  const b2Nodes = getAllMergedB2Nodes().filter(n => n.status === 'connected' && n.applicationKey);
  if (sbNodes.length === 0 && b2Nodes.length === 0) return;
  if (supabaseCoreSyncTimer) clearTimeout(supabaseCoreSyncTimer);
  supabaseCoreSyncTimer = setTimeout(() => {
    supabaseCoreSyncTimer = null;
    const coreSnapshot = {
      config: database.config,
      users: database.users,
      subAdmins: database.subAdmins,
      sites: database.sites.map(stripSiteFileContents),
      auditLogs: database.auditLogs.slice(0, 120),
      popupMessages: database.popupMessages.slice(0, 50),
      updatedAt: new Date().toISOString(),
    };
    if (sbNodes.length > 0) {
      syncCoreStateToSupabase(sbNodes, coreSnapshot).catch(() => {});
    }
    if (b2Nodes.length > 0) {
      syncCoreStateToB2(b2Nodes, coreSnapshot).catch(() => {});
    }
  }, 1500);
  supabaseCoreSyncTimer.unref?.();
}

function writeDbToDisk(database: NighthostDatabase) {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const compactDb: NighthostDatabase = {
    ...database,
    sites: database.sites.map(stripSiteFileContents),
  };
  const tmpFile = `${DB_FILE}.tmp`;
  fs.writeFileSync(tmpFile, JSON.stringify(compactDb), 'utf-8');
  fs.renameSync(tmpFile, DB_FILE);
}

function saveDb(database: NighthostDatabase, emitRealtime = true) {
  try {
    database.sites = database.sites.map(stripSiteFileContents);
    rebuildSiteIndex(database);
    writeDbToDisk(database);
    scheduleSupabaseCoreSync(database);
    if (emitRealtime) {
      broadcastSync();
    }
  } catch (err) {
    console.error('Failed to save DB:', err);
  }
}

function scheduleBackgroundSaveDb(database: NighthostDatabase) {
  invalidateBootstrapCache();
  if (deferredSaveTimer) return;
  deferredSaveTimer = setTimeout(() => {
    deferredSaveTimer = null;
    try {
      writeDbToDisk(database);
      scheduleSupabaseCoreSync(database);
    } catch (err) {
      console.error('Background save DB error:', err);
    }
  }, 1800);
  deferredSaveTimer.unref?.();
}

let db = loadDb();
rebuildSiteIndex(db);

function addLog(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) {
  db.auditLogs.unshift({
    ...entry,
    id: 'log_' + Math.random().toString(36).substring(2, 9),
    timestamp: new Date().toISOString(),
  });
  if (db.auditLogs.length > 150) {
    db.auditLogs = db.auditLogs.slice(0, 150);
  }
}

function sanitizeUser(user: User): User {
  const copy = { ...user };
  delete copy.password;
  return copy;
}

function isUserExpired(user: User): boolean {
  if (user.role === 'admin') return false;
  if (!user.expiresAt) return false;
  return new Date(user.expiresAt).getTime() <= Date.now();
}

function getRealOsDiskStats(): { diskTotalMb: number | null; diskFreeMb: number | null } {
  const now = Date.now();
  if (cachedDiskStats && now - cachedDiskStats.fetchedAt < 10000) {
    return { diskTotalMb: cachedDiskStats.diskTotalMb, diskFreeMb: cachedDiskStats.diskFreeMb };
  }
  let diskTotalMb: number | null = null;
  let diskFreeMb: number | null = null;
  try {
    const statFn = (fs as unknown as { statfsSync?: (p: string) => { bsize: number; blocks: number; bavail: number } }).statfsSync;
    if (typeof statFn === 'function') {
      const targetDir = fs.existsSync(DATA_DIR) ? DATA_DIR : __dirname;
      const st = statFn(targetDir);
      if (st && st.bsize > 0 && st.blocks > 0) {
        diskTotalMb = Math.round((st.bsize * st.blocks) / (1024 * 1024));
        diskFreeMb = Math.round((st.bsize * st.bavail) / (1024 * 1024));
      }
    }
  } catch {
    // ignore statfs unavailability
  }
  cachedDiskStats = { diskTotalMb, diskFreeMb, fetchedAt: now };
  return { diskTotalMb, diskFreeMb };
}

function computeServerStorageStats(): ServerStorageStats {
  const { diskTotalMb, diskFreeMb } = getRealOsDiskStats();
  const mergedSupabase = getAllMergedSupabaseNodes();
  const sbSummary = calculatePoolCapacitySummary(mergedSupabase);
  const mergedB2 = getAllMergedB2Nodes();
  const b2Summary = calculateB2PoolSummary(mergedB2);

  const combinedCloudMb = sbSummary.connectedMb + b2Summary.connectedMb;
  const storageSource: ServerStorageStats['storageSource'] =
    b2Summary.connectedMb > 0 && sbSummary.connectedMb > 0
      ? 'hybrid-cloud-pool'
      : b2Summary.connectedMb > 0
      ? 'b2-pool'
      : sbSummary.connectedMb > 0
      ? 'supabase-pool'
      : 'os-disk';

  const configuredPoolMb =
    combinedCloudMb > 0
      ? combinedCloudMb
      : Math.max(100, Number(db.config.serverStorageCapacityMb) || 1024);

  const defaultQuotaMb = Math.max(10, Number(db.config.defaultStorageMb) || 100);
  const alloc = computePoolAllocationSummary(db.users, db.sites, configuredPoolMb, defaultQuotaMb);

  return {
    configuredPoolMb,
    storageSource,
    supabaseNodesCount: sbSummary.nodesCount,
    supabaseConnectedCount: sbSummary.connectedCount,
    supabaseConnectedMb: sbSummary.connectedMb,
    supabaseNodes: mergedSupabase.map(sanitizeSupabaseNodeForClient),
    b2NodesCount: b2Summary.nodesCount,
    b2ConnectedCount: b2Summary.connectedCount,
    b2ConnectedMb: b2Summary.connectedMb,
    b2Nodes: mergedB2.map(sanitizeB2NodeForClient),
    diskTotalMb,
    diskFreeMb,
    allocatedMb: alloc.allocatedMb,
    usedBySitesMb: alloc.usedBySitesMb,
    usedByAvatarsMb: alloc.usedByAvatarsMb,
    totalUsedMb: alloc.totalUsedMb,
    remainingAllocatableMb: alloc.remainingAllocatableMb,
    defaultQuotaMb,
    estimatedRemainingUsers: alloc.estimatedRemainingUsers,
    totalUsersCount: alloc.totalUsersCount,
    approvedUsersCount: alloc.approvedUsersCount,
    pendingUsersCount: alloc.pendingUsersCount,
    suspendedUsersCount: alloc.suspendedUsersCount,
  };
}

function getUserSitesSizeKb(userId: string): number {
  return db.sites
    .filter(s => s.userId === userId)
    .reduce((acc, s) => acc + (Number(s.totalSizeKb) || 0), 0);
}

function applyAvatarUpdate(
  targetUser: User,
  avatarDataUrl: string | null
): { ok: boolean; error?: string } {
  if (avatarDataUrl === null || avatarDataUrl === '') {
    delete targetUser.avatarDataUrl;
    delete targetUser.avatarSizeKb;
    recalculateUserStorageMb(targetUser.id);
    return { ok: true };
  }

  if (typeof avatarDataUrl !== 'string') {
    return { ok: false, error: 'অবৈধ ছবির ফরম্যাট।' };
  }

  const match = avatarDataUrl.match(/^data:image\/(png|jpe?g|webp|gif);base64,([A-Za-z0-9+/=\s]+)$/i);
  if (!match) {
    return { ok: false, error: 'শুধুমাত্র PNG, JPG, WEBP অথবা GIF ছবি আপলোড করুন।' };
  }

  const base64Clean = match[2].replace(/\s+/g, '');
  const bytes = Math.ceil((base64Clean.length * 3) / 4);
  if (bytes > 2 * 1024 * 1024) {
    return { ok: false, error: 'প্রোফাইল ছবির সাইজ ২ MB এর বেশি হতে পারবে না।' };
  }

  const newKb = Math.max(1, Math.round(bytes / 1024));
  const sitesKb = getUserSitesSizeKb(targetUser.id);

  if (targetUser.role !== 'admin' && sitesKb + newKb > targetUser.storageLimitMb * 1024) {
    return {
      ok: false,
      error: `স্টোরেজ কোটা শেষ! ছবি সেভ করতে ${newKb} KB জায়গা প্রয়োজন (লিমিট: ${targetUser.storageLimitMb} MB)।`,
    };
  }

  targetUser.avatarDataUrl = avatarDataUrl;
  targetUser.avatarSizeKb = newKb;
  recalculateUserStorageMb(targetUser.id);
  return { ok: true };
}

function recalculateUserStorageMb(userId: string) {
  const user = db.users.find(u => u.id === userId);
  if (!user) return;
  const sitesKb = getUserSitesSizeKb(userId);
  const avatarKb = Number(user.avatarSizeKb) || 0;
  const totalKb = sitesKb + avatarKb;
  user.storageUsedMb = totalKb === 0 ? 0 : Math.round((totalKb / 1024) * 1000) / 1000;
}

function computeAdminActivityReports(): AdminActivityReport[] {
  const admins = enrichSubAdmins(db.subAdmins);
  return admins.map(sub => {
    const approvedUsers = db.users.filter(
      u => u.role === 'user' && (u.approvedBy === sub.username || u.approvedBy === sub.id)
    );
    const matchingLogs = db.auditLogs.filter(
      l => l.actor.toLowerCase() === sub.username.toLowerCase()
    );
    const messagesSentCount = (db.popupMessages || []).filter(
      m => m.senderUsername.toLowerCase() === sub.username.toLowerCase()
    ).length;
    const sitesCount = db.sites.filter(s => s.userId === sub.id).length;
    return {
      adminId: sub.id,
      username: sub.username,
      displayName: sub.displayName,
      active: sub.active,
      approvedUsersCount: approvedUsers.length,
      approvedUsernames: approvedUsers.map(u => u.username),
      actionsCount: matchingLogs.length,
      messagesSentCount,
      sitesCount,
      lastActionAt: matchingLogs[0]?.timestamp || sub.lastActive,
    };
  });
}

function needsOwnerSetup(): boolean {
  return !db.users.some(u => u.role === 'admin');
}

function buildFullBootstrapPayloadUncached() {
  return {
    config: getEnrichedConfig(),
    needsOwnerSetup: needsOwnerSetup(),
    users: db.users.map(sanitizeUser),
    subAdmins: enrichSubAdmins(db.subAdmins),
    sites: db.sites.map(stripSiteFileContents),
    auditLogs: db.auditLogs,
    popupMessages: db.popupMessages || [],
    serverStorage: computeServerStorageStats(),
    adminReports: computeAdminActivityReports(),
  };
}

function buildBootstrapPayload() {
  if (!bootstrapPayloadCache) {
    bootstrapPayloadCache = buildFullBootstrapPayloadUncached();
  }
  return bootstrapPayloadCache;
}

function getEffectiveAdminPerms(viewer: User | null) {
  if (!viewer) return null;
  if (viewer.role === 'admin') {
    return {
      isOwner: true,
      canApproveUsers: true,
      canSetQuota: true,
      canSendMessages: true,
      canDownloadSource: true,
      canManageAllSites: true,
    };
  }
  if (viewer.role === 'subadmin') {
    const sub = db.subAdmins.find(
      s => s.id === viewer.id || s.username.toLowerCase() === viewer.username.toLowerCase()
    );
    if (!sub || !sub.active || viewer.status !== 'approved') return null;
    return {
      isOwner: false,
      canApproveUsers: sub.canApproveUsers !== false,
      canSetQuota: sub.canSetQuota !== false,
      canSendMessages: sub.canSendMessages !== false,
      canDownloadSource: sub.canDownloadSource === true,
      canManageAllSites: sub.canManageAllSites === true,
    };
  }
  return null;
}

function buildScopedBootstrapPayload(viewer: User | null) {
  const full = buildBootstrapPayload();
  const publicSubAdmins = full.subAdmins.filter(s => s.active).map(s => ({ ...s, email: '' }));

  if (!viewer) {
    return {
      sessionUser: null,
      config: full.config,
      needsOwnerSetup: full.needsOwnerSetup,
      users: [],
      subAdmins: publicSubAdmins,
      sites: [],
      auditLogs: [],
      popupMessages: [],
      adminReports: [],
    };
  }

  if (viewer.role === 'user') {
    const ownUser = full.users.find(u => u.id === viewer.id);
    const ownSites = full.sites.filter(s => s.userId === viewer.id);
    const ownPopups = full.popupMessages.filter(
      m => m.targetUserId === 'all' || m.targetUserId === viewer.id
    );
    const ownLogs = full.auditLogs
      .filter(
        l =>
          l.actor.toLowerCase() === viewer.username.toLowerCase() ||
          l.target.toLowerCase() === viewer.username.toLowerCase()
      )
      .slice(0, 30);
    return {
      sessionUser: ownUser || sanitizeUser(viewer),
      config: full.config,
      needsOwnerSetup: full.needsOwnerSetup,
      users: ownUser ? [ownUser] : [],
      subAdmins: publicSubAdmins,
      sites: ownSites,
      auditLogs: ownLogs,
      popupMessages: ownPopups,
      adminReports: [],
    };
  }

  const perms = getEffectiveAdminPerms(viewer);
  if (!perms) {
    return {
      sessionUser: null,
      config: full.config,
      needsOwnerSetup: full.needsOwnerSetup,
      users: [],
      subAdmins: publicSubAdmins,
      sites: [],
      auditLogs: [],
      popupMessages: [],
      adminReports: [],
    };
  }

  if (perms.isOwner) {
    return {
      sessionUser: sanitizeUser(viewer),
      ...full,
    };
  }

  // Scoped payload for non-Owner Admin (subadmin) — hides Owner credentials, Supabase keys & Owner-only config logs
  const managedUserIds = new Set(
    db.users.filter(u => u.role === 'user' || u.id === viewer.id).map(u => u.id)
  );
  const scopedUsers = full.users.filter(u => managedUserIds.has(u.id));
  const scopedSites = perms.canManageAllSites
    ? full.sites
    : full.sites.filter(s => managedUserIds.has(s.userId));
  const scopedLogs = full.auditLogs.filter(
    l => l.category !== 'config' && l.category !== 'subadmin'
  );
  const scopedPopups = full.popupMessages.filter(
    m =>
      m.senderUsername.toLowerCase() === viewer.username.toLowerCase() ||
      m.targetUserId === 'all' ||
      m.targetUserId === viewer.id
  );
  const scopedStorage: ServerStorageStats = {
    ...full.serverStorage,
    supabaseNodes: [],
    b2Nodes: [],
  };

  return {
    sessionUser: sanitizeUser(viewer),
    config: full.config,
    needsOwnerSetup: full.needsOwnerSetup,
    users: scopedUsers,
    subAdmins: full.subAdmins.map(s => ({ ...s, email: s.id === viewer.id ? s.email : '' })),
    sites: scopedSites,
    auditLogs: scopedLogs,
    popupMessages: scopedPopups,
    serverStorage: scopedStorage,
    adminReports: [],
  };
}

function isSecureHttpsRequest(req: express.Request): boolean {
  if (req.secure) return true;
  const xfProto = String(req.headers['x-forwarded-proto'] || '').toLowerCase();
  return xfProto.includes('https');
}

function setSessionCookie(req: express.Request, res: express.Response, userId: string) {
  const isHttps = isSecureHttpsRequest(req);
  const token = signSessionToken(userId);
  const cookieAttrs = isHttps
    ? 'Path=/; Max-Age=' + 30 * 24 * 3600 + '; HttpOnly; SameSite=None; Secure'
    : 'Path=/; Max-Age=' + 30 * 24 * 3600 + '; HttpOnly; SameSite=Lax';
  res.setHeader(
    'Set-Cookie',
    `nighthost_session=${encodeURIComponent(token)}; ${cookieAttrs}`
  );
}

function clearSessionCookie(req: express.Request, res: express.Response) {
  const isHttps = isSecureHttpsRequest(req);
  const cookieAttrs = isHttps
    ? 'Path=/; Max-Age=0; HttpOnly; SameSite=None; Secure'
    : 'Path=/; Max-Age=0; HttpOnly; SameSite=Lax';
  res.setHeader(
    'Set-Cookie',
    `nighthost_session=; ${cookieAttrs}`
  );
}

function getRequestViewer(req: express.Request): User | null {
  const cookies = parseCookieHeader(req.headers.cookie);
  const userId = verifySessionToken(cookies.nighthost_session);
  if (!userId) return null;
  const matched = db.users.find(u => u.id === userId);
  if (!matched) return null;
  if (matched.status !== 'approved' || isUserExpired(matched)) return null;
  if (matched.role === 'subadmin') {
    const sub = db.subAdmins.find(
      s => s.id === matched.id || s.username.toLowerCase() === matched.username.toLowerCase()
    );
    if (!sub || !sub.active) return null;
  }
  return matched;
}

function requireAuth(req: express.Request, res: express.Response): User | null {
  const viewer = getRequestViewer(req);
  if (!viewer) {
    res.status(401).json({ success: false, message: 'অনুগ্রহ করে প্রথমে লগইন করুন।' });
    return null;
  }
  return viewer;
}

function requireAdminOrSubadmin(req: express.Request, res: express.Response) {
  const viewer = requireAuth(req, res);
  if (!viewer) return null;
  const perms = getEffectiveAdminPerms(viewer);
  if (!perms) {
    res.status(403).json({ success: false, message: 'এই কাজের জন্য অ্যাডমিন বা মালিকের অনুমতি প্রয়োজন।' });
    return null;
  }
  return { viewer, perms };
}

function requireOwner(req: express.Request, res: express.Response): User | null {
  const viewer = requireAuth(req, res);
  if (!viewer) return null;
  if (viewer.role !== 'admin') {
    res.status(403).json({ success: false, message: 'শুধুমাত্র প্ল্যাটফর্ম মালিক (Owner) এই অ্যাকশনটি করতে পারবেন।' });
    return null;
  }
  return viewer;
}

function parseGithubRepo(url: string): { owner: string; repo: string; branchFromUrl?: string } | null {
  const withoutQueryOrHash = url.trim().split('#')[0].split('?')[0].replace(/\/+$/, '').replace(/\.git$/i, '');
  const treeMatch = withoutQueryOrHash.match(/github\.com\/([^/\s]+)\/([^/\s]+)\/(?:tree|blob)\/([^/\s]+)/i);
  if (treeMatch) {
    return {
      owner: treeMatch[1],
      repo: treeMatch[2].replace(/\.git$/i, ''),
      branchFromUrl: decodeURIComponent(treeMatch[3]),
    };
  }
  const fullMatch = withoutQueryOrHash.match(/github\.com\/([^/\s]+)\/([^/\s]+)/i);
  if (fullMatch) {
    return { owner: fullMatch[1], repo: fullMatch[2].replace(/\.git$/i, '') };
  }
  const shortMatch = withoutQueryOrHash.match(/^([a-zA-Z0-9_.-]+)\/([a-zA-Z0-9_.-]+)$/);
  if (shortMatch) {
    return { owner: shortMatch[1], repo: shortMatch[2].replace(/\.git$/i, '') };
  }
  return null;
}

function parseCookieHeader(rawCookie?: string): Record<string, string> {
  const cookies: Record<string, string> = {};
  if (!rawCookie) return cookies;
  for (const part of rawCookie.split(';')) {
    const eqIdx = part.indexOf('=');
    if (eqIdx <= 0) continue;
    const k = part.slice(0, eqIdx).trim();
    const v = part.slice(eqIdx + 1).trim();
    try {
      cookies[k] = decodeURIComponent(v);
    } catch {
      cookies[k] = v;
    }
  }
  return cookies;
}

async function readRawRequestBody(req: express.Request): Promise<Buffer> {
  const method = req.method.toUpperCase();
  if (method === 'GET' || method === 'HEAD') return Buffer.alloc(0);
  const chunks: Buffer[] = [];
  for await (const chunk of req) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }
  return chunks.length > 0 ? Buffer.concat(chunks) : Buffer.alloc(0);
}

function parsePostBodyForPhp(contentType: string, buf: Buffer): { post: Record<string, any>; rawBody: string } {
  const rawBody = buf.toString('utf-8');
  if (!rawBody) return { post: {}, rawBody: '' };
  const ctLow = contentType.toLowerCase();
  const post: Record<string, any> = {};

  if (ctLow.includes('application/x-www-form-urlencoded')) {
    const params = new URLSearchParams(rawBody);
    params.forEach((val, key) => {
      post[key] = val;
    });
    return { post, rawBody };
  }

  if (ctLow.includes('application/json')) {
    try {
      const parsed = JSON.parse(rawBody);
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        Object.assign(post, parsed);
      }
    } catch {
      // ignore invalid JSON
    }
    return { post, rawBody };
  }

  if (ctLow.includes('multipart/form-data')) {
    const bMatch = contentType.match(/boundary=(?:"([^"]+)"|([^;\s]+))/i);
    if (bMatch) {
      const boundary = bMatch[1] || bMatch[2];
      const parts = rawBody.split(`--${boundary}`);
      for (const part of parts.slice(1)) {
        if (part.startsWith('--')) break;
        const sepIdx = part.indexOf('\r\n\r\n');
        if (sepIdx === -1) continue;
        const hdr = part.slice(0, sepIdx);
        const val = part.slice(sepIdx + 4).replace(/\r\n$/, '');
        const nm = hdr.match(/name="([^"]*)"/i);
        const fnm = hdr.match(/filename="([^"]*)"/i);
        if (nm && !fnm) {
          post[nm[1]] = val;
        }
      }
    }
    return { post, rawBody };
  }

  // Fallback URL-encoded parse if body looks like key=val pairs without explicit Content-Type
  if (rawBody.includes('=') && !rawBody.trim().startsWith('{')) {
    const params = new URLSearchParams(rawBody);
    params.forEach((val, key) => {
      post[key] = val;
    });
  }
  return { post, rawBody };
}

function ensureSitePhpDir(site: HostedSite): string {
  const siteDir = siteRuntime.getSiteRuntimeDir(site.id);
  const markerPath = path.join(siteDir, '.nh_synced_version');
  try {
    if (fs.existsSync(markerPath) && fs.readFileSync(markerPath, 'utf-8') === site.updatedAt) {
      return siteDir;
    }
  } catch {
    // re-materialize
  }
  siteRuntime.materializeSiteFiles(site);
  try {
    fs.writeFileSync(markerPath, site.updatedAt, 'utf-8');
  } catch {
    // ignore
  }
  return siteDir;
}

async function servePhpRequest(
  req: express.Request,
  res: express.Response,
  site: HostedSite,
  phpCode: string,
  scriptName: string,
  mountPrefix = `/site/${site.slug}`
) {
  const siteDir = ensureSitePhpDir(site);
  const bodyBuf = await readRawRequestBody(req);
  const contentType = String(req.headers['content-type'] || '');
  const { post, rawBody } = parsePostBodyForPhp(contentType, bodyBuf);

  const origUrl = req.originalUrl || '';
  const qIdx = origUrl.indexOf('?');
  const rawQuery = qIdx >= 0 ? origUrl.slice(qIdx + 1) : '';
  const getParams: Record<string, any> = {};
  const cleanedParams = new URLSearchParams();
  if (rawQuery) {
    const sp = new URLSearchParams(rawQuery);
    sp.forEach((v, k) => {
      if (k === '_preview') return;
      getParams[k] = v;
      cleanedParams.append(k, v);
    });
  }

  const normalizedHdrs: Record<string, string> = {};
  for (const [hk, hv] of Object.entries(req.headers)) {
    if (!hv) continue;
    normalizedHdrs[hk.toLowerCase()] = Array.isArray(hv) ? hv.join(', ') : String(hv);
  }

  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  const remoteAddr = (forwarded || req.socket.remoteAddress || '127.0.0.1').replace(/^::ffff:/, '');

  const baseDir = scriptName.includes('/')
    ? scriptName.replace(/^\/+/, '').substring(0, scriptName.replace(/^\/+/, '').lastIndexOf('/') + 1)
    : '';

  const phpRes = await executePhpCode(phpCode, {
    method: req.method,
    path: req.path,
    queryString: cleanedParams.toString(),
    get: getParams,
    post,
    rawBody,
    headers: normalizedHdrs,
    cookies: parseCookieHeader(normalizedHdrs['cookie']),
    remoteAddr,
    host: normalizedHdrs['host'] || 'nighthost.local',
    scheme: req.protocol || 'http',
    scriptName: scriptName.startsWith('/') ? scriptName : `/${scriptName}`,
    siteDir,
    siteFiles: site.files,
    siteName: site.name,
  });

  res.status(phpRes.statusCode || 200);

  if (phpRes.cookies.length > 0) {
    const scoped = phpRes.cookies.map(c =>
      mountPrefix ? c.replace(/;\s*Path=\/(?=;|$)/gi, `; Path=${mountPrefix}`) : c
    );
    res.setHeader('Set-Cookie', scoped);
  }

  for (const [hk, hv] of Object.entries(phpRes.headers)) {
    const low = hk.toLowerCase();
    if (low === 'location' && mountPrefix && hv.startsWith('/') && !hv.startsWith('/site/') && !hv.startsWith('/u/') && !hv.startsWith('/d/')) {
      res.setHeader(hk, `${mountPrefix}${hv}`);
      continue;
    }
    res.setHeader(hk, hv);
  }

  const outCt = (phpRes.contentType || '').toLowerCase();
  if (outCt.includes('text/html') || outCt === '') {
    const rewritten = rewriteHtmlForSiteProxy(phpRes.body, site.slug, baseDir, mountPrefix);
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(rewritten);
    return;
  }

  res.send(phpRes.body);
}

function resolveHostHeaderRoute(req: express.Request): { site: HostedSite; subPathRaw: string; mountPrefix: string; label: string } | null {
  const xfHostRaw = String(req.headers['x-forwarded-host'] || '').split(',')[0].trim();
  const rawHost = xfHostRaw || String(req.headers.host || req.hostname || '');
  const host = rawHost.split(':')[0].trim().toLowerCase();
  if (!host || host === 'localhost' || host === '127.0.0.1' || /^\d+\.\d+\.\d+\.\d+$/.test(host)) {
    return null;
  }

  const directSite = siteByDomainCache.get(host);
  if (directSite) {
    return {
      site: directSite,
      subPathRaw: req.path.replace(/^\/+/, ''),
      mountPrefix: '',
      label: host || directSite.customDomain || directSite.slug,
    };
  }

  const primaryDomain = getEnrichedConfig().primaryDomain || DEFAULT_PRIMARY_DOMAIN;
  if (host === primaryDomain || host === `www.${primaryDomain}`) {
    return null;
  }

  const matchesPrimaryWildcard = Boolean(primaryDomain && host.endsWith(`.${primaryDomain}`));
  const labels = host.split('.').filter(Boolean);
  const firstLabel = labels[0] || '';
  if (!firstLabel || isReservedSubdomain(firstLabel)) {
    return null;
  }

  // Only treat multi-label unknown hosts (e.g. foo.onrender.com vs foo.nighthostcloud.dpdns.org) safely
  const isWildcardCandidate =
    matchesPrimaryWildcard ||
    (labels.length >= 3 && !host.endsWith('.onrender.com') && !host.endsWith('.vercel.app') && !host.endsWith('.hf.space'));

  if (!isWildcardCandidate) return null;

  // 1) Direct user subdomain: <ownerSubdomain>.nighthostcloud.dpdns.org[/<slug>/...]
  const matchedOwner = db.users.find(u => u.subdomain?.toLowerCase() === firstLabel);
  if (matchedOwner) {
    const cleanPath = req.path.replace(/^\/+/, '');
    const [firstSeg, ...restSegs] = cleanPath.split('/');
    if (firstSeg) {
      const matchedSite = db.sites.find(
        s =>
          s.userId === matchedOwner.id &&
          (s.slug.toLowerCase() === firstSeg.toLowerCase() || s.customPath?.toLowerCase() === firstSeg.toLowerCase())
      );
      if (matchedSite) {
        return {
          site: matchedSite,
          subPathRaw: restSegs.join('/'),
          mountPrefix: `/${matchedSite.slug}`,
          label: `${host}/${matchedSite.slug}`,
        };
      }
    }

    // Root path (or SPA route under root) on <owner>.nighthostcloud.dpdns.org -> owner's first online site
    const primarySite =
      db.sites.find(s => s.userId === matchedOwner.id && s.status === 'online') ||
      db.sites.find(s => s.userId === matchedOwner.id);
    if (primarySite) {
      return {
        site: primarySite,
        subPathRaw: cleanPath,
        mountPrefix: '',
        label: host,
      };
    }
  }

  // 2) Cloudflare Free Universal SSL 1-level site subdomain: <slug>-<ownerSubdomain>.nighthostcloud.dpdns.org
  const matchingSiteByCombined = db.sites.find(s => {
    const owner = db.users.find(u => u.id === s.userId);
    const ownerSub = owner?.subdomain || s.ownerSubdomain || '';
    if (!ownerSub) return false;
    const expectedCombined = `${s.slug}-${ownerSub}`.toLowerCase().slice(0, 62);
    return expectedCombined === firstLabel || `${s.slug}`.toLowerCase() === firstLabel;
  });

  if (matchingSiteByCombined) {
    return {
      site: matchingSiteByCombined,
      subPathRaw: req.path.replace(/^\/+/, ''),
      mountPrefix: '',
      label: host,
    };
  }

  return null;
}

function sendStaticPayloadWithCompression(
  req: express.Request,
  res: express.Response,
  payload: string | Buffer,
  mimeType: string,
  etag?: string,
  cacheControl?: string
) {
  const buf = Buffer.isBuffer(payload) ? payload : Buffer.from(payload, 'utf-8');
  res.setHeader('Content-Type', mimeType);
  if (etag) res.setHeader('ETag', etag);
  if (cacheControl) res.setHeader('Cache-Control', cacheControl);

  const acceptEnc = String(req.headers['accept-encoding'] || '').toLowerCase();
  const compressible = /^(text\/|application\/(javascript|json|xml|svg\+xml))|svg/i.test(mimeType);
  if (compressible && acceptEnc.includes('gzip') && buf.length >= 512) {
    const gz = zlib.gzipSync(buf, { level: 6 });
    res.setHeader('Content-Encoding', 'gzip');
    res.setHeader('Vary', 'Accept-Encoding');
    res.send(gz);
    return;
  }
  res.send(buf);
}

async function startServer() {
  const app = express();
  app.set('trust proxy', 1);
  app.disable('x-powered-by');
  const portArgIdx = process.argv.indexOf('--port');
  const cliPort = portArgIdx !== -1 ? Number(process.argv[portArgIdx + 1]) : NaN;
  const port = Number.isFinite(cliPort) && cliPort > 0 ? cliPort : Number(process.env.PORT) || 3000;

  // Hardened HTTP security headers & sensitive path protection (anti-dump / anti-traversal)
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    if (!req.path.startsWith('/site/') && !req.path.startsWith('/u/') && !req.path.startsWith('/d/')) {
      res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    }
    const lowPath = req.path.toLowerCase();
    if (
      lowPath === '/data' ||
      lowPath.startsWith('/data/') ||
      lowPath.startsWith('/.env') ||
      lowPath.startsWith('/.git') ||
      lowPath === '/server.ts'
    ) {
      res.status(403).json({ success: false, message: 'Access denied' });
      return;
    }
    next();
  });

  app.use((req, res, next) => {
    if (
      req.path.startsWith('/site/') ||
      req.path.startsWith('/u/') ||
      req.path.startsWith('/d/') ||
      resolveHostHeaderRoute(req)
    ) {
      return next();
    }
    return express.json({ limit: '100mb' })(req, res, next);
  });
  app.use((req, res, next) => {
    if (
      req.path.startsWith('/site/') ||
      req.path.startsWith('/u/') ||
      req.path.startsWith('/d/') ||
      resolveHostHeaderRoute(req)
    ) {
      return next();
    }
    return express.urlencoded({ extended: true, limit: '100mb' })(req, res, next);
  });

  // Prototype-pollution sanitizer for all control-plane JSON/form requests
  const stripDangerousKeysDeep = (val: unknown, depth = 0): void => {
    if (!val || typeof val !== 'object' || depth > 8) return;
    if (Array.isArray(val)) {
      for (const item of val) stripDangerousKeysDeep(item, depth + 1);
      return;
    }
    const rec = val as Record<string, unknown>;
    if (Object.prototype.hasOwnProperty.call(rec, '__proto__')) Reflect.deleteProperty(rec, '__proto__');
    if (Object.prototype.hasOwnProperty.call(rec, 'constructor')) Reflect.deleteProperty(rec, 'constructor');
    if (Object.prototype.hasOwnProperty.call(rec, 'prototype')) Reflect.deleteProperty(rec, 'prototype');
    for (const k of Object.keys(rec)) {
      if (k === '__proto__' || k === 'constructor' || k === 'prototype') {
        Reflect.deleteProperty(rec, k);
      } else {
        stripDangerousKeysDeep(rec[k], depth + 1);
      }
    }
  };
  app.use((req, _res, next) => {
    if (req.body && typeof req.body === 'object') {
      stripDangerousKeysDeep(req.body);
    }
    next();
  });

  // Fast gzip compression for heavy JSON API responses on slow mobile data connections
  app.use((req, res, next) => {
    if (
      req.path === '/api/bootstrap' ||
      req.path === '/api/github/import' ||
      req.path === '/api/sites' ||
      req.path.startsWith('/api/admin/')
    ) {
      const acceptEnc = String(req.headers['accept-encoding'] || '').toLowerCase();
      if (acceptEnc.includes('gzip')) {
        const origJson = res.json.bind(res);
        res.json = ((body: unknown) => {
          const serialized = JSON.stringify(body);
          if (serialized && serialized.length >= 1024 && !res.headersSent) {
            const gz = zlib.gzipSync(Buffer.from(serialized, 'utf-8'), { level: 6 });
            res.setHeader('Content-Type', 'application/json; charset=utf-8');
            res.setHeader('Content-Encoding', 'gzip');
            res.setHeader('Vary', 'Accept-Encoding');
            return res.send(gz);
          }
          return origJson(body);
        }) as express.Response['json'];
      }
    }
    next();
  });

  // Health Check
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      service: `${db.config.brandName} Engine`,
    });
  });

  // Scoped Bootstrap State (prevents unauthenticated DB dumps)
  app.get('/api/bootstrap', (req, res) => {
    const viewer = getRequestViewer(req);
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.json(buildScopedBootstrapPayload(viewer));
  });

  // Real-time Server-Sent Events (SSE) stream scoped strictly to viewer session
  app.get('/api/events', (req, res) => {
    const viewer = getRequestViewer(req);
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    const entry: SseClientEntry = { res, userId: viewer?.id || null };
    res.write(`data: ${JSON.stringify({ type: 'sync', payload: buildScopedBootstrapPayload(viewer) })}\n\n`);
    sseClients.add(entry);

    const heartbeat = setInterval(() => {
      try {
        res.write(': ping\n\n');
      } catch {
        clearInterval(heartbeat);
        sseClients.delete(entry);
      }
    }, 15000);
    heartbeat.unref?.();

    req.on('close', () => {
      clearInterval(heartbeat);
      sseClients.delete(entry);
    });
  });

  // Public support contacts (Owner + active non-deleted Admins, emails masked)
  app.get('/api/public/contacts', (_req, res) => {
    res.json({
      config: getEnrichedConfig(),
      activeSubAdmins: enrichSubAdmins(db.subAdmins)
        .filter(s => s.active)
        .map(s => ({ ...s, email: '' })),
    });
  });

  // Restore Session Cookie
  app.get('/api/auth/me', (req, res) => {
    const cookies = parseCookieHeader(req.headers.cookie);
    if (!cookies.nighthost_session) {
      res.json({ success: true, user: null });
      return;
    }
    const matched = getRequestViewer(req);
    if (!matched) {
      clearSessionCookie(req, res);
      res.json({ success: true, user: null });
      return;
    }
    res.json({ success: true, user: sanitizeUser(matched) });
  });

  // Logout & Clear Session Cookie
  app.post('/api/auth/logout', (req, res) => {
    clearSessionCookie(req, res);
    res.json({ success: true });
  });

  // One-Time Owner Initialization Status & Creation (when no Owner exists)
  app.get('/api/auth/setup-status', (_req, res) => {
    res.json({ success: true, needsOwnerSetup: needsOwnerSetup() });
  });

  app.post('/api/auth/setup-owner', (req, res) => {
    const ip = String(req.ip || req.socket.remoteAddress || 'unknown');
    if (!checkAuthRateLimit(`setup-owner:${ip}`, 10)) {
      res.status(429).json({
        success: false,
        message: 'অনেকবার চেষ্টা করা হয়েছে! ৫ মিনিট পর আবার চেষ্টা করুন।',
      });
      return;
    }
    if (!needsOwnerSetup()) {
      res.status(409).json({
        success: false,
        message: 'প্ল্যাটফর্ম মালিক ইতিমধ্যে সেটআপ করা আছে। অনুগ্রহ করে লগইন করুন।',
      });
      return;
    }

    const { username, fullName, email, password } = req.body || {};
    const cleanUsername = String(username || '').trim().toLowerCase().replace(/[^a-z0-9_.-]/g, '');
    const cleanName = String(fullName || '').trim() || cleanUsername;
    const cleanEmail = String(email || '').trim().toLowerCase();
    const cleanPass = String(password || '').trim();

    if (cleanUsername.length < 3 || !cleanEmail.includes('@') || cleanPass.length < 4) {
      res.status(400).json({
        success: false,
        message: 'কমপক্ষে ৩ অক্ষরের ইউজারনেম, সঠিক ইমেইল এবং কমপক্ষে ৪ অক্ষরের পাসওয়ার্ড দিন।',
      });
      return;
    }
    if (db.users.some(u => u.username.toLowerCase() === cleanUsername)) {
      res.status(409).json({
        success: false,
        message: `ইউজারনেম '${cleanUsername}' ইতিমধ্যে ব্যবহৃত।`,
      });
      return;
    }

    const ownerUser: User = {
      id: 'user_owner_' + Math.random().toString(36).substring(2, 8),
      username: cleanUsername,
      fullName: cleanName,
      email: cleanEmail,
      password: hashPassword(cleanPass),
      role: 'admin',
      status: 'approved',
      storageLimitMb: 5000,
      storageUsedMb: 0,
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      approvalDurationLabel: 'স্থায়ী (Permanent)',
    };

    db.users.unshift(ownerUser);
    db.config.masterAdminName = cleanName;
    addLog({
      actor: cleanUsername,
      action: 'OWNER_INITIALIZED',
      target: cleanUsername,
      details: 'Initialized initial Platform Owner credentials via secure setup.',
      category: 'config',
    });
    saveDb(db);
    setSessionCookie(req, res, ownerUser.id);
    res.json({
      success: true,
      user: sanitizeUser(ownerUser),
      ...buildScopedBootstrapPayload(ownerUser),
    });
  });

  // Regular User Login
  app.post('/api/auth/login', (req, res) => {
    const ip = String(req.ip || req.socket.remoteAddress || 'unknown');
    if (!checkAuthRateLimit(`login:${ip}`, 25)) {
      res.status(429).json({
        success: false,
        message: 'অনেকবার ভুল চেষ্টা করা হয়েছে! ৫ মিনিট পর আবার চেষ্টা করুন।',
      });
      return;
    }

    const { username, password } = req.body || {};
    const clean = String(username || '').trim().toLowerCase();
    const pass = String(password || '').trim();

    if (!clean || !pass) {
      res.status(400).json({ success: false, message: 'ইউজারনেম এবং পাসওয়ার্ড উভয়ই দিন।' });
      return;
    }

    const matched = db.users.find(
      u => u.username.toLowerCase() === clean || u.email.toLowerCase() === clean
    );

    if (!matched) {
      res.status(404).json({
        success: false,
        code: 'NOT_FOUND',
        message: 'ইউজার খুঁজে পাওয়া যায়নি! সঠিক ইউজারনেম দিন অথবা নতুন অ্যাকাউন্ট খুলুন।',
      });
      return;
    }

    if (!verifyPassword(pass, matched.password)) {
      res.status(401).json({
        success: false,
        code: 'WRONG_PASSWORD',
        message: 'ভুল পাসওয়ার্ড! সঠিক পাসওয়ার্ড দিয়ে চেষ্টা করুন।',
      });
      return;
    }

    if (!isHashedPassword(matched.password)) {
      matched.password = hashPassword(pass);
    }

    if (matched.status === 'pending') {
      res.status(403).json({
        success: false,
        code: 'PENDING',
        message: 'আপনার অ্যাকাউন্ট অনুমোদন পেন্ডিং রয়েছে।',
        activeSubAdmins: enrichSubAdmins(db.subAdmins).filter(s => s.active).map(s => ({ ...s, email: '' })),
        config: getEnrichedConfig(),
      });
      return;
    }

    if (matched.status === 'suspended') {
      res.status(403).json({
        success: false,
        code: 'SUSPENDED',
        message: 'আপনার অ্যাকাউন্ট সাময়িকভাবে স্থগিত (Suspended) করা হয়েছে।',
        activeSubAdmins: enrichSubAdmins(db.subAdmins).filter(s => s.active).map(s => ({ ...s, email: '' })),
        config: getEnrichedConfig(),
      });
      return;
    }

    if (isUserExpired(matched)) {
      res.status(403).json({
        success: false,
        code: 'EXPIRED',
        message: 'আপনার অ্যাকাউন্টের মেয়াদ শেষ হয়েছে। অনুগ্রহ করে অ্যাডমিনের সাথে যোগাযোগ করুন।',
        activeSubAdmins: enrichSubAdmins(db.subAdmins).filter(s => s.active).map(s => ({ ...s, email: '' })),
        config: getEnrichedConfig(),
      });
      return;
    }

    matched.lastLoginAt = new Date().toISOString();
    recalculateUserStorageMb(matched.id);
    scheduleBackgroundSaveDb(db);
    setSessionCookie(req, res, matched.id);
    res.json({ success: true, user: sanitizeUser(matched), ...buildScopedBootstrapPayload(matched) });
  });

  // Owner & Admin Login
  app.post('/api/auth/admin-login', (req, res) => {
    const ip = String(req.ip || req.socket.remoteAddress || 'unknown');
    if (!checkAuthRateLimit(`admin-login:${ip}`, 20)) {
      res.status(429).json({
        success: false,
        message: 'অনেকবার ভুল চেষ্টা করা হয়েছে! ৫ মিনিট পর আবার চেষ্টা করুন।',
      });
      return;
    }

    const { role, username, password } = req.body || {};
    const clean = String(username || '').trim().toLowerCase();
    const pass = String(password || '').trim();

    const matched = db.users.find(
      u => u.username.toLowerCase() === clean && (u.role === 'admin' || u.role === 'subadmin')
    );

    if (!matched) {
      res.status(404).json({ success: false, message: 'অ্যাডমিন অ্যাকাউন্ট খুঁজে পাওয়া যায়নি!' });
      return;
    }

    if (role && matched.role !== role) {
      const actualLabel = matched.role === 'admin' ? 'OWNER' : 'ADMIN';
      const reqLabel = role === 'admin' ? 'OWNER' : 'ADMIN';
      res.status(403).json({
        success: false,
        message: `অ্যাকাউন্টটির ভূমিকা '${actualLabel}', কিন্তু আপনি '${reqLabel}' হিসেবে লগইন করতে চেয়েছেন।`,
      });
      return;
    }

    if (matched.status === 'suspended') {
      res.status(403).json({ success: false, message: 'এই অ্যাডমিন অ্যাকাউন্টটি সাসপেন্ড রয়েছে।' });
      return;
    }

    if (!verifyPassword(pass, matched.password)) {
      res.status(401).json({ success: false, message: 'ভুল পাসওয়ার্ড! সঠিক পাসওয়ার্ড দিন।' });
      return;
    }

    if (!isHashedPassword(matched.password)) {
      matched.password = hashPassword(pass);
    }

    matched.lastLoginAt = new Date().toISOString();
    recalculateUserStorageMb(matched.id);
    scheduleBackgroundSaveDb(db);
    setSessionCookie(req, res, matched.id);
    res.json({ success: true, user: sanitizeUser(matched), ...buildScopedBootstrapPayload(matched) });
  });

  // Register New User
  app.post('/api/auth/register', (req, res) => {
    const ip = String(req.ip || req.socket.remoteAddress || 'unknown');
    if (!checkAuthRateLimit(`register:${ip}`, 15)) {
      res.status(429).json({
        success: false,
        message: 'অনেকগুলো রেজিস্ট্রেশন রিকোয়েস্ট পাঠানো হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।',
      });
      return;
    }

    if (db.config.allowRegistration === false) {
      res.status(403).json({
        success: false,
        message: 'বর্তমানে নতুন অ্যাকাউন্ট রেজিস্ট্রেশন সাময়িকভাবে বন্ধ রাখা হয়েছে।',
      });
      return;
    }

    const { username, fullName, email, password } = req.body || {};
    const cleanUsername = String(username || '').trim().toLowerCase().replace(/[^a-z0-9_.-]/g, '');
    const cleanName = String(fullName || '').trim();
    const cleanEmail = String(email || '').trim().toLowerCase();
    const cleanPass = String(password || '').trim();

    if (!cleanUsername || !cleanName || !cleanEmail || cleanPass.length < 4) {
      res.status(400).json({
        success: false,
        message: 'সঠিক নাম, ইউজারনেম, ইমেইল এবং কমপক্ষে ৪ অক্ষরের পাসওয়ার্ড দিন।',
      });
      return;
    }

    if (db.users.some(u => u.username.toLowerCase() === cleanUsername)) {
      res.status(409).json({
        success: false,
        message: `ইউজারনেম '${cleanUsername}' ইতিমধ্যে ব্যবহৃত। অন্য নাম নির্বাচন করুন।`,
      });
      return;
    }

    const newUser: User = {
      id: 'user_' + Math.random().toString(36).substring(2, 9),
      username: cleanUsername,
      fullName: cleanName,
      email: cleanEmail,
      password: hashPassword(cleanPass),
      role: 'user',
      status: 'pending',
      storageLimitMb: db.config.defaultStorageMb || 100,
      storageUsedMb: 0,
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
    };

    db.users.push(newUser);
    addLog({
      actor: cleanUsername,
      action: 'USER_REGISTERED',
      target: cleanUsername,
      details: `New registration pending approval (${cleanEmail}).`,
      category: 'user',
    });
    saveDb(db);

    res.json({
      success: true,
      message: 'রেজিস্ট্রেশন সম্পন্ন হয়েছে! অনুমোদনের জন্য টেলিগ্রামে যোগাযোগ করুন।',
      user: sanitizeUser(newUser),
      activeSubAdmins: enrichSubAdmins(db.subAdmins).filter(s => s.active).map(s => ({ ...s, email: '' })),
      config: getEnrichedConfig(),
    });
  });

  // Live Pending Approval Status Check (for instant AuthModal unlock after admin approves)
  app.get('/api/auth/pending-status', (req, res) => {
    const clean = String(req.query.username || '').trim().toLowerCase();
    if (!clean || clean.length < 2) {
      res.status(400).json({ success: false, status: 'not_found' });
      return;
    }
    const matched = db.users.find(
      u => u.username.toLowerCase() === clean || u.email.toLowerCase() === clean
    );
    if (!matched) {
      res.json({ success: true, status: 'not_found' });
      return;
    }
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      success: true,
      status: matched.status,
      approvalDurationLabel: matched.approvalDurationLabel,
      storageLimitMb: matched.storageLimitMb,
    });
  });

  // Admin: Approve User
  app.post('/api/admin/users/:id/approve', (req, res) => {
    const auth = requireAdminOrSubadmin(req, res);
    if (!auth) return;
    if (!auth.perms.canApproveUsers) {
      res.status(403).json({ success: false, message: 'আপনার ইউজার অ্যাপ্রুভ করার অনুমতি নেই।' });
      return;
    }

    const { id } = req.params;
    const { durationHours = -1, durationLabel = 'স্থায়ী (Permanent)', quotaMb } = req.body || {};
    const user = db.users.find(u => u.id === id);
    if (!user || user.role !== 'user') {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    user.status = 'approved';
    user.approvedAt = new Date().toISOString();
    user.approvedBy = auth.viewer.username;
    user.approvedByRole = auth.viewer.role === 'admin' ? 'admin' : 'subadmin';
    user.approvalDurationLabel = durationLabel;
    if (Number(durationHours) > 0) {
      user.expiresAt = new Date(Date.now() + Number(durationHours) * 3600 * 1000).toISOString();
    } else {
      delete user.expiresAt;
    }
    if (quotaMb !== undefined && (auth.perms.isOwner || auth.perms.canSetQuota)) {
      user.storageLimitMb = Math.max(10, Number(quotaMb) || 100);
    }

    addLog({
      actor: auth.viewer.username,
      action: 'USER_APPROVED',
      target: user.username,
      details: `Approved for ${durationLabel} (${user.storageLimitMb} MB)`,
      category: 'user',
    });
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(auth.viewer) });
  });

  // Admin: Bulk Approve All Pending Users
  app.post('/api/admin/users/approve-all-pending', (req, res) => {
    const auth = requireAdminOrSubadmin(req, res);
    if (!auth) return;
    if (!auth.perms.canApproveUsers) {
      res.status(403).json({ success: false, message: 'আপনার ইউজার অ্যাপ্রুভ করার অনুমতি নেই।' });
      return;
    }

    const { durationHours = 24, durationLabel = '২৪ ঘন্টা (1 Day)', quotaMb } = req.body || {};
    const pendingUsers = db.users.filter(u => u.role === 'user' && u.status === 'pending');
    if (pendingUsers.length === 0) {
      res.json({ success: true, approvedCount: 0, ...buildScopedBootstrapPayload(auth.viewer) });
      return;
    }

    const nowIso = new Date().toISOString();
    for (const user of pendingUsers) {
      user.status = 'approved';
      user.approvedAt = nowIso;
      user.approvedBy = auth.viewer.username;
      user.approvedByRole = auth.viewer.role === 'admin' ? 'admin' : 'subadmin';
      user.approvalDurationLabel = durationLabel;
      if (Number(durationHours) > 0) {
        user.expiresAt = new Date(Date.now() + Number(durationHours) * 3600 * 1000).toISOString();
      } else {
        delete user.expiresAt;
      }
      if (quotaMb !== undefined && (auth.perms.isOwner || auth.perms.canSetQuota)) {
        user.storageLimitMb = Math.max(10, Number(quotaMb) || 100);
      }
    }

    addLog({
      actor: auth.viewer.username,
      action: 'BULK_USERS_APPROVED',
      target: `${pendingUsers.length} Pending Users`,
      details: `Batch approved ${pendingUsers.length} pending accounts for ${durationLabel}.`,
      category: 'user',
    });
    saveDb(db);
    res.json({ success: true, approvedCount: pendingUsers.length, ...buildScopedBootstrapPayload(auth.viewer) });
  });

  // Admin: Suspend User
  app.post('/api/admin/users/:id/suspend', (req, res) => {
    const auth = requireAdminOrSubadmin(req, res);
    if (!auth) return;

    const { id } = req.params;
    const user = db.users.find(u => u.id === id);
    if (!user || user.role === 'admin' || (!auth.perms.isOwner && user.role !== 'user')) {
      res.status(403).json({ success: false, message: 'এই অ্যাকাউন্ট সাসপেন্ড করার অনুমতি নেই।' });
      return;
    }

    user.status = 'suspended';
    if (user.role === 'subadmin') {
      const sub = db.subAdmins.find(s => s.id === user.id || s.username === user.username);
      if (sub) sub.active = false;
    }
    addLog({
      actor: auth.viewer.username,
      action: 'USER_SUSPENDED',
      target: user.username,
      details: 'User access suspended.',
      category: 'user',
    });
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(auth.viewer) });
  });

  // Admin: Unsuspend User (keeps all files & sites intact)
  app.post('/api/admin/users/:id/unsuspend', (req, res) => {
    const auth = requireAdminOrSubadmin(req, res);
    if (!auth) return;

    const { id } = req.params;
    const user = db.users.find(u => u.id === id);
    if (!user || user.role === 'admin' || (!auth.perms.isOwner && user.role !== 'user')) {
      res.status(403).json({ success: false, message: 'এই অ্যাকাউন্ট আনসাসপেন্ড করার অনুমতি নেই।' });
      return;
    }

    user.status = 'approved';
    if (user.expiresAt && new Date(user.expiresAt).getTime() <= Date.now()) {
      delete user.expiresAt;
      user.approvalDurationLabel = 'রিনিউ / স্থায়ী';
    }
    if (user.role === 'subadmin') {
      const sub = db.subAdmins.find(s => s.id === user.id || s.username === user.username);
      if (sub) sub.active = true;
    }
    addLog({
      actor: auth.viewer.username,
      action: 'USER_UNSUSPENDED',
      target: user.username,
      details: 'User access restored cleanly with all files preserved.',
      category: 'user',
    });
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(auth.viewer) });
  });

  // Self Subdomain Check
  app.get('/api/user/subdomain/check', (req, res) => {
    const viewer = requireAuth(req, res);
    if (!viewer) return;
    const raw = String(req.query.subdomain || '');
    const normalized = normalizeUserSubdomain(raw);
    if (!normalized || normalized.length < 3) {
      res.json({
        success: true,
        available: false,
        normalized,
        message: 'সাবডোমেইন কমপক্ষে ৩ অক্ষরের (a-z, 0-9, -) হতে হবে।',
      });
      return;
    }
    if (isReservedSubdomain(normalized)) {
      res.json({
        success: true,
        available: false,
        normalized,
        message: `'${normalized}' সিস্টেম রিজার্ভড নাম! অন্য সাবডোমেইন বেছে নিন।`,
      });
      return;
    }
    const taken = db.users.some(
      u => u.id !== viewer.id && u.subdomain && u.subdomain.toLowerCase() === normalized
    );
    res.json({
      success: true,
      available: !taken,
      normalized,
      message: taken ? `'${normalized}' ইতিমধ্যে ব্যবহৃত! অন্য নাম দিন।` : `'${normalized}' ব্যবহারের জন্য ফ্রি আছে!`,
    });
  });

  // Self Subdomain Onboarding / Update
  app.put('/api/user/subdomain', (req, res) => {
    const viewer = requireAuth(req, res);
    if (!viewer) return;
    const normalized = normalizeUserSubdomain(String(req.body?.subdomain || ''));
    if (!normalized || normalized.length < 3) {
      res.status(400).json({
        success: false,
        message: 'সাবডোমেইন কমপক্ষে ৩ অক্ষরের (ইংরেজি ছোট হাতের অক্ষর, সংখ্যা বা হাইফেন) হতে হবে।',
      });
      return;
    }
    if (isReservedSubdomain(normalized)) {
      res.status(400).json({
        success: false,
        message: `'${normalized}' সিস্টেম রিজার্ভড সাবডোমেইন। অন্য একটি বেছে নিন।`,
      });
      return;
    }
    if (db.users.some(u => u.id !== viewer.id && u.subdomain?.toLowerCase() === normalized)) {
      res.status(409).json({
        success: false,
        message: `সাবডোমেইন '${normalized}' ইতিমধ্যে অন্য অ্যাকাউন্টে ব্যবহৃত!`,
      });
      return;
    }

    viewer.subdomain = normalized;
    for (const s of db.sites) {
      if (s.userId === viewer.id) {
        s.ownerSubdomain = normalized;
      }
    }

    addLog({
      actor: viewer.username,
      action: 'SUBDOMAIN_CLAIMED',
      target: `/u/${normalized}`,
      details: `Personal subdomain set to '${normalized}'.`,
      category: 'user',
    });
    saveDb(db);
    res.json({
      success: true,
      user: sanitizeUser(viewer),
      message: `আপনার নিজস্ব সাবডোমেইন '/u/${normalized}/' সেট হয়েছে!`,
      ...buildScopedBootstrapPayload(viewer),
    });
  });

  // Self Profile & Avatar Update (Authenticated user updates own record only)
  app.put('/api/profile', (req, res) => {
    const current = requireAuth(req, res);
    if (!current) return;

    const { fullName, email, password, avatarDataUrl } = req.body || {};

    if (typeof fullName === 'string' && fullName.trim()) {
      current.fullName = fullName.trim();
    }
    if (typeof email === 'string' && email.trim()) {
      current.email = email.trim().toLowerCase();
    }
    if (typeof password === 'string' && password.trim()) {
      if (password.trim().length < 4) {
        res.status(400).json({ success: false, message: 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।' });
        return;
      }
      current.password = hashPassword(password.trim());
    }
    if (avatarDataUrl !== undefined) {
      const avRes = applyAvatarUpdate(current, avatarDataUrl);
      if (!avRes.ok) {
        res.status(400).json({ success: false, message: avRes.error || 'ছবি আপডেট করা যায়নি।' });
        return;
      }
    }
    recalculateUserStorageMb(current.id);

    if (current.role === 'subadmin') {
      const sub = db.subAdmins.find(s => s.id === current.id || s.username === current.username);
      if (sub) {
        sub.displayName = current.fullName;
        sub.email = current.email;
        sub.lastActive = new Date().toISOString();
      }
    }

    addLog({
      actor: current.username,
      action: 'PROFILE_UPDATED',
      target: current.username,
      details: 'Updated personal profile/avatar.',
      category: 'user',
    });
    saveDb(db);
    res.json({ success: true, user: sanitizeUser(current), ...buildScopedBootstrapPayload(current) });
  });

  // Owner / Admin: Update Own Profile & Credentials
  app.put('/api/admin/profile', (req, res) => {
    const auth = requireAdminOrSubadmin(req, res);
    if (!auth) return;
    const current = auth.viewer;
    const { username, fullName, email, password, avatarDataUrl } = req.body || {};

    const oldUsername = current.username;
    if (typeof username === 'string' && username.trim()) {
      const nextUsername = username.trim().toLowerCase().replace(/[^a-z0-9_.-]/g, '');
      if (nextUsername.length < 3) {
        res.status(400).json({ success: false, message: 'ইউজারনেম কমপক্ষে ৩ অক্ষরের হতে হবে।' });
        return;
      }
      if (
        db.users.some(u => u.id !== current.id && u.username.toLowerCase() === nextUsername)
      ) {
        res.status(409).json({ success: false, message: `ইউজারনেম '${nextUsername}' ইতিমধ্যে ব্যবহৃত!` });
        return;
      }
      current.username = nextUsername;
    }

    if (typeof fullName === 'string' && fullName.trim()) {
      current.fullName = fullName.trim();
    }
    if (typeof email === 'string' && email.trim()) {
      current.email = email.trim().toLowerCase();
    }
    if (typeof password === 'string' && password.trim()) {
      if (password.trim().length < 4) {
        res.status(400).json({ success: false, message: 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।' });
        return;
      }
      current.password = hashPassword(password.trim());
    }
    if (avatarDataUrl !== undefined) {
      const avRes = applyAvatarUpdate(current, avatarDataUrl);
      if (!avRes.ok) {
        res.status(400).json({ success: false, message: avRes.error || 'ছবি আপডেট করা যায়নি।' });
        return;
      }
    }
    recalculateUserStorageMb(current.id);

    if (current.role === 'subadmin') {
      const sub = db.subAdmins.find(s => s.id === current.id || s.username === oldUsername);
      if (sub) {
        sub.username = current.username;
        sub.displayName = current.fullName;
        sub.email = current.email;
        sub.lastActive = new Date().toISOString();
      }
    }

    if (oldUsername !== current.username) {
      for (const s of db.sites) {
        if (s.userId === current.id) s.username = current.username;
      }
    }

    addLog({
      actor: current.username,
      action: 'ADMIN_PROFILE_UPDATED',
      target: current.username,
      details: 'Updated administrator profile, avatar, and credentials.',
      category: 'config',
    });
    saveDb(db);
    res.json({ success: true, user: sanitizeUser(current), ...buildScopedBootstrapPayload(current) });
  });

  // Admin: Server Storage Pool & Multi-Cloud (B2 + Supabase) Telemetry
  app.get('/api/admin/server-storage', (req, res) => {
    const auth = requireAdminOrSubadmin(req, res);
    if (!auth) return;
    const stats = computeServerStorageStats();
    res.json({
      success: true,
      serverStorage: auth.perms.isOwner ? stats : { ...stats, supabaseNodes: [], b2Nodes: [] },
    });
  });

  // Owner-Only: Combined Render Environment Variables + Cloudflare Worker Template
  app.get('/api/admin/cloudflare-worker', (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;
    const cfg = getEnrichedConfig();
    const rawHost = String(req.headers['x-forwarded-host'] || req.headers.host || '')
      .split(',')[0]
      .split(':')[0]
      .trim();
    const primaryDomain = cfg.primaryDomain || DEFAULT_PRIMARY_DOMAIN;
    const isLocalOrPrimary =
      !rawHost ||
      /^(localhost|127\.0\.0\.1|0\.0\.0\.0)$/i.test(rawHost) ||
      rawHost.toLowerCase() === primaryDomain.toLowerCase() ||
      rawHost.toLowerCase().endsWith(`.${primaryDomain.toLowerCase()}`);
    const renderHost = isLocalOrPrimary ? 'YOUR-APP-NAME.onrender.com' : rawHost;
    let workerCode = '';
    try {
      const workerPath = path.join(__dirname, 'cloudflare-worker.js');
      if (fs.existsSync(workerPath)) {
        workerCode = fs.readFileSync(workerPath, 'utf-8').replace('YOUR-APP-NAME.onrender.com', renderHost);
      }
    } catch {
      // ignore missing file
    }
    res.json({
      success: true,
      primaryDomain,
      renderHost,
      routes: [`${primaryDomain}/*`, `*.${primaryDomain}/*`],
      workerCode,
    });
  });

  // Owner-Only: Add & Verify Backblaze B2 Storage Pool Node
  app.post('/api/admin/storage/b2', async (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const {
      label = 'Backblaze B2 Cloud',
      keyId = '',
      applicationKey = '',
      bucketName = 'nighthost-cloud',
      quotaMb = 10240,
    } = req.body || {};

    const cleanKeyId = String(keyId || '').trim();
    const cleanAppKey = String(applicationKey || '').trim();
    const cleanBucket = normalizeB2BucketName(String(bucketName || 'nighthost-cloud'));
    const numericQuota = Math.max(100, Math.min(10485760, Number(quotaMb) || 10240));

    const verify = await verifyAndEnsureB2Bucket(cleanKeyId, cleanAppKey, cleanBucket);
    if (!verify.ok) {
      res.status(400).json({ success: false, message: verify.error || 'Backblaze B2 সংযোগ যাচাই করা যায়নি।' });
      return;
    }

    const usedMb = (await fetchB2BucketUsageMb(cleanKeyId, cleanAppKey, cleanBucket)) ?? 0;

    if (!Array.isArray(db.b2Nodes)) db.b2Nodes = [];
    const existingIdx = db.b2Nodes.findIndex(
      n => n.keyId.toLowerCase() === cleanKeyId.toLowerCase() && n.bucketName.toLowerCase() === cleanBucket.toLowerCase()
    );

    const newNode: B2PoolNode = {
      id: existingIdx >= 0 ? db.b2Nodes[existingIdx].id : 'b2_' + Math.random().toString(36).substring(2, 9),
      label: String(label || '').trim() || `Backblaze B2 (${cleanBucket})`,
      keyId: cleanKeyId,
      applicationKey: cleanAppKey,
      bucketName: cleanBucket,
      quotaMb: numericQuota,
      usedMb,
      status: 'connected',
      source: 'manual',
      lastCheckedAt: new Date().toISOString(),
    };

    if (existingIdx >= 0) {
      db.b2Nodes[existingIdx] = newNode;
    } else {
      db.b2Nodes.push(newNode);
    }

    addLog({
      actor: owner.username,
      action: 'B2_NODE_ADDED',
      target: newNode.label,
      details: `Connected Backblaze B2 Storage bucket (${cleanBucket}, ${numericQuota} MB).`,
      category: 'config',
    });
    invalidateBootstrapCache();
    saveDb(db);

    res.json({
      success: true,
      node: sanitizeB2NodeForClient(newNode),
      renderEnv: generateCombinedRenderEnvVariables(
        getAllMergedSupabaseNodes(),
        getAllMergedB2Nodes(),
        getEnrichedConfig().primaryDomain,
        true
      ),
      ...buildScopedBootstrapPayload(owner),
    });
  });

  // Owner-Only: Verify Existing Backblaze B2 Node
  app.post('/api/admin/storage/b2/:id/verify', async (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const { id } = req.params;
    const manualNode = (db.b2Nodes || []).find(n => n.id === id);
    const envNode = parseB2EnvNodes(process.env).find(n => n.id === id);
    const target = manualNode || envNode;
    if (!target || !target.applicationKey) {
      res.status(404).json({ success: false, message: 'Backblaze B2 নোড খুঁজে পাওয়া যায়নি।' });
      return;
    }

    const check = await verifyAndEnsureB2Bucket(target.keyId, target.applicationKey, target.bucketName);
    const usedMb = check.ok
      ? (await fetchB2BucketUsageMb(target.keyId, target.applicationKey, target.bucketName)) ?? target.usedMb ?? 0
      : target.usedMb ?? 0;
    const nowIso = new Date().toISOString();

    if (manualNode) {
      manualNode.status = check.ok ? 'connected' : 'error';
      manualNode.usedMb = usedMb;
      manualNode.lastCheckedAt = nowIso;
      if (check.ok) delete manualNode.errorMessage;
      else manualNode.errorMessage = check.error;
      invalidateBootstrapCache();
      saveDb(db);
    } else if (envNode) {
      envB2RuntimeStatus.set(envNode.id, {
        status: check.ok ? 'connected' : 'error',
        lastCheckedAt: nowIso,
        errorMessage: check.error,
        usedMb,
      });
      invalidateBootstrapCache();
    }

    res.json({
      success: check.ok,
      message: check.ok
        ? 'Backblaze B2 বাকেট সফলভাবে যাচাই ও সংযুক্ত হয়েছে!'
        : check.error || 'B2 সংযোগ ত্রুটি।',
      renderEnv: generateCombinedRenderEnvVariables(
        getAllMergedSupabaseNodes(),
        getAllMergedB2Nodes(),
        getEnrichedConfig().primaryDomain,
        true
      ),
      ...buildScopedBootstrapPayload(owner),
    });
  });

  // Owner-Only: Sync All Sites to Backblaze B2 Pool
  app.post('/api/admin/storage/b2/sync-all', async (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const mergedB2 = getAllMergedB2Nodes();
    const activeNodes = mergedB2.filter(n => n.status === 'connected' && n.applicationKey);
    if (activeNodes.length === 0) {
      res.status(400).json({ success: false, message: 'কোনো সক্রিয় Backblaze B2 বাকেট যুক্ত নেই।' });
      return;
    }

    let syncedSites = 0;
    for (const s of db.sites) {
      const hydrated = await hydrateSiteFilesAsync(s);
      const r = await syncSiteToB2Pool(mergedB2, hydrated);
      if (r.uploaded) syncedSites++;
    }

    await syncCoreStateToB2(mergedB2, {
      config: db.config,
      users: db.users,
      subAdmins: db.subAdmins,
      sites: db.sites.map(stripSiteFileContents),
      auditLogs: db.auditLogs.slice(0, 120),
      popupMessages: db.popupMessages.slice(0, 50),
      updatedAt: new Date().toISOString(),
    });

    await Promise.all(
      activeNodes.map(async n => {
        if (!n.applicationKey) return;
        const usedMb = await fetchB2BucketUsageMb(n.keyId, n.applicationKey, n.bucketName);
        if (usedMb !== null) {
          const manualTarget = (db.b2Nodes || []).find(m => m.id === n.id);
          if (manualTarget) manualTarget.usedMb = usedMb;
          else {
            const prev = envB2RuntimeStatus.get(n.id);
            envB2RuntimeStatus.set(n.id, {
              status: prev?.status || 'connected',
              lastCheckedAt: new Date().toISOString(),
              usedMb,
            });
          }
        }
      })
    );

    addLog({
      actor: owner.username,
      action: 'B2_SYNC_ALL',
      target: `${syncedSites}/${db.sites.length} Sites`,
      details: `Synced ${syncedSites} sites & core DB state to Backblaze B2 pool.`,
      category: 'config',
    });
    invalidateBootstrapCache();
    saveDb(db);
    res.json({
      success: true,
      syncedSites,
      message: `${syncedSites}টি ওয়েবসাইট Backblaze B2-তে সফলভাবে ব্যাকআপ/সিঙ্ক হয়েছে!`,
      ...buildScopedBootstrapPayload(owner),
    });
  });

  // Owner-Only: Remove Manual Backblaze B2 Storage Node
  app.delete('/api/admin/storage/b2/:id', (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const { id } = req.params;
    const prevLen = (db.b2Nodes || []).length;
    db.b2Nodes = (db.b2Nodes || []).filter(n => n.id !== id);
    if (db.b2Nodes.length === prevLen) {
      res.status(404).json({ success: false, message: 'ম্যানুয়াল Backblaze B2 নোড পাওয়া যায়নি।' });
      return;
    }
    invalidateBootstrapCache();
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(owner) });
  });

  // Owner-Only: Add & Verify Supabase Storage Pool Account
  app.post('/api/admin/storage/supabase', async (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const {
      label = 'Supabase Storage Node',
      url = '',
      serviceRoleKey = '',
      bucketName = 'nighthost-sites',
      quotaMb = 1024,
    } = req.body || {};

    const cleanUrl = normalizeSupabaseUrl(String(url));
    const cleanKey = String(serviceRoleKey || '').trim();
    const cleanBucket = String(bucketName || 'nighthost-sites').trim() || 'nighthost-sites';
    const numericQuota = Math.max(50, Math.min(1048576, Number(quotaMb) || 1024));

    const verify = await verifyAndEnsureSupabaseBucket(cleanUrl, cleanKey, cleanBucket);
    if (!verify.ok) {
      res.status(400).json({ success: false, message: verify.error || 'Supabase সংযোগ যাচাই করা যায়নি।' });
      return;
    }

    const usedMb = (await fetchSupabaseBucketUsageMb(cleanUrl, cleanKey, cleanBucket)) ?? 0;

    if (!Array.isArray(db.supabaseNodes)) db.supabaseNodes = [];
    const existingIdx = db.supabaseNodes.findIndex(
      n => n.url.toLowerCase() === cleanUrl.toLowerCase() && n.bucketName.toLowerCase() === cleanBucket.toLowerCase()
    );

    const newNode: SupabasePoolNode = {
      id: existingIdx >= 0 ? db.supabaseNodes[existingIdx].id : 'sb_' + Math.random().toString(36).substring(2, 9),
      label: String(label || '').trim() || `Supabase (${cleanBucket})`,
      url: cleanUrl,
      serviceRoleKey: cleanKey,
      bucketName: cleanBucket,
      quotaMb: numericQuota,
      usedMb,
      status: 'connected',
      source: 'manual',
      lastCheckedAt: new Date().toISOString(),
    };

    if (existingIdx >= 0) {
      db.supabaseNodes[existingIdx] = newNode;
    } else {
      db.supabaseNodes.push(newNode);
    }

    addLog({
      actor: owner.username,
      action: 'SUPABASE_NODE_ADDED',
      target: newNode.label,
      details: `Connected real Supabase Storage node (${cleanBucket}, ${numericQuota} MB).`,
      category: 'config',
    });
    invalidateBootstrapCache();
    saveDb(db);
    const mergedAll = getAllMergedSupabaseNodes();
    res.json({
      success: true,
      node: sanitizeSupabaseNodeForClient(newNode),
      renderEnv: generateCombinedRenderEnvVariables(
        mergedAll,
        getAllMergedB2Nodes(),
        getEnrichedConfig().primaryDomain,
        true
      ),
      ...buildScopedBootstrapPayload(owner),
    });
  });

  // Owner-Only: Verify Existing Supabase Storage Node
  app.post('/api/admin/storage/supabase/:id/verify', async (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const { id } = req.params;
    const manualNode = (db.supabaseNodes || []).find(n => n.id === id);
    const envNode = parseSupabaseEnvNodes(process.env).find(n => n.id === id);
    const target = manualNode || envNode;
    if (!target || !target.serviceRoleKey) {
      res.status(404).json({ success: false, message: 'Supabase node খুঁজে পাওয়া যায়নি।' });
      return;
    }

    const check = await verifyAndEnsureSupabaseBucket(target.url, target.serviceRoleKey, target.bucketName);
    const usedMb = check.ok
      ? (await fetchSupabaseBucketUsageMb(target.url, target.serviceRoleKey, target.bucketName)) ?? target.usedMb ?? 0
      : target.usedMb ?? 0;
    const nowIso = new Date().toISOString();

    if (manualNode) {
      manualNode.status = check.ok ? 'connected' : 'error';
      manualNode.usedMb = usedMb;
      manualNode.lastCheckedAt = nowIso;
      if (check.ok) delete manualNode.errorMessage;
      else manualNode.errorMessage = check.error;
      invalidateBootstrapCache();
      saveDb(db);
    } else if (envNode) {
      envNodeRuntimeStatus.set(envNode.id, {
        status: check.ok ? 'connected' : 'error',
        lastCheckedAt: nowIso,
        errorMessage: check.error,
        usedMb,
      });
      invalidateBootstrapCache();
    }

    const mergedAll = getAllMergedSupabaseNodes();
    res.json({
      success: check.ok,
      message: check.ok
        ? 'Supabase Storage বাকেট সফলভাবে যাচাই ও সংযুক্ত হয়েছে!'
        : check.error || 'সংযোগ ত্রুটি।',
      renderEnv: generateCombinedRenderEnvVariables(
        mergedAll,
        getAllMergedB2Nodes(),
        getEnrichedConfig().primaryDomain,
        true
      ),
      ...buildScopedBootstrapPayload(owner),
    });
  });

  // Owner-Only: Get Ready-to-Paste Combined Render Env Vars (B2 + Supabase + Domain)
  app.get('/api/admin/storage/supabase/render-env', (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;
    const mergedSupabase = getAllMergedSupabaseNodes();
    const mergedB2 = getAllMergedB2Nodes();
    res.json({
      success: true,
      nodesCount: mergedSupabase.length + mergedB2.length,
      renderEnv: generateCombinedRenderEnvVariables(
        mergedSupabase,
        mergedB2,
        getEnrichedConfig().primaryDomain,
        true
      ),
    });
  });

  // Owner-Only: Re-check / Apply & Re-sync All Supabase Pool Nodes
  app.post('/api/admin/storage/supabase/recheck-all', async (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const envNodes = parseSupabaseEnvNodes(process.env);
    const manualNodes = Array.isArray(db.supabaseNodes) ? db.supabaseNodes : [];
    const nowIso = new Date().toISOString();
    let connected = 0;

    await Promise.all([
      ...envNodes.map(async n => {
        if (!n.serviceRoleKey) return;
        const check = await verifyAndEnsureSupabaseBucket(n.url, n.serviceRoleKey, n.bucketName);
        const usedMb = check.ok
          ? (await fetchSupabaseBucketUsageMb(n.url, n.serviceRoleKey, n.bucketName)) ?? 0
          : 0;
        if (check.ok) connected++;
        envNodeRuntimeStatus.set(n.id, {
          status: check.ok ? 'connected' : 'error',
          lastCheckedAt: nowIso,
          errorMessage: check.error,
          usedMb,
        });
      }),
      ...manualNodes.map(async m => {
        if (!m.serviceRoleKey) return;
        const check = await verifyAndEnsureSupabaseBucket(m.url, m.serviceRoleKey, m.bucketName);
        const usedMb = check.ok
          ? (await fetchSupabaseBucketUsageMb(m.url, m.serviceRoleKey, m.bucketName)) ?? m.usedMb ?? 0
          : m.usedMb ?? 0;
        if (check.ok) connected++;
        m.status = check.ok ? 'connected' : 'error';
        m.usedMb = usedMb;
        m.lastCheckedAt = nowIso;
        if (check.ok) delete m.errorMessage;
        else m.errorMessage = check.error;
      }),
    ]);

    invalidateBootstrapCache();
    if (manualNodes.length > 0) saveDb(db);
    else broadcastSync();

    const mergedAll = getAllMergedSupabaseNodes();
    res.json({
      success: true,
      connectedCount: connected,
      nodesCount: mergedAll.length,
      message: `${connected}/${mergedAll.length}টি Supabase অ্যাকাউন্ট লাইভ ও সচল আছে!`,
      renderEnv: generateCombinedRenderEnvVariables(
        mergedAll,
        getAllMergedB2Nodes(),
        getEnrichedConfig().primaryDomain,
        true
      ),
      ...buildScopedBootstrapPayload(owner),
    });
  });

  // Owner-Only: Sync All Hosted Sites to Active Supabase Pool
  app.post('/api/admin/storage/supabase/sync-all', async (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const mergedAll = getAllMergedSupabaseNodes();
    const activeNodes = mergedAll.filter(n => n.status === 'connected' && n.serviceRoleKey);
    if (activeNodes.length === 0) {
      res.status(400).json({
        success: false,
        message: 'কোনো সক্রিয় Supabase অ্যাকাউন্ট যুক্ত নেই।',
      });
      return;
    }

    let syncedSites = 0;
    for (const s of db.sites) {
      const r = await syncSiteToSupabasePool(mergedAll, s);
      if (r.uploadedFiles > 0) syncedSites++;
    }

    // Refresh real bucket usage after mirroring
    await Promise.all(
      activeNodes.map(async n => {
        if (!n.serviceRoleKey) return;
        const usedMb = await fetchSupabaseBucketUsageMb(n.url, n.serviceRoleKey, n.bucketName);
        if (usedMb !== null) {
          const manualTarget = (db.supabaseNodes || []).find(m => m.id === n.id);
          if (manualTarget) manualTarget.usedMb = usedMb;
          else {
            const prev = envNodeRuntimeStatus.get(n.id);
            envNodeRuntimeStatus.set(n.id, {
              status: prev?.status || 'connected',
              lastCheckedAt: new Date().toISOString(),
              usedMb,
            });
          }
        }
      })
    );

    addLog({
      actor: owner.username,
      action: 'SUPABASE_SYNC_ALL',
      target: `${syncedSites}/${db.sites.length} Sites`,
      details: `Synced ${syncedSites} hosted sites to Supabase pool (${activeNodes.length} buckets).`,
      category: 'config',
    });
    invalidateBootstrapCache();
    saveDb(db);
    res.json({
      success: true,
      syncedSites,
      message: `${syncedSites}টি ওয়েবসাইট Supabase স্টোরেজ পুলে সফলভাবে সিঙ্ক হয়েছে!`,
      ...buildScopedBootstrapPayload(owner),
    });
  });

  // Owner-Only: Remove Manual Supabase Storage Node
  app.delete('/api/admin/storage/supabase/:id', (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const { id } = req.params;
    const prevLen = (db.supabaseNodes || []).length;
    db.supabaseNodes = (db.supabaseNodes || []).filter(n => n.id !== id);
    if (db.supabaseNodes.length === prevLen) {
      res.status(404).json({ success: false, message: 'ম্যানুয়াল Supabase নোড পাওয়া যায়নি (Env নোড Render থেকে সরাতে হবে)।' });
      return;
    }
    invalidateBootstrapCache();
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(owner) });
  });

  // Admin: Download Full Hosted Site Archive (.zip) — Protected by canDownloadSource
  app.get('/api/admin/sites/:id/download.zip', async (req, res) => {
    const auth = requireAdminOrSubadmin(req, res);
    if (!auth) return;
    if (!auth.perms.isOwner && !auth.perms.canDownloadSource) {
      res.status(403).json({ success: false, message: 'আপনার সোর্স কোড (.zip) ডাউনলোডের অনুমতি নেই।' });
      return;
    }
    const rawSite = db.sites.find(s => s.id === req.params.id);
    if (!rawSite) {
      res.status(404).json({ success: false, message: 'Site not found' });
      return;
    }
    const site = await hydrateSiteFilesAsync(rawSite);
    const zipBuf = buildZipBuffer(site.files || {});
    const safeName = slugify(site.slug || site.name || 'site') || 'site';
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${safeName}.zip"`);
    res.setHeader('Content-Length', String(zipBuf.length));
    res.send(zipBuf);
  });

  // Admin: Inspect or Download Single Hosted Site File
  app.get('/api/admin/sites/:id/file', async (req, res) => {
    const auth = requireAdminOrSubadmin(req, res);
    if (!auth) return;
    const rawSite = db.sites.find(s => s.id === req.params.id);
    if (!rawSite) {
      res.status(404).json({ success: false, message: 'Site not found' });
      return;
    }
    if (!auth.perms.isOwner && !auth.perms.canDownloadSource && rawSite.userId !== auth.viewer.id) {
      res.status(403).json({ success: false, message: 'এই সাইটের সোর্স ফাইল দেখার অনুমতি নেই।' });
      return;
    }
    const site = await hydrateSiteFilesAsync(rawSite);
    const reqPath = String(req.query.path || '');
    const file = reqPath ? site.files?.[reqPath] : undefined;
    if (!file) {
      res.status(404).json({ success: false, message: 'File not found' });
      return;
    }
    if (req.query.raw === '1') {
      const buf = file.isBinary
        ? Buffer.from(file.content || '', 'base64')
        : Buffer.from(file.content || '', 'utf-8');
      const baseName = path.basename(file.path) || 'file';
      res.setHeader('Content-Type', file.mimeType || 'application/octet-stream');
      res.setHeader('Content-Disposition', `attachment; filename="${baseName.replace(/"/g, '')}"`);
      res.send(buf);
      return;
    }
    res.json({ success: true, file });
  });

  // Admin: Update User
  app.put('/api/admin/users/:id', (req, res) => {
    const auth = requireAdminOrSubadmin(req, res);
    if (!auth) return;

    const { id } = req.params;
    const { fullName, email, password, storageLimitMb } = req.body || {};
    const user = db.users.find(u => u.id === id);
    if (!user || user.role === 'admin' || (!auth.perms.isOwner && user.role !== 'user')) {
      res.status(403).json({ success: false, message: 'এই অ্যাকাউন্ট পরিবর্তন করার অনুমতি নেই।' });
      return;
    }

    if (typeof fullName === 'string' && fullName.trim()) user.fullName = fullName.trim();
    if (typeof email === 'string' && email.trim()) user.email = email.trim().toLowerCase();
    if (typeof password === 'string' && password.trim()) {
      if (password.trim().length < 4) {
        res.status(400).json({ success: false, message: 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।' });
        return;
      }
      user.password = hashPassword(password.trim());
    }
    if (storageLimitMb !== undefined) {
      if (!auth.perms.isOwner && !auth.perms.canSetQuota) {
        res.status(403).json({ success: false, message: 'আপনার স্টোরেজ লিমিট পরিবর্তনের অনুমতি নেই।' });
        return;
      }
      user.storageLimitMb = Math.max(10, Number(storageLimitMb) || 100);
    }

    addLog({
      actor: auth.viewer.username,
      action: 'USER_UPDATED',
      target: user.username,
      details: `Updated user profile/quota (${user.storageLimitMb} MB).`,
      category: 'user',
    });
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(auth.viewer) });
  });

  // Admin: Delete User (also cleans up subAdmins and sites)
  app.delete('/api/admin/users/:id', (req, res) => {
    const auth = requireAdminOrSubadmin(req, res);
    if (!auth) return;

    const { id } = req.params;
    const target = db.users.find(u => u.id === id);
    if (!target || target.role === 'admin' || (!auth.perms.isOwner && target.role !== 'user')) {
      res.status(403).json({ success: false, message: 'Cannot delete this user.' });
      return;
    }

    const deletedSites = db.sites.filter(s => s.userId === id);
    for (const s of deletedSites) {
      siteRuntime.stopSite(s.id);
      deleteSiteBlob(s.id);
      deleteSiteBundleFromSupabase(getAllMergedSupabaseNodes(), s.slug, s.id).catch(() => {});
    }
    db.users = db.users.filter(u => u.id !== id);
    db.sites = db.sites.filter(s => s.userId !== id);
    db.subAdmins = db.subAdmins.filter(
      s => s.id !== id && s.username.toLowerCase() !== target.username.toLowerCase()
    );

    addLog({
      actor: auth.viewer.username,
      action: 'USER_DELETED',
      target: target.username,
      details: 'Account and hosted sites permanently deleted.',
      category: 'user',
    });
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(auth.viewer) });
  });

  // Owner-Only: Add Admin (role: 'subadmin')
  app.post('/api/admin/subadmins', (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const { username, displayName, email, telegramHandle, password } = req.body || {};
    const cleanUsername = String(username || '').trim().toLowerCase().replace(/[^a-z0-9_.-]/g, '');
    if (!cleanUsername || !email || !telegramHandle) {
      res.status(400).json({ success: false, message: 'ইউজারনেম, ইমেইল এবং টেলিগ্রাম হ্যান্ডেল দিন।' });
      return;
    }

    if (db.users.some(u => u.username.toLowerCase() === cleanUsername)) {
      res.status(409).json({ success: false, message: `ইউজারনেম '${cleanUsername}' ইতিমধ্যে ব্যবহৃত!` });
      return;
    }

    let cleanTg = String(telegramHandle).trim();
    let tgHandle = cleanTg;
    let tgUrl = cleanTg;
    if (cleanTg.startsWith('http://') || cleanTg.startsWith('https://')) {
      const handlePart = cleanTg.split('/').filter(Boolean).pop() || cleanUsername;
      tgHandle = `@${handlePart.replace(/^@/, '')}`;
      tgUrl = cleanTg;
    } else {
      const bare = cleanTg.replace(/^@/, '');
      tgHandle = `@${bare}`;
      tgUrl = `https://t.me/${bare}`;
    }

    const subId = 'sub_' + Math.random().toString(36).substring(2, 9);
    const newSub: SubAdmin = {
      id: subId,
      username: cleanUsername,
      displayName: String(displayName || '').trim() || `অ্যাডমিন (${cleanUsername})`,
      email: String(email).trim().toLowerCase(),
      telegramUsername: tgHandle,
      telegramUrl: tgUrl,
      active: true,
      canApproveUsers: true,
      canSetQuota: true,
      canSendMessages: true,
      canDownloadSource: false,
      canManageAllSites: false,
      createdAt: new Date().toISOString(),
      lastActive: new Date().toISOString(),
    };

    const cleanPassword = String(password || '').trim();
    if (cleanPassword.length < 4) {
      res.status(400).json({
        success: false,
        message: 'অ্যাডমিনের জন্য কমপক্ষে ৪ অক্ষরের পাসওয়ার্ড দিন।',
      });
      return;
    }

    const newUserRecord: User = {
      id: subId,
      username: cleanUsername,
      fullName: newSub.displayName,
      email: newSub.email,
      password: hashPassword(cleanPassword),
      role: 'subadmin',
      status: 'approved',
      storageLimitMb: 1000,
      storageUsedMb: 0,
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      approvalDurationLabel: 'স্থায়ী অ্যাডমিন',
    };

    db.subAdmins.push(newSub);
    db.users.push(newUserRecord);
    addLog({
      actor: owner.username,
      action: 'SUBADMIN_ADDED',
      target: cleanUsername,
      details: `Added Admin with Telegram ${tgHandle}`,
      category: 'subadmin',
    });
    saveDb(db);

    res.json({
      success: true,
      message: `অ্যাডমিন '${cleanUsername}' সফলভাবে যুক্ত হয়েছে!`,
      subAdmin: newSub,
      ...buildScopedBootstrapPayload(owner),
    });
  });

  // Owner-Only: Toggle Admin
  app.post('/api/admin/subadmins/:id/toggle', (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const { id } = req.params;
    const sub = db.subAdmins.find(s => s.id === id);
    if (!sub) {
      res.status(404).json({ success: false });
      return;
    }
    sub.active = !sub.active;
    const u = db.users.find(user => user.id === id || user.username === sub.username);
    if (u) {
      u.status = sub.active ? 'approved' : 'suspended';
    }
    addLog({
      actor: owner.username,
      action: sub.active ? 'SUBADMIN_ENABLED' : 'SUBADMIN_DISABLED',
      target: sub.username,
      details: `Status toggled to ${sub.active ? 'ACTIVE' : 'DISABLED'}.`,
      category: 'subadmin',
    });
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(owner) });
  });

  // Owner-Only: Update Admin Permissions
  app.put('/api/admin/subadmins/:id/permissions', (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const { id } = req.params;
    const { canApproveUsers, canSetQuota, canSendMessages, canDownloadSource, canManageAllSites } = req.body || {};
    const sub = db.subAdmins.find(s => s.id === id);
    if (!sub) {
      res.status(404).json({ success: false });
      return;
    }
    if (canApproveUsers !== undefined) sub.canApproveUsers = Boolean(canApproveUsers);
    if (canSetQuota !== undefined) sub.canSetQuota = Boolean(canSetQuota);
    if (canSendMessages !== undefined) sub.canSendMessages = Boolean(canSendMessages);
    if (canDownloadSource !== undefined) sub.canDownloadSource = Boolean(canDownloadSource);
    if (canManageAllSites !== undefined) sub.canManageAllSites = Boolean(canManageAllSites);

    addLog({
      actor: owner.username,
      action: 'SUBADMIN_PERMS_UPDATED',
      target: sub.username,
      details: `Permissions: approve=${sub.canApproveUsers}, quota=${sub.canSetQuota}, msg=${sub.canSendMessages !== false}, download=${Boolean(sub.canDownloadSource)}, allSites=${Boolean(sub.canManageAllSites)}`,
      category: 'subadmin',
    });
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(owner) });
  });

  // Owner-Only: Delete Admin (deletes from BOTH subAdmins and users)
  app.delete('/api/admin/subadmins/:id', (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const { id } = req.params;
    const sub = db.subAdmins.find(s => s.id === id);
    if (!sub) {
      res.status(404).json({ success: false });
      return;
    }
    db.subAdmins = db.subAdmins.filter(s => s.id !== id);
    db.users = db.users.filter(
      u => u.id !== id && u.username.toLowerCase() !== sub.username.toLowerCase()
    );
    db.sites = db.sites.filter(s => s.userId !== id);

    addLog({
      actor: owner.username,
      action: 'SUBADMIN_REMOVED',
      target: sub.username,
      details: 'Admin permanently deleted from platform and Telegram list.',
      category: 'subadmin',
    });
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(owner) });
  });

  // Owner-Only: Update Platform Config
  app.put('/api/admin/config', (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;

    const updates = { ...(req.body?.updates || {}) } as Partial<PlatformConfig>;
    if (typeof updates.primaryDomain === 'string') {
      updates.primaryDomain = normalizePrimaryDomain(updates.primaryDomain) || DEFAULT_PRIMARY_DOMAIN;
    }
    db.config = { ...db.config, ...updates };
    addLog({
      actor: owner.username,
      action: 'CONFIG_UPDATED',
      target: db.config.brandName,
      details: 'Updated platform configuration.',
      category: 'config',
    });
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(owner) });
  });

  // Owner-Only: Clear Audit Logs
  app.delete('/api/admin/audit-logs', (req, res) => {
    const owner = requireOwner(req, res);
    if (!owner) return;
    db.auditLogs = [];
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(owner) });
  });

  // Owner / Admin: Send One-Time Popup Message (supports optional Marked/Unmarked external link)
  app.post('/api/admin/messages', (req, res) => {
    const auth = requireAdminOrSubadmin(req, res);
    if (!auth) return;
    if (!auth.perms.canSendMessages) {
      res.status(403).json({ success: false, message: 'আপনার পপআপ মেসেজ পাঠানোর অনুমতি নেই।' });
      return;
    }

    const { title, message, targetUserId = 'all', linkUrl, linkText, linkMarked } = req.body || {};
    const cleanTitle = String(title || '').trim() || 'অ্যাডমিন বিজ্ঞপ্তি';
    const cleanMsg = String(message || '').trim();
    if (!cleanMsg) {
      res.status(400).json({ success: false, message: 'মেসেজের টেক্সট লিখুন।' });
      return;
    }

    const rawLink = String(linkUrl || '').trim();
    let safeLinkUrl: string | undefined;
    if (rawLink) {
      safeLinkUrl = sanitizeExternalLinkUrl(rawLink);
      if (!safeLinkUrl) {
        res.status(400).json({
          success: false,
          message: 'লিংকটি সঠিক http:// বা https:// ফরম্যাটে হতে হবে (যেমন: https://t.me/...)',
        });
        return;
      }
    }
    const cleanLinkText = String(linkText || '').trim().slice(0, 80);

    let targetUsername: string | undefined;
    if (targetUserId !== 'all') {
      const targetUser = db.users.find(u => u.id === targetUserId);
      if (!targetUser) {
        res.status(404).json({ success: false, message: 'টার্গেট ইউজার পাওয়া যায়নি।' });
        return;
      }
      targetUsername = targetUser.username;
    }

    const entry: UserPopupMessage = {
      id: 'msg_' + Math.random().toString(36).substring(2, 9),
      title: cleanTitle,
      message: cleanMsg,
      ...(safeLinkUrl ? { linkUrl: safeLinkUrl } : {}),
      ...(safeLinkUrl && cleanLinkText ? { linkText: cleanLinkText } : {}),
      ...(safeLinkUrl ? { linkMarked: linkMarked !== false } : {}),
      targetUserId: String(targetUserId || 'all'),
      targetUsername,
      senderUsername: auth.viewer.username,
      createdAt: new Date().toISOString(),
      dismissedByUserIds: [],
    };
    if (!Array.isArray(db.popupMessages)) db.popupMessages = [];
    db.popupMessages.unshift(entry);
    if (db.popupMessages.length > 50) {
      db.popupMessages = db.popupMessages.slice(0, 50);
    }

    addLog({
      actor: auth.viewer.username,
      action: 'POPUP_MESSAGE_SENT',
      target: targetUserId === 'all' ? 'ALL USERS' : (targetUsername || String(targetUserId)),
      details: safeLinkUrl ? `${cleanTitle} [Link]` : cleanTitle,
      category: 'config',
    });
    saveDb(db);
    res.json({ success: true, messageItem: entry, ...buildScopedBootstrapPayload(auth.viewer) });
  });

  // Admin: Delete Popup Message
  app.delete('/api/admin/messages/:id', (req, res) => {
    const auth = requireAdminOrSubadmin(req, res);
    if (!auth) return;
    const { id } = req.params;
    const targetMsg = (db.popupMessages || []).find(m => m.id === id);
    if (!targetMsg) {
      res.status(404).json({ success: false });
      return;
    }
    if (!auth.perms.isOwner && targetMsg.senderUsername.toLowerCase() !== auth.viewer.username.toLowerCase()) {
      res.status(403).json({ success: false, message: 'অন্য অ্যাডমিনের পাঠানো মেসেজ ডিলিট করা যাবে না।' });
      return;
    }
    db.popupMessages = (db.popupMessages || []).filter(m => m.id !== id);
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(auth.viewer) });
  });

  // User: Dismiss Popup Message Permanently (one-time view per user)
  app.post('/api/messages/:id/dismiss', (req, res) => {
    const viewer = requireAuth(req, res);
    if (!viewer) return;
    const { id } = req.params;
    const msg = (db.popupMessages || []).find(m => m.id === id);
    if (!msg) {
      res.status(404).json({ success: false });
      return;
    }
    if (!msg.dismissedByUserIds.includes(viewer.id)) {
      msg.dismissedByUserIds.push(viewer.id);
      saveDb(db);
    }
    res.json({ success: true, ...buildScopedBootstrapPayload(viewer) });
  });

  // Helper to verify site ownership / admin permission
  function authorizeSiteAccess(
    req: express.Request,
    res: express.Response,
    siteId: string,
    requireSourceDownload = false
  ): { viewer: User; site: HostedSite } | null {
    const viewer = requireAuth(req, res);
    if (!viewer) return null;
    const site = db.sites.find(s => s.id === siteId);
    if (!site) {
      res.status(404).json({ success: false, message: 'সাইট খুঁজে পাওয়া যায়নি।' });
      return null;
    }
    if (site.userId === viewer.id || viewer.role === 'admin') {
      return { viewer, site };
    }
    const perms = getEffectiveAdminPerms(viewer);
    if (perms) {
      if (requireSourceDownload && !perms.canDownloadSource) {
        res.status(403).json({ success: false, message: 'আপনার সোর্স কোড ডাউনলোডের অনুমতি নেই।' });
        return null;
      }
      const siteOwner = db.users.find(u => u.id === site.userId);
      if (perms.canManageAllSites || siteOwner?.role === 'user') {
        return { viewer, site };
      }
    }
    res.status(403).json({ success: false, message: 'এই ওয়েবসাইট এক্সেস করার অনুমতি নেই।' });
    return null;
  }

  // Sites: Create Site (Authenticated user deploys under own account)
  app.post('/api/sites', async (req, res) => {
    const viewer = requireAuth(req, res);
    if (!viewer) return;

    const siteData = req.body || {};
    const finalSlug = slugify(siteData.slug || siteData.name || 'site');

    if (db.sites.some(s => s.slug.toLowerCase() === finalSlug.toLowerCase())) {
      res.status(409).json({
        success: false,
        message: `স্লাগ '${finalSlug}' ইতিমধ্যে ব্যবহৃত! অনুগ্রহ করে অন্য লিংক দিন।`,
      });
      return;
    }

    const cleanCustomDomain = siteData.customDomain ? normalizeCustomDomain(String(siteData.customDomain)) : '';
    if (
      cleanCustomDomain &&
      db.sites.some(s => s.customDomain && s.customDomain.toLowerCase() === cleanCustomDomain.toLowerCase())
    ) {
      res.status(409).json({
        success: false,
        message: `ডোমেইন '${cleanCustomDomain}' ইতিমধ্যে অন্য সাইটে ব্যবহৃত! ইউনিক ডোমেইন দিন।`,
      });
      return;
    }

    const rawFilesInput = (siteData.files && typeof siteData.files === 'object' ? siteData.files : {}) as Record<string, SiteFile>;
    const sanitizedInputFiles: Record<string, SiteFile> = {};
    for (const [k, f] of Object.entries(rawFilesInput)) {
      if (!k || k === '__proto__' || k === 'constructor' || k === 'prototype') continue;
      if (!f || typeof f !== 'object') continue;
      sanitizedInputFiles[k] = f;
    }

    // Clone raw pre-heal files snapshot if fixes are applied
    const preRepairSnapshot: Record<string, SiteFile> = {};
    for (const [k, f] of Object.entries(sanitizedInputFiles)) {
      preRepairSnapshot[k] = { ...f };
    }

    const repaired = autoRepairSiteFiles(sanitizedInputFiles);
    const detectedBeforeHeal = detectProjectRuntime(
      Object.values(repaired.files).map(f => ({
        path: f.path,
        content: f.isBinary ? '' : f.content,
      }))
    );

    // Run Layer 1 fast deterministic auto-healer on upload (AI remains fast & non-blocking or triggered on crash/request)
    const healRes = await runSiteAutoHeal({
      files: repaired.files,
      rootFile: String(siteData.rootFile || 'index.html'),
      runtimeType: detectedBeforeHeal.runtime || siteData.runtimeType || 'static',
      preferAi: false,
    });

    const mergedFiles = healRes.files;
    const totalBytes = Object.values(mergedFiles).reduce((acc, f) => acc + (Number(f.size) || 0), 0);
    const finalSizeKb = totalBytes > 0 ? Math.max(1, Math.ceil(totalBytes / 1024)) : 0;
    const finalFileCount = Object.keys(mergedFiles).length || Number(siteData.totalFiles) || 1;

    recalculateUserStorageMb(viewer.id);
    const existingSitesKb = getUserSitesSizeKb(viewer.id);
    const existingAvatarKb = Number(viewer.avatarSizeKb) || 0;
    if (viewer.role !== 'admin' && existingSitesKb + existingAvatarKb + finalSizeKb > viewer.storageLimitMb * 1024) {
      res.status(507).json({
        success: false,
        code: 'INSUFFICIENT_STORAGE',
        message: `স্টোরেজ কোটা শেষ (HTTP 507)! আপনার নির্ধারিত সীমা ${viewer.storageLimitMb} MB অতিক্রম করেছে। পুরোনো ফাইল মুছে আবার চেষ্টা করুন।`,
      });
      return;
    }

    const detected = detectProjectRuntime(
      Object.values(mergedFiles).map(f => ({
        path: f.path,
        content: f.isBinary ? '' : f.content,
      }))
    );

    const repairLogEntries = [
      ...repaired.repairLogs.map(msg => ({
        timestamp: new Date().toISOString(),
        level: 'info' as const,
        message: msg,
      })),
      ...healRes.reports.map(r => ({
        timestamp: r.timestamp,
        level: 'success' as const,
        message: `[AUTO-HEAL] ${r.summaryBn}`,
      })),
    ];

    const hiddenCount = Object.values(mergedFiles).filter(f => f.isHidden).length;
    const allowedSiteType =
      siteData.type === 'single-file' || siteData.type === 'github' ? siteData.type : 'folder';
    const cleanName = String(siteData.name || finalSlug).trim().slice(0, 80) || finalSlug;
    const cleanDescription = String(siteData.description || '').trim().slice(0, 300);
    const cleanRootFile = String(siteData.rootFile || 'index.html').trim().replace(/^\/+/, '');
    const allowedLogs = Array.isArray(siteData.deploymentLogs)
      ? siteData.deploymentLogs
          .slice(-20)
          .filter((l: unknown): l is { timestamp: string; level: 'info' | 'warn' | 'error'; message: string } =>
            Boolean(l && typeof l === 'object' && typeof (l as { message?: unknown }).message === 'string')
          )
      : [];

    const fullNewSite: HostedSite = {
      id: 'site_' + Math.random().toString(36).substring(2, 9),
      userId: viewer.id,
      username: viewer.username,
      ...(viewer.subdomain ? { ownerSubdomain: viewer.subdomain } : {}),
      name: cleanName,
      description: cleanDescription,
      type: allowedSiteType,
      status: siteData.status === 'paused' ? 'paused' : 'online',
      slug: finalSlug,
      customPath: finalSlug,
      ...(cleanCustomDomain ? { customDomain: cleanCustomDomain } : {}),
      rootFile: cleanRootFile || 'index.html',
      ...(siteData.singleFileConfig && typeof siteData.singleFileConfig === 'object'
        ? { singleFileConfig: siteData.singleFileConfig }
        : {}),
      ...(siteData.githubConfig && typeof siteData.githubConfig === 'object'
        ? { githubConfig: siteData.githubConfig }
        : {}),
      files: mergedFiles,
      totalFiles: finalFileCount,
      totalSizeKb: finalSizeKb,
      hiddenFilesCount: Number(siteData.hiddenFilesCount ?? hiddenCount),
      repairedFilesCount: repaired.repairedPaths.length + healRes.reports.length,
      runtimeType: detected.runtime || siteData.runtimeType || 'static',
      deploymentLogs: [...allowedLogs, ...repairLogEntries],
      ...(healRes.reports.length > 0
        ? {
            autoFixReports: healRes.reports,
            preHealBackup: {
              createdAt: new Date().toISOString(),
              reasonBn: 'ডিপ্লয়ের সময় স্বয়ংক্রিয় কোড অটো-হিল প্রয়োগ করা হয়েছে',
              files: preRepairSnapshot,
              rootFile: cleanRootFile || 'index.html',
            },
          }
        : {}),
      visitsCount: 1,
      bandwidthMb: 0.1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Persist full site blob to disk + LRU cache + B2 & Supabase pools
    persistSiteBlob(fullNewSite);
    const slimSite = stripSiteFileContents(fullNewSite);

    db.sites.unshift(slimSite);
    recalculateUserStorageMb(viewer.id);
    addLog({
      actor: viewer.username,
      action: 'SITE_DEPLOYED',
      target: viewer.subdomain ? `/u/${viewer.subdomain}/${finalSlug}` : `/site/${finalSlug}`,
      details: `Deployed ${allowedSiteType} site (${finalFileCount} files, auto-healed: ${healRes.reports.length}, runtime: ${slimSite.runtimeType}).`,
      category: 'site',
    });
    saveDb(db);

    if (fullNewSite.runtimeType === 'node' || fullNewSite.runtimeType === 'python') {
      siteRuntime.ensureRunning(fullNewSite).catch(() => {});
    }

    // Replicate full bundle to connected Backblaze B2 & Supabase pools asynchronously
    syncSiteToB2Pool(getAllMergedB2Nodes(), fullNewSite).catch(() => {});
    syncSiteToSupabasePool(getAllMergedSupabaseNodes(), fullNewSite).catch(() => {});

    res.json({ success: true, site: slimSite, ...buildScopedBootstrapPayload(viewer) });
  });

  // Sites: Runtime Status & Logs
  app.get('/api/sites/:id/runtime', async (req, res) => {
    const auth = authorizeSiteAccess(req, res, req.params.id);
    if (!auth) return;
    const hydrated = await hydrateSiteFilesAsync(auth.site);
    res.json({ success: true, ...siteRuntime.getSiteRuntimeMeta(hydrated) });
  });

  // Sites: Live Frontend + Backend Health Probe
  app.get('/api/sites/:id/health', async (req, res) => {
    const auth = authorizeSiteAccess(req, res, req.params.id);
    if (!auth) return;
    const hydrated = await hydrateSiteFilesAsync(auth.site);
    const health = await siteRuntime.getSiteHealth(hydrated);
    res.json({ success: true, ...health });
  });

  // Sites: Restart Backend Runtime
  app.post('/api/sites/:id/runtime/restart', async (req, res) => {
    const auth = authorizeSiteAccess(req, res, req.params.id);
    if (!auth) return;
    const hydrated = await hydrateSiteFilesAsync(auth.site);
    await siteRuntime.restartSite(hydrated);
    res.json({ success: true, ...siteRuntime.getSiteRuntimeMeta(hydrated) });
  });

  // Sites: AI + Rule-Based Code Auto-Heal with Backup Snapshot & Bengali Reports
  app.post('/api/sites/:id/auto-heal', async (req, res) => {
    const auth = authorizeSiteAccess(req, res, req.params.id);
    if (!auth) return;
    const hydrated = await hydrateSiteFilesAsync(auth.site);
    const rtMeta = siteRuntime.getSiteRuntimeMeta(hydrated);

    const backupFiles: Record<string, SiteFile> = {};
    for (const [k, f] of Object.entries(hydrated.files || {})) {
      backupFiles[k] = { ...f };
    }

    const healRes = await runSiteAutoHeal({
      files: hydrated.files || {},
      rootFile: hydrated.rootFile,
      runtimeType: rtMeta.runtime,
      errorLogs: rtMeta.state?.logs || [],
      errorMessage: rtMeta.state?.errorMessage,
      preferAi: true,
    });

    if (!healRes.healed) {
      res.json({
        success: true,
        healed: false,
        message: 'আপনার প্রজেক্ট কোডে বড় কোনো ত্রুটি পাওয়া যায়নি — কোড সুস্থ আছে!',
        reports: auth.site.autoFixReports || [],
        ...buildScopedBootstrapPayload(auth.viewer),
      });
      return;
    }

    auth.site.preHealBackup = {
      createdAt: new Date().toISOString(),
      reasonBn:
        healRes.usedEngine === 'gemini-ai'
          ? 'Gemini AI অটো-হিল করার আগের মূল কোড ব্যাকআপ'
          : 'অটো-রিপেয়ার করার আগের মূল কোড ব্যাকআপ',
      files: backupFiles,
      rootFile: auth.site.rootFile,
    };

    auth.site.autoFixReports = [...healRes.reports, ...(auth.site.autoFixReports || [])].slice(0, 15);
    auth.site.files = healRes.files;
    auth.site.repairedFilesCount = (auth.site.repairedFilesCount || 0) + healRes.reports.length;
    auth.site.totalFiles = Object.keys(healRes.files).length;
    const totalBytes = Object.values(healRes.files).reduce((a, f) => a + (Number(f.size) || 0), 0);
    auth.site.totalSizeKb = Math.max(1, Math.ceil(totalBytes / 1024));
    auth.site.updatedAt = new Date().toISOString();
    auth.site.deploymentLogs = [
      ...(auth.site.deploymentLogs || []).slice(-25),
      ...healRes.reports.map(r => ({
        timestamp: r.timestamp,
        level: 'success' as const,
        message: `[${r.engine === 'gemini-ai' ? 'AI-HEAL' : 'RULE-HEAL'}] ${r.filePath}: ${r.summaryBn}`,
      })),
    ];

    const fullUpdated: HostedSite = { ...auth.site, files: healRes.files };
    persistSiteBlob(fullUpdated);
    recalculateUserStorageMb(auth.site.userId);
    saveDb(db);
    syncSiteToB2Pool(getAllMergedB2Nodes(), fullUpdated).catch(() => {});
    syncSiteToSupabasePool(getAllMergedSupabaseNodes(), fullUpdated).catch(() => {});

    if (fullUpdated.runtimeType === 'node' || fullUpdated.runtimeType === 'python') {
      await siteRuntime.restartSite(fullUpdated).catch(() => {});
    }

    res.json({
      success: true,
      healed: true,
      usedEngine: healRes.usedEngine,
      reports: healRes.reports,
      message: `${healRes.reports.length}টি সমস্যা অটো-হিল করা হয়েছে! পূর্বের কোডে ফিরতে Undo বাটন ব্যবহার করতে পারবেন।`,
      site: stripSiteFileContents(fullUpdated),
      ...buildScopedBootstrapPayload(auth.viewer),
    });
  });

  // Sites: 1-Click Undo Last Auto-Heal Restore
  app.post('/api/sites/:id/auto-heal/undo', async (req, res) => {
    const auth = authorizeSiteAccess(req, res, req.params.id);
    if (!auth) return;
    if (!auth.site.preHealBackup || !auth.site.preHealBackup.files) {
      res.status(404).json({ success: false, message: 'পূর্বের কোড ব্যাকআপ পাওয়া যায়নি।' });
      return;
    }

    const restoredFiles = auth.site.preHealBackup.files;
    auth.site.files = restoredFiles;
    auth.site.rootFile = auth.site.preHealBackup.rootFile || auth.site.rootFile;
    auth.site.totalFiles = Object.keys(restoredFiles).length;
    const totalBytes = Object.values(restoredFiles).reduce((a, f) => a + (Number(f.size) || 0), 0);
    auth.site.totalSizeKb = Math.max(1, Math.ceil(totalBytes / 1024));
    delete auth.site.preHealBackup;
    auth.site.autoFixReports = [];
    auth.site.updatedAt = new Date().toISOString();
    auth.site.deploymentLogs = [
      ...(auth.site.deploymentLogs || []).slice(-25),
      {
        timestamp: new Date().toISOString(),
        level: 'info',
        message: '[UNDO-HEAL] Reverted code files back to original pre-heal snapshot.',
      },
    ];

    const fullRestored: HostedSite = { ...auth.site, files: restoredFiles };
    persistSiteBlob(fullRestored);
    recalculateUserStorageMb(auth.site.userId);
    saveDb(db);
    syncSiteToB2Pool(getAllMergedB2Nodes(), fullRestored).catch(() => {});
    syncSiteToSupabasePool(getAllMergedSupabaseNodes(), fullRestored).catch(() => {});

    if (fullRestored.runtimeType === 'node' || fullRestored.runtimeType === 'python') {
      await siteRuntime.restartSite(fullRestored).catch(() => {});
    }

    res.json({
      success: true,
      message: 'পূর্বের মূল কোড সফলভাবে ফিরিয়ে আনা হয়েছে!',
      site: stripSiteFileContents(fullRestored),
      ...buildScopedBootstrapPayload(auth.viewer),
    });
  });

  // Sites: Update Slug
  app.put('/api/sites/:id/slug', (req, res) => {
    const auth = authorizeSiteAccess(req, res, req.params.id);
    if (!auth) return;

    const cleanSlug = slugify(String(req.body?.newSlug || ''));
    if (!cleanSlug) {
      res.status(400).json({ success: false, message: 'স্লাগ খালি হতে পারবে না।' });
      return;
    }
    if (db.sites.some(s => s.slug.toLowerCase() === cleanSlug.toLowerCase() && s.id !== auth.site.id)) {
      res.status(409).json({ success: false, message: `স্লাগ '${cleanSlug}' ইতিমধ্যে অন্য সাইটে ব্যবহৃত।` });
      return;
    }
    auth.site.slug = cleanSlug;
    auth.site.customPath = cleanSlug;
    auth.site.updatedAt = new Date().toISOString();
    saveDb(db);
    res.json({
      success: true,
      message: `লিংক সফলভাবে পরিবর্তন হয়েছে: /site/${cleanSlug}`,
      ...buildScopedBootstrapPayload(auth.viewer),
    });
  });

  // Sites: Update Unique Custom Subdomain / Domain Route (/d/:domain + Host Header)
  app.put('/api/sites/:id/domain', (req, res) => {
    const auth = authorizeSiteAccess(req, res, req.params.id);
    if (!auth) return;

    const rawDomain = String(req.body?.customDomain || '');
    const site = auth.site;

    if (!rawDomain.trim()) {
      delete site.customDomain;
      site.updatedAt = new Date().toISOString();
      saveDb(db);
      res.json({
        success: true,
        site,
        message: 'কাস্টম ডোমেইন রিমুভ করা হয়েছে।',
        ...buildScopedBootstrapPayload(auth.viewer),
      });
      return;
    }

    const cleanDomain = normalizeCustomDomain(rawDomain);
    if (!cleanDomain) {
      res.status(400).json({ success: false, message: 'সঠিক সাবডোমেইন বা ডোমেইন নাম লিখুন (যেমন: myapp.nighthost.app)।' });
      return;
    }
    if (
      db.sites.some(
        s => s.id !== site.id && s.customDomain && s.customDomain.toLowerCase() === cleanDomain.toLowerCase()
      )
    ) {
      res.status(409).json({
        success: false,
        message: `ডোমেইন '${cleanDomain}' ইতিমধ্যে অন্য ওয়েবসাইটে ব্যবহৃত! ইউনিক ডোমেইন দিন।`,
      });
      return;
    }

    site.customDomain = cleanDomain;
    site.updatedAt = new Date().toISOString();
    saveDb(db);
    res.json({
      success: true,
      site,
      message: `কাস্টম ডোমেইন সেট হয়েছে: ${cleanDomain} (/d/${cleanDomain})`,
      ...buildScopedBootstrapPayload(auth.viewer),
    });
  });

  // Sites: Toggle Status
  app.post('/api/sites/:id/toggle', async (req, res) => {
    const auth = authorizeSiteAccess(req, res, req.params.id);
    if (!auth) return;
    const site = auth.site;
    site.status = site.status === 'online' ? 'paused' : 'online';
    site.updatedAt = new Date().toISOString();
    if (site.status === 'paused') {
      siteRuntime.stopSite(site.id);
    } else if (site.runtimeType === 'node' || site.runtimeType === 'python') {
      const hydrated = await hydrateSiteFilesAsync(site);
      siteRuntime.ensureRunning(hydrated).catch(() => {});
    }
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(auth.viewer) });
  });

  // Sites: Download ZIP archive (Protected by ownership or canDownloadSource)
  app.get('/api/sites/:id/download.zip', async (req, res) => {
    const auth = authorizeSiteAccess(req, res, req.params.id, true);
    if (!auth) return;
    const hydrated = await hydrateSiteFilesAsync(auth.site);
    const zipBuf = buildZipBuffer(hydrated.files || {});
    const safeName = slugify(hydrated.slug || hydrated.name || 'site') || 'site';
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${safeName}.zip"`);
    res.setHeader('Content-Length', String(zipBuf.length));
    res.send(zipBuf);
  });

  // Sites: On-demand Single File Fetch for Inspector / Live Editor
  app.get('/api/sites/:id/file', async (req, res) => {
    const auth = authorizeSiteAccess(req, res, req.params.id);
    if (!auth) return;
    const hydrated = await hydrateSiteFilesAsync(auth.site);
    const reqPath = String(req.query.path || '').trim().replace(/^\/+/, '').replace(/\\/g, '/');
    const file = reqPath ? hydrated.files?.[reqPath] : undefined;
    if (!file) {
      res.status(404).json({ success: false, message: 'ফাইল খুঁজে পাওয়া যায়নি।' });
      return;
    }
    res.json({ success: true, file });
  });

  // Sites: Live Edit Text/Code File & Redeploy
  app.put('/api/sites/:id/files', async (req, res) => {
    const auth = authorizeSiteAccess(req, res, req.params.id);
    if (!auth) return;
    const site = auth.site;
    const hydrated = await hydrateSiteFilesAsync(site);
    const workingFiles: Record<string, SiteFile> = { ...(hydrated.files || {}) };

    const { filePath, content } = req.body || {};
    const cleanPath = String(filePath || '').trim().replace(/^\/+/, '').replace(/\\/g, '/');
    if (!cleanPath || cleanPath.includes('..') || path.isAbsolute(cleanPath) || typeof content !== 'string') {
      res.status(400).json({ success: false, message: 'সঠিক ফাইল পাথ এবং কনটেন্ট দিন।' });
      return;
    }
    const existing = workingFiles[cleanPath];
    if (existing?.isBinary) {
      res.status(400).json({ success: false, message: 'বাইনারি ফাইল অনলাইনে এডিট করা যাবে না।' });
      return;
    }

    const oldSizeBytes = existing ? Number(existing.size) || 0 : 0;
    const newSizeBytes = Buffer.byteLength(content, 'utf-8');
    const totalBytesAll =
      Object.values(workingFiles).reduce((acc, f) => acc + (Number(f.size) || 0), 0) -
      oldSizeBytes +
      newSizeBytes;
    const oldTotalKb = Number(site.totalSizeKb) || 0;
    const newTotalKb = Math.max(1, Math.ceil(totalBytesAll / 1024));
    const deltaMb = (newTotalKb - oldTotalKb) / 1024;

    const owner = db.users.find(u => u.id === site.userId);
    if (owner && owner.role !== 'admin' && deltaMb > 0 && owner.storageUsedMb + deltaMb > owner.storageLimitMb) {
      res.status(400).json({
        success: false,
        message: `স্টোরেজ কোটা অতিক্রম করেছে! (লিমিট: ${owner.storageLimitMb} MB)`,
      });
      return;
    }

    workingFiles[cleanPath] = {
      path: cleanPath,
      content,
      size: newSizeBytes,
      isHidden: isPathHidden(cleanPath),
      isBinary: false,
      mimeType: existing?.mimeType || getMimeType(cleanPath),
      type: existing?.type || getFileType(cleanPath),
    };
    site.files = workingFiles;
    if (site.type === 'single-file' && site.singleFileConfig && cleanPath === site.rootFile) {
      site.singleFileConfig.rawContent = content;
    }
    site.totalFiles = Object.keys(workingFiles).length;
    site.totalSizeKb = newTotalKb;
    if (owner) recalculateUserStorageMb(owner.id);
    site.updatedAt = new Date().toISOString();
    site.deploymentLogs = [
      ...(site.deploymentLogs || []).slice(-30),
      {
        timestamp: new Date().toISOString(),
        level: 'info',
        message: `Updated ${cleanPath} (${newSizeBytes} B) via Live Code Editor.`,
      },
    ];

    const fullUpdatedSite: HostedSite = { ...site, files: workingFiles };
    persistSiteBlob(fullUpdatedSite);
    syncSiteToB2Pool(getAllMergedB2Nodes(), fullUpdatedSite).catch(() => {});
    syncSiteToSupabasePool(getAllMergedSupabaseNodes(), fullUpdatedSite).catch(() => {});

    addLog({
      actor: auth.viewer.username,
      action: 'SITE_FILE_EDITED',
      target: `/site/${site.slug}/${cleanPath}`,
      details: `Live file update (${newSizeBytes} bytes).`,
      category: 'site',
    });
    saveDb(db);

    if (site.runtimeType === 'node' || site.runtimeType === 'python') {
      siteRuntime.restartSite(fullUpdatedSite).catch(() => {});
    }
    res.json({ success: true, site: stripSiteFileContents(fullUpdatedSite), ...buildScopedBootstrapPayload(auth.viewer) });
  });

  // Sites: Delete Site
  app.delete('/api/sites/:id', (req, res) => {
    const auth = authorizeSiteAccess(req, res, req.params.id);
    if (!auth) return;
    const { id } = req.params;
    siteRuntime.stopSite(id);
    deleteSiteBlob(id);
    deleteSiteBundleFromB2(getAllMergedB2Nodes(), id).catch(() => {});
    deleteSiteBundleFromSupabase(getAllMergedSupabaseNodes(), auth.site.slug, id).catch(() => {});
    const owner = db.users.find(u => u.id === auth.site.userId);
    db.sites = db.sites.filter(s => s.id !== id);
    if (owner) recalculateUserStorageMb(owner.id);
    addLog({
      actor: auth.viewer.username,
      action: 'SITE_DELETED',
      target: `/site/${auth.site.slug}`,
      details: 'Site permanently deleted.',
      category: 'site',
    });
    saveDb(db);
    res.json({ success: true, ...buildScopedBootstrapPayload(auth.viewer) });
  });

  // Real GitHub Repository Importer (Public via codeload ZIP + Private PAT — Auth Required)
  app.post('/api/github/import', async (req, res) => {
    const viewer = requireAuth(req, res);
    if (!viewer) return;
    try {
      const { repoUrl, branch, token } = req.body || {};
      const parsed = parseGithubRepo(String(repoUrl || ''));
      if (!parsed) {
        res.status(400).json({
          success: false,
          message: 'সঠিক GitHub রিপোজিটরি লিংক দিন (যেমন: https://github.com/user/repo)।',
        });
        return;
      }

      const cleanUserToken = token ? String(token).trim() : '';
      const serverFallbackToken = !cleanUserToken ? String(process.env.GITHUB_TOKEN || '').trim() : '';
      const activeToken = cleanUserToken || serverFallbackToken;

      const buildGhHeaders = (scheme: 'Bearer' | 'token' = 'Bearer'): Record<string, string> => {
        const h: Record<string, string> = {
          'User-Agent': 'NIGHTHOST-Cloud-Engine',
          Accept: 'application/vnd.github+json',
        };
        if (activeToken) {
          h.Authorization = `${scheme} ${activeToken}`;
        }
        return h;
      };

      const requestedBranch = String(branch || '').trim() || parsed.branchFromUrl || '';
      const filesRecord: Record<string, SiteFile> = {};
      let resolvedBranch = requestedBranch || 'main';
      let isRepoPrivate = false;
      let importedViaZip = false;

      const scoreFilePriority = (p: string) => {
        const l = p.toLowerCase();
        const base = l.split('/').pop() || l;
        if (
          l.startsWith('dist/') ||
          l.startsWith('build/') ||
          l.startsWith('static/') ||
          l.startsWith('templates/') ||
          l.startsWith('public/') ||
          base === 'requirements.txt' ||
          base === 'package.json' ||
          base === 'dockerfile' ||
          base === 'render.yaml' ||
          base === 'procfile' ||
          base.startsWith('.env')
        ) {
          return 0;
        }
        if (
          l.endsWith('.html') ||
          l.endsWith('.php') ||
          base === 'app.py' ||
          base === 'main.py' ||
          base === 'server.py' ||
          base === 'server.js' ||
          base === 'index.js' ||
          base === 'index.mjs'
        ) {
          return 1;
        }
        if (l.endsWith('.css') || l.endsWith('.js') || l.endsWith('.mjs') || l.endsWith('.py')) return 2;
        if (
          l.endsWith('.png') ||
          l.endsWith('.jpg') ||
          l.endsWith('.jpeg') ||
          l.endsWith('.svg') ||
          l.endsWith('.webp') ||
          l.endsWith('.ico') ||
          l.endsWith('.json')
        ) {
          return 3;
        }
        if (l.endsWith('.ts') || l.endsWith('.tsx') || l.endsWith('.jsx')) return 4;
        return 5;
      };

      // Helper: Download public repository archive directly from codeload.github.com (no 60/hr API rate limit)
      const tryImportPublicZip = async (branchCandidates: string[]): Promise<boolean> => {
        const tried = new Set<string>();
        for (const br of branchCandidates) {
          const cleanBr = br.trim();
          if (!cleanBr || tried.has(cleanBr)) continue;
          tried.add(cleanBr);
          const zipUrls =
            cleanBr === 'HEAD'
              ? [`https://codeload.github.com/${parsed.owner}/${parsed.repo}/zip/HEAD`]
              : [
                  `https://codeload.github.com/${parsed.owner}/${parsed.repo}/zip/refs/heads/${encodeURIComponent(cleanBr)}`,
                  `https://codeload.github.com/${parsed.owner}/${parsed.repo}/zip/${encodeURIComponent(cleanBr)}`,
                ];

          for (const zipUrl of zipUrls) {
            try {
              const controller = new AbortController();
              const timer = setTimeout(() => controller.abort(), 15000);
              const zipRes = await fetch(zipUrl, {
                headers: { 'User-Agent': 'NIGHTHOST-Cloud-Engine' },
                signal: controller.signal,
              }).finally(() => clearTimeout(timer));

              if (!zipRes.ok) continue;
              const buf = Buffer.from(await zipRes.arrayBuffer());
              if (buf.length < 22) continue;

              const rawEntries = extractZipEntries(buf);
              if (rawEntries.length === 0) continue;

              const isGithubBloat = (p: string) =>
                /(^|\/)(node_modules|__pycache__|\.pytest_cache|\.git|\.github|\.gitlab|\.vscode|\.idea|coverage|playwright-report|\.next|\.nuxt)\/|(\.map|\.d\.ts|\.spec\.[jt]sx?|\.test\.[jt]sx?|\.psd|\.ai|\.sketch|\.zip|\.tar|\.gz|\.rar|\.7z|\.mp4|\.mov|\.avi|\.mkv|\.bak)$/i.test(
                  p
                );

              const cleanedEntries: { path: string; data: Buffer }[] = [];
              for (const ent of rawEntries) {
                const slashIdx = ent.path.indexOf('/');
                const relPath = slashIdx >= 0 ? ent.path.slice(slashIdx + 1) : ent.path;
                if (!relPath || isGithubBloat(relPath)) continue;
                if (ent.data.byteLength > 2 * 1024 * 1024) continue;
                cleanedEntries.push({ path: relPath, data: ent.data });
              }

              if (cleanedEntries.length === 0) continue;

              const prioritizedZip = cleanedEntries
                .sort((a, b) => scoreFilePriority(a.path) - scoreFilePriority(b.path))
                .slice(0, 140);

              let totalBytes = 0;
              for (const item of prioritizedZip) {
                const size = item.data.byteLength;
                if (totalBytes + size > 12 * 1024 * 1024) continue;
                totalBytes += size;
                const binary = isBinaryFile(item.path);
                const content = binary ? item.data.toString('base64') : item.data.toString('utf-8');
                filesRecord[item.path] = {
                  path: item.path,
                  content,
                  size,
                  isHidden: isPathHidden(item.path),
                  isBinary: binary,
                  mimeType: getMimeType(item.path),
                  type: getFileType(item.path),
                };
              }

              resolvedBranch = cleanBr === 'HEAD' ? requestedBranch || 'main' : cleanBr;
              return Object.keys(filesRecord).length > 0;
            } catch {
              // try next archive candidate
            }
          }
        }
        return false;
      };

      // 1. For public repos (no user PAT), try API metadata briefly or bypass straight to codeload ZIP on rate limit
      let headers = buildGhHeaders('Bearer');
      let repoRes: Response | null = null;
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 5000);
        repoRes = await fetch(`https://api.github.com/repos/${parsed.owner}/${parsed.repo}`, {
          headers,
          signal: controller.signal,
        }).finally(() => clearTimeout(timer));

        if (repoRes.status === 401 && activeToken) {
          headers = buildGhHeaders('token');
          const retryController = new AbortController();
          const retryTimer = setTimeout(() => retryController.abort(), 5000);
          repoRes = await fetch(`https://api.github.com/repos/${parsed.owner}/${parsed.repo}`, {
            headers,
            signal: retryController.signal,
          }).finally(() => clearTimeout(retryTimer));
        }
      } catch {
        repoRes = null;
      }

      if (!cleanUserToken) {
        // Public mode: try direct ZIP archive first whenever API is rate-limited (403/429), failed, or confirms repo is public
        const rateLimitedOrDown = !repoRes || repoRes.status === 403 || repoRes.status === 429 || repoRes.status >= 500;
        let defaultBranchFromApi = '';
        if (repoRes && repoRes.ok) {
          const repoJson = (await repoRes.json()) as { default_branch?: string; private?: boolean };
          isRepoPrivate = Boolean(repoJson.private);
          defaultBranchFromApi = repoJson.default_branch || '';
          if (isRepoPrivate) {
            res.status(403).json({
              success: false,
              message: 'এটি একটি Private রিপোজিটরি! Private Repository সিলেক্ট করে Personal Access Token (PAT) দিন।',
            });
            return;
          }
        }

        const zipCandidates = Array.from(
          new Set(
            [
              requestedBranch,
              defaultBranchFromApi,
              'main',
              'master',
              'HEAD',
            ].filter(Boolean)
          )
        );

        importedViaZip = await tryImportPublicZip(zipCandidates);

        if (!importedViaZip) {
          if (repoRes && repoRes.status === 404) {
            res.status(404).json({
              success: false,
              message:
                'রিপোজিটরি পাওয়া যায়নি (404)! লিংকটি ঠিক আছে কি না দেখুন, অথবা রিপোটি Private হলে Private Repository সিলেক্ট করে PAT টোকেন দিন।',
            });
            return;
          }
          if (rateLimitedOrDown) {
            res.status(404).json({
              success: false,
              message:
                'পাবলিক রিপোজিটরি বা ব্রাঞ্চ পাওয়া যায়নি। রিপো লিংক ও ব্রাঞ্চ (main/master) যাচাই করুন—অথবা রিপোটি Private হলে PAT টোকেন দিন।',
            });
            return;
          }
        }
      }

      // 2. Private repo (with PAT) OR fallback via GitHub REST Tree API
      if (!importedViaZip) {
        if (!repoRes) {
          res.status(502).json({
            success: false,
            message: 'GitHub সার্ভারে সংযোগ করা যায়নি। কিছুক্ষণ পর আবার চেষ্টা করুন।',
          });
          return;
        }

        if (!repoRes.ok) {
          const statusMsg =
            repoRes.status === 401 || repoRes.status === 403
              ? cleanUserToken
                ? 'আপনার দেওয়া GitHub Personal Access Token (PAT) সঠিক নয় বা মেয়াদোত্তীর্ণ হয়েছে।'
                : 'GitHub অ্যাক্সেস ডিনাইড! রিপোটি Private হলে সঠিক Personal Access Token (PAT) দিন।'
              : repoRes.status === 404
              ? 'রিপোজিটরি খুঁজে পাওয়া যায়নি (404)। লিংক, ইউজারনেম অথবা প্রাইভেট টোকেন যাচাই করুন।'
              : `GitHub API ত্রুটি (${repoRes.status})।`;
          res.status(repoRes.status).json({ success: false, message: statusMsg });
          return;
        }

        const repoJson = (await repoRes.json()) as { default_branch?: string; private?: boolean };
        isRepoPrivate = Boolean(repoJson.private);
        const targetBranch = requestedBranch || repoJson.default_branch || 'main';
        resolvedBranch = targetBranch;

        let treeRes = await fetch(
          `https://api.github.com/repos/${parsed.owner}/${parsed.repo}/git/trees/${encodeURIComponent(targetBranch)}?recursive=1`,
          { headers }
        );
        if (!treeRes.ok && requestedBranch && repoJson.default_branch && requestedBranch !== repoJson.default_branch) {
          resolvedBranch = repoJson.default_branch;
          treeRes = await fetch(
            `https://api.github.com/repos/${parsed.owner}/${parsed.repo}/git/trees/${encodeURIComponent(resolvedBranch)}?recursive=1`,
            { headers }
          );
        }
        if (!treeRes.ok) {
          res.status(treeRes.status).json({
            success: false,
            message: `ব্রাঞ্চ '${targetBranch}' খুঁজে পাওয়া যায়নি। ব্রাঞ্চের নাম (যেমন main বা master) চেক করুন।`,
          });
          return;
        }

        const treeData = (await treeRes.json()) as {
          tree?: { path: string; type: string; size?: number; sha: string }[];
        };

        const blobs = (treeData.tree || []).filter(item => {
          if (item.type !== 'blob') return false;
          if (
            /(^|\/)(node_modules|__pycache__|\.pytest_cache|\.git|\.github|\.gitlab|\.vscode|\.idea|coverage|playwright-report|\.next|\.nuxt)\/|(\.map|\.d\.ts|\.spec\.[jt]sx?|\.test\.[jt]sx?|\.psd|\.ai|\.sketch|\.zip|\.tar|\.gz|\.rar|\.7z|\.mp4|\.mov|\.avi|\.mkv|\.bak)$/i.test(
              item.path
            )
          ) {
            return false;
          }
          if ((item.size || 0) > 2 * 1024 * 1024) return false;
          return true;
        });

        if (blobs.length === 0) {
          res.status(400).json({
            success: false,
            message: 'রিপোজিটরিতে কোনো ডিপ্লয়যোগ্য ফাইল পাওয়া যায়নি।',
          });
          return;
        }

        const prioritized = [...blobs]
          .sort((a, b) => scoreFilePriority(a.path) - scoreFilePriority(b.path))
          .slice(0, 140);

        let totalBytes = 0;
        const batchSize = 15;
        for (let i = 0; i < prioritized.length; i += batchSize) {
          const chunk = prioritized.slice(i, i + batchSize);
          await Promise.all(
            chunk.map(async item => {
              try {
                const binary = isBinaryFile(item.path);
                let content = '';
                let size = item.size || 0;
                let fetched = false;

                if (!isRepoPrivate && !cleanUserToken) {
                  const encodedPath = item.path
                    .split('/')
                    .map(seg => encodeURIComponent(seg))
                    .join('/');
                  const rawUrl = `https://raw.githubusercontent.com/${parsed.owner}/${parsed.repo}/${encodeURIComponent(resolvedBranch)}/${encodedPath}`;
                  const rawRes = await fetch(rawUrl, {
                    headers: { 'User-Agent': 'NIGHTHOST-Cloud-Engine' },
                  });
                  if (rawRes.ok) {
                    const buf = Buffer.from(await rawRes.arrayBuffer());
                    size = buf.byteLength;
                    if (totalBytes + size > 20 * 1024 * 1024) return;
                    totalBytes += size;
                    content = binary ? buf.toString('base64') : buf.toString('utf-8');
                    fetched = true;
                  }
                }

                if (!fetched) {
                  const blobRes = await fetch(
                    `https://api.github.com/repos/${parsed.owner}/${parsed.repo}/git/blobs/${item.sha}`,
                    { headers }
                  );
                  if (!blobRes.ok) return;
                  const blobJson = (await blobRes.json()) as { content?: string; encoding?: string; size?: number };
                  const rawBase64 = (blobJson.content || '').replace(/\n/g, '');
                  size = blobJson.size || item.size || 0;
                  if (totalBytes + size > 20 * 1024 * 1024) return;
                  totalBytes += size;
                  content = binary ? rawBase64 : Buffer.from(rawBase64, 'base64').toString('utf-8');
                }

                filesRecord[item.path] = {
                  path: item.path,
                  content,
                  size,
                  isHidden: isPathHidden(item.path),
                  isBinary: binary,
                  mimeType: getMimeType(item.path),
                  type: getFileType(item.path),
                };
              } catch {
                // ignore individual blob fetch error
              }
            })
          );
        }
      }

      if (Object.keys(filesRecord).length === 0) {
        res.status(400).json({
          success: false,
          message: 'রিপোজিটরি থেকে কোনো ফাইল ডাউনলোড করা যায়নি।',
        });
        return;
      }

      const repaired = autoRepairSiteFiles(filesRecord);
      const mergedFiles = repaired.files;
      const repairedAuditInput = Object.values(mergedFiles).map(f => ({
        path: f.path,
        content: f.isBinary ? '[binary]' : f.content,
        size: f.size,
      }));
      const mergedBytes = Object.values(mergedFiles).reduce((acc, f) => acc + (Number(f.size) || 0), 0);

      const audit = auditFolderFiles(repairedAuditInput);
      if (audit.errors.length > 0 && !audit.entryPointFound) {
        res.status(400).json({
          success: false,
          message: audit.errors[0],
        });
        return;
      }

      res.json({
        success: true,
        repoOwner: parsed.owner,
        repoName: parsed.repo,
        branch: resolvedBranch,
        isPrivate: isRepoPrivate,
        files: mergedFiles,
        rootFile: audit.entryPointFound || 'index.html',
        runtimeType: audit.detectedRuntime || 'static',
        totalFiles: Object.keys(mergedFiles).length,
        hiddenFilesCount: audit.hiddenCount,
        repairedFilesCount: repaired.repairedPaths.length,
        totalSizeKb: Math.max(1, Math.ceil(mergedBytes / 1024)),
        warnings: [...(audit.warnings || []), ...repaired.repairLogs],
      });
    } catch (err) {
      console.error('GitHub import error:', err);
      res.status(500).json({
        success: false,
        message: 'GitHub থেকে রিপোজিটরি ক্লোন করতে সমস্যা হয়েছে। ইন্টারনেট ও লিংক যাচাই করুন।',
      });
    }
  });

  // =========================================================================
  // STANDALONE HOSTED WEBSITE SERVING (/site/:slug, /d/:domain, & Custom Host)
  // Renders frontend & executes Node/Python/PHP/Vercel-Serverless seamlessly
  // =========================================================================
  async function serveHostedSiteRequest(
    req: express.Request,
    res: express.Response,
    site: HostedSite | undefined,
    notFoundLabel: string,
    subPathRaw: string,
    mountPrefix: string
  ) {
    if (!site) {
      res.status(404).type('html').send(`<!DOCTYPE html>
<html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>404 - Site Not Found</title>
<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:system-ui,sans-serif;background:#090d16;color:#f8fafc;padding:20px;text-align:center;}
.box{max-width:440px;padding:32px;border-radius:18px;background:#111827;border:1px solid #1f2937;}h1{color:#f43f5e;margin:0 0 8px;}p{color:#94a3b8;font-size:14px;}</style></head>
<body><div class="box"><h1>404</h1><p><strong>${notFoundLabel}</strong> ঠিকানায় কোনো ওয়েবসাইট খুঁজে পাওয়া যায়নি।</p></div></body></html>`);
      return;
    }

    const owner = db.users.find(u => u.id === site.userId);
    const isOwnerSuspended = Boolean(owner && owner.role !== 'admin' && owner.status === 'suspended');
    const isOwnerExpired = Boolean(owner && owner.role !== 'admin' && isUserExpired(owner));
    if (site.status === 'paused' || isOwnerSuspended || isOwnerExpired) {
      const reason = isOwnerSuspended ? 'suspended' : isOwnerExpired ? 'expired' : 'paused';
      const cfg = getEnrichedConfig();
      res.status(503).type('html').send(
        renderSiteUnavailableHtml({
          siteName: site.name,
          reason,
          ownerName: cfg.masterAdminName || 'NIGHT HEX',
          ownerTelegramUrl: cfg.masterAdminTelegram || 'https://t.me/NightHex_X',
          ownerTelegramHandle: cfg.masterAdminTelegramHandle || '@NightHex_X',
          brandName: cfg.brandName || 'NIGHTHOST',
        })
      );
      return;
    }

    const subPath = subPathRaw.replace(/^\/+/, '');
    const isPreviewReq = req.query._preview !== undefined;

    // SSRF-safe external image proxy (bypasses hotlink Referer/CORP blocks for hosted sites)
    if (subPath === '__nh_img_proxy') {
      const targetUrl = String(req.query.url || '').trim();
      const safe = targetUrl ? await isSafePublicUrl(targetUrl) : false;
      if (!safe) {
        res.status(403).json({ error: 'Blocked unsafe or invalid image URL' });
        return;
      }
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 9000);
      try {
        const upstream = await fetch(targetUrl, {
          method: 'GET',
          headers: {
            'User-Agent': 'Mozilla/5.0 (compatible; NIGHTHOST-MediaProxy/1.0)',
            Accept: 'image/avif,image/webp,image/png,image/jpeg,image/svg+xml,image/*,*/*;q=0.8',
          },
          signal: controller.signal,
        });
        if (!upstream.ok) {
          res.status(502).end();
          return;
        }
        const ct = String(upstream.headers.get('content-type') || '').toLowerCase();
        const imgBuf = Buffer.from(await upstream.arrayBuffer());
        if (imgBuf.byteLength === 0 || imgBuf.byteLength > 5 * 1024 * 1024) {
          res.status(502).end();
          return;
        }
        const isImgMime = ct.startsWith('image/');
        const looksLikeSvg = ct.includes('svg') || imgBuf.subarray(0, 128).toString('utf-8').toLowerCase().includes('<svg');
        const looksLikeRaster =
          (imgBuf[0] === 0x89 && imgBuf[1] === 0x50) || // PNG
          (imgBuf[0] === 0xff && imgBuf[1] === 0xd8) || // JPEG
          (imgBuf[0] === 0x47 && imgBuf[1] === 0x49) || // GIF
          (imgBuf.subarray(0, 4).toString('ascii') === 'RIFF'); // WEBP
        if (!isImgMime && !looksLikeSvg && !looksLikeRaster) {
          res.status(415).end();
          return;
        }
        res.status(200);
        res.setHeader('Content-Type', isImgMime ? ct : looksLikeSvg ? 'image/svg+xml' : 'image/png');
        res.setHeader('Cache-Control', 'public, max-age=600');
        res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
        res.setHeader('X-Content-Type-Options', 'nosniff');
        res.send(imgBuf);
      } catch {
        res.status(502).end();
      } finally {
        clearTimeout(timer);
      }
      return;
    }

    // CORS-safe external API relay for hosted HTML/JS/PHP frontends
    if (subPath === '__nh_relay') {
      if (req.method === 'OPTIONS') {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,HEAD,OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', '*');
        res.status(204).end();
        return;
      }

      const targetUrl = String(req.query.url || '').trim();
      const safe = targetUrl ? await isSafePublicUrl(targetUrl) : false;
      if (!safe) {
        res.status(403).json({ error: 'Blocked unsafe or invalid external relay URL' });
        return;
      }

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 12000);
      try {
        const bodyBuf = await readRawRequestBody(req);
        const relayHeaders: Record<string, string> = {
          'User-Agent': 'NIGHTHOST-Relay/1.0',
          Accept: String(req.headers.accept || '*/*'),
        };
        if (req.headers['content-type']) {
          relayHeaders['Content-Type'] = String(req.headers['content-type']);
        }
        const upstream = await fetch(targetUrl, {
          method: req.method,
          headers: relayHeaders,
          body: bodyBuf.length > 0 ? new Uint8Array(bodyBuf) : undefined,
          signal: controller.signal,
        });
        const respBuf = Buffer.from(await upstream.arrayBuffer());
        res.status(upstream.status);
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Content-Type', upstream.headers.get('content-type') || 'application/octet-stream');
        res.send(respBuf);
      } catch (relayErr) {
        res.status(502).json({
          error: relayErr instanceof Error ? relayErr.message : 'Upstream relay request failed',
        });
      } finally {
        clearTimeout(timer);
      }
      return;
    }

    if (!subPath && req.method === 'GET' && !isPreviewReq) {
      site.visitsCount = (site.visitsCount || 0) + 1;
      scheduleBackgroundSaveDb(db);
    }

    // Hydrate hosted files on demand (LRU cache -> disk blob -> Supabase Storage) so RAM stays ultra lean
    const hydratedSite = await hydrateSiteFilesAsync(site);

    // 1. Check if site has a real Node.js or Python backend runtime
    const runtimeMeta = siteRuntime.getSiteRuntimeMeta(hydratedSite);
    if (runtimeMeta.hasBackend) {
      let rt = await siteRuntime.ensureRunning(hydratedSite);
      // Bounded automatic 1-shot AI + Rule Auto-Heal if backend crashed on startup (once per site.updatedAt)
      if (rt && rt.status === 'error') {
        const attemptKey = `${site.id}:${site.updatedAt}`;
        if (!autoHealAttemptedKeys.has(attemptKey) && !/RENDER_OOM/i.test(rt.errorMessage || '')) {
          autoHealAttemptedKeys.add(attemptKey);
          const preBackupFiles: Record<string, SiteFile> = {};
          for (const [k, f] of Object.entries(hydratedSite.files || {})) {
            preBackupFiles[k] = { ...f };
          }
          const autoHeal = await runSiteAutoHeal({
            files: hydratedSite.files,
            rootFile: hydratedSite.rootFile,
            runtimeType: runtimeMeta.runtime,
            errorLogs: rt.logs || [],
            errorMessage: rt.errorMessage,
            preferAi: true,
          });
          if (autoHeal.healed) {
            site.preHealBackup = {
              createdAt: new Date().toISOString(),
              reasonBn: 'সার্ভার স্টার্টআপ ক্র্যাশের পর স্বয়ংক্রিয় কোড অটো-হিল',
              files: preBackupFiles,
              rootFile: site.rootFile,
            };
            site.autoFixReports = [...autoHeal.reports, ...(site.autoFixReports || [])].slice(0, 15);
            site.files = autoHeal.files;
            site.repairedFilesCount = (site.repairedFilesCount || 0) + autoHeal.reports.length;
            site.updatedAt = new Date().toISOString();
            const patchedFull: HostedSite = { ...site, files: autoHeal.files };
            persistSiteBlob(patchedFull);
            saveDb(db);
            syncSiteToB2Pool(getAllMergedB2Nodes(), patchedFull).catch(() => {});
            syncSiteToSupabasePool(getAllMergedSupabaseNodes(), patchedFull).catch(() => {});
            rt = await siteRuntime.restartSite(patchedFull);
          }
        }
      }
      if (rt && rt.status === 'running') {
        try {
          const origUrl = req.originalUrl || '';
          const qIdx = origUrl.indexOf('?');
          let queryStr = qIdx >= 0 ? origUrl.slice(qIdx) : '';
          if (queryStr) {
            const params = new URLSearchParams(queryStr.slice(1));
            params.delete('_preview');
            const cleaned = params.toString();
            queryStr = cleaned ? `?${cleaned}` : '';
          }

          const targetUrl = `http://127.0.0.1:${rt.port}/${subPath}${queryStr}`;
          const fwdHeaders: Record<string, string> = {};
          for (const [hk, hv] of Object.entries(req.headers)) {
            if (!hv) continue;
            const low = hk.toLowerCase();
            if (['host', 'connection', 'content-length', 'accept-encoding'].includes(low)) continue;
            fwdHeaders[hk] = Array.isArray(hv) ? hv.join(', ') : String(hv);
          }

          let bodyPayload: Buffer | undefined;
          if (!['GET', 'HEAD'].includes(req.method.toUpperCase())) {
            const chunks: Buffer[] = [];
            for await (const chunk of req) {
              chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
            }
            if (chunks.length > 0) {
              bodyPayload = Buffer.concat(chunks);
            }
          }

          const proxyRes = await fetch(targetUrl, {
            method: req.method,
            headers: fwdHeaders,
            body: bodyPayload ? new Uint8Array(bodyPayload) : undefined,
            redirect: 'manual',
          });

          const contentType = proxyRes.headers.get('content-type') || 'application/octet-stream';
          res.status(proxyRes.status);

          const rawSetCookies =
            typeof (proxyRes.headers as unknown as { getSetCookie?: () => string[] }).getSetCookie === 'function'
              ? (proxyRes.headers as unknown as { getSetCookie: () => string[] }).getSetCookie()
              : [];

          proxyRes.headers.forEach((val, key) => {
            const low = key.toLowerCase();
            if (['content-length', 'transfer-encoding', 'connection', 'content-encoding', 'set-cookie', 'x-frame-options'].includes(low)) return;
            if (low === 'content-security-policy') {
              const relaxed = val.replace(/frame-ancestors\s+[^;]+;?/gi, '').trim();
              if (relaxed) res.setHeader(key, relaxed);
              return;
            }
            if (low === 'location' && mountPrefix && val.startsWith('/') && !val.startsWith('/site/') && !val.startsWith('/u/') && !val.startsWith('/d/')) {
              res.setHeader(key, `${mountPrefix}${val}`);
              return;
            }
            res.setHeader(key, val);
          });

          if (rawSetCookies.length > 0) {
            const scopedCookies = rawSetCookies.map(c =>
              mountPrefix ? c.replace(/;\s*Path=\/(?=;|$)/gi, `; Path=${mountPrefix}`) : c
            );
            res.setHeader('Set-Cookie', scopedCookies);
          } else {
            const singleCookie = proxyRes.headers.get('set-cookie');
            if (singleCookie) {
              res.setHeader(
                'Set-Cookie',
                mountPrefix
                  ? singleCookie.replace(/;\s*Path=\/(?=;|$)/gi, `; Path=${mountPrefix}`)
                  : singleCookie
              );
            }
          }

          const buf = Buffer.from(await proxyRes.arrayBuffer());
          if (contentType.includes('text/html')) {
            const html = rewriteHtmlForSiteProxy(buf.toString('utf-8'), hydratedSite.slug, '', mountPrefix);
            res.setHeader('Content-Type', 'text/html; charset=utf-8');
            res.send(html);
            return;
          }
          if (contentType.includes('text/css')) {
            const css = rewriteCssUrls(buf.toString('utf-8'), hydratedSite.slug, mountPrefix);
            res.setHeader('Content-Type', 'text/css; charset=utf-8');
            res.send(css);
            return;
          }
          res.send(buf);
          return;
        } catch (proxyErr) {
          const staticFallback = subPath ? resolveHostedFile(hydratedSite, subPath) : undefined;
          if (!staticFallback) {
            const msg = proxyErr instanceof Error ? proxyErr.message : 'Backend proxy connection error';
            const diag = diagnoseRuntimeError(rt.logs || [msg], runtimeMeta.runtime, runtimeMeta.backendEntry);
            const rawLogs = (rt.logs || []).join('\n') || msg;
            res.status(502).type('html').send(`<!DOCTYPE html>
<html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>502 - Runtime Error</title>
<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:system-ui,sans-serif;background:#090d16;color:#f8fafc;padding:20px;}
.box{max-width:720px;width:100%;padding:28px;border-radius:16px;background:#111827;border:1px solid #334155;}h2{color:#fb7185;margin:0 0 8px;}p{color:#cbd5e1;font-size:13px;}
.fix{margin:14px 0;padding:14px 16px;border-radius:12px;background:#0f172a;border:1px solid #0284c7;}
.fix h3{margin:0 0 6px;color:#38bdf8;font-size:14px;}.fix ul{margin:6px 0 0 18px;padding:0;font-size:12px;color:#e2e8f0;line-height:1.6;}
.bar{display:flex;align-items:center;justify-content:space-between;margin:10px 0 6px;}
.btn{background:#0284c7;color:#fff;border:none;padding:7px 14px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;}
.btn:hover{background:#0ea5e9;}
pre{background:#030712;color:#fca5a5;padding:14px;border-radius:10px;overflow:auto;font-size:12px;white-space:pre-wrap;margin:0;}</style></head>
<body><div class="box"><h2>⚠️ Backend Runtime Error (${runtimeMeta.runtime.toUpperCase()})</h2><p>${msg}</p>
<div class="fix"><h3>🛠️ প্রজেক্টে যেভাবে সমাধান করবেন (${diag.titleBn})</h3><p>${diag.causeBn}</p><ul>${diag.stepsBn.map(s => `<li>${s}</li>`).join('')}</ul></div>
<div class="bar"><span style="font-size:12px;color:#94a3b8;">Runtime Error Log</span><button class="btn" onclick="copyErr(this)">📋 এরর কপি করুন</button></div>
<pre id="errlog">${rawLogs.replace(/</g, '&lt;')}</pre></div>
<script>function copyErr(b){var t=document.getElementById('errlog').innerText;if(navigator.clipboard){navigator.clipboard.writeText(t).then(function(){b.innerText='✅ কপি হয়েছে!';setTimeout(function(){b.innerText='📋 এরর কপি করুন';},2000);});}}</script></body></html>`);
            return;
          }
        }
      } else if (rt && rt.status === 'error') {
        const staticAsset = subPath ? resolveHostedFile(hydratedSite, subPath) : undefined;
        const isMissingPythonBinary =
          runtimeMeta.runtime === 'python' &&
          /ENOENT/i.test(rt.errorMessage || '') &&
          Boolean(resolveHostedFile(hydratedSite, 'index.html') || resolveHostedFile(hydratedSite, 'dist/index.html'));
        if (!staticAsset && !isMissingPythonBinary) {
          const isOomOrLoad = /RENDER_OOM|HIGH_LOAD/i.test(rt.errorMessage || '');
          const diag = diagnoseRuntimeError(rt.logs || [rt.errorMessage || ''], runtimeMeta.runtime, runtimeMeta.backendEntry);
          const isApiLike = req.method !== 'GET' || subPath.startsWith('api/') || (req.headers.accept || '').includes('application/json');
          if (isApiLike) {
            res.status(isOomOrLoad ? 503 : 500).json({
              code: isOomOrLoad ? 'HIGH_LOAD' : 'RUNTIME_ERROR',
              error: rt.errorMessage || 'Backend runtime crashed',
              message: rt.errorMessage || 'Backend runtime crashed',
              runtime: runtimeMeta.runtime,
              diagnostic: diag,
              logs: rt.logs,
            });
            return;
          }
          const rawLogs = rt.logs.join('\n') || 'No output logs';
          res.status(isOomOrLoad ? 503 : 500).type('html').send(`<!DOCTYPE html>
<html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${hydratedSite.name} - Runtime Error</title>
<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:system-ui,sans-serif;background:#090d16;color:#f8fafc;padding:20px;}
.box{max-width:740px;width:100%;padding:28px;border-radius:16px;background:#111827;border:1px solid #ef4444;}h2{color:#fb7185;margin:0 0 8px;}p{color:#cbd5e1;font-size:13px;}
.fix{margin:14px 0;padding:14px 16px;border-radius:12px;background:#0f172a;border:1px solid #0284c7;}
.fix h3{margin:0 0 6px;color:#38bdf8;font-size:14px;}.fix ul{margin:6px 0 0 18px;padding:0;font-size:12px;color:#e2e8f0;line-height:1.6;}
.bar{display:flex;align-items:center;justify-content:space-between;margin:10px 0 6px;}
.btn{background:#0284c7;color:#fff;border:none;padding:7px 14px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;}
.btn:hover{background:#0ea5e9;}
pre{background:#030712;color:#fda4af;padding:14px;border-radius:10px;overflow:auto;font-size:12px;max-height:360px;white-space:pre-wrap;margin:0;}</style></head>
<body><div class="box"><h2>⚠️ Backend Startup Error (${runtimeMeta.runtime.toUpperCase()}: ${runtimeMeta.backendEntry})</h2><p>${rt.errorMessage || 'Process failed to start.'}</p>
<div class="fix"><h3>🛠️ প্রজেক্টে যেভাবে সমাধান করবেন — ${diag.titleBn}</h3><p>${diag.causeBn}</p><ul>${diag.stepsBn.map(s => `<li>${s}</li>`).join('')}</ul></div>
<div class="bar"><span style="font-size:12px;color:#94a3b8;">Startup Error Log</span><button class="btn" onclick="copyErr(this)">📋 এরর কপি করুন</button></div>
<pre id="errlog">${rawLogs.replace(/</g, '&lt;')}</pre></div>
<script>function copyErr(b){var t=document.getElementById('errlog').innerText;if(navigator.clipboard){navigator.clipboard.writeText(t).then(function(){b.innerText='✅ কপি হয়েছে!';setTimeout(function(){b.innerText='📋 এরর কপি করুন';},2000);});}}</script></body></html>`);
          return;
        }
      }
    }

    // 2. Static / HTML / SPA / Real PHP Entry Point & Asset Serving
    if (!subPath) {
      if (hydratedSite.type === 'single-file' && hydratedSite.singleFileConfig?.language === 'php') {
        const phpRaw = hydratedSite.singleFileConfig.rawContent || hydratedSite.files[hydratedSite.rootFile || 'index.php']?.content || '';
        await servePhpRequest(req, res, hydratedSite, phpRaw, '/' + (hydratedSite.rootFile || 'index.php'), mountPrefix);
        return;
      }

      const rootFileObj =
        hydratedSite.files[hydratedSite.rootFile || 'index.html'] ||
        Object.values(hydratedSite.files).find(f => f.path.toLowerCase().endsWith('.php'));
      if (
        rootFileObj &&
        !rootFileObj.isBinary &&
        (rootFileObj.path.toLowerCase().endsWith('.php') || rootFileObj.content.includes('<?'))
      ) {
        await servePhpRequest(req, res, hydratedSite, rootFileObj.content, '/' + rootFileObj.path, mountPrefix);
        return;
      }

      const html = prepareStandaloneHtmlForServer(hydratedSite, undefined, mountPrefix);
      sendStaticPayloadWithCompression(req, res, html, 'text/html; charset=utf-8', undefined, 'no-cache');
      return;
    }

    const matchedFile = resolveHostedFile(hydratedSite, subPath);

    if (!matchedFile) {
      if (!subPath.includes('.')) {
        if (hydratedSite.type === 'single-file' && hydratedSite.singleFileConfig?.language === 'php') {
          const phpRaw = hydratedSite.singleFileConfig.rawContent || hydratedSite.files[hydratedSite.rootFile || 'index.php']?.content || '';
          await servePhpRequest(req, res, hydratedSite, phpRaw, '/' + (hydratedSite.rootFile || 'index.php'), mountPrefix);
          return;
        }
        const rootFileObj = hydratedSite.files[hydratedSite.rootFile || 'index.html'];
        if (
          rootFileObj &&
          !rootFileObj.isBinary &&
          (rootFileObj.path.toLowerCase().endsWith('.php') || rootFileObj.content.includes('<?'))
        ) {
          await servePhpRequest(req, res, hydratedSite, rootFileObj.content, '/' + rootFileObj.path, mountPrefix);
          return;
        }

        const html = prepareStandaloneHtmlForServer(hydratedSite, undefined, mountPrefix);
        sendStaticPayloadWithCompression(req, res, html, 'text/html; charset=utf-8', undefined, 'no-cache');
        return;
      }
      res.status(404).send('Asset not found');
      return;
    }

    const etag = `W/"${hydratedSite.id}-${matchedFile.size}-${hydratedSite.updatedAt}"`;
    if (matchedFile.isBinary) {
      if (!isPreviewReq && req.headers['if-none-match'] === etag) {
        res.status(304).end();
        return;
      }
      res.setHeader('Content-Type', matchedFile.mimeType || getMimeType(matchedFile.path));
      if (!isPreviewReq) {
        res.setHeader('ETag', etag);
        res.setHeader('Cache-Control', 'public, max-age=300');
      }
      res.send(Buffer.from(matchedFile.content, 'base64'));
      return;
    }

    const lowerPath = matchedFile.path.toLowerCase();

    if (lowerPath.endsWith('.php')) {
      await servePhpRequest(req, res, hydratedSite, matchedFile.content, '/' + matchedFile.path, mountPrefix);
      return;
    }

    if (lowerPath.endsWith('.html') || lowerPath.endsWith('.htm')) {
      if (matchedFile.content.includes('<?')) {
        await servePhpRequest(req, res, hydratedSite, matchedFile.content, '/' + matchedFile.path, mountPrefix);
        return;
      }
      sendStaticPayloadWithCompression(
        req,
        res,
        prepareStandaloneHtmlForServer(hydratedSite, matchedFile.path, mountPrefix),
        'text/html; charset=utf-8',
        undefined,
        'no-cache'
      );
      return;
    }

    if (lowerPath.endsWith('.css')) {
      if (!isPreviewReq && req.headers['if-none-match'] === etag) {
        res.status(304).end();
        return;
      }
      const cleanedCss = matchedFile.content
        .replace(/^\s*@import\s+['"]tailwindcss(?:\/[^'"]*)?['"]\s*;\s*$/gim, '/* tailwindcss via CDN */')
        .replace(/^\s*@tailwind\s+(?:base|components|utilities)\s*;\s*$/gim, '');
      sendStaticPayloadWithCompression(
        req,
        res,
        rewriteCssUrls(cleanedCss, hydratedSite.slug, mountPrefix),
        'text/css; charset=utf-8',
        !isPreviewReq ? etag : undefined,
        !isPreviewReq ? 'public, max-age=120' : undefined
      );
      return;
    }

    if (lowerPath.endsWith('.tsx') || lowerPath.endsWith('.ts') || lowerPath.endsWith('.jsx')) {
      try {
        const loader = lowerPath.endsWith('.tsx') ? 'tsx' : lowerPath.endsWith('.jsx') ? 'jsx' : 'ts';
        const cssImportReplaced = matchedFile.content.replace(
          /^\s*import\s+['"](\.[^'"]+\.css)['"]\s*;?\s*$/gm,
          (_m, cssRel) =>
            `if(typeof document!=='undefined'){const l=document.createElement('link');l.rel='stylesheet';l.href=new URL(${JSON.stringify(cssRel)},import.meta.url).href;document.head.appendChild(l);}`
        );
        const compiled = await esbuildTransform(cssImportReplaced, { loader, format: 'esm', jsx: 'automatic' });
        sendStaticPayloadWithCompression(req, res, compiled.code, 'application/javascript; charset=utf-8');
        return;
      } catch {
        // Fallback to raw content if transform fails
      }
    }

    if (!isPreviewReq && req.headers['if-none-match'] === etag) {
      res.status(304).end();
      return;
    }
    sendStaticPayloadWithCompression(
      req,
      res,
      matchedFile.content,
      matchedFile.mimeType || getMimeType(matchedFile.path),
      !isPreviewReq ? etag : undefined,
      !isPreviewReq ? 'public, max-age=120' : undefined
    );
  }

  // Primary slug routing (/site/:slug)
  app.all(['/site/:slug', '/site/:slug/*'], async (req, res) => {
    const slug = String(req.params.slug || '').toLowerCase();
    const site =
      siteBySlugCache.get(slug) ||
      db.sites.find(s => s.slug.toLowerCase() === slug || s.customPath?.toLowerCase() === slug);
    const subPathRaw = (req.params as Record<string, string>)[0] || '';
    await serveHostedSiteRequest(req, res, site, `/site/${slug}`, subPathRaw, site ? `/site/${site.slug}` : `/site/${slug}`);
  });

  // Personal Subdomain Routing (/u/:subdomain/:slug) — works on all single-host deployments
  app.get('/u/:subdomain', (req, res) => {
    const sub = String(req.params.subdomain || '').toLowerCase();
    const owner = db.users.find(u => u.subdomain?.toLowerCase() === sub);
    const firstSite = owner
      ? db.sites.find(s => s.userId === owner.id && s.status === 'online') || db.sites.find(s => s.userId === owner.id)
      : undefined;
    if (firstSite) {
      res.redirect(302, `/u/${sub}/${firstSite.slug}/`);
      return;
    }
    res.status(404).type('html').send(`<!DOCTYPE html><html lang="bn"><head><meta charset="utf-8"><title>404</title></head><body style="font-family:sans-serif;background:#090d16;color:#f8fafc;display:flex;align-items:center;justify-content:center;min-height:100vh;"><p>/u/${sub} সাবডোমেইনে কোনো লাইভ সাইট নেই।</p></body></html>`);
  });

  app.all(['/u/:subdomain/:slug', '/u/:subdomain/:slug/*'], async (req, res) => {
    const sub = String(req.params.subdomain || '').toLowerCase();
    const slug = String(req.params.slug || '').toLowerCase();
    const owner = db.users.find(u => u.subdomain?.toLowerCase() === sub);
    const site = owner
      ? db.sites.find(
          s =>
            s.userId === owner.id &&
            (s.slug.toLowerCase() === slug || s.customPath?.toLowerCase() === slug)
        )
      : undefined;
    const subPathRaw = (req.params as Record<string, string>)[0] || '';
    const effectivePrefix = site ? `/u/${sub}/${site.slug}` : `/u/${sub}/${slug}`;
    await serveHostedSiteRequest(req, res, site, effectivePrefix, subPathRaw, effectivePrefix);
  });

  // Subdomain-style Custom Domain Path Routing (/d/:domain)
  app.all(['/d/:domain', '/d/:domain/*'], async (req, res) => {
    const rawDom = String(req.params.domain || '').toLowerCase();
    const cleanDom = normalizeCustomDomain(rawDom);
    const site =
      (cleanDom && siteByDomainCache.get(cleanDom.toLowerCase())) ||
      db.sites.find(
        s =>
          (s.customDomain && s.customDomain.toLowerCase() === cleanDom.toLowerCase()) ||
          s.slug.toLowerCase() === rawDom
      );
    const subPathRaw = (req.params as Record<string, string>)[0] || '';
    const effectiveDomain = site?.customDomain || cleanDom || rawDom;
    await serveHostedSiteRequest(req, res, site, `/d/${effectiveDomain}`, subPathRaw, `/d/${effectiveDomain}`);
  });

  // Incoming Host-Header Custom Domain / Wildcard User Subdomain Interceptor
  app.use((req, res, next) => {
    if (
      req.path.startsWith('/api/') ||
      req.path.startsWith('/site/') ||
      req.path.startsWith('/u/') ||
      req.path.startsWith('/d/')
    ) {
      return next();
    }
    const matchedRoute = resolveHostHeaderRoute(req);
    if (!matchedRoute) {
      return next();
    }
    serveHostedSiteRequest(
      req,
      res,
      matchedRoute.site,
      matchedRoute.label,
      matchedRoute.subPathRaw,
      matchedRoute.mountPrefix
    ).catch(next);
  });

  // Structured JSON error handler for /api/* routes (prevents HTML 413/400/500 pages)
  app.use((err: unknown, req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (res.headersSent) {
      return next(err);
    }
    const errObj = (err && typeof err === 'object' ? err : {}) as {
      type?: string;
      status?: number;
      statusCode?: number;
      message?: string;
    };
    const status = Number(errObj.statusCode || errObj.status || 500);
    if (req.path.startsWith('/api/')) {
      if (errObj.type === 'entity.too.large' || status === 413) {
        res.status(413).json({
          success: false,
          message:
            'প্রজেক্টের সাইজ সার্ভার সীমা (100MB) অতিক্রম করেছে। বড় ভিডিও/মিডিয়া বা অপ্রয়োজনীয় ফাইল বাদ দিয়ে আবার আপলোড করুন।',
        });
        return;
      }
      if (errObj.type === 'entity.parse.failed' || (err instanceof SyntaxError && status === 400)) {
        res.status(400).json({
          success: false,
          message: 'রিকোয়েস্ট ডেটা অসম্পূর্ণ বা ক্ষতিগ্রস্ত হয়েছে। অনুগ্রহ করে আবার ডিপ্লয় চেষ্টা করুন।',
        });
        return;
      }
      res.status(status >= 400 && status < 600 ? status : 500).json({
        success: false,
        message: errObj.message || 'সার্ভারে অপ্রত্যাশিত ত্রুটি ঘটেছে।',
      });
      return;
    }
    next(err);
  });

  // =========================================================================
  // VITE MIDDLEWARE (Dev) OR STATIC DIST (Production)
  // =========================================================================
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false, ws: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res, next) => {
      if (
        req.path.startsWith('/api/') ||
        req.path.startsWith('/site/') ||
        req.path.startsWith('/u/') ||
        req.path.startsWith('/d/')
      ) {
        return next();
      }
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const httpServer = app.listen(port, '0.0.0.0', () => {
    console.log(`🚀 NIGHTHOST Server running on http://0.0.0.0:${port}`);
    // Verify connected Backblaze B2 & Supabase env pools & restore core state if ephemeral disk rebooted.
    const sbEnvNodes = parseSupabaseEnvNodes(process.env);
    const b2EnvNodes = parseB2EnvNodes(process.env);
    if (sbEnvNodes.length > 0 || b2EnvNodes.length > 0) {
      Promise.all([
        ...sbEnvNodes.map(async n => {
          if (!n.serviceRoleKey) return;
          const res = await verifyAndEnsureSupabaseBucket(n.url, n.serviceRoleKey, n.bucketName);
          envNodeRuntimeStatus.set(n.id, {
            status: res.ok ? 'connected' : 'error',
            lastCheckedAt: new Date().toISOString(),
            errorMessage: res.error,
          });
        }),
        ...b2EnvNodes.map(async n => {
          if (!n.applicationKey) return;
          const res = await verifyAndEnsureB2Bucket(n.keyId, n.applicationKey, n.bucketName);
          envB2RuntimeStatus.set(n.id, {
            status: res.ok ? 'connected' : 'error',
            lastCheckedAt: new Date().toISOString(),
            errorMessage: res.error,
          });
        }),
      ])
        .then(async () => {
          const allSbNodes = getAllMergedSupabaseNodes();
          const allB2Nodes = getAllMergedB2Nodes();
          const hasLocalUsers = db.users.some(u => u.role === 'user');
          if (db.sites.length === 0 && !hasLocalUsers) {
            type RemoteCoreShape = {
              config?: PlatformConfig;
              users?: User[];
              subAdmins?: SubAdmin[];
              sites?: HostedSite[];
              auditLogs?: AuditLogEntry[];
              popupMessages?: UserPopupMessage[];
            };
            const remoteCore =
              (await fetchCoreStateFromB2<RemoteCoreShape>(allB2Nodes)) ||
              (await fetchCoreStateFromSupabase<RemoteCoreShape>(allSbNodes));
            if (remoteCore && ((Array.isArray(remoteCore.sites) && remoteCore.sites.length > 0) || (Array.isArray(remoteCore.users) && remoteCore.users.some(u => u.role === 'user')))) {
              if (remoteCore.config) db.config = { ...DEFAULT_CONFIG, ...remoteCore.config };
              if (Array.isArray(remoteCore.users) && remoteCore.users.length > 0) {
                const envOwner = buildEnvOwnerIfConfigured();
                db.users = remoteCore.users;
                if (envOwner && !db.users.some(u => u.role === 'admin')) {
                  db.users.unshift(envOwner);
                }
              }
              if (Array.isArray(remoteCore.subAdmins)) db.subAdmins = remoteCore.subAdmins;
              if (Array.isArray(remoteCore.sites)) db.sites = remoteCore.sites.map(stripSiteFileContents);
              if (Array.isArray(remoteCore.auditLogs)) db.auditLogs = remoteCore.auditLogs;
              if (Array.isArray(remoteCore.popupMessages)) db.popupMessages = remoteCore.popupMessages;
              rebuildSiteIndex(db);
              writeDbToDisk(db);
              broadcastSync();
              console.log(`☁️ Restored ${db.users.length} users & ${db.sites.length} sites metadata from Cloud Core Pool.`);
            }
          }
          invalidateBootstrapCache();
        })
        .catch(() => {});
    }
  });

  const shutdown = () => {
    siteRuntime.stopAll();
    for (const client of sseClients) {
      try {
        client.res.end();
      } catch {
        // ignore
      }
    }
    sseClients.clear();
    httpServer.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 250).unref();
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

startServer();
