import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  isPathHidden,
  getFileType,
  isBinaryFile,
  getMimeType,
  auditFolderFiles,
  slugify,
  emulatePhpExecution,
  prepareStandaloneHtmlForServer,
  detectProjectRuntime,
  resolveHostedFile,
  rewriteCssUrls,
  rewriteHtmlForSiteProxy,
  diagnoseRuntimeError,
  autoRepairSiteFiles,
  assessProjectCloudFootprint,
  optimizeProjectToRunnableCore,
} from './siteEngine';
import {
  executePhpCode,
  resolveSandboxedSitePath,
  isPrivateOrReservedIp,
  isSafePublicUrl,
} from './phpRuntime';
import { siteRuntime, buildIsolatedChildEnv } from './siteRuntime';
import { storage } from './storage';
import {
  formatStorageFromMb,
  formatStorageFromKb,
  getRoleDisplayLabel,
  normalizeCustomDomain,
  normalizeUserSubdomain,
  isReservedSubdomain,
  sanitizeExternalLinkUrl,
  computePoolAllocationSummary,
  renderSiteUnavailableHtml,
  formatHttpTransportError,
  buildSubdomainUrls,
  SERVER_POOL_PRESETS,
} from './format';
import {
  parseSupabaseEnvNodes,
  mergeSupabaseNodes,
  calculatePoolCapacitySummary,
  generateRenderEnvVariables,
} from './supabaseStorage';
import {
  parseB2EnvNodes,
  mergeB2Nodes,
  sanitizeB2NodeForClient,
  calculateB2PoolSummary,
  generateCombinedRenderEnvVariables,
} from './b2Storage';
import { applyDeterministicHealRules, runSiteAutoHeal } from './aiHealer';
import { buildZipBuffer, crc32, extractZipEntries } from './zip';
import { HostedSite } from '../types';

test('isPathHidden correctly identifies hidden and config files', () => {
  assert.equal(isPathHidden('.env'), true);
  assert.equal(isPathHidden('.htaccess'), true);
  assert.equal(isPathHidden('.gitignore'), true);
  assert.equal(isPathHidden('assets/.secret_key'), true);
  assert.equal(isPathHidden('index.html'), false);
  assert.equal(isPathHidden('assets/style.css'), false);
  assert.equal(isPathHidden('js/main.js'), false);
});

test('getFileType, isBinaryFile, and getMimeType detect extensions accurately', () => {
  assert.equal(getFileType('index.html'), 'html');
  assert.equal(getFileType('style.css'), 'css');
  assert.equal(getFileType('app.js'), 'js');
  assert.equal(getFileType('api.php'), 'php');
  assert.equal(getFileType('package.json'), 'json');
  assert.equal(getFileType('logo.png'), 'image');
  assert.equal(getFileType('font.woff2'), 'font');
  assert.equal(getFileType('.env'), 'config');

  assert.equal(isBinaryFile('photo.png'), true);
  assert.equal(isBinaryFile('font.woff2'), true);
  assert.equal(isBinaryFile('index.html'), false);
  assert.equal(isBinaryFile('app.php'), false);

  assert.equal(getMimeType('style.css'), 'text/css; charset=utf-8');
  assert.equal(getMimeType('logo.png'), 'image/png');
  assert.equal(getMimeType('icon.svg'), 'image/svg+xml');
});

test('slugify transforms strings into clean url slugs', () => {
  assert.equal(slugify('NIGHTHOST App 2026!'), 'nighthost-app-2026');
  assert.equal(slugify('portfolio_2026---v1'), 'portfolio-2026-v1');
});

test('auditFolderFiles preserves hidden files and detects index entry point', () => {
  const sampleFolder = [
    { path: 'index.html', content: '<h1>Hello NIGHTHOST</h1>', size: 100 },
    { path: 'style.css', content: 'body { color: red; }', size: 50 },
    { path: '.env', content: 'DATABASE_URL=postgres://...', size: 30 },
    { path: '.htaccess', content: 'RewriteEngine On', size: 20 },
  ];

  const result = auditFolderFiles(sampleFolder);
  assert.equal(result.fileCount, 4);
  assert.equal(result.hiddenCount, 2);
  assert.equal(result.entryPointFound, 'index.html');
  assert.equal(result.errors.length, 0);
  assert.ok(result.warnings.some(w => w.includes('হিডেন ও কনফিগারেশন ফাইল')));
});

test('auditFolderFiles detects nested dist/index.html entry point', () => {
  const distFolder = [
    { path: 'dist/index.html', content: '<h1>Built App</h1>', size: 120 },
    { path: 'dist/assets/app.js', content: 'console.log(1)', size: 20 },
  ];
  const result = auditFolderFiles(distFolder);
  assert.equal(result.entryPointFound, 'dist/index.html');
  assert.equal(result.errors.length, 0);
});

test('auditFolderFiles catches missing entry points and provides diagnostics', () => {
  const brokenFolder = [
    { path: 'data.json', content: '{}', size: 10 },
    { path: 'script.js', content: 'console.log(1)', size: 20 },
  ];

  const result = auditFolderFiles(brokenFolder);
  assert.ok(result.errors.length > 0);
  assert.ok(result.errors[0].includes('কোনো রান-যোগ্য এন্ট্রি পেজ পাওয়া যায়নি'));
});

test('emulatePhpExecution evaluates variables, short echo, and string concatenation', () => {
  const phpSnippet = '<?php $name = "NightHex"; ?><h1><?= "Welcome " . $name; ?></h1>';
  const rendered = emulatePhpExecution(phpSnippet, 'Test Site');
  assert.ok(rendered.includes('<h1>Welcome NightHex</h1>'));
  assert.equal(rendered.includes('<?php'), false);
  assert.equal(rendered.includes('<?='), false);
});

test('prepareStandaloneHtmlForServer injects base tag and rewrites root-relative asset URLs without NIGHTHOST UI', () => {
  const mockSite: HostedSite = {
    id: 'site_1',
    userId: 'u_1',
    username: 'tester',
    name: 'Portfolio',
    slug: 'my-portfolio',
    description: 'Test portfolio',
    type: 'folder',
    status: 'online',
    rootFile: 'dist/index.html',
    totalFiles: 2,
    hiddenFilesCount: 0,
    totalSizeKb: 10,
    visitsCount: 1,
    bandwidthMb: 0.1,
    deploymentLogs: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    files: {
      'dist/index.html': {
        path: 'dist/index.html',
        content: '<!doctype html><html><head><link rel="stylesheet" href="/assets/app.css"></head><body><script src="/assets/app.js"></script></body></html>',
        size: 100,
        isHidden: false,
        type: 'html',
      },
    },
  };

  const served = prepareStandaloneHtmlForServer(mockSite);
  assert.ok(served.includes('<base href="/site/my-portfolio/dist/">'));
  assert.ok(served.includes('href="/site/my-portfolio/assets/app.css"'));
  assert.ok(served.includes('src="/site/my-portfolio/assets/app.js"'));
  assert.equal(served.includes('NIGHTHOST Cloud Engine'), false);
});

test('storage initializes clean without demo regular users, hardcoded admin, or default subadmins', () => {
  const users = storage.getUsers();
  assert.equal(users.some(u => u.username === 'robiul'), false);
  assert.equal(users.some(u => u.username === 'sabbir'), false);
  assert.equal(users.some(u => u.username === 'admin'), false);
  assert.equal(users.length, 0);
  assert.equal(storage.getNeedsOwnerSetup(), true);
  assert.equal(storage.getSubAdmins().length, 0);
  assert.equal(storage.getSites().length, 0);
});

test('storage approval time calculation handles 1 hour, permanent, and expired states', () => {
  const now = Date.now();
  
  const permUser = {
    id: 'u_perm',
    username: 'permuser',
    fullName: 'Perm',
    email: 'p@test.com',
    role: 'user' as const,
    status: 'approved' as const,
    storageLimitMb: 100,
    storageUsedMb: 0,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
  };
  const permResult = storage.getRemainingApprovalTime(permUser);
  assert.equal(permResult.isExpired, false);
  assert.equal(permResult.seconds, Infinity);

  const activeUser = {
    ...permUser,
    expiresAt: new Date(now + 45 * 60 * 1000).toISOString(),
  };
  const activeResult = storage.getRemainingApprovalTime(activeUser);
  assert.equal(activeResult.isExpired, false);
  assert.ok(activeResult.seconds > 2600);
  assert.ok(activeResult.label.includes('মিনিট'));

  const expiredUser = {
    ...permUser,
    expiresAt: new Date(now - 10000).toISOString(),
  };
  const expiredResult = storage.getRemainingApprovalTime(expiredUser);
  assert.equal(expiredResult.isExpired, true);
  assert.equal(expiredResult.seconds, 0);
});

test('platform config has NIGHTHOST brand name, NIGHT HEX owner, and NightHex_X Telegram', () => {
  const config = storage.getConfig();
  assert.equal(config.brandName, 'NIGHTHOST');
  assert.equal(config.masterAdminName, 'NIGHT HEX');
  assert.equal(config.masterAdminTelegram, 'https://t.me/NightHex_X');
  assert.equal(config.masterAdminTelegramHandle, '@NightHex_X');
});

test('storage user registration, deletion, and subadmin removal clean both collections', () => {
  const uniqueName = 'testuser_' + Date.now();
  const res = storage.registerUser(uniqueName, 'Test User', `${uniqueName}@test.com`, 'securePass123');
  assert.equal(res.success, true);
  assert.ok(res.user);
  assert.equal(res.user?.status, 'pending');

  // Approve with atomic quota
  const uid = res.user!.id;
  assert.equal(storage.approveUser(uid, 1, '১ ঘন্টা', 250), true);
  const approved = storage.getUsers().find(u => u.id === uid);
  assert.equal(approved?.status, 'approved');
  assert.equal(approved?.storageLimitMb, 250);

  // Delete user frees username
  assert.equal(storage.deleteUser(uid), true);
  assert.equal(storage.getUsers().some(u => u.id === uid), false);

  // Add SubAdmin and delete via deleteUser -> cleans BOTH users and subAdmins
  const subName = 'sub_del_' + Date.now();
  const subRes = storage.addSubAdmin(subName, 'Sub Del', `${subName}@mod.com`, '@sub_del', 'pass123');
  assert.equal(subRes.success, true);
  const sid = subRes.subAdmin!.id;
  assert.equal(storage.getSubAdmins().some(s => s.id === sid), true);
  assert.equal(storage.getUsers().some(u => u.id === sid), true);

  assert.equal(storage.deleteUser(sid), true);
  assert.equal(storage.getSubAdmins().some(s => s.id === sid), false);
  assert.equal(storage.getUsers().some(u => u.id === sid), false);
});

test('storage supports updateUser, audit logs, subAdmin permissions, and removal', () => {
  const uname = 'adv_user_' + Date.now();
  const reg = storage.registerUser(uname, 'Initial Name', `${uname}@test.com`, 'oldpass');
  assert.equal(reg.success, true);
  const uid = reg.user!.id;

  const updated = storage.updateUser(uid, {
    fullName: 'Updated Name',
    password: 'newpass456',
    storageLimitMb: 500,
  });
  assert.equal(updated, true);

  const found = storage.getUsers().find(u => u.id === uid);
  assert.equal(found?.fullName, 'Updated Name');
  assert.equal(found?.password, 'newpass456');
  assert.equal(found?.storageLimitMb, 500);

  const subName = 'sub_perm_' + Date.now();
  const subRes = storage.addSubAdmin(subName, 'Sub Perm', `${subName}@mod.com`, 'https://t.me/subperm', 'p123');
  assert.equal(subRes.success, true);
  const sid = subRes.subAdmin!.id;

  storage.updateSubAdminPermissions(sid, { canApproveUsers: false, canSetQuota: true });
  const updatedSub = storage.getSubAdmins().find(s => s.id === sid);
  assert.equal(updatedSub?.canApproveUsers, false);
  assert.equal(updatedSub?.canSetQuota, true);

  assert.equal(storage.removeSubAdmin(sid), true);
  assert.equal(storage.getSubAdmins().some(s => s.id === sid), false);
  assert.equal(storage.getUsers().some(u => u.id === sid), false);

  storage.updateConfig({ broadcastMessage: 'Maintenance at 12 AM' });
  assert.equal(storage.getConfig().broadcastMessage, 'Maintenance at 12 AM');

  const logs = storage.getAuditLogs();
  assert.ok(logs.some(l => l.action === 'USER_UPDATED' && l.target === uname));
  assert.ok(logs.some(l => l.action === 'SUBADMIN_REMOVED' && l.target === subName));
});

test('emulatePhpExecution is quote-aware and does not close on ?> inside PHP string literals', () => {
  const phpCode = `<?php
    $snippet = '<div>?></div>';
    echo '<h1>Safe Output</h1>';
  ?>`;
  const rendered = emulatePhpExecution(phpCode, 'Quote Test');
  assert.ok(rendered.includes('<h1>Safe Output</h1>'));
  assert.equal(rendered.includes("$snippet"), false);
  assert.equal(rendered.includes("echo '"), false);
});

test('emulatePhpExecution never leaks PDO/foreach/e(S()) raw PHP into rendered HTML', () => {
  const pdoPhp = `<?php
    function S($k){ return $k; }
    function e($v){ return htmlspecialchars($v); }
    foreach($it as $p)$pdo->prepare('UPDATE products SET stock=GREATEST(stock-?,0) WHERE id=?')->execute([$p['q'],$p['id']]);
    if(S('maint')==='1'){echo '<div>Maintenance</div>';exit;}
  ?>
  <header><span><?= e(S('name')) ?></span><span><?= array_sum($_SES ?? []) ?: "" ?></span></header>`;

  const rendered = emulatePhpExecution(pdoPhp, 'Greenora');
  assert.equal(rendered.includes('$pdo->prepare'), false);
  assert.equal(rendered.includes('foreach($it'), false);
  assert.equal(rendered.includes("e(S('name'))"), false);
  assert.equal(rendered.includes('array_sum('), false);
  assert.ok(rendered.includes('PHP DATABASE PROJECT') || rendered.includes('Greenora'));
});

test('auditFolderFiles prefers dist/index.html over raw Vite root index.html pointing to /src/main.tsx', () => {
  const viteFolder = [
    {
      path: 'index.html',
      content: '<!doctype html><html><body><div id="root"></div><script type="module" src="/src/main.tsx"></script></body></html>',
      size: 120,
    },
    {
      path: 'src/main.tsx',
      content: 'console.log("src")',
      size: 40,
    },
    {
      path: 'dist/index.html',
      content: '<!doctype html><html><body><div id="root"></div><script type="module" src="/assets/index-123.js"></script></body></html>',
      size: 130,
    },
  ];
  const result = auditFolderFiles(viteFolder);
  assert.equal(result.entryPointFound, 'dist/index.html');
  assert.equal(result.errors.length, 0);
});

test('storage.getRemainingApprovalTime supports English language formatting', () => {
  const now = Date.now();
  const baseUser = {
    id: 'u_en',
    username: 'enuser',
    fullName: 'English User',
    email: 'en@test.com',
    role: 'user' as const,
    status: 'approved' as const,
    storageLimitMb: 100,
    storageUsedMb: 0,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
  };

  const perm = storage.getRemainingApprovalTime(baseUser, 'en');
  assert.equal(perm.label, 'Unlimited Access');
  assert.equal(perm.formattedCountdown, 'Permanent Active');

  const expired = storage.getRemainingApprovalTime({ ...baseUser, expiresAt: new Date(now - 5000).toISOString() }, 'en');
  assert.equal(expired.isExpired, true);
  assert.equal(expired.label, 'Expired');

  const oneHour = storage.getRemainingApprovalTime({ ...baseUser, expiresAt: new Date(now + 2 * 3600 * 1000 + 5 * 60 * 1000).toISOString() }, 'en');
  assert.equal(oneHour.isExpired, false);
  assert.ok(oneHour.label.includes('h ') && oneHour.label.includes('m left'));
});

test('detectProjectRuntime identifies Python Flask, Node backend, Vite static, and PHP projects', () => {
  const py = detectProjectRuntime([
    { path: 'app.py', content: 'from flask import Flask\napp = Flask(__name__)\napp.run()' },
    { path: 'templates/index.html', content: '<h1>Hi</h1>' },
  ]);
  assert.equal(py.runtime, 'python');
  assert.equal(py.backendEntry, 'app.py');

  const nodeBackend = detectProjectRuntime([
    { path: 'server.js', content: 'const http = require("http"); http.createServer((q,s)=>s.end("ok")).listen(3000);' },
    { path: 'public/index.html', content: '<h1>Node</h1>' },
  ]);
  assert.equal(nodeBackend.runtime, 'node');
  assert.equal(nodeBackend.backendEntry, 'server.js');

  const viteFrontendOnly = detectProjectRuntime([
    { path: 'vite.config.ts', content: 'export default {}' },
    { path: 'dist/index.html', content: '<div id="root"></div>' },
  ]);
  assert.equal(viteFrontendOnly.runtime, 'static');
  assert.equal(viteFrontendOnly.backendEntry, null);

  const phpProj = detectProjectRuntime([
    { path: 'index.php', content: '<?php echo "hello"; ?>' },
  ]);
  assert.equal(phpProj.runtime, 'php');
});

test('resolveHostedFile handles rootDir prefix mismatches, static fallbacks, and blocks traversal', () => {
  const site: HostedSite = {
    id: 's_res',
    userId: 'u1',
    username: 'u',
    name: 'Flask Repo',
    slug: 'flask-repo',
    description: '',
    type: 'github',
    status: 'online',
    rootFile: 'templates/index.html',
    totalFiles: 3,
    totalSizeKb: 2,
    hiddenFilesCount: 0,
    deploymentLogs: [],
    visitsCount: 0,
    bandwidthMb: 0,
    createdAt: '',
    updatedAt: '',
    files: {
      'templates/index.html': { path: 'templates/index.html', content: '<h1>Hi</h1>', size: 10, isHidden: false, type: 'html' },
      'static/css/style.css': { path: 'static/css/style.css', content: 'body{color:cyan}', size: 15, isHidden: false, type: 'css' },
      'static/img/logo.png': { path: 'static/img/logo.png', content: '', size: 20, isHidden: false, isBinary: true, type: 'image' },
    },
  };

  assert.equal(resolveHostedFile(site, 'templates/static/css/style.css')?.path, 'static/css/style.css');
  assert.equal(resolveHostedFile(site, 'css/style.css')?.path, 'static/css/style.css');
  assert.equal(resolveHostedFile(site, 'logo.png')?.path, 'static/img/logo.png');
  assert.equal(resolveHostedFile(site, '../../etc/passwd'), undefined);
});

test('rewriteCssUrls and rewriteHtmlForSiteProxy rewrite url_for, root assets, and inject API fetch bridge', () => {
  const css = rewriteCssUrls("body { background: url('/img/hero.png'); } @import '/base.css';", 'my-app');
  assert.ok(css.includes("url('/site/my-app/img/hero.png')"));
  assert.ok(css.includes("@import '/site/my-app/base.css'"));

  const rawHtml = `<!doctype html><html><head>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/app.css') }}">
    <img src="/static/logo.png">
  </head><body><script>fetch('/api/audit')</script></body></html>`;

  const rewritten = rewriteHtmlForSiteProxy(rawHtml, 'my-app', 'templates/');
  assert.ok(rewritten.includes('<base href="/site/my-app/templates/">'));
  assert.ok(rewritten.includes('href="/site/my-app/static/css/app.css"'));
  assert.ok(rewritten.includes('src="/site/my-app/static/logo.png"'));
  assert.ok(rewritten.includes('data-nighthost-bridge="1"'));
  assert.ok(rewritten.includes("window.fetch=function"));
});

test('siteRuntime launches Python Flask shim app and serves templates + JSON API endpoints', async () => {
  const site: HostedSite = {
    id: 'test_flask_live',
    userId: '1',
    username: 'admin',
    name: 'Audit Flask',
    slug: 'audit-flask',
    description: '',
    type: 'github',
    status: 'online',
    rootFile: 'app.py',
    runtimeType: 'python',
    totalFiles: 3,
    totalSizeKb: 2,
    hiddenFilesCount: 0,
    deploymentLogs: [],
    visitsCount: 0,
    bandwidthMb: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    files: {
      'app.py': {
        path: 'app.py',
        content: `from flask import Flask, render_template, jsonify, request
app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html", title="NightHex Audit")

@app.route("/api/audit", methods=["POST"])
def audit():
    body = request.get_json(silent=True) or {}
    return jsonify({"status": "ok", "domain": body.get("domain", "")})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
`,
        size: 300,
        isHidden: false,
        type: 'other',
      },
      'templates/index.html': {
        path: 'templates/index.html',
        content: `<!doctype html><html><head><link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}"></head><body><h1>{{ title }}</h1></body></html>`,
        size: 140,
        isHidden: false,
        type: 'html',
      },
      'static/style.css': {
        path: 'static/style.css',
        content: 'body { color: #38bdf8; }',
        size: 25,
        isHidden: false,
        type: 'css',
      },
    },
  };

  try {
    const state = await siteRuntime.ensureRunning(site);
    assert.ok(state);
    assert.equal(state.status, 'running');

    const homeRes = await fetch(`http://127.0.0.1:${state.port}/`);
    assert.equal(homeRes.status, 200);
    const homeHtml = await homeRes.text();
    assert.ok(homeHtml.includes('<h1>NightHex Audit</h1>'));
    assert.ok(homeHtml.includes('/static/style.css'));

    const cssRes = await fetch(`http://127.0.0.1:${state.port}/static/style.css`);
    assert.equal(cssRes.status, 200);
    assert.ok((await cssRes.text()).includes('#38bdf8'));

    const apiRes = await fetch(`http://127.0.0.1:${state.port}/api/audit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain: 'example.com' }),
    });
    assert.equal(apiRes.status, 200);
    const apiJson = await apiRes.json() as { status: string; domain: string };
    assert.equal(apiJson.status, 'ok');
    assert.equal(apiJson.domain, 'example.com');
  } finally {
    siteRuntime.stopAll();
  }
});

test('siteRuntime Python shims support BeautifulSoup4, Flask sessions, |tojson, multipart upload, and reportlab PDF', async () => {
  const site: HostedSite = {
    id: 'test_py_shims',
    userId: '1',
    username: 'admin',
    name: 'Shim Verification',
    slug: 'shim-verification',
    description: '',
    type: 'github',
    status: 'online',
    rootFile: 'app.py',
    runtimeType: 'python',
    totalFiles: 2,
    totalSizeKb: 2,
    hiddenFilesCount: 0,
    deploymentLogs: [],
    visitsCount: 0,
    bandwidthMb: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    files: {
      'app.py': {
        path: 'app.py',
        content: `import io, re, secrets
from bs4 import BeautifulSoup
from flask import Flask, render_template, jsonify, request, session, send_file
from werkzeug.utils import secure_filename
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4

app = Flask(__name__)

@app.get("/")
def index():
    session.setdefault("csrf", "tok_test_123")
    return render_template("index.html", csrf=session["csrf"])

@app.post("/api/parse")
def parse():
    body = request.get_json(silent=True) or {}
    if not secrets.compare_digest(session.get("csrf", ""), str(body.get("csrf", ""))):
        return jsonify(error="bad csrf"), 403
    soup = BeautifulSoup('<form method="POST"><input type="password" name="pw"><a href="/ok">Go</a></form>', "html.parser")
    links = [a.get("href") for a in soup.find_all("a", href=True)]
    pws = soup.find_all("input", attrs={"type": re.compile(r"^password$", re.I)})
    return jsonify(links=links, pw_count=len(pws), clean=secure_filename("../../evil file.zip"))

@app.post("/api/upload")
def upload():
    if not secrets.compare_digest(session.get("csrf", ""), str(request.form.get("csrf", ""))):
        return jsonify(error="bad csrf"), 403
    f = request.files.get("source_zip")
    return jsonify(filename=f.filename, bytes_len=len(f.read()))

@app.get("/api/pdf")
def pdf():
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4)
    st = getSampleStyleSheet()
    doc.build([Paragraph("<b>NIGHTHOST</b> Audit Report", st["Title"])])
    buf.seek(0)
    return send_file(buf, mimetype="application/pdf", as_attachment=True, download_name="report.pdf")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
`,
        size: 1200,
        isHidden: false,
        type: 'python',
      },
      'templates/index.html': {
        path: 'templates/index.html',
        content: `<script>window.CSRF={{ csrf|tojson }};</script>`,
        size: 60,
        isHidden: false,
        type: 'html',
      },
    },
  };

  try {
    const state = await siteRuntime.ensureRunning(site);
    assert.ok(state && state.status === 'running');

    const homeRes = await fetch(`http://127.0.0.1:${state.port}/`);
    assert.equal(homeRes.status, 200);
    const cookie = homeRes.headers.get('set-cookie')?.split(';')[0] || '';
    assert.ok(cookie.includes('nh_py_sid='));
    const homeHtml = await homeRes.text();
    assert.ok(homeHtml.includes('window.CSRF="tok_test_123"'));

    const parseRes = await fetch(`http://127.0.0.1:${state.port}/api/parse`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify({ csrf: 'tok_test_123' }),
    });
    assert.equal(parseRes.status, 200);
    const parseJson = (await parseRes.json()) as { links: string[]; pw_count: number; clean: string };
    assert.deepEqual(parseJson.links, ['/ok']);
    assert.equal(parseJson.pw_count, 1);
    assert.equal(parseJson.clean, 'evil_file.zip');

    const fd = new FormData();
    fd.append('csrf', 'tok_test_123');
    fd.append('source_zip', new Blob(['ZIPDATA'], { type: 'application/zip' }), 'sample.zip');
    const upRes = await fetch(`http://127.0.0.1:${state.port}/api/upload`, {
      method: 'POST',
      headers: { Cookie: cookie },
      body: fd,
    });
    assert.equal(upRes.status, 200);
    const upJson = (await upRes.json()) as { filename: string; bytes_len: number };
    assert.equal(upJson.filename, 'sample.zip');
    assert.equal(upJson.bytes_len, 7);

    const pdfRes = await fetch(`http://127.0.0.1:${state.port}/api/pdf`);
    assert.equal(pdfRes.status, 200);
    const pdfBuf = Buffer.from(await pdfRes.arrayBuffer());
    assert.ok(pdfBuf.toString('latin1').startsWith('%PDF-1.4'));
  } finally {
    siteRuntime.stopAll();
  }
});

test('siteRuntime remaps hardcoded Python and Node listening ports to assigned PORT', async () => {
  const pyHardcoded: HostedSite = {
    id: 'test_py_port_remap',
    userId: '1',
    username: 'admin',
    name: 'Hardcoded Py Port',
    slug: 'py-port-remap',
    description: '',
    type: 'github',
    status: 'online',
    rootFile: 'server.py',
    runtimeType: 'python',
    totalFiles: 1,
    totalSizeKb: 1,
    hiddenFilesCount: 0,
    deploymentLogs: [],
    visitsCount: 0,
    bandwidthMb: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    files: {
      'server.py': {
        path: 'server.py',
        content: `from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"py-ok")
ThreadingHTTPServer(("0.0.0.0", 8765), H).serve_forever()
`,
        size: 250,
        isHidden: false,
        type: 'python',
      },
    },
  };

  const nodeHardcoded: HostedSite = {
    id: 'test_node_port_remap',
    userId: '1',
    username: 'admin',
    name: 'Hardcoded Node Port',
    slug: 'node-port-remap',
    description: '',
    type: 'github',
    status: 'online',
    rootFile: 'server.js',
    runtimeType: 'node',
    totalFiles: 1,
    totalSizeKb: 1,
    hiddenFilesCount: 0,
    deploymentLogs: [],
    visitsCount: 0,
    bandwidthMb: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    files: {
      'server.js': {
        path: 'server.js',
        content: `const http = require('http');
http.createServer((req, res) => { res.end('node-ok'); }).listen(9099, '0.0.0.0');
`,
        size: 120,
        isHidden: false,
        type: 'js',
      },
    },
  };

  try {
    const pyState = await siteRuntime.ensureRunning(pyHardcoded);
    assert.ok(pyState && pyState.status === 'running');
    assert.equal(await (await fetch(`http://127.0.0.1:${pyState.port}/`)).text(), 'py-ok');

    const nodeState = await siteRuntime.ensureRunning(nodeHardcoded);
    assert.ok(nodeState && nodeState.status === 'running');
    assert.equal(await (await fetch(`http://127.0.0.1:${nodeState.port}/`)).text(), 'node-ok');
  } finally {
    siteRuntime.stopAll();
  }
});

test('executePhpCode runs real PHP POST message persistence, REMOTE_ADDR IP logging, global arrays, data URI logos, and ?api=1 JSON', async () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'nh_php_test_'));
  const phpScript = `<?php
$logoData = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
$file = "msgs.json";
$list = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
if (!is_array($list)) $list = [];

$sharedCounter = 10;
$sharedItems = ["init"];
function bumpShared($val) {
  global $sharedCounter, $sharedItems;
  $sharedCounter += 5;
  $sharedItems[] = $val;
}
bumpShared("tested");

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["msg"])) {
  $list[] = ["msg" => trim($_POST["msg"]), "ip" => $_SERVER["REMOTE_ADDR"]];
  file_put_contents($file, json_encode($list));
}

if (isset($_GET["api"])) {
  header("Content-Type: application/json");
  echo json_encode([
    "ok" => true,
    "counter" => $sharedCounter,
    "items" => $sharedItems,
    "messages" => $list
  ]);
  exit;
}
?>
<!doctype html>
<html>
<body>
  <img id="logo" src="<?php echo $logoData; ?>" alt="logo">
  <span id="ip"><?php echo $_SERVER["REMOTE_ADDR"]; ?></span>
  <span id="count"><?php echo count($list); ?></span>
  <span id="global"><?php echo $sharedCounter; ?></span>
</body>
</html>`;

  try {
    const postRes = await executePhpCode(phpScript, {
      method: 'POST',
      path: '/',
      queryString: '',
      get: {},
      post: { msg: 'Hello NightHost' },
      rawBody: 'msg=Hello+NightHost',
      headers: {},
      cookies: {},
      remoteAddr: '203.0.113.42',
      host: 'localhost:3000',
      scheme: 'http',
      scriptName: 'index.php',
      siteDir: tmpDir,
    });
    assert.equal(postRes.statusCode, 200);
    assert.ok(postRes.body.includes('src="data:image/png;base64,'));
    assert.ok(postRes.body.includes('<span id="ip">203.0.113.42</span>'));
    assert.ok(postRes.body.includes('<span id="count">1</span>'));
    assert.ok(postRes.body.includes('<span id="global">15</span>'));

    // Reload via GET to confirm file persistence
    const getRes = await executePhpCode(phpScript, {
      method: 'GET',
      path: '/?api=1',
      queryString: 'api=1',
      get: { api: '1' },
      post: {},
      rawBody: '',
      headers: {},
      cookies: {},
      remoteAddr: '203.0.113.42',
      host: 'localhost:3000',
      scheme: 'http',
      scriptName: 'index.php',
      siteDir: tmpDir,
    });
    assert.equal(getRes.statusCode, 200);
    assert.ok(getRes.contentType.includes('application/json'));
    const parsed = JSON.parse(getRes.body) as {
      ok: boolean;
      counter: number;
      items: string[];
      messages: Array<{ msg: string; ip: string }>;
    };
    assert.equal(parsed.ok, true);
    assert.equal(parsed.counter, 15);
    assert.deepEqual(parsed.items, ['init', 'tested']);
    assert.equal(parsed.messages.length, 1);
    assert.equal(parsed.messages[0].msg, 'Hello NightHost');
    assert.equal(parsed.messages[0].ip, '203.0.113.42');
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

test('phpRuntime path sandboxing and SSRF guards block traversal and private IPs', async () => {
  const sandbox = path.resolve('/tmp/nh_sandbox_demo');
  assert.equal(resolveSandboxedSitePath(sandbox, '../../etc/passwd'), null);
  assert.equal(resolveSandboxedSitePath(sandbox, '../outside.json'), null);
  assert.equal(
    resolveSandboxedSitePath(sandbox, 'data/records.json'),
    path.join(sandbox, 'data/records.json')
  );

  assert.equal(isPrivateOrReservedIp('127.0.0.1'), true);
  assert.equal(isPrivateOrReservedIp('10.0.0.5'), true);
  assert.equal(isPrivateOrReservedIp('192.168.1.10'), true);
  assert.equal(isPrivateOrReservedIp('169.254.169.254'), true);
  assert.equal(isPrivateOrReservedIp('8.8.8.8'), false);

  assert.equal(await isSafePublicUrl('http://127.0.0.1:3000/secret'), false);
  assert.equal(await isSafePublicUrl('http://localhost/admin'), false);
  assert.equal(await isSafePublicUrl('file:///etc/passwd'), false);
});

test('rewriteHtmlForSiteProxy injects __nh_relay CORS fallback bridge script', () => {
  const html = '<!doctype html><html><head><title>Scanner</title></head><body><script>fetch("/api/scan")</script></body></html>';
  const rewritten = rewriteHtmlForSiteProxy(html, 'scanner-app', '');
  assert.ok(rewritten.includes('var B="/site/scanner-app"'));
  assert.ok(rewritten.includes('/__nh_relay?url='));
  assert.ok(rewritten.includes('XMLHttpRequest'));
});

test('buildZipBuffer packages text and base64 binary files into a valid PK zip archive', () => {
  const png1x1Base64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
  const buf = buildZipBuffer({
    'index.html': {
      path: 'index.html',
      content: '<h1>NightHost Zip Test</h1>',
      size: 27,
      isHidden: false,
      type: 'html',
    },
    'assets/dot.png': {
      path: 'assets/dot.png',
      content: png1x1Base64,
      size: 68,
      isHidden: false,
      isBinary: true,
      type: 'image',
    },
  });

  // Local file header signature PK\x03\x04 and End of Central Directory PK\x05\x06
  assert.equal(buf.readUInt32LE(0), 0x04034b50);
  const eocdOffset = buf.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  assert.ok(eocdOffset > 0);
  // Central directory total entries = 2
  assert.equal(buf.readUInt16LE(eocdOffset + 10), 2);
  assert.ok(buf.includes(Buffer.from('index.html')));
  assert.ok(buf.includes(Buffer.from('assets/dot.png')));
  assert.equal(crc32(Buffer.from('123456789')), 0xcbf43926);
});

test('diagnoseRuntimeError gives actionable self-service steps with zero admin references', () => {
  const cases = [
    { logs: ["Error [ERR_MODULE_NOT_FOUND]: Cannot find package 'cors' imported from server.js"], rt: 'node' as const, entry: 'server.js', match: /cors/i },
    { logs: ["ModuleNotFoundError: No module named 'dns'"], rt: 'python' as const, entry: 'app.py', match: /dns/i },
    { logs: ["SyntaxError: Unexpected token '{'"], rt: 'node' as const, entry: 'index.js', match: /Syntax|সিনট্যাক্স/i },
    { logs: ["Error: ENOENT: no such file or directory, open 'templates/index.html'"], rt: 'node' as const, entry: 'server.js', match: /templates|ফাইল/i },
    { logs: ["Process did not open HTTP port within timeout"], rt: 'python' as const, entry: 'app.py', match: /PORT/i },
  ];

  for (const c of cases) {
    const diag = diagnoseRuntimeError(c.logs, c.rt, c.entry);
    const allText = [diag.titleBn, diag.titleEn, diag.causeBn, diag.causeEn, ...diag.stepsBn, ...diag.stepsEn].join(' ');
    assert.ok(c.match.test(allText), `Expected diagnostic to match ${c.match}`);
    assert.equal(/অ্যাডমিন|\badmin\b/i.test(allText), false, `Diagnostic should never mention admin: ${allText}`);
  }
});

test('siteRuntime auto-serves FastAPI app without uvicorn.run plus dns.resolver, httpx, pydantic, and StaticFiles', async () => {
  const fastApiSite: HostedSite = {
    id: 'test_fastapi_revengi_style',
    userId: '1',
    username: 'admin',
    name: 'FastAPI Shim Check',
    slug: 'fastapi-shim-check',
    description: '',
    type: 'folder',
    status: 'online',
    rootFile: 'app.py',
    runtimeType: 'python',
    totalFiles: 2,
    totalSizeKb: 2,
    hiddenFilesCount: 0,
    deploymentLogs: [],
    visitsCount: 0,
    bandwidthMb: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    files: {
      'app.py': {
        path: 'app.py',
        content: `from __future__ import annotations
from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator
import dns.resolver
import httpx

class LookupReq(BaseModel):
    host: str = Field(..., min_length=1)

    @field_validator("host")
    @classmethod
    def clean_host(cls, v: str) -> str:
        return v.strip().lower()

app = FastAPI(title="FastAPI Shim")

@app.get("/api/ping")
async def ping():
    res = dns.resolver.resolve("localhost", "A")
    client_ok = hasattr(httpx, "AsyncClient")
    req = LookupReq(host=" Example.COM ")
    return JSONResponse({"ok": True, "host": req.host, "client": client_ok, "dns_len": len(list(res))})

BASE_DIR = Path(__file__).resolve().parent
app.mount("/", StaticFiles(directory=str(BASE_DIR / "static"), html=True), name="static")
`,
        size: 800,
        isHidden: false,
        type: 'python',
      },
      'static/index.html': {
        path: 'static/index.html',
        content: '<!doctype html><html><body><h1>FastAPI Static OK</h1></body></html>',
        size: 70,
        isHidden: false,
        type: 'html',
      },
    },
  };

  try {
    const state = await siteRuntime.ensureRunning(fastApiSite);
    assert.ok(state && state.status === 'running');

    const staticRes = await fetch(`http://127.0.0.1:${state.port}/`);
    assert.equal(staticRes.status, 200);
    assert.ok((await staticRes.text()).includes('FastAPI Static OK'));

    const pingRes = await fetch(`http://127.0.0.1:${state.port}/api/ping`);
    assert.equal(pingRes.status, 200);
    const pingJson = (await pingRes.json()) as { ok: boolean; host: string; client: boolean };
    assert.equal(pingJson.ok, true);
    assert.equal(pingJson.host, 'example.com');
    assert.equal(pingJson.client, true);
  } finally {
    siteRuntime.stopAll();
  }
});

test('siteRuntime Node ESM supports shimmed cors package when unbundled in package.json', async () => {
  const esmSite: HostedSite = {
    id: 'test_node_esm_cors_shim',
    userId: '1',
    username: 'admin',
    name: 'Node ESM Cors',
    slug: 'node-esm-cors',
    description: '',
    type: 'folder',
    status: 'online',
    rootFile: 'server.js',
    runtimeType: 'node',
    totalFiles: 2,
    totalSizeKb: 1,
    hiddenFilesCount: 0,
    deploymentLogs: [],
    visitsCount: 0,
    bandwidthMb: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    files: {
      'package.json': {
        path: 'package.json',
        content: '{"name":"esm-cors-app","type":"module"}',
        size: 40,
        isHidden: false,
        type: 'json',
      },
      'server.js': {
        path: 'server.js',
        content: `import http from 'node:http';
import cors from 'cors';

const mw = cors();
const port = Number(process.env.PORT || 3000);
http.createServer((req, res) => {
  mw(req, res, () => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, cors: typeof mw }));
  });
}).listen(port, '0.0.0.0');
`,
        size: 280,
        isHidden: false,
        type: 'js',
      },
    },
  };

  try {
    const state = await siteRuntime.ensureRunning(esmSite);
    assert.ok(state && state.status === 'running');
    const res = await fetch(`http://127.0.0.1:${state.port}/`);
    assert.equal(res.status, 200);
    assert.equal(res.headers.get('access-control-allow-origin'), '*');
    const data = (await res.json()) as { ok: boolean; cors: string };
    assert.equal(data.ok, true);
    assert.equal(data.cors, 'function');
  } finally {
    siteRuntime.stopAll();
  }
});

test('siteRuntime Node ESM supports @supabase/supabase-js shim, dotenv/config, and getSiteHealth', async () => {
  const supaSite: HostedSite = {
    id: 'test_node_supa_shim',
    userId: '1',
    username: 'admin',
    name: 'Supa App',
    slug: 'supa-app',
    description: '',
    type: 'folder',
    status: 'online',
    rootFile: 'server.js',
    runtimeType: 'node',
    totalFiles: 3,
    totalSizeKb: 2,
    hiddenFilesCount: 1,
    deploymentLogs: [],
    visitsCount: 0,
    bandwidthMb: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    files: {
      'package.json': {
        path: 'package.json',
        content: '{"name":"supa-app","type":"module"}',
        size: 38,
        isHidden: false,
        type: 'json',
      },
      '.env.example': {
        path: '.env.example',
        content: 'APP_TAG=nighthost-env-ok',
        size: 26,
        isHidden: true,
        type: 'other',
      },
      'server.js': {
        path: 'server.js',
        content: `import 'dotenv/config';
import http from 'node:http';
import { createClient } from '@supabase/supabase-js';

const sb = createClient(process.env.SUPABASE_URL || '', process.env.SUPABASE_ANON_KEY || '');
const port = Number(process.env.PORT || 3000);
http.createServer(async (req, res) => {
  if (req.url === '/api/health') {
    const q = await sb.from('items').select('*');
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, envTag: process.env.APP_TAG, hasErrorObj: Boolean(q.error) }));
    return;
  }
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end('<html><body><h1>Supa App Ready</h1></body></html>');
}).listen(port, '0.0.0.0');
`,
        size: 560,
        isHidden: false,
        type: 'js',
      },
    },
  };

  try {
    const state = await siteRuntime.ensureRunning(supaSite);
    assert.ok(state && state.status === 'running');

    const apiRes = await fetch(`http://127.0.0.1:${state.port}/api/health`);
    assert.equal(apiRes.status, 200);
    const json = (await apiRes.json()) as { ok: boolean; envTag: string; hasErrorObj: boolean };
    assert.equal(json.ok, true);
    assert.equal(json.envTag, 'nighthost-env-ok');
    assert.equal(json.hasErrorObj, true);

    const health = await siteRuntime.getSiteHealth(supaSite);
    assert.equal(health.frontendOk, true);
    assert.equal(health.backendOk, true);
  } finally {
    siteRuntime.stopAll();
  }
});

test('siteRuntime auto-heals ESM import script when package.json lacks type: module', async () => {
  const autoHealSite: HostedSite = {
    id: 'test_node_esm_autoheal',
    userId: '1',
    username: 'admin',
    name: 'AutoHeal ESM',
    slug: 'autoheal-esm',
    description: '',
    type: 'folder',
    status: 'online',
    rootFile: 'server.js',
    runtimeType: 'node',
    totalFiles: 2,
    totalSizeKb: 1,
    hiddenFilesCount: 0,
    deploymentLogs: [],
    visitsCount: 0,
    bandwidthMb: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    files: {
      'package.json': {
        path: 'package.json',
        content: '{"name":"autoheal-app"}',
        size: 25,
        isHidden: false,
        type: 'json',
      },
      'server.js': {
        path: 'server.js',
        content: `import http from 'node:http';
const port = Number(process.env.PORT || 3000);
http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('healed-ok');
}).listen(port, '0.0.0.0');
`,
        size: 190,
        isHidden: false,
        type: 'js',
      },
    },
  };

  try {
    const state = await siteRuntime.ensureRunning(autoHealSite);
    assert.ok(state && state.status === 'running');
    const res = await fetch(`http://127.0.0.1:${state.port}/`);
    assert.equal(res.status, 200);
    assert.equal(await res.text(), 'healed-ok');
  } finally {
    siteRuntime.stopAll();
  }
});

test('storage supports unsuspendUser, canSendMessages permission, and one-time popup message dismissal', async () => {
  const uname = 'pop_' + Date.now();
  const reg = storage.registerUser(uname, 'Popup User', `${uname}@test.com`, 'pass123');
  assert.equal(reg.success, true);
  const uid = reg.user!.id;

  storage.approveUser(uid, 24, '24 Hours', 100);
  storage.suspendUser(uid);
  assert.equal(storage.getUsers().find(u => u.id === uid)?.status, 'suspended');

  const restored = await storage.unsuspendUser(uid);
  assert.equal(restored, true);
  assert.equal(storage.getUsers().find(u => u.id === uid)?.status, 'approved');

  const subRes = storage.addSubAdmin('subm_' + Date.now(), 'Sub Msg', 'sm@test.com', '@sm', 'p123');
  assert.equal(subRes.success, true);
  const sid = subRes.subAdmin!.id;
  storage.updateSubAdminPermissions(sid, { canSendMessages: false });
  assert.equal(storage.getSubAdmins().find(s => s.id === sid)?.canSendMessages, false);
  storage.removeSubAdmin(sid);

  const msgRes = await storage.sendPopupMessageAsync(uid, 'Welcome Notice', 'Hello once!', 'admin');
  assert.equal(msgRes.success, true);
  const mid = msgRes.message!.id;

  assert.equal(storage.getUnreadPopupMessagesForUser(uid).some(m => m.id === mid), true);
  await storage.dismissPopupMessageAsync(mid, uid);
  assert.equal(storage.getUnreadPopupMessagesForUser(uid).some(m => m.id === mid), false);
  await storage.deletePopupMessageAsync(mid);
  storage.deleteUser(uid);
});

test('formatStorageFromMb and formatStorageFromKb format dynamically into KB, MB, and GB', () => {
  assert.equal(formatStorageFromMb(0), '0 KB');
  assert.equal(formatStorageFromMb(-5), '0 KB');
  assert.equal(formatStorageFromMb(0.5), '512 KB');
  assert.equal(formatStorageFromMb(0.01), '10 KB');
  assert.equal(formatStorageFromMb(10), '10 MB');
  assert.equal(formatStorageFromMb(12.5), '12.5 MB');
  assert.equal(formatStorageFromMb(1024), '1 GB');
  assert.equal(formatStorageFromMb(10240), '10 GB');

  assert.equal(formatStorageFromKb(0), '0 KB');
  assert.equal(formatStorageFromKb(0.08), '1 KB');
  assert.equal(formatStorageFromKb(42.4), '42 KB');
  assert.equal(formatStorageFromKb(1536), '1.5 MB');
  assert.equal(formatStorageFromKb(1024 * 1024), '1 GB');
  assert.ok(SERVER_POOL_PRESETS.some((p) => p.capacityMb === 10240));
});

test('getRoleDisplayLabel maps admin to মালিক/Owner and subadmin to অ্যাডমিন/Admin', () => {
  assert.equal(getRoleDisplayLabel('admin', 'bn'), 'মালিক');
  assert.equal(getRoleDisplayLabel('admin', 'en'), 'Owner');
  assert.equal(getRoleDisplayLabel('subadmin', 'bn'), 'অ্যাডমিন');
  assert.equal(getRoleDisplayLabel('subadmin', 'en'), 'Admin');
  assert.equal(getRoleDisplayLabel('user', 'bn'), 'ইউজার');
  assert.equal(getRoleDisplayLabel('user', 'en'), 'User');
});

test('storage saved user page and admin tab default to overview cleanly', () => {
  assert.equal(storage.getSavedUserPage(), 'overview');
  assert.equal(storage.getSavedAdminTab(), 'overview');
  storage.setCurrentUser(null);
  assert.equal(storage.getSavedUserPage(), 'overview');
  assert.equal(storage.getSavedAdminTab(), 'overview');
});

test('normalizeCustomDomain sanitizes protocols, paths, ports, and defaults single labels to .nighthost.app', () => {
  assert.equal(normalizeCustomDomain('my-shop'), 'my-shop.nighthost.app');
  assert.equal(normalizeCustomDomain('https://Demo_App.Custom.IO:8443/path/to/page'), 'demo-app.custom.io');
  assert.equal(normalizeCustomDomain('  SUB.Domain.Com/ '), 'sub.domain.com');
  assert.equal(normalizeCustomDomain('   '), '');
  assert.equal(normalizeCustomDomain('---'), '');
});

test('autoRepairSiteFiles synthesizes missing JS/CSS/Python imports and Vercel serverless bridge', () => {
  const vercelReport = autoRepairSiteFiles({
    'index.html': {
      path: 'index.html',
      content: '<html><head><link rel="stylesheet" href="./styles/missing.css"><script src="./missing-widget.js"></script></head><body>Hi</body></html>',
      size: 130,
      isHidden: false,
      type: 'html',
    },
    'api/hello.js': {
      path: 'api/hello.js',
      content: 'import { utilFn } from "../lib/missingUtil";\nexport default (req, res) => res.json({ ok: true });\n',
      size: 95,
      isHidden: false,
      type: 'js',
    },
  });

  assert.equal(vercelReport.addedVercelBridge, true);
  assert.ok(vercelReport.repairedPaths.includes('styles/missing.css'));
  assert.ok(vercelReport.repairedPaths.includes('missing-widget.js'));
  assert.ok(vercelReport.repairedPaths.includes('lib/missingUtil.js'));
  assert.ok(vercelReport.repairedPaths.includes('__nighthost_serverless_entry.mjs'));
  assert.ok(vercelReport.repairedPaths.includes('package.json'));
  assert.ok(vercelReport.files['__nighthost_serverless_entry.mjs'].content.includes('__NIGHTHOST_SERVERLESS_BRIDGE__'));
  assert.ok(vercelReport.files['lib/missingUtil.js'].content.includes('export const utilFn'));

  const pyReport = autoRepairSiteFiles({
    'app.py': {
      path: 'app.py',
      content: 'from .helper import run_task\n',
      size: 28,
      isHidden: false,
      type: 'python',
    },
  });
  assert.equal(pyReport.addedVercelBridge, false);
  assert.ok(pyReport.repairedPaths.includes('helper.py'));
});

test('supabaseStorage parses env nodes, merges deduplicated buckets, and computes connected pool capacity', () => {
  const envNodes = parseSupabaseEnvNodes({
    SUPABASE_URL: 'https://proj-a.supabase.co/',
    SUPABASE_SERVICE_ROLE_KEY: 'eyJ_secret_key_a_123456',
    SUPABASE_BUCKET: 'nh-a',
    SUPABASE_STORAGE_MB: '1024',
    SUPABASE_URL_1: 'https://proj-b.supabase.co',
    SUPABASE_KEY_1: 'eyJ_secret_key_b_789012',
    SUPABASE_BUCKET_1: 'nh-b',
    SUPABASE_STORAGE_MB_1: '2048',
  });

  assert.equal(envNodes.length, 2);
  assert.equal(envNodes[0].url, 'https://proj-a.supabase.co');
  assert.equal(envNodes[1].quotaMb, 2048);

  const merged = mergeSupabaseNodes(envNodes, [
    // duplicate of proj-a/nh-a should be deduplicated
    {
      id: 'man_dup',
      label: 'Dup',
      url: 'https://proj-a.supabase.co/',
      bucketName: 'nh-a',
      quotaMb: 500,
      status: 'connected',
      source: 'manual',
    },
    {
      id: 'man_c',
      label: 'Bucket C',
      url: 'https://proj-c.supabase.co',
      bucketName: 'nh-c',
      quotaMb: 1500,
      status: 'error',
      source: 'manual',
    },
  ]);

  assert.equal(merged.length, 3);
  const summary = calculatePoolCapacitySummary(merged);
  assert.equal(summary.nodesCount, 3);
  assert.equal(summary.connectedCount, 2);
  assert.equal(summary.connectedMb, 3072);
});

test('rewriteHtmlForSiteProxy supports /d/:domain mountPrefix and root custom host mode', () => {
  const rawHtml = '<html><head><link href="/app.css" rel="stylesheet"></head><body><script src="/main.js"></script></body></html>';

  const domainMounted = rewriteHtmlForSiteProxy(rawHtml, 'demo-slug', '', '/d/demo.nighthost.app');
  assert.ok(domainMounted.includes('<base href="/d/demo.nighthost.app/">'));
  assert.ok(domainMounted.includes('href="/d/demo.nighthost.app/app.css"'));
  assert.ok(domainMounted.includes('src="/d/demo.nighthost.app/main.js"'));
  assert.ok(domainMounted.includes('var B="/d/demo.nighthost.app"'));

  const rootHostMounted = rewriteHtmlForSiteProxy(rawHtml, 'demo-slug', '', '');
  assert.ok(rootHostMounted.includes('<base href="/">'));
  assert.ok(rootHostMounted.includes('href="/app.css"'));
  assert.ok(rootHostMounted.includes('var B=""'));
});

test('computePoolAllocationSummary excludes pending users from allocated storage until approved', () => {
  const summaryWithOnlyPending = computePoolAllocationSummary(
    [
      { role: 'admin', status: 'approved', storageLimitMb: 5000, storageUsedMb: 0 },
      { role: 'user', status: 'pending', storageLimitMb: 100, storageUsedMb: 0 },
      { role: 'user', status: 'pending', storageLimitMb: 250, storageUsedMb: 0 },
    ],
    [],
    1024,
    100
  );
  assert.equal(summaryWithOnlyPending.allocatedMb, 0);
  assert.equal(summaryWithOnlyPending.remainingAllocatableMb, 1024);
  assert.equal(summaryWithOnlyPending.pendingUsersCount, 2);
  assert.equal(summaryWithOnlyPending.approvedUsersCount, 0);

  const summaryMixed = computePoolAllocationSummary(
    [
      { role: 'user', status: 'pending', storageLimitMb: 100, storageUsedMb: 0 },
      { role: 'user', status: 'approved', storageLimitMb: 200, storageUsedMb: 20 },
      { role: 'user', status: 'suspended', storageLimitMb: 300, storageUsedMb: 15 },
    ],
    [{ totalSizeKb: 20 * 1024 }, { totalSizeKb: 15 * 1024 }],
    1024,
    100
  );
  assert.equal(summaryMixed.allocatedMb, 200);
  assert.equal(summaryMixed.usedBySitesMb, 35);
  assert.equal(summaryMixed.approvedUsersCount, 1);
  assert.equal(summaryMixed.pendingUsersCount, 1);
  assert.equal(summaryMixed.suspendedUsersCount, 1);
  assert.equal(summaryMixed.remainingAllocatableMb, 1024 - 215);
});

test('generateRenderEnvVariables builds numbered Render env variables and pool JSON for multi-Supabase', () => {
  const result = generateRenderEnvVariables([
    {
      id: 'sb_1',
      label: 'Primary Bucket',
      url: 'https://first-proj.supabase.co/',
      serviceRoleKey: 'secret_key_1',
      bucketName: 'nighthost-1',
      quotaMb: 1024,
      status: 'connected',
      source: 'manual',
    },
    {
      id: 'sb_2',
      label: 'Second Bucket',
      url: 'https://second-proj.supabase.co',
      serviceRoleKey: 'secret_key_2',
      bucketName: 'nighthost-2',
      quotaMb: 2048,
      status: 'connected',
      source: 'manual',
    },
  ]);

  assert.ok(result.pairs.some((p) => p.key === 'SUPABASE_URL_1' && p.value === 'https://first-proj.supabase.co'));
  assert.ok(result.pairs.some((p) => p.key === 'SUPABASE_SERVICE_ROLE_KEY_2' && p.value === 'secret_key_2'));
  assert.ok(result.dotenvText.includes('SUPABASE_BUCKET_1=nighthost-1'));
  assert.ok(result.dotenvText.includes('SUPABASE_STORAGE_MB_2=2048'));
  const parsedPool = JSON.parse(result.poolJson);
  assert.equal(parsedPool.length, 2);
  assert.equal(parsedPool[1].quotaMb, 2048);
});

test('renderSiteUnavailableHtml renders NIGHT HEX & NightHex_X contact info and escapes XSS payloads', () => {
  const suspendedHtml = renderSiteUnavailableHtml({
    siteName: '<script>alert(1)</script>Shop',
    reason: 'suspended',
    ownerName: 'NIGHT HEX',
    ownerTelegramUrl: 'https://t.me/NightHex_X',
    ownerTelegramHandle: '@NightHex_X',
  });
  assert.ok(suspendedHtml.includes('ACCOUNT SUSPENDED'));
  assert.ok(suspendedHtml.includes('NIGHT HEX'));
  assert.ok(suspendedHtml.includes('https://t.me/NightHex_X'));
  assert.ok(suspendedHtml.includes('@NightHex_X'));
  assert.equal(suspendedHtml.includes('<script>alert(1)</script>'), false);
  assert.ok(suspendedHtml.includes('&lt;script&gt;alert(1)&lt;/script&gt;Shop'));

  const expiredHtml = renderSiteUnavailableHtml({
    siteName: 'ExpiredApp',
    reason: 'expired',
    ownerName: 'NIGHT HEX',
    ownerTelegramUrl: 'https://t.me/NightHex_X',
    ownerTelegramHandle: '@NightHex_X',
  });
  assert.ok(expiredHtml.includes('HOSTING EXPIRED'));

  const pausedHtml = renderSiteUnavailableHtml({
    siteName: 'PausedApp',
    reason: 'paused',
    ownerName: 'NIGHT HEX',
    ownerTelegramUrl: 'https://t.me/NightHex_X',
    ownerTelegramHandle: '@NightHex_X',
  });
  assert.ok(pausedHtml.includes('WEBSITE PAUSED'));
});

test('storage.approveAllPendingUsersAsync approves pending users only and updates pool allocation', async () => {
  const ts = Date.now();
  const u1 = storage.registerUser(`bulk_p1_${ts}`, 'Bulk One', `p1_${ts}@test.com`, 'pass123');
  const u2 = storage.registerUser(`bulk_p2_${ts}`, 'Bulk Two', `p2_${ts}@test.com`, 'pass123');
  assert.equal(u1.success, true);
  assert.equal(u2.success, true);

  const beforeStats = storage.getServerStorageStats();
  assert.ok((beforeStats.pendingUsersCount ?? 0) >= 2);

  const bulkRes = await storage.approveAllPendingUsersAsync(24, '24 Hours', 150);
  assert.equal(bulkRes.success, true);
  assert.ok((bulkRes.approvedCount ?? 0) >= 2);

  const f1 = storage.getUsers().find((u) => u.id === u1.user!.id);
  const f2 = storage.getUsers().find((u) => u.id === u2.user!.id);
  assert.equal(f1?.status, 'approved');
  assert.equal(f2?.status, 'approved');
  assert.equal(f1?.storageLimitMb, 150);

  storage.deleteUser(u1.user!.id);
  storage.deleteUser(u2.user!.id);
});

test('computePoolAllocationSummary excludes subadmin (Admin) and pending users from Shared Pool allocation', () => {
  const summary = computePoolAllocationSummary(
    [
      { role: 'admin', status: 'approved', storageLimitMb: 5000, storageUsedMb: 0 },
      { role: 'subadmin', status: 'approved', storageLimitMb: 1000, storageUsedMb: 0 },
      { role: 'user', status: 'pending', storageLimitMb: 100, storageUsedMb: 0 },
      { role: 'user', status: 'approved', storageLimitMb: 250, storageUsedMb: 25 },
    ],
    [{ totalSizeKb: 25 * 1024 }],
    1024,
    100
  );
  assert.equal(summary.allocatedMb, 250);
  assert.equal(summary.usedBySitesMb, 25);
  assert.equal(summary.approvedUsersCount, 1);
  assert.equal(summary.pendingUsersCount, 1);
  assert.equal(summary.remainingAllocatableMb, 1024 - 250);
});

test('normalizeUserSubdomain and isReservedSubdomain validate safe DNS labels and block reserved paths', () => {
  assert.equal(normalizeUserSubdomain('NightHex_99!'), 'nighthex-99');
  assert.equal(normalizeUserSubdomain('https://RiadCloud.nighthost.app/test'), 'riadcloud');
  assert.equal(normalizeUserSubdomain('ab'), '');
  assert.equal(normalizeUserSubdomain('admin'), '');
  assert.equal(normalizeUserSubdomain('api'), '');
  assert.equal(normalizeUserSubdomain('www'), '');
  assert.equal(isReservedSubdomain('admin'), true);
  assert.equal(isReservedSubdomain('mybrand'), false);
});

test('sanitizeExternalLinkUrl enforces http(s) safety and sendPopupMessageAsync persists Marked/Unmarked links', async () => {
  assert.equal(sanitizeExternalLinkUrl('https://t.me/NightHex_X'), 'https://t.me/NightHex_X');
  assert.equal(sanitizeExternalLinkUrl('example.com/docs'), 'https://example.com/docs');
  assert.equal(sanitizeExternalLinkUrl('javascript:alert(1)'), '');
  assert.equal(sanitizeExternalLinkUrl('data:text/html,<script>1</script>'), '');
  assert.equal(sanitizeExternalLinkUrl('file:///etc/passwd'), '');

  const badRes = await storage.sendPopupMessageAsync('all', 'Test', 'Body', 'admin', {
    linkUrl: 'javascript:alert(1)',
    linkText: 'Click',
    linkMarked: true,
  });
  assert.equal(badRes.success, false);

  const okRes = await storage.sendPopupMessageAsync('all', 'Channel', 'Join now!', 'admin', {
    linkUrl: 'https://t.me/NightHex_X',
    linkText: 'Join Channel',
    linkMarked: false,
  });
  assert.equal(okRes.success, true);
  assert.equal(okRes.message?.linkUrl, 'https://t.me/NightHex_X');
  assert.equal(okRes.message?.linkText, 'Join Channel');
  assert.equal(okRes.message?.linkMarked, false);
  if (okRes.message) {
    await storage.deletePopupMessageAsync(okRes.message.id);
  }
});

test('rewriteHtmlForSiteProxy injects no-referrer, supports /u/<subdomain>/<slug> without double-prefixing, and embeds SVG image fallback', () => {
  const html = '<!doctype html><html><head></head><body><img src="https://cdn.example.com/logo.png" alt="CYBER X"><a href="/dashboard">Go</a></body></html>';
  const out = rewriteHtmlForSiteProxy(html, 'tg', '', '/u/riad/tg');
  assert.ok(out.includes('<meta name="referrer" content="no-referrer">'));
  assert.ok(out.includes('<base href="/u/riad/tg/">'));
  assert.ok(out.includes('href="/u/riad/tg/dashboard"'));
  assert.ok(out.includes('u.indexOf("/u/")!==0'));
  assert.ok(out.includes('makeFallbackSvg'));
  assert.ok(out.includes('data:image/svg+xml;charset=utf-8,'));
});

test('siteRuntime Python shims execute flask_limiter and unknown dynamic modules cleanly', async () => {
  const flaskSite: HostedSite = {
    id: 'test_py_flask_limiter',
    userId: '1',
    username: 'admin',
    name: 'Limiter App',
    slug: 'limiter-app',
    description: '',
    type: 'folder',
    status: 'online',
    rootFile: 'app.py',
    runtimeType: 'python',
    totalFiles: 1,
    totalSizeKb: 2,
    hiddenFilesCount: 0,
    deploymentLogs: [],
    visitsCount: 0,
    bandwidthMb: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    files: {
      'app.py': {
        path: 'app.py',
        content: `from flask import Flask, jsonify
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import some_unlisted_helper_pkg

app = Flask(__name__)
limiter = Limiter(key_func=get_remote_address, app=app, default_limits=["200 per day"])

@app.route("/")
@limiter.limit("30 per minute")
def home():
    return jsonify({"ok": True, "pkg": some_unlisted_helper_pkg.__name__})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
`,
        size: 420,
        isHidden: false,
        type: 'python',
      },
    },
  };

  try {
    const state = await siteRuntime.ensureRunning(flaskSite);
    assert.ok(state && state.status === 'running');
    const res = await fetch(`http://127.0.0.1:${state.port}/`);
    assert.equal(res.status, 200);
    const json = (await res.json()) as { ok: boolean; pkg: string };
    assert.equal(json.ok, true);
    assert.equal(json.pkg, 'some_unlisted_helper_pkg');
  } finally {
    siteRuntime.stopAll();
  }
});

test('buildIsolatedChildEnv strips sensitive platform/runtime secrets while keeping OS baseline & user env', () => {
  const isolated = buildIsolatedChildEnv(
    {
      PATH: '/usr/bin:/bin',
      HOME: '/tmp/home',
      LANG: 'en_US.UTF-8',
      NIGHTHOST_OWNER_PASSWORD: 'super-secret-owner-pass',
      NIGHTHOST_SESSION_SECRET: 'signing-secret',
      SUPABASE_SERVICE_ROLE_KEY_1: 'sb-secret-key',
      GEMINI_API_KEY: 'gemini-secret',
      NODE_OPTIONS: '--require /evil/preload.js',
      LD_PRELOAD: '/evil/lib.so',
      PYTHONPATH: '/evil/py',
    },
    {
      PUBLIC_TAG: 'hello-app',
      NIGHTHOST_HACK: 'blocked',
      NODE_OPTIONS: '--inspect',
    },
    { port: 4123, autoHealDir: '/tmp/nighthost-test-auto', nodePath: '/tmp/nighthost-test-node' }
  );

  assert.equal(isolated.PATH, '/usr/bin:/bin');
  assert.equal(isolated.PORT, '4123');
  assert.equal(isolated.PUBLIC_TAG, 'hello-app');
  assert.equal(isolated.NIGHTHOST_OWNER_PASSWORD, undefined);
  assert.equal(isolated.NIGHTHOST_SESSION_SECRET, undefined);
  assert.equal(isolated.SUPABASE_SERVICE_ROLE_KEY_1, undefined);
  assert.equal(isolated.GEMINI_API_KEY, undefined);
  assert.equal(isolated.NODE_OPTIONS, undefined);
  assert.equal(isolated.LD_PRELOAD, undefined);
  assert.equal(isolated.PYTHONPATH, undefined);
  assert.equal(isolated.NIGHTHOST_HACK, undefined);
});

test('storage rejects empty or short (<4 chars) passwords for users and subadmins', () => {
  const suffix = Date.now();
  const badUser = storage.registerUser(`short_${suffix}`, 'Short User', `short_${suffix}@test.com`, '123');
  assert.equal(badUser.success, false);

  const emptyUser = storage.registerUser(`empty_${suffix}`, 'Empty User', `empty_${suffix}@test.com`, '');
  assert.equal(emptyUser.success, false);

  const badSub = storage.addSubAdmin(`subshort_${suffix}`, 'Sub Short', `sub_${suffix}@test.com`, '@sub', 'ab');
  assert.equal(badSub.success, false);
});

test('storage tracks exact KB to MB calculations without inflating empty or tiny uploads', () => {
  const uname = 'exactkb_' + Date.now();
  const reg = storage.registerUser(uname, 'KB User', `${uname}@test.com`, 'pass1234');
  assert.equal(reg.success, true);
  const uid = reg.user!.id;
  storage.approveUser(uid, -1, 'Permanent', 100);

  const before = storage.getUsers().find(u => u.id === uid)!;
  assert.equal(before.storageUsedMb, 0);

  const tinySite = storage.createSite({
    userId: uid,
    username: uname,
    name: 'Tiny Site',
    slug: 'tiny-' + Date.now(),
    description: '',
    type: 'single-file',
    status: 'online',
    rootFile: 'index.html',
    totalFiles: 1,
    totalSizeKb: 2,
    hiddenFilesCount: 0,
    deploymentLogs: [],
    files: {
      'index.html': { path: 'index.html', content: '<h1>Hi</h1>', size: 2048, isHidden: false, type: 'html' },
    },
  });

  const afterUpload = storage.getUsers().find(u => u.id === uid)!;
  assert.equal(afterUpload.storageUsedMb, 0.002);

  storage.deleteSite(tinySite.id);
  const afterDelete = storage.getUsers().find(u => u.id === uid)!;
  assert.equal(afterDelete.storageUsedMb, 0);

  storage.deleteUser(uid);
});

test('Notification Inbox retains dismissed notices while unread list excludes them', async () => {
  const uname = 'inboxuser_' + Date.now();
  const reg = storage.registerUser(uname, 'Inbox User', `${uname}@test.com`, 'pass1234');
  assert.equal(reg.success, true);
  const uid = reg.user!.id;

  const sent = await storage.sendPopupMessageAsync(uid, 'Alert Title', 'Read details here', 'owner', {
    linkUrl: 'https://example.com/guide',
    linkText: 'Open Guide',
    linkMarked: true,
  });
  assert.equal(sent.success, true);
  const msg = sent.message!;

  assert.equal(storage.getPopupMessagesForUser(uid).some(m => m.id === msg.id), true);
  assert.equal(storage.getUnreadPopupMessagesForUser(uid).some(m => m.id === msg.id), true);

  await storage.dismissPopupMessageAsync(msg.id, uid);
  assert.equal(storage.getUnreadPopupMessagesForUser(uid).some(m => m.id === msg.id), false);
  const inboxList = storage.getPopupMessagesForUser(uid);
  const retained = inboxList.find(m => m.id === msg.id);
  assert.ok(retained);
  assert.equal(retained?.linkMarked, true);
  assert.equal(retained?.linkUrl, 'https://example.com/guide');

  await storage.deletePopupMessageAsync(msg.id);
  storage.deleteUser(uid);
});

test('formatHttpTransportError turns non-JSON proxy/Express HTML errors into actionable messages', () => {
  const err413 = formatHttpTransportError(413, '<!doctype html><pre>PayloadTooLargeError</pre>');
  assert.ok(err413.includes('HTTP 413'));

  const err502 = formatHttpTransportError(502, '<html>502 Bad Gateway</html>');
  assert.ok(err502.includes('HTTP 502'));

  const err401 = formatHttpTransportError(401, 'Unauthorized');
  assert.ok(err401.includes('HTTP 401'));

  const errNet = formatHttpTransportError(0, '');
  assert.ok(errNet.includes('Network / Timeout'));
});

test('extractZipEntries unpacks text and binary files built by buildZipBuffer cleanly', () => {
  const png1x1Base64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
  const zipBuf = buildZipBuffer({
    'repo-main/index.html': {
      path: 'repo-main/index.html',
      content: '<h1>NightHost ZIP Extract</h1>',
      size: 30,
      isHidden: false,
      type: 'html',
    },
    'repo-main/assets/dot.png': {
      path: 'repo-main/assets/dot.png',
      content: png1x1Base64,
      size: 68,
      isHidden: false,
      isBinary: true,
      type: 'image',
    },
  });

  const extracted = extractZipEntries(zipBuf);
  assert.equal(extracted.length, 2);
  const htmlEntry = extracted.find(e => e.path === 'repo-main/index.html');
  assert.ok(htmlEntry);
  assert.equal(htmlEntry.data.toString('utf-8'), '<h1>NightHost ZIP Extract</h1>');
  const pngEntry = extracted.find(e => e.path === 'repo-main/assets/dot.png');
  assert.ok(pngEntry);
  assert.equal(pngEntry.data.toString('base64'), png1x1Base64);
});

test('detectProjectRuntime keeps HTML game with SimpleHTTPRequestHandler helper as static while preserving real Python backends', () => {
  const htmlWithPyHelper = detectProjectRuntime([
    { path: 'index.html', content: '<canvas id="game"></canvas>' },
    {
      path: 'server.py',
      content: 'import http.server\nhttp.server.test(HandlerClass=http.server.SimpleHTTPRequestHandler, port=8000)',
    },
  ]);
  assert.equal(htmlWithPyHelper.runtime, 'static');
  assert.equal(htmlWithPyHelper.backendEntry, null);

  const realFlaskWithRootHtml = detectProjectRuntime([
    { path: 'index.html', content: '<h1>App</h1>' },
    { path: 'app.py', content: 'from flask import Flask\napp = Flask(__name__)\n@app.route("/api")\ndef api(): return "ok"' },
  ]);
  assert.equal(realFlaskWithRootHtml.runtime, 'python');
  assert.equal(realFlaskWithRootHtml.backendEntry, 'app.py');
});

test('assessProjectCloudFootprint flags heavy 200-500MB+ runtime repos and optimizeProjectToRunnableCore keeps runnable core', () => {
  const bloatedFiles = [
    { path: 'index.html', content: '<html><body><h1>Core App</h1></body></html>', size: 42, isBinary: false },
    { path: 'package.json', content: JSON.stringify({ dependencies: { next: '15.0.0', react: '19.0.0', three: '0.170.0' }, devDependencies: { webpack: '5.0.0', typescript: '5.0.0' } }), size: 120, isBinary: false },
    { path: 'app.py', content: 'from flask import Flask\napp = Flask(__name__)\n', size: 45, isBinary: false },
    { path: 'dist/bundle.js.map', content: '{}'.repeat(500), size: 1000, isBinary: false },
    { path: 'src/types/global.d.ts', content: 'export type X = string;', size: 23, isBinary: false },
    ...Array.from({ length: 120 }, (_, i) => ({
      path: `docs/guide-${i}.md`,
      content: `# Doc ${i}\nDetails`,
      size: 500,
      isBinary: false,
    })),
  ];

  const footprint = assessProjectCloudFootprint(bloatedFiles);
  assert.equal(footprint.needsOptimization, true);
  assert.ok(footprint.estimatedRuntimeMb >= 200);
  assert.ok(footprint.bloatFilesCount >= 120);

  const trimmed = optimizeProjectToRunnableCore(bloatedFiles);
  assert.ok(trimmed.removedCount >= 120);
  assert.ok(trimmed.afterCount < 20);
  const keptPaths = new Set(trimmed.files.map(f => f.path));
  assert.ok(keptPaths.has('index.html'));
  assert.ok(keptPaths.has('package.json'));
  assert.ok(keptPaths.has('app.py'));
  assert.equal(keptPaths.has('dist/bundle.js.map'), false);
  assert.equal(keptPaths.has('docs/guide-0.md'), false);
});

test('resolveHostedFile resolves extensionless TSX imports and prepareStandaloneHtmlForServer injects ESM importmap', () => {
  const site: import('../types').HostedSite = {
    id: 'site_tsx_test',
    userId: 'u1',
    username: 'tester',
    name: 'Unbuilt React App',
    description: '',
    type: 'github',
    status: 'online',
    slug: 'unbuilt-react-app',
    rootFile: 'index.html',
    totalFiles: 3,
    totalSizeKb: 2,
    hiddenFilesCount: 0,
    deploymentLogs: [],
    visitsCount: 0,
    bandwidthMb: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    files: {
      'index.html': {
        path: 'index.html',
        content: '<!doctype html><html><head></head><body><div id="root"></div><script type="module" src="/src/main.tsx"></script></body></html>',
        size: 130,
        isHidden: false,
        type: 'html',
      },
      'src/main.tsx': {
        path: 'src/main.tsx',
        content: 'import App from "./App";\nconsole.log(App);',
        size: 42,
        isHidden: false,
        type: 'js',
      },
      'src/App.tsx': {
        path: 'src/App.tsx',
        content: 'export default function App() { return <div className="p-4">Hello TSX</div>; }',
        size: 76,
        isHidden: false,
        type: 'js',
      },
    },
  };

  const resolvedApp = resolveHostedFile(site, 'src/App');
  assert.ok(resolvedApp);
  assert.equal(resolvedApp.path, 'src/App.tsx');

  const html = prepareStandaloneHtmlForServer(site, undefined, '/site/unbuilt-react-app');
  assert.ok(html.includes('<script type="importmap">'));
  assert.ok(html.includes('https://esm.sh/react@19'));
  assert.ok(html.includes('https://cdn.tailwindcss.com'));
});

test('siteRuntime Python dns.reversename shim and metadata-stripped getSiteRuntimeMeta work reliably', async () => {
  const strippedSite: import('../types').HostedSite = {
    id: 'site_stripped_meta',
    userId: 'u1',
    username: 'tester',
    name: 'Stripped Python App',
    description: '',
    type: 'folder',
    status: 'online',
    slug: 'stripped-py',
    rootFile: 'app.py',
    runtimeType: 'python',
    totalFiles: 1,
    totalSizeKb: 1,
    hiddenFilesCount: 0,
    deploymentLogs: [],
    visitsCount: 0,
    bandwidthMb: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    files: {
      'app.py': {
        path: 'app.py',
        content: '',
        size: 120,
        isHidden: false,
        type: 'python',
      },
    },
  };
  const meta = siteRuntime.getSiteRuntimeMeta(strippedSite);
  assert.equal(meta.hasBackend, true);
  assert.equal(meta.runtime, 'python');

  const pyDnsSite: import('../types').HostedSite = {
    ...strippedSite,
    id: 'site_py_dns_shim_test',
    slug: 'py-dns-shim-test',
    files: {
      'app.py': {
        path: 'app.py',
        content: [
          'import os, json',
          'from http.server import HTTPServer, BaseHTTPRequestHandler',
          'import dns.reversename',
          'import dns.resolver',
          'rev4 = str(dns.reversename.from_address("8.8.8.8"))',
          'ip4 = dns.reversename.to_address(rev4)',
          'class H(BaseHTTPRequestHandler):',
          '    def do_GET(self):',
          '        self.send_response(200)',
          '        self.send_header("Content-Type", "application/json")',
          '        self.end_headers()',
          '        self.wfile.write(json.dumps({"rev4": rev4, "ip4": ip4}).encode())',
          '    def log_message(self, *args): pass',
          'HTTPServer(("127.0.0.1", int(os.environ.get("PORT", 5000))), H).serve_forever()',
        ].join('\n'),
        size: 500,
        isHidden: false,
        type: 'python',
      },
    },
  };

  try {
    const rt = await siteRuntime.ensureRunning(pyDnsSite);
    assert.ok(rt);
    assert.equal(rt.status, 'running', `Expected Python dns.reversename site to run, got error: ${rt.errorMessage} | logs: ${rt.logs.join(' ; ')}`);
    const resp = await fetch(`http://127.0.0.1:${rt.port}/`);
    assert.equal(resp.status, 200);
    const body = (await resp.json()) as { rev4: string; ip4: string };
    assert.equal(body.rev4, '8.8.8.8.in-addr.arpa.');
    assert.equal(body.ip4, '8.8.8.8');
  } finally {
    siteRuntime.stopSite(pyDnsSite.id);
  }
});

test('buildSubdomainUrls generates Cloudflare-Free-SSL-safe wildcard URLs and rejects reserved subdomains', () => {
  const urls = buildSubdomainUrls('RafiqDev', 'Shop-App', 'nighthostcloud.dpdns.org');
  assert.equal(urls.primaryDomain, 'nighthostcloud.dpdns.org');
  assert.equal(urls.wildcardSiteUrl, 'https://rafiqdev.nighthostcloud.dpdns.org/shop-app');
  assert.equal(urls.wildcardRootUrl, 'https://rafiqdev.nighthostcloud.dpdns.org');
  assert.equal(urls.wildcardAltUrl, 'https://shop-app-rafiqdev.nighthostcloud.dpdns.org');
  assert.equal(urls.pathUrl, '/u/rafiqdev/shop-app');

  const reservedUrls = buildSubdomainUrls('admin', 'shop-app', 'nighthostcloud.dpdns.org');
  assert.equal(reservedUrls.wildcardSiteUrl, null);
  assert.equal(isReservedSubdomain('www'), true);
  assert.equal(isReservedSubdomain('admin'), true);
  assert.equal(isReservedSubdomain('api'), true);
  assert.equal(isReservedSubdomain('rafiqdev'), false);
});

test('Backblaze B2 pool parsing, merging, sanitization, capacity, and combined Render Env work accurately', () => {
  const envNodes = parseB2EnvNodes({
    B2_KEY_ID: '005abcdef123456789',
    B2_APPLICATION_KEY: 'K005supersecretappkey',
    B2_BUCKET_NAME: 'NightHost-Main',
    B2_STORAGE_MB: '10240',
    B2_KEY_ID_1: '005xyz999888777',
    B2_APPLICATION_KEY_1: 'K005secondsecret',
    B2_BUCKET_NAME_1: 'nighthost-extra',
    B2_STORAGE_MB_1: '10240',
  } as unknown as NodeJS.ProcessEnv);

  assert.equal(envNodes.length, 2);
  assert.equal(envNodes[0].bucketName, 'nighthost-main');

  const sanitized = sanitizeB2NodeForClient(envNodes[0]);
  assert.equal(sanitized.applicationKey, undefined);
  assert.ok(sanitized.keyId.includes('••••'));

  const manualConnected = {
    ...envNodes[0],
    id: 'b2_manual_1',
    keyId: '005manual123',
    bucketName: 'nighthost-manual',
    status: 'connected' as const,
    source: 'manual' as const,
  };
  const merged = mergeB2Nodes(envNodes, [manualConnected]);
  assert.equal(merged.length, 3);

  const summary = calculateB2PoolSummary(merged);
  assert.equal(summary.nodesCount, 3);
  assert.equal(summary.connectedCount, 1);
  assert.equal(summary.connectedMb, 10240);

  const combined = generateCombinedRenderEnvVariables([], [manualConnected], 'nighthostcloud.dpdns.org', true);
  assert.ok(combined.pairs.some(p => p.key === 'NIGHTHOST_PRIMARY_DOMAIN' && p.value === 'nighthostcloud.dpdns.org'));
  assert.ok(combined.pairs.some(p => p.key === 'B2_BUCKET_NAME' && p.value === 'nighthost-manual'));
  assert.ok(combined.dotenvText.includes('B2_KEY_ID=005manual123'));
});

test('AI Auto-Healer Layer 1 repairs trailing JSON commas, ESM/CJS mismatch, hardcoded ports, and Python 127.0.0.1 host', async () => {
  const brokenFiles: Record<string, import('../types').SiteFile> = {
    'package.json': {
      path: 'package.json',
      content: '{\n  "name": "broken-node",\n  "type": "module",\n  "main": "server.js",\n}',
      size: 72,
      isHidden: false,
      isBinary: false,
      type: 'json',
    },
    'server.js': {
      path: 'server.js',
      content: 'const http = require("http");\nhttp.createServer((req, res) => res.end("ok")).listen(3000);\n',
      size: 95,
      isHidden: false,
      isBinary: false,
      type: 'js',
    },
    'app.py': {
      path: 'app.py',
      content: 'from flask import Flask\napp = Flask(__name__)\napp.run(host="127.0.0.1", port=5000)\n',
      size: 84,
      isHidden: false,
      isBinary: false,
      type: 'python',
    },
  };

  const ruleResult = applyDeterministicHealRules(brokenFiles, ['require is not defined in ES module scope']);
  assert.ok(ruleResult.reports.length >= 3);

  const fixedPkg = JSON.parse(ruleResult.files['package.json'].content);
  assert.equal(fixedPkg.type, 'commonjs');
  assert.ok(ruleResult.files['server.js'].content.includes('process.env.PORT || 3000'));
  assert.ok(ruleResult.files['app.py'].content.includes('0.0.0.0'));
  assert.ok(ruleResult.files['app.py'].content.includes('os.environ.get("PORT", 5000)'));

  const prevKey = process.env.GEMINI_API_KEY;
  delete process.env.GEMINI_API_KEY;
  try {
    const fullHeal = await runSiteAutoHeal({
      files: brokenFiles,
      rootFile: 'server.js',
      runtimeType: 'node',
      errorLogs: [],
      preferAi: false,
    });
    assert.equal(fullHeal.healed, true);
    assert.equal(fullHeal.usedEngine, 'auto-rule');
    assert.ok(fullHeal.reports.every(r => r.issueBn.length > 5 && r.fixAppliedBn.length > 5));
  } finally {
    if (prevKey !== undefined) process.env.GEMINI_API_KEY = prevKey;
  }
});

test('diagnoseRuntimeError and formatHttpTransportError return accurate Bengali messages for OOM, 503 High Load, 507 Storage, and 403', () => {
  const oomDiag = diagnoseRuntimeError(['FATAL ERROR: JavaScript heap out of memory (exit code 137 / RENDER_OOM)'], 'node', 'server.js');
  assert.ok(oomDiag.titleBn.includes('OOM') && oomDiag.titleBn.includes('মেমোরি'));

  const loadDiag = diagnoseRuntimeError(['503 HIGH_LOAD: maxWarm limit reached'], 'python', 'app.py');
  assert.ok(loadDiag.titleBn.includes('লোড') || loadDiag.causeBn.includes('মেমোরি'));

  assert.ok(formatHttpTransportError(507, JSON.stringify({ message: 'কোটা পূর্ণ' })).includes('কোটা পূর্ণ'));
  assert.ok(formatHttpTransportError(503, '').includes('HTTP 503'));
  assert.ok(formatHttpTransportError(403, '').includes('HTTP 403'));
});


