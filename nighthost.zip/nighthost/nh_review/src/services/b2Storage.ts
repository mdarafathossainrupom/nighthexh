import crypto from 'crypto';
import zlib from 'zlib';
import {
  B2PoolNode,
  HostedSite,
  SiteFile,
  SupabasePoolNode,
} from '../types/index.js';
import { DEFAULT_PRIMARY_DOMAIN, normalizePrimaryDomain } from './format.js';
import { normalizeSupabaseUrl } from './supabaseStorage.js';

interface B2AuthSession {
  accountId: string;
  authorizationToken: string;
  apiUrl: string;
  downloadUrl: string;
  expiresAt: number;
}

const b2AuthCache = new Map<string, B2AuthSession>();

export function normalizeB2BucketName(raw: string): string {
  return String(raw || 'nighthost-cloud')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 50);
}

export function maskB2KeyId(keyId: string): string {
  const clean = String(keyId || '').trim();
  if (!clean) return '';
  if (clean.length <= 8) return `${clean.slice(0, 2)}***${clean.slice(-2)}`;
  return `${clean.slice(0, 6)}••••${clean.slice(-4)}`;
}

export function parseB2EnvNodes(env: NodeJS.ProcessEnv = process.env): B2PoolNode[] {
  const nodes: B2PoolNode[] = [];
  const seen = new Set<string>();

  const tryAdd = (
    suffix: string,
    keyId?: string,
    applicationKey?: string,
    bucketName?: string,
    quotaRaw?: string,
    labelRaw?: string
  ) => {
    const cleanKeyId = String(keyId || '').trim();
    const cleanAppKey = String(applicationKey || '').trim();
    const cleanBucket = normalizeB2BucketName(bucketName || 'nighthost-cloud');
    if (!cleanKeyId || !cleanAppKey || !cleanBucket) return;
    const dedupe = `${cleanKeyId.toLowerCase()}::${cleanBucket.toLowerCase()}`;
    if (seen.has(dedupe)) return;
    seen.add(dedupe);
    const quotaMb = Math.max(100, Math.min(10485760, Number(quotaRaw) || 10240));
    nodes.push({
      id: `env_b2_${suffix || 'main'}`,
      label: String(labelRaw || '').trim() || `Backblaze B2 Pool ${suffix || 'Main'}`,
      keyId: cleanKeyId,
      applicationKey: cleanAppKey,
      bucketName: cleanBucket,
      quotaMb,
      usedMb: 0,
      status: 'checking',
      source: 'env',
    });
  };

  tryAdd(
    'main',
    env.B2_KEY_ID,
    env.B2_APPLICATION_KEY,
    env.B2_BUCKET_NAME || 'nighthost-cloud',
    env.B2_STORAGE_MB,
    env.B2_LABEL || 'Backblaze B2 Cloud (Primary)'
  );

  for (let i = 1; i <= 15; i++) {
    tryAdd(
      String(i),
      env[`B2_KEY_ID_${i}`],
      env[`B2_APPLICATION_KEY_${i}`],
      env[`B2_BUCKET_NAME_${i}`] || 'nighthost-cloud',
      env[`B2_STORAGE_MB_${i}`],
      env[`B2_LABEL_${i}`] || `Backblaze B2 Pool #${i}`
    );
  }

  return nodes;
}

export function mergeB2Nodes(envNodes: B2PoolNode[], manualNodes: B2PoolNode[] = []): B2PoolNode[] {
  const result: B2PoolNode[] = [...envNodes];
  const seen = new Set(envNodes.map(n => `${n.keyId.toLowerCase()}::${n.bucketName.toLowerCase()}`));
  for (const m of manualNodes) {
    const key = `${String(m.keyId || '').toLowerCase()}::${String(m.bucketName || '').toLowerCase()}`;
    if (!seen.has(key)) {
      seen.add(key);
      result.push(m);
    }
  }
  return result;
}

export function sanitizeB2NodeForClient(node: B2PoolNode): B2PoolNode {
  const copy = { ...node };
  delete copy.applicationKey;
  copy.keyId = maskB2KeyId(copy.keyId);
  return copy;
}

export function calculateB2PoolSummary(nodes: B2PoolNode[]): {
  nodesCount: number;
  connectedCount: number;
  connectedMb: number;
} {
  const connected = nodes.filter(n => n.status === 'connected');
  return {
    nodesCount: nodes.length,
    connectedCount: connected.length,
    connectedMb: connected.reduce((acc, n) => acc + (Number(n.quotaMb) || 0), 0),
  };
}

export async function b2AuthorizeAccount(
  keyId: string,
  applicationKey: string,
  forceRefresh = false
): Promise<{ ok: boolean; session?: B2AuthSession; error?: string }> {
  const cleanKeyId = String(keyId || '').trim();
  const cleanAppKey = String(applicationKey || '').trim();
  if (!cleanKeyId || !cleanAppKey) {
    return { ok: false, error: 'Backblaze B2 Key ID এবং Application Key দিন।' };
  }

  const cacheKey = `${cleanKeyId}:${cleanAppKey.slice(-6)}`;
  const cached = b2AuthCache.get(cacheKey);
  if (!forceRefresh && cached && cached.expiresAt > Date.now()) {
    return { ok: true, session: cached };
  }

  try {
    const basic = Buffer.from(`${cleanKeyId}:${cleanAppKey}`, 'utf-8').toString('base64');
    const res = await fetch('https://api.backblazeb2.com/b2api/v2/b2_authorize_account', {
      method: 'GET',
      headers: {
        Authorization: `Basic ${basic}`,
      },
      signal: AbortSignal.timeout(12000),
    });
    const text = await res.text();
    let json: {
      accountId?: string;
      authorizationToken?: string;
      apiUrl?: string;
      downloadUrl?: string;
      message?: string;
      code?: string;
    } = {};
    try {
      json = JSON.parse(text || '{}');
    } catch {
      // non-json
    }

    if (!res.ok || !json.authorizationToken || !json.apiUrl || !json.accountId) {
      return {
        ok: false,
        error: json.message || `Backblaze B2 Auth ব্যর্থ (HTTP ${res.status}): Key ID / Application Key যাচাই করুন।`,
      };
    }

    const session: B2AuthSession = {
      accountId: json.accountId,
      authorizationToken: json.authorizationToken,
      apiUrl: json.apiUrl.replace(/\/+$/, ''),
      downloadUrl: (json.downloadUrl || json.apiUrl).replace(/\/+$/, ''),
      expiresAt: Date.now() + 12 * 60 * 60 * 1000,
    };
    b2AuthCache.set(cacheKey, session);
    return { ok: true, session };
  } catch (err) {
    return {
      ok: false,
      error: `Backblaze B2 সার্ভার সংযোগ ত্রুটি: ${err instanceof Error ? err.message : 'Timeout'}`,
    };
  }
}

async function resolveB2BucketId(
  session: B2AuthSession,
  bucketName: string
): Promise<{ ok: boolean; bucketId?: string; error?: string }> {
  const cleanBucket = normalizeB2BucketName(bucketName);
  try {
    const res = await fetch(`${session.apiUrl}/b2api/v2/b2_list_buckets`, {
      method: 'POST',
      headers: {
        Authorization: session.authorizationToken,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        accountId: session.accountId,
        bucketName: cleanBucket,
      }),
      signal: AbortSignal.timeout(12000),
    });
    const json = (await res.json()) as {
      buckets?: Array<{ bucketId: string; bucketName: string }>;
      message?: string;
    };
    if (!res.ok) {
      return { ok: false, error: json.message || `B2 list_buckets failed (HTTP ${res.status})` };
    }
    const found = (json.buckets || []).find(b => b.bucketName.toLowerCase() === cleanBucket.toLowerCase());
    if (found) {
      return { ok: true, bucketId: found.bucketId };
    }

    // Attempt auto-creation if the key allows writeBuckets
    const createRes = await fetch(`${session.apiUrl}/b2api/v2/b2_create_bucket`, {
      method: 'POST',
      headers: {
        Authorization: session.authorizationToken,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        accountId: session.accountId,
        bucketName: cleanBucket,
        bucketType: 'allPrivate',
      }),
      signal: AbortSignal.timeout(12000),
    });
    if (createRes.ok) {
      const created = (await createRes.json()) as { bucketId?: string };
      if (created.bucketId) {
        return { ok: true, bucketId: created.bucketId };
      }
    }

    return {
      ok: false,
      error: `'${cleanBucket}' নামে Backblaze B2 Bucket পাওয়া যায়নি। B2 ড্যাশবোর্ডে বাকেট তৈরি করুন অথবা সঠিক নাম দিন।`,
    };
  } catch (err) {
    return {
      ok: false,
      error: `B2 Bucket যাচাই ত্রুটি: ${err instanceof Error ? err.message : 'Network error'}`,
    };
  }
}

export async function verifyAndEnsureB2Bucket(
  keyId: string,
  applicationKey: string,
  bucketName: string
): Promise<{ ok: boolean; bucketId?: string; error?: string }> {
  const auth = await b2AuthorizeAccount(keyId, applicationKey, true);
  if (!auth.ok || !auth.session) {
    return { ok: false, error: auth.error };
  }
  return resolveB2BucketId(auth.session, bucketName);
}

export async function fetchB2BucketUsageMb(
  keyId: string,
  applicationKey: string,
  bucketName: string
): Promise<number | null> {
  const auth = await b2AuthorizeAccount(keyId, applicationKey);
  if (!auth.ok || !auth.session) return null;
  const bucket = await resolveB2BucketId(auth.session, bucketName);
  if (!bucket.ok || !bucket.bucketId) return null;

  try {
    let totalBytes = 0;
    let startFileName: string | undefined;
    for (let page = 0; page < 10; page++) {
      const res = await fetch(`${auth.session.apiUrl}/b2api/v2/b2_list_file_names`, {
        method: 'POST',
        headers: {
          Authorization: auth.session.authorizationToken,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          bucketId: bucket.bucketId,
          maxFileCount: 1000,
          ...(startFileName ? { startFileName } : {}),
        }),
        signal: AbortSignal.timeout(12000),
      });
      if (!res.ok) break;
      const json = (await res.json()) as {
        files?: Array<{ contentLength?: number; fileName?: string }>;
        nextFileName?: string | null;
      };
      for (const f of json.files || []) {
        totalBytes += Number(f.contentLength) || 0;
      }
      if (!json.nextFileName) break;
      startFileName = json.nextFileName;
    }
    return Math.round((totalBytes / (1024 * 1024)) * 100) / 100;
  } catch {
    return null;
  }
}

async function uploadBufferToB2(
  node: B2PoolNode,
  remotePath: string,
  payload: Buffer,
  contentType = 'application/octet-stream'
): Promise<boolean> {
  if (!node.keyId || !node.applicationKey) return false;
  let auth = await b2AuthorizeAccount(node.keyId, node.applicationKey);
  if (!auth.ok || !auth.session) return false;

  const bucket = await resolveB2BucketId(auth.session, node.bucketName);
  if (!bucket.ok || !bucket.bucketId) return false;

  const attemptUpload = async (session: B2AuthSession, bucketId: string): Promise<boolean> => {
    const urlRes = await fetch(`${session.apiUrl}/b2api/v2/b2_get_upload_url`, {
      method: 'POST',
      headers: {
        Authorization: session.authorizationToken,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ bucketId }),
      signal: AbortSignal.timeout(12000),
    });
    if (!urlRes.ok) return false;
    const urlData = (await urlRes.json()) as {
      uploadUrl?: string;
      authorizationToken?: string;
    };
    if (!urlData.uploadUrl || !urlData.authorizationToken) return false;

    const sha1 = crypto.createHash('sha1').update(payload).digest('hex');
    const encodedName = remotePath
      .split('/')
      .map(seg => encodeURIComponent(seg))
      .join('/');

    const upRes = await fetch(urlData.uploadUrl, {
      method: 'POST',
      headers: {
        Authorization: urlData.authorizationToken,
        'X-Bz-File-Name': encodedName,
        'Content-Type': contentType,
        'Content-Length': String(payload.length),
        'X-Bz-Content-Sha1': sha1,
      },
      body: new Uint8Array(payload),
      signal: AbortSignal.timeout(30000),
    });
    return upRes.ok;
  };

  const firstOk = await attemptUpload(auth.session, bucket.bucketId);
  if (firstOk) return true;

  // Retry once with refreshed B2 token in case auth token expired
  auth = await b2AuthorizeAccount(node.keyId, node.applicationKey, true);
  if (!auth.ok || !auth.session) return false;
  return attemptUpload(auth.session, bucket.bucketId);
}

async function downloadBufferFromB2(node: B2PoolNode, remotePath: string): Promise<Buffer | null> {
  if (!node.keyId || !node.applicationKey) return null;
  const auth = await b2AuthorizeAccount(node.keyId, node.applicationKey);
  if (!auth.ok || !auth.session) return null;

  const encodedPath = remotePath
    .split('/')
    .map(seg => encodeURIComponent(seg))
    .join('/');
  const cleanBucket = normalizeB2BucketName(node.bucketName);

  try {
    const res = await fetch(`${auth.session.downloadUrl}/file/${cleanBucket}/${encodedPath}`, {
      method: 'GET',
      headers: {
        Authorization: auth.session.authorizationToken,
      },
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) return null;
    const arr = await res.arrayBuffer();
    return Buffer.from(arr);
  } catch {
    return null;
  }
}

async function deletePrefixFromB2(node: B2PoolNode, prefix: string): Promise<void> {
  if (!node.keyId || !node.applicationKey) return;
  const auth = await b2AuthorizeAccount(node.keyId, node.applicationKey);
  if (!auth.ok || !auth.session) return;
  const bucket = await resolveB2BucketId(auth.session, node.bucketName);
  if (!bucket.ok || !bucket.bucketId) return;

  try {
    const res = await fetch(`${auth.session.apiUrl}/b2api/v2/b2_list_file_versions`, {
      method: 'POST',
      headers: {
        Authorization: auth.session.authorizationToken,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        bucketId: bucket.bucketId,
        prefix,
        maxFileCount: 100,
      }),
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) return;
    const json = (await res.json()) as {
      files?: Array<{ fileId: string; fileName: string }>;
    };
    await Promise.all(
      (json.files || []).map(f =>
        fetch(`${auth.session!.apiUrl}/b2api/v2/b2_delete_file_version`, {
          method: 'POST',
          headers: {
            Authorization: auth.session!.authorizationToken,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ fileId: f.fileId, fileName: f.fileName }),
          signal: AbortSignal.timeout(10000),
        }).catch(() => {})
      )
    );
  } catch {
    // ignore cleanup error
  }
}

export async function syncSiteToB2Pool(
  nodes: B2PoolNode[],
  site: HostedSite
): Promise<{ uploaded: boolean; usedNodeId?: string }> {
  const active = nodes.filter(n => n.status === 'connected' && n.applicationKey);
  if (active.length === 0) return { uploaded: false };

  const filesMap = site.files || {};
  if (Object.keys(filesMap).length === 0) return { uploaded: false };

  const rawJson = JSON.stringify({
    siteId: site.id,
    slug: site.slug,
    updatedAt: site.updatedAt,
    files: filesMap,
  });
  const gz = zlib.gzipSync(Buffer.from(rawJson, 'utf-8'), { level: 6 });

  const idx =
    Math.abs(
      String(site.id || '')
        .split('')
        .reduce((a, c) => a + c.charCodeAt(0), 0)
    ) % active.length;
  const primaryNode = active[idx];
  const ordered = [primaryNode, ...active.filter(n => n.id !== primaryNode.id)];

  for (const node of ordered) {
    const ok = await uploadBufferToB2(
      node,
      `nighthost/sites/${site.id}/bundle.json.gz`,
      gz,
      'application/gzip'
    );
    if (ok) {
      return { uploaded: true, usedNodeId: node.id };
    }
  }
  return { uploaded: false };
}

export async function fetchSiteBundleFromB2(
  nodes: B2PoolNode[],
  siteId: string
): Promise<Record<string, SiteFile> | null> {
  const active = nodes.filter(n => n.status === 'connected' && n.applicationKey);
  if (active.length === 0) return null;

  for (const node of active) {
    const buf = await downloadBufferFromB2(node, `nighthost/sites/${siteId}/bundle.json.gz`);
    if (!buf) continue;
    try {
      const jsonStr = zlib.gunzipSync(buf).toString('utf-8');
      const parsed = JSON.parse(jsonStr) as { files?: Record<string, SiteFile> };
      if (parsed?.files && typeof parsed.files === 'object' && Object.keys(parsed.files).length > 0) {
        return parsed.files;
      }
    } catch {
      // try next node
    }
  }
  return null;
}

export async function deleteSiteBundleFromB2(nodes: B2PoolNode[], siteId: string): Promise<void> {
  const active = nodes.filter(n => n.status === 'connected' && n.applicationKey);
  await Promise.all(active.map(n => deletePrefixFromB2(n, `nighthost/sites/${siteId}/`)));
}

export async function syncCoreStateToB2(
  nodes: B2PoolNode[],
  coreState: Record<string, unknown>
): Promise<boolean> {
  const active = nodes.filter(n => n.status === 'connected' && n.applicationKey);
  if (active.length === 0) return false;
  const gz = zlib.gzipSync(Buffer.from(JSON.stringify(coreState), 'utf-8'), { level: 6 });

  for (const node of active) {
    const ok = await uploadBufferToB2(node, 'nighthost-core/state.json.gz', gz, 'application/gzip');
    if (ok) return true;
  }
  return false;
}

export async function fetchCoreStateFromB2<T = Record<string, unknown>>(
  nodes: B2PoolNode[]
): Promise<T | null> {
  const active = nodes.filter(n => n.status === 'connected' && n.applicationKey);
  for (const node of active) {
    const buf = await downloadBufferFromB2(node, 'nighthost-core/state.json.gz');
    if (!buf) continue;
    try {
      const jsonStr = zlib.gunzipSync(buf).toString('utf-8');
      return JSON.parse(jsonStr) as T;
    } catch {
      // try next node
    }
  }
  return null;
}

export function generateCombinedRenderEnvVariables(
  supabaseNodes: SupabasePoolNode[],
  b2Nodes: B2PoolNode[],
  primaryDomain?: string,
  includeActualKeys = true
): {
  pairs: Array<{ key: string; value: string }>;
  dotenvText: string;
  poolJson: string;
} {
  const pairs: Array<{ key: string; value: string }> = [];
  const cleanDomain = normalizePrimaryDomain(primaryDomain) || DEFAULT_PRIMARY_DOMAIN;
  pairs.push({ key: 'NIGHTHOST_PRIMARY_DOMAIN', value: cleanDomain });

  b2Nodes.forEach((n, index) => {
    const suffix = index === 0 ? '' : `_${index}`;
    const appKeyVal = includeActualKeys
      ? n.applicationKey || '<YOUR_B2_APPLICATION_KEY>'
      : n.applicationKey
      ? `${n.applicationKey.slice(0, 6)}...${n.applicationKey.slice(-4)}`
      : '<YOUR_B2_APPLICATION_KEY>';
    pairs.push({ key: `B2_KEY_ID${suffix}`, value: n.keyId });
    pairs.push({ key: `B2_APPLICATION_KEY${suffix}`, value: appKeyVal });
    pairs.push({ key: `B2_BUCKET_NAME${suffix}`, value: n.bucketName });
    pairs.push({ key: `B2_STORAGE_MB${suffix}`, value: String(n.quotaMb || 10240) });
  });

  const validSb = supabaseNodes.filter(n => n.url && n.bucketName);
  validSb.forEach((n, index) => {
    const idx = index + 1;
    const keyVal = includeActualKeys
      ? n.serviceRoleKey || n.serviceRoleKeyMasked || '<PASTE_SERVICE_ROLE_KEY>'
      : n.serviceRoleKeyMasked || '<PASTE_SERVICE_ROLE_KEY>';
    pairs.push({ key: `SUPABASE_LABEL_${idx}`, value: n.label || `Supabase Pool #${idx}` });
    pairs.push({ key: `SUPABASE_URL_${idx}`, value: normalizeSupabaseUrl(n.url) });
    pairs.push({ key: `SUPABASE_SERVICE_ROLE_KEY_${idx}`, value: keyVal });
    pairs.push({ key: `SUPABASE_BUCKET_${idx}`, value: n.bucketName || 'nighthost-sites' });
    pairs.push({ key: `SUPABASE_STORAGE_MB_${idx}`, value: String(Math.max(50, Number(n.quotaMb) || 1024)) });
  });

  const compactPool = validSb.map((node, idx) => ({
    label: node.label || `Supabase Pool #${idx + 1}`,
    url: normalizeSupabaseUrl(node.url),
    key: includeActualKeys ? node.serviceRoleKey || node.serviceRoleKeyMasked || '' : node.serviceRoleKeyMasked || '',
    bucket: node.bucketName || 'nighthost-sites',
    quotaMb: Math.max(50, Number(node.quotaMb) || 1024),
  }));

  return {
    pairs,
    dotenvText: pairs.map(v => `${v.key}=${v.value}`).join('\n'),
    poolJson: JSON.stringify(compactPool),
  };
}
