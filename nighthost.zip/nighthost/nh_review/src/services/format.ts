import { UserRole } from '../types';

export interface ServerPoolPreset {
  id: string;
  nameBn: string;
  nameEn: string;
  providerNote: string;
  capacityMb: number;
}

export const SERVER_POOL_PRESETS: ServerPoolPreset[] = [
  {
    id: 'github-free',
    nameBn: 'GitHub ফ্রি স্টোরেজ (1 GB)',
    nameEn: 'GitHub Free Pool (1 GB)',
    providerNote: 'GitHub Pages / Repo Starter',
    capacityMb: 1024,
  },
  {
    id: 'supabase-render',
    nameBn: 'Supabase + Render স্টার্টার (5 GB)',
    nameEn: 'Supabase + Render Starter (5 GB)',
    providerNote: 'Free Tier Cloud Mix',
    capacityMb: 5120,
  },
  {
    id: 'pro-cloud',
    nameBn: 'প্রো ক্লাউড পুল (10 GB)',
    nameEn: 'Pro Cloud Pool (10 GB)',
    providerNote: 'Standard Production Node',
    capacityMb: 10240,
  },
  {
    id: 'scale-node',
    nameBn: 'স্কেল এন্টারপ্রাইজ নোড (25 GB)',
    nameEn: 'Scale Enterprise Node (25 GB)',
    providerNote: 'High-Volume Hosting Node',
    capacityMb: 25600,
  },
];

function stripTrailingZeroes(val: string): string {
  return val.replace(/\.0+$/, '').replace(/(\.\d*[1-9])0+$/, '$1');
}

/**
 * Formats a megabyte value cleanly into KB (< 1 MB), MB (1 - 1023.9 MB), or GB (>= 1024 MB).
 */
export function formatStorageFromMb(mb: number): string {
  const safeMb = Number.isFinite(mb) ? Math.max(0, mb) : 0;
  if (safeMb === 0) return '0 KB';
  if (safeMb < 1) {
    const kb = Math.max(1, Math.round(safeMb * 1024));
    if (kb >= 1024) return '1 MB';
    return `${kb} KB`;
  }
  if (safeMb < 1024) {
    return `${stripTrailingZeroes(safeMb.toFixed(1))} MB`;
  }
  const gb = safeMb / 1024;
  return `${stripTrailingZeroes(gb.toFixed(2))} GB`;
}

/**
 * Formats a kilobyte value cleanly into KB (< 1024 KB), MB, or GB.
 */
export function formatStorageFromKb(kb: number): string {
  const safeKb = Number.isFinite(kb) ? Math.max(0, kb) : 0;
  if (safeKb === 0) return '0 KB';
  if (safeKb < 1) return '1 KB';
  if (safeKb < 1024) {
    return `${Math.round(safeKb)} KB`;
  }
  return formatStorageFromMb(safeKb / 1024);
}

/**
 * Maps internal role ('admin' | 'subadmin' | 'user') to localized display names:
 * - 'admin' -> মালিক / Owner
 * - 'subadmin' -> অ্যাডমিন / Admin
 * - 'user' -> ইউজার / User
 */
export function getRoleDisplayLabel(role: UserRole | string, lang: 'bn' | 'en'): string {
  if (role === 'admin') {
    return lang === 'bn' ? 'মালিক' : 'Owner';
  }
  if (role === 'subadmin') {
    return lang === 'bn' ? 'অ্যাডমিন' : 'Admin';
  }
  return lang === 'bn' ? 'ইউজার' : 'User';
}

/**
 * Normalizes a user-specified unique link/domain (e.g. "my-shop", "myshop.nighthost.app", "app.custom.io")
 * into a clean DNS-safe hostname string. Single labels automatically receive `.nighthost.app`.
 */
export function normalizeCustomDomain(raw: string, baseSuffix = 'nighthost.app'): string {
  let cleaned = String(raw || '')
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/\/.*$/, '')
    .replace(/:\d+$/, '')
    .replace(/[^a-z0-9.-]/g, '-')
    .replace(/\.{2,}/g, '.')
    .replace(/^-+|-+$/g, '')
    .replace(/^\.+|\.+$/g, '');

  if (!cleaned) return '';

  if (!cleaned.includes('.')) {
    cleaned = `${cleaned}.${baseSuffix}`;
  }

  const labels = cleaned
    .split('.')
    .map(part => part.replace(/^-+|-+$/g, ''))
    .filter(Boolean);

  if (labels.length < 2) return '';
  return labels.join('.');
}

export const DEFAULT_PRIMARY_DOMAIN = 'nighthostcloud.dpdns.org';

const RESERVED_SUBDOMAINS = new Set([
  'www',
  'admin',
  'owner',
  'api',
  'app',
  'auth',
  'login',
  'register',
  'panel',
  'control',
  'mail',
  'smtp',
  'imap',
  'ftp',
  'ssh',
  'cpanel',
  'webmail',
  'ns1',
  'ns2',
  'dns',
  'edge',
  'proxy',
  'worker',
  'cloudflare',
  'root',
  'sys',
  'system',
  'support',
  'help',
  'status',
  'billing',
  'dashboard',
  'console',
  'portal',
  'nighthost',
  'nighthostcloud',
  'static',
  'assets',
  'uploads',
  'blob',
  'storage',
  'runtime',
  'node',
  'python',
  'php',
  'db',
  'sql',
  'b2',
  'supabase',
  'gemini',
  'cdn',
  'site',
  'sites',
  'u',
  'd',
]);

export function isReservedSubdomain(subdomain: string): boolean {
  return RESERVED_SUBDOMAINS.has(String(subdomain || '').trim().toLowerCase());
}

/**
 * Normalizes a user account subdomain label (lowercase DNS label, 3-32 chars, [a-z0-9-]).
 * Returns '' if invalid or reserved.
 */
export function normalizeUserSubdomain(raw: string): string {
  const cleaned = String(raw || '')
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/\..*$/, '')
    .replace(/[^a-z0-9-]/g, '-')
    .replace(/-{2,}/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 32)
    .replace(/-+$/g, '');

  if (!cleaned || cleaned.length < 3 || isReservedSubdomain(cleaned)) {
    return '';
  }
  return cleaned;
}

export function normalizePrimaryDomain(raw?: string): string {
  return String(raw || '')
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/\/.*$/, '')
    .replace(/:\d+$/, '')
    .replace(/^\.+|\.+$/g, '');
}

export interface SubdomainUrlsResult {
  primaryDomain: string;
  wildcardRootUrl: string | null;
  wildcardSiteUrl: string | null;
  wildcardAltUrl: string | null;
  pathUrl: string;
  directSiteUrl: string;
}

/**
 * Builds Cloudflare Free Universal SSL safe 1-level wildcard URLs alongside standard fallback routes.
 */
export function buildSubdomainUrls(
  ownerSubdomain?: string,
  siteSlug?: string,
  primaryDomainInput?: string
): SubdomainUrlsResult {
  const domain = normalizePrimaryDomain(primaryDomainInput) || DEFAULT_PRIMARY_DOMAIN;
  const cleanSub = normalizeUserSubdomain(ownerSubdomain || '');
  const cleanSlug =
    String(siteSlug || 'site')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9-]+/g, '-')
      .replace(/-{2,}/g, '-')
      .replace(/^-+|-+$/g, '') || 'site';

  const canUseSub = Boolean(cleanSub && domain && !isReservedSubdomain(cleanSub));
  const combinedLabel = `${cleanSlug}-${cleanSub}`.replace(/-{2,}/g, '-').slice(0, 62).replace(/-+$/g, '');

  return {
    primaryDomain: domain,
    wildcardRootUrl: canUseSub ? `https://${cleanSub}.${domain}` : null,
    wildcardSiteUrl: canUseSub ? `https://${cleanSub}.${domain}/${cleanSlug}` : null,
    wildcardAltUrl: canUseSub && combinedLabel ? `https://${combinedLabel}.${domain}` : null,
    pathUrl: cleanSub ? `/u/${cleanSub}/${cleanSlug}` : `/site/${cleanSlug}`,
    directSiteUrl: `/site/${cleanSlug}`,
  };
}

/**
 * Sanitizes an external popup/notice link URL so only safe http(s) URLs are accepted.
 * Rejects javascript:, data:, vbscript:, file: and invalid schemes.
 */
export function sanitizeExternalLinkUrl(raw: string): string {
  const trimmed = String(raw || '').trim();
  if (!trimmed) return '';
  if (/^(javascript|data|vbscript|file):/i.test(trimmed)) {
    return '';
  }
  const withScheme = /^https?:\/\//i.test(trimmed)
    ? trimmed
    : /^[a-z0-9.-]+\.[a-z]{2,}([/:?#].*)?$/i.test(trimmed)
    ? `https://${trimmed}`
    : '';
  if (!withScheme) return '';
  try {
    const parsed = new URL(withScheme);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return '';
    }
    return parsed.toString();
  } catch {
    return '';
  }
}

export interface PoolAllocationInputUser {
  role: string;
  status: string;
  storageLimitMb: number;
  storageUsedMb: number;
  avatarSizeKb?: number;
}

export interface PoolAllocationInputSite {
  totalSizeKb: number;
}

export interface PoolAllocationSummary {
  allocatedMb: number;
  usedBySitesMb: number;
  usedByAvatarsMb: number;
  totalUsedMb: number;
  remainingAllocatableMb: number;
  estimatedRemainingUsers: number;
  totalUsersCount: number;
  approvedUsersCount: number;
  pendingUsersCount: number;
  suspendedUsersCount: number;
}

/**
 * Computes real pool allocation & consumption.
 * - Owner ('admin') and Admin ('subadmin') personal records do NOT consume normal user pool quota
 *   unless they actually upload sites/avatars (actual bytes are always counted in totalUsedMb).
 * - Pending (unapproved) normal users reserve 0 MB until approved by Owner/Admin.
 */
export function computePoolAllocationSummary(
  users: PoolAllocationInputUser[],
  sites: PoolAllocationInputSite[],
  configuredPoolMb: number,
  defaultQuotaMb = 100
): PoolAllocationSummary {
  const managedUsers = users.filter((u) => u.role === 'user');
  const approvedUsers = managedUsers.filter((u) => u.status === 'approved');
  const pendingUsers = managedUsers.filter((u) => u.status === 'pending');
  const suspendedUsers = managedUsers.filter((u) => u.status === 'suspended');

  const allocatedMb =
    Math.round(
      approvedUsers.reduce((acc, u) => acc + Math.max(0, Number(u.storageLimitMb) || 0), 0) * 10
    ) / 10;

  const usedBySitesMb =
    Math.round(sites.reduce((acc, s) => acc + Math.max(0, Number(s.totalSizeKb) || 0) / 1024, 0) * 1000) /
    1000;
  const usedByAvatarsMb =
    Math.round(users.reduce((acc, u) => acc + Math.max(0, Number(u.avatarSizeKb) || 0) / 1024, 0) * 1000) /
    1000;
  const totalUsedMb = Math.round((usedBySitesMb + usedByAvatarsMb) * 1000) / 1000;

  // Suspended accounts still keep any existing site bytes on disk even though active quota reservation is paused
  const suspendedUsedMb = suspendedUsers.reduce(
    (acc, u) => acc + Math.max(0, Number(u.storageUsedMb) || 0),
    0
  );
  const effectiveCommittedMb = Math.max(allocatedMb + suspendedUsedMb, totalUsedMb);
  const safePoolMb = Math.max(0, Number(configuredPoolMb) || 0);
  const safeDefaultQuota = Math.max(10, Number(defaultQuotaMb) || 100);
  const remainingAllocatableMb = Math.max(0, Math.round((safePoolMb - effectiveCommittedMb) * 1000) / 1000);
  const estimatedRemainingUsers = Math.floor(remainingAllocatableMb / safeDefaultQuota);

  return {
    allocatedMb,
    usedBySitesMb,
    usedByAvatarsMb,
    totalUsedMb,
    remainingAllocatableMb,
    estimatedRemainingUsers,
    totalUsersCount: managedUsers.length,
    approvedUsersCount: approvedUsers.length,
    pendingUsersCount: pendingUsers.length,
    suspendedUsersCount: suspendedUsers.length,
  };
}

function escapeNoticeHtml(input: string): string {
  return String(input || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function renderSiteUnavailableHtml(params: {
  siteName: string;
  reason: 'suspended' | 'expired' | 'paused';
  ownerName: string;
  ownerTelegramUrl: string;
  ownerTelegramHandle: string;
  brandName?: string;
}): string {
  const safeSiteName = escapeNoticeHtml(params.siteName || 'Hosted Website');
  const safeBrand = escapeNoticeHtml(params.brandName || 'NIGHTHOST');
  const safeOwnerName = escapeNoticeHtml(params.ownerName || 'NIGHT HEX');
  const safeHandle = escapeNoticeHtml(params.ownerTelegramHandle || '@NightHex_X');
  const safeTgUrl = /^https?:\/\//i.test(params.ownerTelegramUrl || '')
    ? escapeNoticeHtml(params.ownerTelegramUrl)
    : 'https://t.me/NightHex_X';

  const isSuspended = params.reason === 'suspended';
  const isExpired = params.reason === 'expired';

  const badgeText = isSuspended
    ? 'ACCOUNT SUSPENDED • WEBSITE OFFLINE'
    : isExpired
    ? 'HOSTING EXPIRED • RENEWAL REQUIRED'
    : 'WEBSITE PAUSED • TEMPORARILY OFFLINE';

  const titleText = isSuspended
    ? 'এই ওয়েবসাইটটি সাময়িকভাবে বন্ধ রয়েছে'
    : isExpired
    ? 'এই ওয়েবসাইটের হোস্টিং মেয়াদ শেষ হয়েছে'
    : 'ওয়েবসাইটটি বর্তমানে পজ রাখা হয়েছে';

  const descBn = isSuspended
    ? 'এই ওয়েবসাইটের মালিকের হোস্টিং অ্যাকাউন্টটি অ্যাডমিনিস্ট্রেটর কর্তৃক সাময়িকভাবে সাসপেন্ড করা হয়েছে। ওয়েবসাইট পুনরায় সচল করতে হোস্টিং মালিকের সাথে যোগাযোগ করুন।'
    : isExpired
    ? 'এই ওয়েবসাইটের হোস্টিং অ্যাক্সেসের মেয়াদ শেষ হয়ে গেছে। সাইটটি আবার লাইভ করতে হোস্টিং মালিকের সাথে যোগাযোগ করে মেয়াদ রিনিউ করুন।'
    : 'সাইটের মালিক সাময়িকভাবে এই ওয়েবসাইটটি পজ করে রেখেছেন। কিছুক্ষণ পর আবার চেষ্টা করুন।';

  const descEn = isSuspended
    ? 'This website is offline because its hosting account has been suspended. Please contact the platform owner to restore access.'
    : isExpired
    ? 'This website is offline because its hosting validity period has expired. Please contact the platform owner to renew hosting.'
    : 'This website is temporarily paused by its owner.';

  const accentBorder = isSuspended
    ? 'rgba(244,63,94,0.38)'
    : isExpired
    ? 'rgba(245,158,11,0.38)'
    : 'rgba(56,189,248,0.35)';
  const accentColor = isSuspended ? '#fb7185' : isExpired ? '#fbbf24' : '#38bdf8';

  return `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${safeSiteName} - ${isSuspended ? 'Account Suspended' : isExpired ? 'Hosting Expired' : 'Paused'}</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
      background: radial-gradient(circle at top, #0f172a, #020617);
      color: #f8fafc;
      padding: 20px;
    }
    .card {
      width: 100%;
      max-width: 480px;
      padding: 30px 26px;
      border-radius: 22px;
      background: rgba(15, 23, 42, 0.92);
      border: 1px solid ${accentBorder};
      box-shadow: 0 24px 60px -15px rgba(0, 0, 0, 0.65);
      text-align: center;
    }
    .badge {
      display: inline-block;
      padding: 5px 12px;
      border-radius: 999px;
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.04em;
      color: ${accentColor};
      background: rgba(2, 6, 23, 0.7);
      border: 1px solid ${accentBorder};
      margin-bottom: 14px;
    }
    h1 {
      margin: 0 0 10px;
      font-size: 20px;
      line-height: 1.35;
      color: #ffffff;
    }
    .site-name {
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
      font-size: 12px;
      color: #38bdf8;
      margin-bottom: 12px;
    }
    p {
      margin: 0 0 10px;
      color: #cbd5e1;
      font-size: 13.5px;
      line-height: 1.65;
    }
    .en {
      color: #94a3b8;
      font-size: 12px;
      margin-bottom: 20px;
    }
    .contact-box {
      padding: 14px 16px;
      border-radius: 16px;
      background: rgba(2, 6, 23, 0.72);
      border: 1px solid rgba(51, 65, 85, 0.75);
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      text-align: left;
      flex-wrap: wrap;
    }
    .owner-meta {
      min-width: 0;
    }
    .owner-label {
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: #94a3b8;
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    }
    .owner-name {
      font-size: 14px;
      font-weight: 700;
      color: #f8fafc;
    }
    .owner-handle {
      font-size: 11px;
      color: #38bdf8;
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    }
    .tg-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 9px 15px;
      border-radius: 12px;
      background: linear-gradient(135deg, #0284c7, #2563eb);
      color: #ffffff;
      text-decoration: none;
      font-size: 12px;
      font-weight: 700;
      white-space: nowrap;
    }
    .foot {
      margin-top: 16px;
      font-size: 11px;
      color: #64748b;
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="badge">${badgeText}</div>
    <div class="site-name">${safeSiteName}</div>
    <h1>${titleText}</h1>
    <p>${descBn}</p>
    <p class="en">${descEn}</p>
    <div class="contact-box">
      <div class="owner-meta">
        <div class="owner-label">Hosting Owner</div>
        <div class="owner-name">${safeOwnerName}</div>
        <div class="owner-handle">${safeHandle}</div>
      </div>
      <a class="tg-btn" href="${safeTgUrl}" target="_blank" rel="noopener noreferrer">Contact on Telegram</a>
    </div>
    <div class="foot">Powered by ${safeBrand} Cloud</div>
  </div>
</body>
</html>`;
}

/**
 * Formats non-JSON HTTP responses (e.g. Render 502/504/413/503/507 HTML proxy pages or Express body-parser errors)
 * into a clear diagnostic message instead of a generic JSON parse failure or false 403 expiration notice.
 */
export function formatHttpTransportError(status: number, rawBody = ''): string {
  const raw = String(rawBody || '').trim();
  if (raw.startsWith('{')) {
    try {
      const parsed = JSON.parse(raw) as { message?: string };
      if (parsed?.message && !/^\s*</.test(parsed.message)) {
        return parsed.message;
      }
    } catch {
      // fall through
    }
  }

  const lower = raw.toLowerCase();
  if (status === 507 || /insufficient_storage|quota_exceeded/i.test(lower)) {
    return 'স্টোরেজ কোটা বা সার্ভার স্টোরেজ সীমা পূর্ণ হয়েছে (HTTP 507)। পুরোনো সাইট বা বড় ফাইল কমিয়ে পুনরায় চেষ্টা করুন।';
  }
  if (status === 503 || /high_load|concurrency_limit|too many concurrent/i.test(lower)) {
    return 'সার্ভারে ডায়নামিক লোড সাময়িকভাবে বেশি (HTTP 503 High Load)। ৫-১০ সেকেন্ড পর আবার চেষ্টা করুন।';
  }
  if (status === 413 || lower.includes('payloadtoolarge') || lower.includes('entity too large')) {
    return 'প্রজেক্ট ফোল্ডারের সাইজ সার্ভার সীমা অতিক্রম করেছে (HTTP 413)। বড় মিডিয়া/ভিডিও বা node_modules বাদ দিয়ে আবার আপলোড করুন।';
  }
  if (status === 502 || status === 504) {
    return `সার্ভার সাময়িকভাবে রিস্টার্ট বা টাইমআউট হয়েছে (HTTP ${status})। ১০-১৫ সেকেন্ড অপেক্ষা করে আবার চেষ্টা করুন, অথবা ফোল্ডারের সাইজ কিছুটা কমিয়ে দিন।`;
  }
  if (status === 401) {
    return 'লগইন সেশন মেয়াদোত্তীর্ণ হয়েছে (HTTP 401)। পেজ রিলোড করে পুনরায় লগইন করুন।';
  }
  if (status === 403) {
    return 'এই কাজের অনুমতি নেই বা আপনার অ্যাকাউন্ট অনুমোদন/মেয়াদ বাকি (HTTP 403)।';
  }
  if (status >= 500) {
    return `সার্ভারে অভ্যন্তরীণ ত্রুটি ঘটেছে (HTTP ${status})। কিছুক্ষণ পর আবার চেষ্টা করুন।`;
  }
  if (status === 0) {
    return 'সার্ভারের সাথে সংযোগ বিচ্ছিন্ন হয়েছে (Network / Timeout)। ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।';
  }
  return `সার্ভার রেসপন্স পার্স করতে সমস্যা হয়েছে (HTTP ${status || 'Unknown'})।`;
}

