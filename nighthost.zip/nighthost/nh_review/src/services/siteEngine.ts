import { HostedSite, ScanResult, SiteFile } from '../types';

const BINARY_EXTENSIONS = [
  '.png', '.jpg', '.jpeg', '.gif', '.webp', '.ico', '.bmp', '.avif',
  '.woff', '.woff2', '.ttf', '.eot', '.otf',
  '.mp3', '.wav', '.ogg', '.mp4', '.webm',
  '.pdf', '.zip', '.wasm',
];

export function isBinaryFile(fileName: string): boolean {
  const lower = fileName.toLowerCase();
  return BINARY_EXTENSIONS.some(ext => lower.endsWith(ext));
}

export function getMimeType(fileName: string): string {
  const lower = fileName.toLowerCase();
  if (lower.endsWith('.html') || lower.endsWith('.htm')) return 'text/html; charset=utf-8';
  if (lower.endsWith('.css')) return 'text/css; charset=utf-8';
  if (lower.endsWith('.js') || lower.endsWith('.mjs') || lower.endsWith('.cjs')) return 'application/javascript; charset=utf-8';
  if (lower.endsWith('.ts') || lower.endsWith('.tsx') || lower.endsWith('.jsx')) return 'application/javascript; charset=utf-8';
  if (lower.endsWith('.json')) return 'application/json; charset=utf-8';
  if (lower.endsWith('.svg')) return 'image/svg+xml';
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
  if (lower.endsWith('.gif')) return 'image/gif';
  if (lower.endsWith('.webp')) return 'image/webp';
  if (lower.endsWith('.ico')) return 'image/x-icon';
  if (lower.endsWith('.avif')) return 'image/avif';
  if (lower.endsWith('.woff')) return 'font/woff';
  if (lower.endsWith('.woff2')) return 'font/woff2';
  if (lower.endsWith('.ttf')) return 'font/ttf';
  if (lower.endsWith('.otf')) return 'font/otf';
  if (lower.endsWith('.eot')) return 'application/vnd.ms-fontobject';
  if (lower.endsWith('.wasm')) return 'application/wasm';
  if (lower.endsWith('.pdf')) return 'application/pdf';
  if (lower.endsWith('.mp4')) return 'video/mp4';
  if (lower.endsWith('.mp3')) return 'audio/mpeg';
  if (lower.endsWith('.txt') || lower.endsWith('.md')) return 'text/plain; charset=utf-8';
  if (lower.endsWith('.xml')) return 'application/xml; charset=utf-8';
  return 'application/octet-stream';
}

export function isPathHidden(path: string): boolean {
  const segments = path.split('/');
  return segments.some(segment => segment.startsWith('.') && segment.length > 1);
}

export function getFileType(fileName: string): string {
  const lower = fileName.toLowerCase();
  if (lower.endsWith('.html') || lower.endsWith('.htm')) return 'html';
  if (lower.endsWith('.css')) return 'css';
  if (lower.endsWith('.js') || lower.endsWith('.mjs') || lower.endsWith('.cjs') || lower.endsWith('.ts') || lower.endsWith('.tsx') || lower.endsWith('.jsx')) return 'js';
  if (lower.endsWith('.php')) return 'php';
  if (lower.endsWith('.json')) return 'json';
  if (
    lower.endsWith('.png') ||
    lower.endsWith('.jpg') ||
    lower.endsWith('.jpeg') ||
    lower.endsWith('.svg') ||
    lower.endsWith('.webp') ||
    lower.endsWith('.gif') ||
    lower.endsWith('.ico') ||
    lower.endsWith('.avif')
  ) {
    return 'image';
  }
  if (lower.endsWith('.woff') || lower.endsWith('.woff2') || lower.endsWith('.ttf') || lower.endsWith('.otf') || lower.endsWith('.eot')) {
    return 'font';
  }
  if (lower.endsWith('.md') || lower.endsWith('.txt')) return 'text';
  if (
    isPathHidden(fileName) ||
    lower.endsWith('.env') ||
    lower.endsWith('.htaccess') ||
    lower.endsWith('.yml') ||
    lower.endsWith('.yaml') ||
    lower.endsWith('.config.js')
  ) {
    return 'config';
  }
  if (lower.endsWith('.py')) return 'python';
  return 'other';
}

export function detectProjectRuntime(
  files: { path: string; content?: string }[]
): { runtime: 'static' | 'php' | 'node' | 'python'; backendEntry: string | null } {
  const byLower = new Map<string, { path: string; content: string }>();
  for (const f of files) {
    const clean = f.path.replace(/^\/+/, '');
    byLower.set(clean.toLowerCase(), { path: clean, content: f.content || '' });
  }

  // 1. Check Python web backend entrypoints
  const hasRootIndexHtml = byLower.has('index.html');
  const isSimpleStaticPyHelper = (content: string) =>
    /(http\.server|SimpleHTTPRequestHandler|http\.server\.test)/i.test(content) &&
    !/(Flask|FastAPI|BaseHTTPRequestHandler|def\s+do_(?:GET|POST)|@app\.|@router\.)/i.test(content);

  const pyCandidates = ['app.py', 'main.py', 'server.py', 'run.py', 'wsgi.py', 'api/index.py', 'backend/app.py'];
  for (const cand of pyCandidates) {
    const hit = byLower.get(cand);
    if (hit) {
      if (hasRootIndexHtml && isSimpleStaticPyHelper(hit.content)) {
        continue;
      }
      return { runtime: 'python', backendEntry: hit.path };
    }
  }
  for (const [, val] of byLower) {
    if (
      val.path.toLowerCase().endsWith('.py') &&
      /(Flask\s*\(|FastAPI\s*\(|ThreadingHTTPServer|HTTPServer|BaseHTTPRequestHandler|app\.run\s*\()/i.test(
        val.content
      )
    ) {
      if (hasRootIndexHtml && isSimpleStaticPyHelper(val.content)) {
        continue;
      }
      return { runtime: 'python', backendEntry: val.path };
    }
  }

  // 2. Check Node.js backend server entrypoints (ignore frontend-only Vite React projects)
  const isViteFrontendOnly =
    (byLower.has('vite.config.ts') || byLower.has('vite.config.js')) &&
    !byLower.has('server.ts') &&
    !byLower.has('server.js') &&
    !byLower.has('app.js');

  if (!isViteFrontendOnly) {
    const pkgFile = byLower.get('package.json');
    if (pkgFile?.content) {
      try {
        const parsedPkg = JSON.parse(pkgFile.content) as { main?: string };
        if (typeof parsedPkg.main === 'string') {
          const pkgMain = byLower.get(parsedPkg.main.replace(/^\.\//, '').toLowerCase());
          if (
            pkgMain &&
            /(express\s*\(|http\.createServer|https\.createServer|\.listen\s*\(|Fastify|Koa|Hono)/i.test(pkgMain.content)
          ) {
            return { runtime: 'node', backendEntry: pkgMain.path };
          }
        }
      } catch {
        // ignore invalid package.json
      }
    }

    const nodeCandidates = [
      '__nighthost_serverless_entry.mjs',
      'server.js',
      'server.mjs',
      'server.ts',
      'app.js',
      'app.mjs',
      'app.ts',
      'index.js',
      'index.mjs',
      'api/index.js',
      'backend/server.js',
      'src/server.js',
    ];
    for (const cand of nodeCandidates) {
      const hit = byLower.get(cand);
      if (
        hit &&
        /(express\s*\(|http\.createServer|https\.createServer|\.listen\s*\(|Fastify|Koa|Hono|__NIGHTHOST_SERVERLESS_BRIDGE__)/i.test(hit.content)
      ) {
        return { runtime: 'node', backendEntry: hit.path };
      }
    }

    // Check raw Vercel/Netlify serverless handlers even before repair wrapper is synthesized
    for (const [, val] of byLower) {
      const low = val.path.toLowerCase();
      if (
        (/^(api|netlify\/functions)\/[^/].*\.(js|mjs|cjs|ts)$/i.test(low) ||
          low === 'vercel.json') &&
        byLower.has('vercel.json')
      ) {
        return { runtime: 'node', backendEntry: val.path };
      }
      if (
        /^(api|netlify\/functions)\/.+\.(js|mjs|cjs|ts)$/i.test(low) &&
        /(export\s+default|module\.exports|exports\.handler|export\s+(async\s+)?function\s+(GET|POST|PUT|DELETE|handler))/i.test(
          val.content
        )
      ) {
        return { runtime: 'node', backendEntry: val.path };
      }
    }
  }

  // 3. Check PHP
  if (
    byLower.has('index.php') ||
    Array.from(byLower.keys()).some(k => k.endsWith('.php'))
  ) {
    return { runtime: 'php', backendEntry: null };
  }

  return { runtime: 'static', backendEntry: null };
}

export function generateChecksum(input: string): string {
  let hash = 0;
  for (let i = 0; i < input.length; i++) {
    const char = input.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0');
  return `0x${hex}f94c8e71`;
}

export function auditFolderFiles(files: { path: string; content: string; size: number }[]): ScanResult {
  let hiddenCount = 0;
  let totalSizeBytes = 0;
  let entryPointFound: string | null = null;
  const warnings: string[] = [];
  const errors: string[] = [];
  const fileTree: ScanResult['fileTree'] = [];
  let concatenated = '';

  const normalizedMap = new Map<string, { path: string; content: string; size: number }>();

  for (const f of files) {
    const cleanPath = f.path.replace(/^\/+/, '');
    const isHidden = isPathHidden(cleanPath);
    if (isHidden) {
      hiddenCount++;
    }
    totalSizeBytes += f.size;
    concatenated += cleanPath + f.size;

    const fileType = getFileType(cleanPath);
    fileTree.push({
      path: cleanPath,
      size: f.size,
      isHidden,
      type: fileType,
    });

    normalizedMap.set(cleanPath.toLowerCase(), { ...f, path: cleanPath });
  }

  // If a built dist/index.html or build/index.html exists AND root index.html points to /src/main.tsx, prefer dist/build
  const rootHtml = normalizedMap.get('index.html');
  const distHtml = normalizedMap.get('dist/index.html');
  const buildHtml = normalizedMap.get('build/index.html');
  const isRootRawViteSource =
    rootHtml &&
    (/src=["'][^"']*\/src\/main\.(tsx|ts|jsx)["']/i.test(rootHtml.content) ||
      /src=["']src\/main\.(tsx|ts|jsx)["']/i.test(rootHtml.content));

  if (isRootRawViteSource && (distHtml || buildHtml)) {
    entryPointFound = (distHtml || buildHtml)!.path;
    warnings.push(
      `Vite প্রজেক্টের বিল্ড আউটপুট '${entryPointFound}' সনাক্ত হয়েছে এবং প্রাইমারি এন্ট্রি পেজ হিসেবে সেট করা হয়েছে।`
    );
  }

  const runtimeInfo = detectProjectRuntime(files);

  const entryPriority = [
    'index.html',
    'index.htm',
    'index.php',
    'dist/index.html',
    'build/index.html',
    'public/index.html',
    'public/index.php',
    'templates/index.html',
    'views/index.html',
    'static/index.html',
    'frontend/index.html',
    'web/index.html',
    'docs/index.html',
    'home.html',
    'main.html',
  ];

  if (!entryPointFound) {
    for (const candidate of entryPriority) {
      const hit = normalizedMap.get(candidate);
      if (hit) {
        entryPointFound = hit.path;
        break;
      }
    }
  }

  if (!entryPointFound) {
    for (const [, val] of normalizedMap) {
      const low = val.path.toLowerCase();
      if (low.endsWith('/index.html') || low.endsWith('/index.htm') || low.endsWith('/index.php')) {
        entryPointFound = val.path;
        break;
      }
    }
  }

  if (files.length === 0) {
    errors.push('ফোল্ডারে কোনো ফাইল পাওয়া যায়নি (No files found in selected directory).');
  } else if (!entryPointFound) {
    const anyHtmlOrPhp = Array.from(normalizedMap.values()).find(f => {
      const low = f.path.toLowerCase();
      return low.endsWith('.html') || low.endsWith('.htm') || low.endsWith('.php');
    });
    if (anyHtmlOrPhp) {
      warnings.push(
        `কোনো সরাসরি 'index.html' বা 'index.php' পাওয়া যায়নি। ডিফল্টভাবে '${anyHtmlOrPhp.path}' কে হোম পেজ হিসেবে ব্যবহার করা হবে।`
      );
      entryPointFound = anyHtmlOrPhp.path;
    } else if (runtimeInfo.backendEntry) {
      entryPointFound = runtimeInfo.backendEntry;
      warnings.push(
        `ব্যাকএন্ড সার্ভার ফাইল '${runtimeInfo.backendEntry}' (${runtimeInfo.runtime.toUpperCase()}) শনাক্ত হয়েছে এবং সরাসরি রানটাইম হিসেবে সেট করা হয়েছে।`
      );
    } else {
      errors.push(
        "কোনো রান-যোগ্য এন্ট্রি পেজ পাওয়া যায়নি! ওয়েবসাইট চালানোর জন্য ফোল্ডারে অন্তত একটি 'index.html', 'index.php', 'app.py', অথবা 'server.js' থাকতে হবে।"
      );
    }
  }

  if (runtimeInfo.backendEntry && runtimeInfo.runtime !== 'static') {
    warnings.push(
      `লাইভ ব্যাকএন্ড রানটাইম শনাক্ত: ${runtimeInfo.runtime.toUpperCase()} (${runtimeInfo.backendEntry})`
    );
  }

  if (hiddenCount > 0) {
    warnings.push(
      `${hiddenCount}টি হিডেন ও কনফিগারেশন ফাইল সনাক্ত করা হয়েছে (যেমন .env, .htaccess)। এগুলো সফলভাবে ওয়েব সার্ভার ডিরেক্টরিতে সুরক্ষিত রাখা হবে।`
    );
  }

  return {
    fileCount: files.length,
    hiddenCount,
    totalSizeBytes,
    entryPointFound,
    detectedRuntime: runtimeInfo.runtime,
    warnings,
    errors,
    fileTree,
    checksum: generateChecksum(concatenated),
  };
}

/**
 * Quote- and comment-aware PHP block scanner.
 * Ensures `?>` inside PHP string literals ('...' / "...") or comments NEVER terminates a PHP block early.
 */
interface PhpTokenSegment {
  kind: 'html' | 'php' | 'short-echo';
  content: string;
}

function tokenizePhpDocument(source: string): PhpTokenSegment[] {
  const segments: PhpTokenSegment[] = [];
  let idx = 0;
  const len = source.length;

  while (idx < len) {
    const openIdx = source.indexOf('<?', idx);
    if (openIdx === -1) {
      if (idx < len) {
        segments.push({ kind: 'html', content: source.slice(idx) });
      }
      break;
    }

    if (openIdx > idx) {
      segments.push({ kind: 'html', content: source.slice(idx, openIdx) });
    }

    const afterOpen = source.slice(openIdx, openIdx + 5).toLowerCase();
    let kind: 'php' | 'short-echo' = 'php';
    let codeStart = openIdx + 2;

    if (source[openIdx + 2] === '=') {
      kind = 'short-echo';
      codeStart = openIdx + 3;
    } else if (afterOpen === '<?php') {
      kind = 'php';
      codeStart = openIdx + 5;
    }

    // Scan forward respecting quotes, escapes, and comments until matching `?>`
    let p = codeStart;
    let inSingle = false;
    let inDouble = false;
    let inLineComment = false;
    let inBlockComment = false;
    let escaped = false;
    let closeIdx = -1;

    while (p < len) {
      const ch = source[p];
      const next = source[p + 1] || '';

      if (inLineComment) {
        if (ch === '\n') {
          inLineComment = false;
        } else if (ch === '?' && next === '>') {
          closeIdx = p;
          break;
        }
        p++;
        continue;
      }

      if (inBlockComment) {
        if (ch === '*' && next === '/') {
          inBlockComment = false;
          p += 2;
          continue;
        }
        p++;
        continue;
      }

      if (escaped) {
        escaped = false;
        p++;
        continue;
      }

      if ((inSingle || inDouble) && ch === '\\') {
        escaped = true;
        p++;
        continue;
      }

      if (!inDouble && ch === "'") {
        inSingle = !inSingle;
        p++;
        continue;
      }

      if (!inSingle && ch === '"') {
        inDouble = !inDouble;
        p++;
        continue;
      }

      if (!inSingle && !inDouble) {
        if (ch === '/' && next === '/') {
          inLineComment = true;
          p += 2;
          continue;
        }
        if (ch === '#') {
          inLineComment = true;
          p++;
          continue;
        }
        if (ch === '/' && next === '*') {
          inBlockComment = true;
          p += 2;
          continue;
        }
        if (ch === '?' && next === '>') {
          closeIdx = p;
          break;
        }
      }

      p++;
    }

    if (closeIdx === -1) {
      segments.push({ kind, content: source.slice(codeStart) });
      idx = len;
    } else {
      segments.push({ kind, content: source.slice(codeStart, closeIdx) });
      idx = closeIdx + 2;
    }
  }

  return segments;
}

/**
 * Sandboxed PHP execution for web apps without native php-cgi.
 * Never leaks raw PHP code (`$pdo->prepare`, `foreach`, `e(S(...))`) into the DOM.
 */
export function emulatePhpExecution(
  phpCode: string,
  siteName: string,
  siteFiles?: Record<string, SiteFile>
): string {
  if (!phpCode.includes('<?')) {
    return phpCode;
  }

  try {
    const vars: Record<string, string> = {};
    const now = new Date();
    const hasDatabaseLogic = /\$pdo\b|new\s+PDO\b|mysqli_|sqlite3|->prepare\s*\(/i.test(phpCode);

    const evaluateSegments = (code: string, depth = 0): string => {
      if (depth > 4) return '';
      const segments = tokenizePhpDocument(code);
      const htmlOut: string[] = [];

      for (const seg of segments) {
        if (seg.kind === 'html') {
          htmlOut.push(seg.content);
          continue;
        }

        if (seg.kind === 'short-echo') {
          const expr = seg.content.trim().replace(/;\s*$/, '');
          const evaluated = evaluatePhpExpression(expr, vars, now, true);
          htmlOut.push(evaluated);
          continue;
        }

        const cleanedBody = stripPhpComments(seg.content);
        const statements = splitPhpStatements(cleanedBody);
        for (const stmt of statements) {
          const trimmed = stmt.trim();
          if (!trimmed) continue;

          // Skip control structures cleanly without leaking raw PHP code
          if (/^(if|elseif|else|foreach|for|while|switch|function|class|try|catch|use|namespace)\b/i.test(trimmed)) {
            continue;
          }

          if (/^phpinfo\s*\(\s*\)$/i.test(trimmed)) {
            htmlOut.push(`
              <div style="font-family:system-ui,sans-serif; background:#0b0f19; color:#94a3b8; padding:20px; border-radius:10px; border:1px solid #1e293b; margin:12px 0;">
                <h2 style="color:#38bdf8; margin-top:0;">PHP 8.3 NIGHTHOST Runtime</h2>
                <p><strong>Server:</strong> NIGHTHOST Cloud Engine</p>
                <p><strong>Project:</strong> ${escapeHtml(siteName)}</p>
                <p><strong>Timestamp:</strong> ${now.toISOString()}</p>
              </div>
            `);
            continue;
          }

          // Local include / require resolution if siteFiles provided
          const incMatch = trimmed.match(/^(?:include|include_once|require|require_once)\s*\(?\s*['"]([^'"]+)['"]\s*\)?$/i);
          if (incMatch && siteFiles) {
            const incPath = incMatch[1].replace(/^\.\//, '');
            const target =
              siteFiles[incPath] ||
              Object.values(siteFiles).find(f => f.path.toLowerCase().endsWith('/' + incPath.toLowerCase()));
            if (target && !target.isBinary) {
              htmlOut.push(evaluateSegments(target.content, depth + 1));
            }
            continue;
          }

          // Variable assignment: $var = expr
          const assignMatch = trimmed.match(/^\$([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*([\s\S]+)$/);
          if (assignMatch) {
            const val = evaluatePhpExpression(assignMatch[2], vars, now, false);
            vars[assignMatch[1]] = val;
            continue;
          }

          // echo or print
          const echoMatch = trimmed.match(/^(?:echo|print)\s+([\s\S]+)$/i);
          if (echoMatch) {
            htmlOut.push(evaluatePhpExpression(echoMatch[1], vars, now, true));
            continue;
          }
        }
      }

      return htmlOut.join('');
    };

    let result = evaluateSegments(phpCode);

    // If it's a pure server-side database PHP app whose HTML output is minimal or empty,
    // render a clean informative preview instead of broken fragments.
    const textOnly = result.replace(/<[^>]+>/g, '').trim();
    if (hasDatabaseLogic && textOnly.length < 20) {
      result = `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${escapeHtml(siteName)}</title>
  <style>
    body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:system-ui,-apple-system,sans-serif;background:#0b0f19;color:#e2e8f0;padding:24px;}
    .card{max-width:520px;width:100%;background:#111827;border:1px solid #1e293b;border-radius:16px;padding:28px;box-shadow:0 20px 45px rgba(0,0,0,0.45);}
    .badge{display:inline-block;padding:4px 10px;border-radius:999px;background:rgba(6,182,212,0.12);border:1px solid rgba(6,182,212,0.35);color:#22d3ee;font-size:11px;font-weight:700;margin-bottom:12px;}
    h1{margin:0 0 8px;font-size:20px;color:#fff;}
    p{margin:0;color:#94a3b8;font-size:13px;line-height:1.6;}
  </style>
</head>
<body>
  <div class="card">
    <div class="badge">PHP DATABASE PROJECT</div>
    <h1>${escapeHtml(siteName)}</h1>
    <p>এই প্রজেক্টটি সার্ভার-সাইড PDO/SQL ডেটাবেস নির্ভর PHP অ্যাপ্লিকেশন। স্ট্যাটিক/HTML/CSS/JS এবং স্ট্যান্ডার্ড PHP স্ক্রিপ্ট সরাসরি ব্রাউজার স্যান্ডবক্সে রান হয়।</p>
  </div>
</body>
</html>`;
    }

    return result;
  } catch {
    return `<!DOCTYPE html><html><body style="font-family:system-ui,sans-serif;padding:24px;background:#0b0f19;color:#f8fafc;"><h2>${escapeHtml(siteName)}</h2></body></html>`;
  }
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function stripPhpComments(code: string): string {
  let out = '';
  let inSingle = false;
  let inDouble = false;
  let escaped = false;
  for (let i = 0; i < code.length; i++) {
    const ch = code[i];
    const next = code[i + 1] || '';
    if (escaped) {
      out += ch;
      escaped = false;
      continue;
    }
    if ((inSingle || inDouble) && ch === '\\') {
      out += ch;
      escaped = true;
      continue;
    }
    if (!inDouble && ch === "'") {
      inSingle = !inSingle;
      out += ch;
      continue;
    }
    if (!inSingle && ch === '"') {
      inDouble = !inDouble;
      out += ch;
      continue;
    }
    if (!inSingle && !inDouble) {
      if (ch === '/' && next === '*') {
        const end = code.indexOf('*/', i + 2);
        i = end === -1 ? code.length : end + 1;
        continue;
      }
      if ((ch === '/' && next === '/') || ch === '#') {
        const end = code.indexOf('\n', i);
        if (end === -1) break;
        i = end - 1;
        continue;
      }
    }
    out += ch;
  }
  return out;
}

function splitPhpStatements(code: string): string[] {
  const statements: string[] = [];
  let current = '';
  let inSingle = false;
  let inDouble = false;
  let escaped = false;
  let braceDepth = 0;

  for (let i = 0; i < code.length; i++) {
    const ch = code[i];
    if (escaped) {
      current += ch;
      escaped = false;
      continue;
    }
    if ((inSingle || inDouble) && ch === '\\') {
      current += ch;
      escaped = true;
      continue;
    }
    if (ch === "'" && !inDouble) {
      inSingle = !inSingle;
      current += ch;
      continue;
    }
    if (ch === '"' && !inSingle) {
      inDouble = !inDouble;
      current += ch;
      continue;
    }
    if (!inSingle && !inDouble) {
      if (ch === '{') braceDepth++;
      else if (ch === '}' && braceDepth > 0) braceDepth--;
      if (ch === ';' && braceDepth === 0) {
        statements.push(current);
        current = '';
        continue;
      }
    }
    current += ch;
  }
  if (current.trim()) statements.push(current);
  return statements;
}

function evaluatePhpExpression(
  expr: string,
  vars: Record<string, string>,
  now: Date,
  safeEmptyOnUnknown = true
): string {
  const trimmedExpr = expr.trim();
  if (!trimmedExpr) return '';

  // Handle null coalescing `a ?? b` or elvis `a ?: b`
  const nullishSplit = trimmedExpr.split(/\s*\?\?\s*/);
  if (nullishSplit.length > 1) {
    for (const candidate of nullishSplit) {
      const val = evaluatePhpExpression(candidate, vars, now, true);
      if (val !== '') return val;
    }
    return '';
  }

  const parts: string[] = [];
  let current = '';
  let inSingle = false;
  let inDouble = false;
  let escaped = false;
  let parenDepth = 0;

  for (let i = 0; i < trimmedExpr.length; i++) {
    const ch = trimmedExpr[i];
    if (escaped) {
      current += ch;
      escaped = false;
      continue;
    }
    if ((inSingle || inDouble) && ch === '\\') {
      current += ch;
      escaped = true;
      continue;
    }
    if (ch === "'" && !inDouble) {
      inSingle = !inSingle;
      current += ch;
      continue;
    }
    if (ch === '"' && !inSingle) {
      inDouble = !inDouble;
      current += ch;
      continue;
    }
    if (!inSingle && !inDouble) {
      if (ch === '(') parenDepth++;
      else if (ch === ')' && parenDepth > 0) parenDepth--;
      if (ch === '.' && parenDepth === 0) {
        parts.push(current.trim());
        current = '';
        continue;
      }
    }
    current += ch;
  }
  if (current.trim()) parts.push(current.trim());

  return parts
    .map(part => {
      if ((part.startsWith('"') && part.endsWith('"')) || (part.startsWith("'") && part.endsWith("'"))) {
        const inner = part.slice(1, -1);
        if (part.startsWith('"')) {
          return inner
            .replace(/\\"/g, '"')
            .replace(/\\n/g, '\n')
            .replace(/\$([a-zA-Z_][a-zA-Z0-9_]*)/g, (_m, v) => vars[v] ?? '');
        }
        return inner.replace(/\\'/g, "'");
      }
      if (/^\$[a-zA-Z_][a-zA-Z0-9_]*$/.test(part)) {
        return vars[part.slice(1)] ?? '';
      }
      if (/^-?\d+(\.\d+)?$/.test(part)) {
        return part;
      }
      if (/^date\s*\(/i.test(part)) {
        return now.toLocaleString();
      }
      if (/^time\s*\(\s*\)$/i.test(part)) {
        return String(Math.floor(now.getTime() / 1000));
      }
      const escCall = part.match(/^(?:e|htmlspecialchars|htmlentities)\s*\(([\s\S]+)\)$/i);
      if (escCall) {
        return escapeHtml(evaluatePhpExpression(escCall[1], vars, now, true));
      }
      if (safeEmptyOnUnknown) {
        return '';
      }
      return '';
    })
    .join('');
}

export function buildSingleFileHtml(site: HostedSite): string {
  if (!site.singleFileConfig) {
    return `<!DOCTYPE html><html><body style="font-family:sans-serif;padding:30px;"><h1>${escapeHtml(site.name)}</h1></body></html>`;
  }
  const lang = site.singleFileConfig.language;
  const raw = site.singleFileConfig.rawContent;

  if (lang === 'html') {
    const processed = raw.includes('<?') ? emulatePhpExecution(raw, site.name, site.files) : raw;
    return /<html/i.test(processed)
      ? processed
      : `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(site.name)}</title></head><body>${processed}</body></html>`;
  }

  if (lang === 'php') {
    const rendered = emulatePhpExecution(raw, site.name, site.files);
    return /<html/i.test(rendered)
      ? rendered
      : `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(site.name)}</title><style>body{font-family:system-ui,-apple-system,sans-serif;margin:0;padding:24px;background:#0d1117;color:#f0f6fc;}</style></head><body>${rendered}</body></html>`;
  }

  if (lang === 'css') {
    return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${escapeHtml(site.name)} - CSS</title>
  <style>${raw}</style>
</head>
<body>
  <div style="max-width:640px; margin:40px auto; padding:28px; border-radius:14px;">
    <h1>${escapeHtml(site.name)}</h1>
    <p>Stylesheet active and rendered.</p>
    <button type="button">Interactive Element</button>
  </div>
</body>
</html>`;
  }

  if (lang === 'javascript') {
    return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${escapeHtml(site.name)} - JS Runner</title>
  <style>
    body { font-family: ui-monospace, monospace; margin: 0; padding: 24px; background: #0b0f19; color: #38bdf8; }
    #console { background: #030712; padding: 16px; border-radius: 8px; border: 1px solid #1e293b; min-height: 180px; white-space: pre-wrap; color: #a5f3fc; }
  </style>
</head>
<body>
  <h2>${escapeHtml(site.name)} — Console Output</h2>
  <div id="console"></div>
  <script>
    const logEl = document.getElementById('console');
    const origLog = console.log;
    console.log = function(...args) {
      origLog.apply(console, args);
      logEl.textContent += args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' ') + '\\n';
    };
    try {
      ${raw}
    } catch(err) {
      logEl.innerHTML += '<span style="color:#ef4444;">Error: ' + err.message + '</span>\\n';
    }
  </script>
</body>
</html>`;
  }

  if (lang === 'java') {
    return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${escapeHtml(site.name)} - Java Service</title>
  <style>body{font-family:system-ui,-apple-system,sans-serif;margin:0;padding:24px;background:#0d1117;color:#f0f6fc;}</style>
</head>
<body>
  <div style="max-width:720px; margin:20px auto; padding:24px; border-radius:12px; background:#161b22; border:1px solid #30363d;">
    <h2 style="color:#f59e0b; margin-top:0;">☕ ${escapeHtml(site.name)} (Java Source)</h2>
    <pre style="background:#0d1117; padding:16px; border-radius:8px; overflow-x:auto; color:#7ee787;">${escapeHtml(raw)}</pre>
  </div>
</body>
</html>`;
  }

  return raw;
}

function escapeRegExp(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Self-contained HTML bundle for offline/unsaved srcDoc preview (e.g. SingleFileDeployer live preview)
 */
export function bundleSiteForExecution(site: HostedSite): string {
  if (site.type === 'single-file' && site.singleFileConfig) {
    return buildSingleFileHtml(site);
  }

  const rootKey = site.rootFile || 'index.html';
  const entryFile =
    site.files[rootKey] ||
    Object.values(site.files).find(f => f.path.endsWith('.html') || f.path.endsWith('.htm') || f.path.endsWith('.php'));

  if (!entryFile) {
    return `<!DOCTYPE html><html><body style="font-family:sans-serif;padding:30px;background:#090d16;color:#f87171;">
      <h2>কোনো এন্ট্রি পয়েন্ট পাওয়া যায়নি (No Entry Point Found)</h2>
      <p>এই প্রজেক্টে 'index.html' বা 'index.php' পাওয়া যায়নি।</p>
    </body></html>`;
  }

  let htmlContent = entryFile.content;
  if (entryFile.path.toLowerCase().endsWith('.php') || htmlContent.includes('<?')) {
    htmlContent = emulatePhpExecution(htmlContent, site.name, site.files);
  }

  const baseDir = rootKey.includes('/') ? rootKey.substring(0, rootKey.lastIndexOf('/') + 1) : '';

  try {
    for (const [filePath, fileObj] of Object.entries(site.files)) {
      const relPath = baseDir && filePath.startsWith(baseDir) ? filePath.slice(baseDir.length) : filePath;

      if (fileObj.type === 'css' && !fileObj.isBinary) {
        const pattern = new RegExp(`<link[^>]+href=["'](?:\\.?/)?${escapeRegExp(relPath)}["'][^>]*>`, 'gi');
        if (pattern.test(htmlContent)) {
          htmlContent = htmlContent.replace(pattern, `<style>\n${fileObj.content}\n</style>`);
        }
      } else if (fileObj.type === 'js' && !fileObj.isBinary) {
        const pattern = new RegExp(`<script[^>]+src=["'](?:\\.?/)?${escapeRegExp(relPath)}["'][^>]*>\\s*</script>`, 'gi');
        if (pattern.test(htmlContent)) {
          htmlContent = htmlContent.replace(pattern, `<script>\n${fileObj.content}\n</script>`);
        }
      } else if (fileObj.type === 'image') {
        const mime = fileObj.mimeType || getMimeType(filePath);
        const dataUri = fileObj.isBinary
          ? `data:${mime};base64,${fileObj.content}`
          : `data:image/svg+xml;utf8,${encodeURIComponent(fileObj.content)}`;
        const imgPattern = new RegExp(`(["'])(?:\\.?/)?${escapeRegExp(relPath)}\\1`, 'gi');
        htmlContent = htmlContent.replace(imgPattern, `$1${dataUri}$1`);
      }
    }
  } catch {
    // ignore regex errors
  }

  if (!htmlContent.includes('<base') && htmlContent.includes('<head>')) {
    htmlContent = htmlContent.replace('<head>', '<head><base target="_self">');
  }

  return htmlContent;
}

function normalizePosixPath(p: string): string {
  const parts: string[] = [];
  for (const seg of p.replace(/\\/g, '/').split('/')) {
    if (!seg || seg === '.') continue;
    if (seg === '..') {
      parts.pop();
    } else {
      parts.push(seg);
    }
  }
  return parts.join('/');
}

/**
 * Resolves static assets & sub-pages smartly across nested directories
 * (handles rootDir base prefix collisions, static/, public/, assets/, dist/, build/).
 */
export function resolveHostedFile(site: HostedSite, rawSubPath: string): SiteFile | undefined {
  if (rawSubPath.replace(/\\/g, '/').split('/').includes('..')) {
    return undefined;
  }
  const cleanSub = normalizePosixPath(rawSubPath.replace(/^\/+/, ''));
  if (!cleanSub) return undefined;

  const rootDir =
    site.rootFile && site.rootFile.includes('/')
      ? site.rootFile.substring(0, site.rootFile.lastIndexOf('/') + 1)
      : '';

  const candidates: string[] = [cleanSub];

  if (rootDir) {
    candidates.push(normalizePosixPath(`${rootDir}${cleanSub}`));
    if (cleanSub.toLowerCase().startsWith(rootDir.toLowerCase())) {
      candidates.push(cleanSub.slice(rootDir.length));
    }
  }

  for (const prefix of ['static/', 'public/', 'assets/', 'dist/', 'build/', 'src/', 'templates/', 'views/', 'img/', 'images/', 'media/', 'uploads/']) {
    candidates.push(`${prefix}${cleanSub}`);
    if (cleanSub.toLowerCase().startsWith(prefix)) {
      candidates.push(cleanSub.slice(prefix.length));
    }
  }

  const allFiles = Object.values(site.files);

  for (const cand of candidates) {
    if (site.files[cand]) return site.files[cand];
    const ci = allFiles.find(f => f.path.toLowerCase() === cand.toLowerCase());
    if (ci) return ci;
  }

  // Safe filename fallback for static assets (CSS, JS, images, fonts)
  const hasExt = /\.[a-z0-9]{1,8}$/i.test(cleanSub);
  if (hasExt) {
    const baseName = cleanSub.split('/').pop()!.toLowerCase();
    const suffixMatches = allFiles.filter(f => f.path.toLowerCase().endsWith('/' + baseName) || f.path.toLowerCase() === baseName);
    if (suffixMatches.length === 1) {
      return suffixMatches[0];
    }
    const preferred = suffixMatches.find(f =>
      /^(static|public|assets|images|img|css|js|dist|build)\//i.test(f.path)
    );
    if (preferred) return preferred;
  } else {
    // Extensionless ESM/TS/React module resolution (e.g., import App from './App')
    const codeExts = ['.tsx', '.ts', '.jsx', '.js', '.mjs', '.cjs'];
    for (const cand of candidates) {
      for (const ext of codeExts) {
        const directMatch = allFiles.find(f => f.path.toLowerCase() === `${cand}${ext}`.toLowerCase());
        if (directMatch) return directMatch;
        const indexMatch = allFiles.find(f => f.path.toLowerCase() === `${cand}/index${ext}`.toLowerCase());
        if (indexMatch) return indexMatch;
      }
    }
  }

  return undefined;
}

function normalizeMountPrefix(slug: string, mountPrefix?: string): string {
  if (typeof mountPrefix === 'string') {
    if (mountPrefix === '') return '';
    return '/' + mountPrefix.replace(/^\/+|\/+$/g, '');
  }
  return `/site/${slug}`;
}

export function rewriteCssUrls(cssContent: string, slug: string, mountPrefix?: string): string {
  const prefix = normalizeMountPrefix(slug, mountPrefix);
  if (!prefix) return cssContent;
  return cssContent
    .replace(/url\(\s*(['"]?)\/(?!site\/|d\/|u\/|\/)([^)'"]+)\1\s*\)/gi, `url($1${prefix}/$2$1)`)
    .replace(/@import\s+(['"])\/(?!site\/|d\/|u\/|\/)([^'"]+)\1/gi, `@import $1${prefix}/$2$1`);
}

function buildClientApiBridgeScript(slug: string, mountPrefix?: string): string {
  const prefix = normalizeMountPrefix(slug, mountPrefix);
  const safePrefix = JSON.stringify(prefix);
  return `<script data-nighthost-bridge="1">(function(){try{var B=${safePrefix};function rw(u){if(!B)return u;if(typeof u==="string"&&u.charAt(0)==="/"&&u.indexOf("/site/")!==0&&u.indexOf("/d/")!==0&&u.indexOf("/u/")!==0&&u.indexOf("/__nh_img_proxy")!==0&&u.indexOf("//")!==0){return B+u;}return u;}function isExt(u){try{var p=new URL(u,location.href);return(p.protocol==="http:"||p.protocol==="https:")&&p.origin!==location.origin;}catch(e){return false;}}function relayUrl(u){return (B||"")+"/__nh_relay?url="+encodeURIComponent(u);}function imgProxyUrl(u){return (B||"")+"/__nh_img_proxy?url="+encodeURIComponent(u);}function makeFallbackSvg(label){var txt=String(label||"NH").replace(/[^A-Za-z0-9\\u0980-\\u09FF ]/g," ").trim();var words=txt?txt.split(/\\s+/):["NH"];var mono=(words.length>=2?(words[0].charAt(0)+words[1].charAt(0)):(words[0].slice(0,2)||"NH")).toUpperCase();var svg='<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#0ea5e9"/><stop offset="100%" stop-color="#4f46e5"/></linearGradient></defs><rect width="128" height="128" rx="28" fill="#0f172a"/><rect x="4" y="4" width="120" height="120" rx="24" fill="url(#g)" fill-opacity="0.18" stroke="#38bdf8" stroke-opacity="0.55" stroke-width="2"/><text x="64" y="74" text-anchor="middle" font-family="system-ui,-apple-system,sans-serif" font-weight="700" font-size="40" fill="#e0f2fe">'+mono.replace(/[<>&"']/g,"")+'</text></svg>';return "data:image/svg+xml;charset=utf-8,"+encodeURIComponent(svg);}function recoverImg(el){if(!el||el.tagName!=="IMG")return;if(el.dataset&&el.dataset.nhFallback==="1")return;var raw=el.getAttribute("src")||el.src||"";if(el.dataset&&el.dataset.nhProxied!=="1"&&raw&&raw.indexOf("data:")!==0&&raw.indexOf("/__nh_img_proxy")===-1&&isExt(raw)){try{var abs=new URL(raw,location.href).href;el.dataset.nhProxied="1";el.removeAttribute("crossorigin");el.referrerPolicy="no-referrer";el.src=imgProxyUrl(abs);return;}catch(e){}}if(el.dataset)el.dataset.nhFallback="1";el.src=makeFallbackSvg(el.alt||document.title||"NH");if(!el.style.objectFit)el.style.objectFit="contain";}document.addEventListener("error",function(ev){var t=ev&&ev.target;if(t&&t.tagName==="IMG"){recoverImg(t);}},true);function scanImgs(){var imgs=document.querySelectorAll?document.querySelectorAll("img"):[];for(var idx=0;idx<imgs.length;idx++){var im=imgs[idx];if(im.complete&&im.naturalWidth===0&&(im.getAttribute("src")||"")!==""){recoverImg(im);}}}if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",function(){scanImgs();setTimeout(scanImgs,600);});}else{scanImgs();setTimeout(scanImgs,600);}window.addEventListener("load",scanImgs);var f=window.fetch;if(f){window.fetch=function(i,n){var rawUrl=typeof i==="string"?i:(i&&typeof Request!=="undefined"&&i instanceof Request?i.url:"");if(typeof i==="string"){i=rw(i);}else if(B&&i&&typeof Request!=="undefined"&&i instanceof Request){try{var p=new URL(i.url);if(p.origin===location.origin&&p.pathname.charAt(0)==="/"&&p.pathname.indexOf("/site/")!==0&&p.pathname.indexOf("/d/")!==0&&p.pathname.indexOf("/u/")!==0){i=new Request(B+p.pathname+p.search,i);}}catch(e){}}var targetUrl=typeof i==="string"?i:(i&&i.url)||rawUrl;if(!isExt(targetUrl)){return f.call(this,i,n);}return f.call(this,i,n).catch(function(err){if(err&&err.name==="AbortError")throw err;var opts=n?Object.assign({},n):{};return f.call(window,relayUrl(targetUrl),opts);});};}if(window.XMLHttpRequest){var xo=XMLHttpRequest.prototype.open;var xs=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this.__nhMethod=m;if(typeof u==="string"){u=rw(u);arguments[1]=u;}this.__nhUrl=u;this.__nhAsync=arguments.length>2?arguments[2]:true;return xo.apply(this,arguments);};XMLHttpRequest.prototype.send=function(body){var self=this;if(this.__nhAsync!==false&&this.__nhUrl&&isExt(this.__nhUrl)&&!this.__nhRelayed){var origErr=this.onerror;this.onerror=function(ev){if(!self.__nhRelayed&&self.status===0){self.__nhRelayed=true;try{xo.call(self,self.__nhMethod||"GET",relayUrl(self.__nhUrl),true);xs.call(self,body);return;}catch(e){}}if(typeof origErr==="function")return origErr.call(this,ev);};}return xs.apply(this,arguments);};}if(window.EventSource){var ES=window.EventSource;window.EventSource=function(u,c){return new ES(rw(u),c);};}}catch(e){}})();</script>`;
}

/**
 * Rewrites HTML (whether static or proxied from a live Python/Node backend) so
 * root-relative assets, inline styles, Jinja static helpers, and client fetch/XHR calls
 * work accurately under /site/:slug/, /u/:subdomain/:slug/, /d/:domain/, or root custom-host domains.
 */
export function rewriteHtmlForSiteProxy(
  htmlContent: string,
  slug: string,
  baseDir = '',
  mountPrefix?: string
): string {
  const prefix = normalizeMountPrefix(slug, mountPrefix);
  let out = htmlContent;

  // Resolve common Jinja2/Flask static url_for expressions if unrendered in static mode
  out = out.replace(
    /\{\{\s*url_for\(\s*['"]static['"]\s*,\s*filename\s*=\s*['"]([^'"]+)['"]\s*\)\s*\}\}/gi,
    (_m, file) => `${prefix}/static/${String(file).replace(/^\/+/, '')}`
  );

  if (prefix) {
    // Rewrite root-absolute HTML attributes (src, href, action, poster, data-src, data-href)
    out = out.replace(
      /(src|href|action|poster|data-src|data-href)=(["'])\/(?!site\/|d\/|u\/|\/)([^"']*)\2/gi,
      `$1=$2${prefix}/$3$2`
    );

    // Rewrite root-absolute CSS url('/...') inside inline <style> or style=""
    out = out.replace(/url\(\s*(['"]?)\/(?!site\/|d\/|u\/|\/)([^)'"]+)\1\s*\)/gi, `url($1${prefix}/$2$1)`);
  }

  const baseHref = `${prefix}/${baseDir}`.replace(/\/{2,}/g, '/');
  const bridgeScript = buildClientApiBridgeScript(slug, mountPrefix);
  const referrerMeta = /<meta[^>]+name=["']referrer["']/i.test(out) ? '' : '<meta name="referrer" content="no-referrer">';

  if (/<head[^>]*>/i.test(out)) {
    const baseTag = /<base\s/i.test(out) ? '' : `<base href="${baseHref}">`;
    const bridge = out.includes('data-nighthost-bridge') ? '' : bridgeScript;
    out = out.replace(/<head([^>]*)>/i, `<head$1>${referrerMeta}${baseTag}${bridge}`);
  } else {
    const baseTag = /<base\s/i.test(out) ? '' : `<base href="${baseHref}">`;
    const bridge = out.includes('data-nighthost-bridge') ? '' : bridgeScript;
    out = `${referrerMeta}${baseTag}${bridge}` + out;
  }

  return out;
}

/**
 * Rewrites HTML entry point so it runs cleanly standalone at /site/:slug/, /d/:domain/, or custom host on Express server
 */
export function prepareStandaloneHtmlForServer(
  site: HostedSite,
  targetFilePath?: string,
  mountPrefix?: string
): string {
  if (site.type === 'single-file' && site.singleFileConfig) {
    const html = buildSingleFileHtml(site);
    return rewriteHtmlForSiteProxy(html, site.slug, '', mountPrefix);
  }

  const rootKey = targetFilePath || site.rootFile || 'index.html';
  const entryFile =
    site.files[rootKey] ||
    Object.values(site.files).find(f => f.path.endsWith('.html') || f.path.endsWith('.htm') || f.path.endsWith('.php'));

  if (!entryFile) {
    return `<!DOCTYPE html><html><body style="font-family:sans-serif;padding:30px;background:#090d16;color:#f87171;">
      <h2>No Entry Point Found</h2>
      <p>No index.html or index.php was found in this project.</p>
    </body></html>`;
  }

  let htmlContent = entryFile.content;
  if (entryFile.path.toLowerCase().endsWith('.php') || htmlContent.includes('<?')) {
    htmlContent = emulatePhpExecution(htmlContent, site.name, site.files);
  }

  const baseDir = rootKey.includes('/') ? rootKey.substring(0, rootKey.lastIndexOf('/') + 1) : '';
  let outHtml = rewriteHtmlForSiteProxy(htmlContent, site.slug, baseDir, mountPrefix);

  // Auto-enable browser ESM importmap when serving unbuilt React/Vite/TSX/JSX source repos without dist/
  const usesUnbuiltTsxModule =
    /<script[^>]+type=["']module["'][^>]+src=["'][^"']*\.(tsx|jsx|ts)(\?[^"']*)?["']/i.test(outHtml) ||
    Object.keys(site.files || {}).some(k => /^src\/(main|index|App)\.(tsx|jsx)$/i.test(k));
  if (usesUnbuiltTsxModule && !/<script[^>]+type=["']importmap["']/i.test(outHtml)) {
    const importMapTag = `<script type="importmap">{"imports":{"react":"https://esm.sh/react@19?dev","react-dom":"https://esm.sh/react-dom@19?dev","react-dom/client":"https://esm.sh/react-dom@19/client?dev","react/jsx-runtime":"https://esm.sh/react@19/jsx-runtime?dev","lucide-react":"https://esm.sh/lucide-react@0.475.0?deps=react@19","axios":"https://esm.sh/axios@1.7.9","clsx":"https://esm.sh/clsx@2.1.1"}}</script>`;
    const needsTailwindCdn = Object.values(site.files || {}).some(
      f =>
        !f.isBinary &&
        ((f.path.toLowerCase().endsWith('.css') && /(@import\s+["']tailwindcss["']|@tailwind\s+)/i.test(f.content || '')) ||
          (/\.(tsx|jsx)$/i.test(f.path) && /className=["'][^"']*\b(flex|grid|p-\d|px-\d|py-\d|bg-|text-|rounded-)/i.test(f.content || '')))
    );
    const tailwindTag = needsTailwindCdn && !outHtml.includes('cdn.tailwindcss.com')
      ? '<script src="https://cdn.tailwindcss.com"></script>'
      : '';
    if (/<head[^>]*>/i.test(outHtml)) {
      outHtml = outHtml.replace(/<head([^>]*)>/i, `<head$1>${importMapTag}${tailwindTag}`);
    } else {
      outHtml = `${importMapTag}${tailwindTag}${outHtml}`;
    }
  }

  return outHtml;
}

export interface AutoRepairReport {
  files: Record<string, SiteFile>;
  repairedPaths: string[];
  repairLogs: string[];
  addedVercelBridge: boolean;
}

function buildMissingStubContent(filePath: string, referencedBy: string, symbolHint?: string, preferEsm = false): string {
  const low = filePath.toLowerCase();
  if (low.endsWith('.json')) {
    if (low.endsWith('package.json')) {
      return JSON.stringify({ name: 'nighthost-repaired-app', private: true }, null, 2);
    }
    return '{}\n';
  }
  if (low.endsWith('.css')) {
    return `/* NIGHTHOST Auto-Repair stub for missing stylesheet referenced by ${referencedBy} */\n`;
  }
  if (low.endsWith('.py')) {
    return `# NIGHTHOST Auto-Repair stub for missing local module (${filePath})\n# Referenced by: ${referencedBy}\n\ndef __getattr__(name):\n    def _stub(*args, **kwargs):\n        return {}\n    return _stub\n`;
  }
  if (preferEsm || low.endsWith('.mjs') || low.endsWith('.ts') || low.endsWith('.tsx') || low.endsWith('.jsx')) {
    const namedExport = symbolHint && /^[A-Za-z_$][A-Za-z0-9_$]*$/.test(symbolHint) && symbolHint !== 'default'
      ? `\nexport const ${symbolHint} = (..._args) => ({ ok: true, stub: true });`
      : '';
    return `// NIGHTHOST Auto-Repair stub for missing module (${filePath}) referenced by ${referencedBy}\nconst _defaultStub = (..._args) => ({ ok: true, stub: true });\nexport default _defaultStub;${namedExport}\nexport const router = (_req, _res, next) => (typeof next === 'function' ? next() : undefined);\n`;
  }
  // Default JS / CJS
  const namedProp = symbolHint && /^[A-Za-z_$][A-Za-z0-9_$]*$/.test(symbolHint)
    ? `fn.${symbolHint} = (..._args) => ({ ok: true, stub: true });\n`
    : '';
  return `// NIGHTHOST Auto-Repair stub for missing module (${filePath}) referenced by ${referencedBy}\nconst fn = function(..._args) { return { ok: true, stub: true }; };\nfn.default = fn;\n${namedProp}module.exports = fn;\n`;
}

function buildVercelServerlessBridgeSource(): string {
  return `// __NIGHTHOST_SERVERLESS_BRIDGE__
// Auto-generated adapter allowing Vercel / Netlify / static-serverless projects to run natively on NIGHTHOST & Render.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const ROOT = process.cwd();
const PORT = Number(process.env.PORT || 3000);
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

function loadVercelConfig() {
  try {
    const p = path.join(ROOT, 'vercel.json');
    if (fs.existsSync(p)) return JSON.parse(fs.readFileSync(p, 'utf-8'));
  } catch {}
  return {};
}

function findStaticBase() {
  for (const dir of ['dist', 'build', 'public', 'out', '.']) {
    const full = path.join(ROOT, dir, 'index.html');
    if (fs.existsSync(full)) return path.join(ROOT, dir);
  }
  return ROOT;
}

function collectApiRoutes() {
  const routes = [];
  const scan = (baseDir, urlPrefix) => {
    if (!fs.existsSync(baseDir)) return;
    for (const ent of fs.readdirSync(baseDir, { withFileTypes: true })) {
      const full = path.join(baseDir, ent.name);
      if (ent.isDirectory()) {
        scan(full, urlPrefix + '/' + ent.name);
      } else if (/\\.(js|mjs|cjs)$/i.test(ent.name)) {
        const stem = ent.name.replace(/\\.(js|mjs|cjs)$/i, '');
        const routePath = stem === 'index' ? urlPrefix : urlPrefix + '/' + stem;
        routes.push({ routePath: routePath.toLowerCase(), file: full });
      }
    }
  };
  scan(path.join(ROOT, 'api'), '/api');
  scan(path.join(ROOT, 'netlify', 'functions'), '/.netlify/functions');
  return routes;
}

const STATIC_ROOT = findStaticBase();
const API_ROUTES = collectApiRoutes();
const VERCEL_CFG = loadVercelConfig();

function readReqBody(req) {
  return new Promise((resolve) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', () => resolve(Buffer.alloc(0)));
  });
}

function decorateRes(rawRes) {
  rawRes.status = (code) => { rawRes.statusCode = code; return rawRes; };
  rawRes.json = (obj) => {
    if (!rawRes.headersSent) rawRes.setHeader('Content-Type', 'application/json; charset=utf-8');
    rawRes.end(JSON.stringify(obj));
    return rawRes;
  };
  rawRes.send = (val) => {
    if (typeof val === 'object' && !Buffer.isBuffer(val)) return rawRes.json(val);
    rawRes.end(val == null ? '' : val);
    return rawRes;
  };
  rawRes.redirect = (codeOrUrl, maybeUrl) => {
    const code = typeof codeOrUrl === 'number' ? codeOrUrl : 302;
    const loc = typeof codeOrUrl === 'string' ? codeOrUrl : maybeUrl;
    rawRes.statusCode = code;
    rawRes.setHeader('Location', loc || '/');
    rawRes.end();
    return rawRes;
  };
  return rawRes;
}

async function invokeHandler(file, req, res) {
  let mod;
  try {
    mod = await import(pathToFileURL(file).href);
  } catch {
    mod = require(file);
  }
  const methodFn = mod && (mod[req.method] || (mod.default && mod.default[req.method]));
  const fn = typeof mod?.default === 'function' ? mod.default : typeof mod === 'function' ? mod : typeof mod?.handler === 'function' ? mod.handler : typeof methodFn === 'function' ? methodFn : null;
  if (!fn) {
    res.status(501).json({ error: 'Serverless function did not export a valid handler' });
    return;
  }
  if (typeof methodFn === 'function' && fn === methodFn && fn.length <= 1) {
    const webReq = new Request('http://localhost' + req.url, { method: req.method, headers: req.headers, body: ['GET','HEAD'].includes(req.method) ? undefined : req.rawBody });
    const webRes = await fn(webReq);
    res.statusCode = webRes.status || 200;
    webRes.headers.forEach((v, k) => res.setHeader(k, v));
    res.end(Buffer.from(await webRes.arrayBuffer()));
    return;
  }
  await fn(req, res);
}

http.createServer(async (req, rawRes) => {
  const res = decorateRes(rawRes);
  const parsed = new URL(req.url || '/', 'http://127.0.0.1');
  const pathname = parsed.pathname;
  req.query = Object.fromEntries(parsed.searchParams.entries());
  const rawBody = ['GET', 'HEAD'].includes(req.method || 'GET') ? Buffer.alloc(0) : await readReqBody(req);
  req.rawBody = rawBody;
  if (rawBody.length > 0 && (req.headers['content-type'] || '').includes('application/json')) {
    try { req.body = JSON.parse(rawBody.toString('utf-8')); } catch { req.body = rawBody.toString('utf-8'); }
  } else {
    req.body = rawBody.toString('utf-8');
  }

  const matchedApi = API_ROUTES.find(r => r.routePath === pathname.toLowerCase());
  if (matchedApi) {
    try {
      await invokeHandler(matchedApi.file, req, res);
    } catch (err) {
      if (!res.headersSent) res.status(500).json({ error: err?.message || 'Function failed' });
    }
    return;
  }

  // Serve static files or SPA rewrite fallback
  const rel = pathname.replace(/^\\/+/, '') || 'index.html';
  let target = path.join(STATIC_ROOT, rel);
  if (!target.startsWith(STATIC_ROOT) || !fs.existsSync(target) || fs.statSync(target).isDirectory()) {
    const htmlAlt = target + '.html';
    if (VERCEL_CFG.cleanUrls !== false && fs.existsSync(htmlAlt)) {
      target = htmlAlt;
    } else {
      target = path.join(STATIC_ROOT, 'index.html');
    }
  }
  if (fs.existsSync(target) && fs.statSync(target).isFile()) {
    const ext = path.extname(target).toLowerCase();
    res.setHeader('Content-Type', MIME[ext] || 'application/octet-stream');
    fs.createReadStream(target).pipe(res);
    return;
  }
  res.status(404).json({ error: 'Not Found', path: pathname });
}).listen(PORT, '0.0.0.0');
`;
}

/**
 * Automatically repairs common missing project references/modules and bridges Vercel/Netlify
 * serverless apps so hosted folders and downloaded ZIP archives run cleanly without broken imports.
 */
export function autoRepairSiteFiles(rawFiles: Record<string, SiteFile>): AutoRepairReport {
  const files: Record<string, SiteFile> = { ...rawFiles };
  const repairedPaths: string[] = [];
  const repairLogs: string[] = [];
  let addedVercelBridge = false;

  const normalizeKey = (p: string) => normalizePosixPath(p.replace(/^\/+/, ''));
  const hasFileCI = (candidate: string): boolean => {
    const low = candidate.toLowerCase();
    return Object.keys(files).some(k => k.toLowerCase() === low);
  };

  const addRepairedFile = (targetPath: string, content: string, reason: string) => {
    const clean = normalizeKey(targetPath);
    if (!clean || clean.includes('..') || hasFileCI(clean)) return;
    const size = new TextEncoder().encode(content).byteLength;
    files[clean] = {
      path: clean,
      content,
      size,
      isHidden: isPathHidden(clean),
      isBinary: false,
      mimeType: getMimeType(clean),
      type: getFileType(clean),
    };
    repairedPaths.push(clean);
    repairLogs.push(reason);
  };

  const resolveLocalRef = (fromPath: string, relSpec: string): string => {
    const baseDir = fromPath.includes('/') ? fromPath.slice(0, fromPath.lastIndexOf('/')) : '';
    const joined = baseDir ? `${baseDir}/${relSpec}` : relSpec;
    return normalizePosixPath(joined);
  };

  const jsCodeExts = ['.js', '.mjs', '.cjs', '.ts', '.tsx', '.jsx', '.json'];
  const doesJsTargetExist = (resolvedNoExt: string): boolean => {
    if (hasFileCI(resolvedNoExt)) return true;
    for (const ext of jsCodeExts) {
      if (hasFileCI(resolvedNoExt + ext)) return true;
      if (hasFileCI(resolvedNoExt + '/index' + ext)) return true;
    }
    return false;
  };

  // 1. Scan JS/TS/JSX/MJS/CJS files for missing relative local imports/requires
  const snapshotEntries = Object.values(files);
  for (const file of snapshotEntries) {
    if (file.isBinary) continue;
    const low = file.path.toLowerCase();
    const isJsLike = /\.(js|mjs|cjs|ts|tsx|jsx)$/i.test(low);
    const isHtmlLike = /\.(html|htm)$/i.test(low);
    const isPyLike = /\.py$/i.test(low);

    if (isJsLike && file.content) {
      const importRegex =
        /(?:import\s+(?:(?:\*\s+as\s+[A-Za-z0-9_$]+|\{([^}]+)\}|([A-Za-z0-9_$]+))\s+from\s+)?|require\s*\(\s*)(['"])(\.\.?\/[^'"\s)]+)\3/g;
      let m: RegExpExecArray | null;
      while ((m = importRegex.exec(file.content)) !== null) {
        const isEsmImport = m[0].trimStart().startsWith('import');
        const namedGroup = (m[1] || '').split(',')[0]?.trim().split(/\s+as\s+/)[0]?.trim();
        const spec = m[4];
        const resolved = resolveLocalRef(file.path, spec);
        if (!resolved || resolved.includes('..')) continue;
        if (!doesJsTargetExist(resolved)) {
          const targetPath = /\.[a-z0-9]+$/i.test(resolved)
            ? resolved
            : low.endsWith('.ts') || low.endsWith('.tsx')
            ? `${resolved}.ts`
            : `${resolved}.js`;
          addRepairedFile(
            targetPath,
            buildMissingStubContent(targetPath, file.path, namedGroup, isEsmImport),
            `Auto-created missing local module '${targetPath}' referenced by '${file.path}'.`
          );
        }
      }
    }

    if (isHtmlLike && file.content) {
      const assetRegex = /<(?:script[^>]+src|link[^>]+rel=["']stylesheet["'][^>]+href)=["'](\.?\/[^"'?#]+)["']/gi;
      let hm: RegExpExecArray | null;
      while ((hm = assetRegex.exec(file.content)) !== null) {
        const spec = hm[1].replace(/^\.\//, '');
        if (!spec || spec.startsWith('/site/') || spec.startsWith('/d/')) continue;
        const resolved = hm[1].startsWith('./') || !hm[1].startsWith('/')
          ? resolveLocalRef(file.path, spec)
          : spec.replace(/^\/+/, '');
        if (!resolved || resolved.includes('..') || hasFileCI(resolved)) continue;
        if (/\.(js|mjs|css|json)$/i.test(resolved)) {
          addRepairedFile(
            resolved,
            buildMissingStubContent(resolved, file.path),
            `Auto-created missing asset '${resolved}' linked inside '${file.path}'.`
          );
        }
      }
    }

    if (isPyLike && file.content) {
      const pyRelRegex = /^\s*from\s+\.([A-Za-z0-9_]+)\s+import\s+/gm;
      let pm: RegExpExecArray | null;
      while ((pm = pyRelRegex.exec(file.content)) !== null) {
        const modName = pm[1];
        const resolvedPy = resolveLocalRef(file.path, `${modName}.py`);
        if (resolvedPy && !hasFileCI(resolvedPy) && !hasFileCI(resolveLocalRef(file.path, `${modName}/__init__.py`))) {
          addRepairedFile(
            resolvedPy,
            buildMissingStubContent(resolvedPy, file.path),
            `Auto-created missing Python module '${resolvedPy}' imported by '${file.path}'.`
          );
        }
      }
    }
  }

  // 2. Vercel / Netlify Serverless Compatibility Bridge
  const keys = Object.keys(files);
  const hasNativeServer = keys.some(k => {
    const low = k.toLowerCase();
    return (
      low === 'server.js' ||
      low === 'server.mjs' ||
      low === 'server.ts' ||
      low === 'app.js' ||
      low === 'app.py' ||
      low === 'main.py' ||
      low === 'server.py'
    );
  });
  const hasVercelApiOrFunctions = keys.some(k =>
    /^(api|netlify\/functions)\/.+\.(js|mjs|cjs)$/i.test(k.toLowerCase())
  );

  if (!hasNativeServer && hasVercelApiOrFunctions && !hasFileCI('__nighthost_serverless_entry.mjs')) {
    addRepairedFile(
      '__nighthost_serverless_entry.mjs',
      buildVercelServerlessBridgeSource(),
      'Synthesized Vercel/Netlify serverless adapter (__nighthost_serverless_entry.mjs) so /api/* routes run natively.'
    );
    addedVercelBridge = true;
  }

  // 3. Ensure package.json exists with matching ESM/CJS type for Node backends
  const hasNodeBackend =
    hasVercelApiOrFunctions ||
    keys.some(k => /^(server|app|index)\.(js|mjs)$/i.test(k.toLowerCase()));
  if (hasNodeBackend && !hasFileCI('package.json')) {
    addRepairedFile(
      'package.json',
      JSON.stringify({ name: 'nighthost-project', version: '1.0.0', private: true, type: 'module' }, null, 2),
      'Auto-created package.json for Node runtime execution.'
    );
  }

  return {
    files,
    repairedPaths,
    repairLogs,
    addedVercelBridge,
  };
}

export function slugify(text: string): string {
  return (
    text
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/[\s_-]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'app-' + Math.floor(1000 + Math.random() * 9000)
  );
}

export interface RuntimeDiagnostic {
  titleBn: string;
  titleEn: string;
  causeBn: string;
  causeEn: string;
  stepsBn: string[];
  stepsEn: string[];
}

/**
 * Generates actionable, user-owned project repair guidance from runtime logs.
 * Focuses exclusively on edits the developer can make in their own project files.
 */
export function diagnoseRuntimeError(
  logs: string[],
  runtime: 'node' | 'python' | 'php' | 'static',
  backendEntry: string | null
): RuntimeDiagnostic {
  const joined = (logs || []).join('\n');
  const entry = backendEntry || (runtime === 'python' ? 'app.py' : 'server.js');

  // 0. Supabase / Environment variable configuration error
  if (/SUPABASE_URL|SUPABASE_SERVICE_ROLE_KEY|SUPABASE_ANON_KEY|supabaseUrl is required|supabaseKey is required/i.test(joined)) {
    return {
      titleBn: 'Supabase বা এনভায়রনমেন্ট ভেরিয়েবল (.env) সেট করা নেই',
      titleEn: 'Missing Supabase or .env configuration variables',
      causeBn: `'${entry}' প্রজেক্টে Supabase URL/Key প্রয়োজন, কিন্তু আপনার আপলোড করা ফোল্ডার বা রিপোতে .env ফাইলে মানগুলো দেওয়া নেই।`,
      causeEn: `'${entry}' requires Supabase credentials (SUPABASE_URL / SUPABASE_ANON_KEY / SUPABASE_SERVICE_ROLE_KEY) in a .env file.`,
      stepsBn: [
        'আপনার প্রজেক্ট রুটে .env ফাইল তৈরি করে SUPABASE_URL এবং SUPABASE_ANON_KEY (অথবা SERVICE_ROLE_KEY) বসান।',
        '.env ফাইলে মান যোগ করে প্রজেক্টটি পুনরায় আপলোড বা GitHub থেকে রি-ডিপ্লয় করুন।',
      ],
      stepsEn: [
        'Add a .env file in your project root containing SUPABASE_URL and SUPABASE_ANON_KEY / SUPABASE_SERVICE_ROLE_KEY.',
        'Re-upload the folder or re-sync from GitHub once .env values are set.',
      ],
    };
  }

  // 0b. ESM vs CommonJS mismatch
  if (/require is not defined in ES module scope|ERR_REQUIRE_ESM|Cannot use import statement outside a module/i.test(joined)) {
    return {
      titleBn: 'Node.js মডিউল ফরম্যাট (ESM / CommonJS) অসামঞ্জস্য',
      titleEn: 'Node.js module format mismatch (ESM vs CommonJS)',
      causeBn: `'${entry}' ফাইলের import/require ধরন এবং package.json-এর "type" ফিল্ডের মধ্যে অমিল রয়েছে।`,
      causeEn: `Mismatch between import/require syntax in '${entry}' and the "type" setting in package.json.`,
      stepsBn: [
        'কোডে import/export ব্যবহার করলে package.json-এ "type": "module" রাখুন; আর require() ব্যবহার করলে "type": "commonjs" রাখুন।',
        'প্রজেক্টের অটো-হিল ইঞ্জিনও এটি স্বয়ংক্রিয়ভাবে ঠিক করার চেষ্টা করে — তারপরও সমস্যা থাকলে package.json আপডেট করুন।',
      ],
      stepsEn: [
        'Use "type": "module" in package.json for import/export syntax, or "commonjs" for require().',
        'Update package.json and re-deploy if the mismatch persists across helper files.',
      ],
    };
  }

  // 1. Node.js missing package / module
  const nodeModMatch =
    joined.match(/Cannot find package ['"]([^'"]+)['"]/i) ||
    joined.match(/Cannot find module ['"]([^'"]+)['"]/i);
  if (nodeModMatch) {
    const pkg = nodeModMatch[1];
    const isRelative = pkg.startsWith('./') || pkg.startsWith('../');
    return {
      titleBn: isRelative
        ? `প্রজেক্টের ফাইল '${pkg}' খুঁজে পাওয়া যায়নি`
        : `Node.js প্যাকেজ '${pkg}' পাওয়া যায়নি`,
      titleEn: isRelative ? `Missing local file '${pkg}'` : `Missing Node.js package '${pkg}'`,
      causeBn: isRelative
        ? `'${entry}' ফাইলের import/require পাথে থাকা '${pkg}' ফাইলটি ফোল্ডার বা রিপোতে আপলোড হয়নি।`
        : `'${entry}' ফাইলে '${pkg}' প্যাকেজটি import করা হয়েছে, কিন্তু package.json বা প্রজেক্ট ফোল্ডারে সেটি অনুপস্থিত।`,
      causeEn: isRelative
        ? `Your entry file '${entry}' imports '${pkg}', which does not exist in the uploaded folder or repository.`
        : `Your '${entry}' imports '${pkg}', which is not bundled in package.json or available in the runtime.`,
      stepsBn: isRelative
        ? [
            `আপনার ফোল্ডার বা গিটহাব রিপোতে '${pkg}' ফাইলটি সঠিক পাথে আছে কিনা নিশ্চিত করুন।`,
            `ফাইলের নামের ছোট/বড় হাতের অক্ষর (Case Sensitivity) ও এক্সটেনশন (.js/.json) মিলিয়ে আবার আপলোড করুন।`,
          ]
        : [
            `প্রজেক্টের package.json ফাইলের "dependencies" সেকশনে "${pkg}" যুক্ত করুন এবং প্রজেক্টটি আবার সিঙ্ক করুন।`,
            `যদি এটি কাস্টম/ব্রাউজার-অনলি প্যাকেজ হয় বা সহজে Node স্ট্যান্ডার্ড মডিউল (যেমন http/fs) দিয়ে বদলানো যায়, কোডে সেটি ব্যবহার করুন।`,
            `Vite/React প্রজেক্ট হলে 'npm run build' চালিয়ে তৈরি হওয়া dist/ ফোল্ডারসহ আপলোড করুন।`,
          ],
      stepsEn: isRelative
        ? [
            `Ensure '${pkg}' exists at the exact relative path inside your folder or repository.`,
            `Check exact letter casing and extension (.js/.json) and re-deploy.`,
          ]
        : [
            `Add "${pkg}" under "dependencies" in your package.json and re-deploy.`,
            `If using Vite/React, run 'npm run build' locally and include the dist/ directory in your upload or repo.`,
          ],
    };
  }

  // 2. Python missing module
  const pyModMatch = joined.match(/No module named ['"]([^'"]+)['"]/i);
  if (pyModMatch) {
    const mod = pyModMatch[1];
    return {
      titleBn: `Python মডিউল '${mod}' পাওয়া যায়নি`,
      titleEn: `Python module '${mod}' not found`,
      causeBn: `'${entry}' ফাইলে '${mod}' মডিউল import করা হয়েছে, যা প্রজেক্টের প্যাকেজ বা স্ট্যান্ডার্ড লাইব্রেরিতে পাওয়া যায়নি।`,
      causeEn: `'${entry}' imports '${mod}', which is missing from the project directory or standard Python packages.`,
      stepsBn: [
        `প্রজেক্টের রুটে requirements.txt ফাইলে '${mod}' যুক্ত আছে কিনা নিশ্চিত করুন।`,
        `যদি '${mod}' আপনার নিজের প্রজেক্টের কোনো ফাইল/ফোল্ডার হয়, ফোল্ডারের রুটে '${mod}.py' বা '${mod}/__init__.py' সহ আপলোড করুন।`,
        `খুব ভারি বাইনারি প্যাকেজ (যেমন compiled C-extensions) এর বদলে স্ট্যান্ডার্ড Python মডিউল ব্যবহার করলে সহজে রান হয়।`,
      ],
      stepsEn: [
        `Verify '${mod}' is listed inside requirements.txt at your project root.`,
        `If '${mod}' is a local module in your project, ensure '${mod}.py' or '${mod}/__init__.py' was uploaded.`,
        `Where possible, replace heavy native-C dependencies with pure-Python or standard-library equivalents.`,
      ],
    };
  }

  // 3. Syntax / Indentation errors
  if (/SyntaxError|IndentationError|Unexpected token/i.test(joined)) {
    return {
      titleBn: `কোডে সিনট্যাক্স ত্রুটি (Syntax Error) রয়েছে`,
      titleEn: `Syntax error in '${entry}' or imported file`,
      causeBn: `প্রজেক্টের জাভাস্ক্রিপ্ট/টাইপস্ক্রিপ্ট বা পাইথন কোডের গঠনে বা ব্র্যাকেট/ইন্ডেন্টেশনে ভুল পাওয়া গেছে।`,
      causeEn: `A syntax or module format error prevented '${entry}' from parsing cleanly.`,
      stepsBn: [
        `আপনার লোকাল এডিটরে কোডটি চালিয়ে (node ${entry} অথবা python3 ${entry}) সিনট্যাক্স ঠিক করুন।`,
        `Node-এ যদি import/export ব্যবহার করেন তবে package.json-এ "type": "module" রাখুন; আর require() ব্যবহার করলে "type": "commonjs" রাখুন।`,
      ],
      stepsEn: [
        `Run '${runtime === 'python' ? 'python3' : 'node'} ${entry}' locally to locate and fix the exact line.`,
        `For Node.js: set "type": "module" in package.json for ESM import/export, or "commonjs" for require().`,
      ],
    };
  }

  // 4. Missing template / static file / directory (ENOENT / FileNotFoundError)
  if (/ENOENT|FileNotFoundError|Template .* not found|no such file or directory/i.test(joined)) {
    return {
      titleBn: `প্রজেক্টের অভ্যন্তরীণ ফাইল বা ফোল্ডার অনুপস্থিত`,
      titleEn: `Missing file or directory referenced by '${entry}'`,
      causeBn: `ব্যাকএন্ড কোড রান হওয়ার সময় একটি নির্দিষ্ট ফাইল বা ফোল্ডার (যেমন templates/, static/, dist/, .env) খুঁজতে গিয়ে পায়নি।`,
      causeEn: `The app attempted to read a local file, template, or build folder that is missing from the upload.`,
      stepsBn: [
        `প্রজেক্টের সব ফোল্ডার (templates/, static/, public/, data/, dist/) সহ আপলোড করুন।`,
        `আপনার কোডে __dirname বা Path(__file__).parent ব্যবহার করে রিলেটিভ পাথ লিখুন এবং হার্ডকোডেড লোকাল ড্রাইভ পাথ (যেমন C:\\ বা /Users/...) সরিয়ে দিন।`,
        `.env ফাইলে থাকা জরুরি এনভায়রনমেন্ট ভেরিয়েবলগুলো ফোল্ডারে যুক্ত রাখুন।`,
      ],
      stepsEn: [
        `Ensure supporting folders (templates/, static/, public/, dist/) are included in the folder/repository.`,
        `Use relative paths based on __dirname / Path(__file__).parent instead of local machine paths.`,
      ],
    };
  }

  // 5. Port / Startup timeout
  if (/within timeout|EADDRINUSE|did not open HTTP port/i.test(joined)) {
    return {
      titleBn: `অ্যাপটি নির্ধারিত PORT-এ সার্ভার চালু করেনি`,
      titleEn: `App did not bind to the assigned HTTP PORT`,
      causeBn: `'${entry}' রান হয়েছে কিন্তু HTTP পোর্টে লিসেন করেনি অথবা শুরুতেই কাজ শেষ হয়ে বন্ধ হয়ে গেছে।`,
      causeEn: `Your entry script ran without opening a listening HTTP server on process.env.PORT / os.environ["PORT"].`,
      stepsBn: [
        `Node.js হলে কোডে app.listen(process.env.PORT || 3000) ব্যবহার করুন।`,
        `Python (Flask/FastAPI) হলে অ্যাপের শেষে app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000))) অথবা ফাইলে 'app' অবজেক্ট সংজ্ঞায়িত রাখুন।`,
        `ডাটাবেস URL বা এক্সটার্নাল কানেকশন ব্যর্থ হলে যেন প্রসেস ক্র্যাশ না করে সেভাবে try/except হ্যান্ডলিং যোগ করুন।`,
      ],
      stepsEn: [
        `In Node.js, ensure your server calls listen(process.env.PORT || 3000).`,
        `In Python, use port=int(os.environ.get("PORT", 5000)) or expose a top-level 'app' object.`,
      ],
    };
  }

  // 6. OOM / SIGKILL / Render 512MB Memory Exceeded
  if (/JavaScript heap out of memory|MemoryError|Killed|SIGKILL|exit code 137|ENOMEM|RENDER_OOM/i.test(joined)) {
    return {
      titleBn: `মেমোরি লিমিট অতিক্রম করেছে (OOM / 512MB Cap)`,
      titleEn: `Process killed due to memory limit (OOM / SIGKILL)`,
      causeBn: `'${entry}' রান হওয়ার সময় নির্ধারিত RAM সীমা (160MB/512MB) ছাড়িয়ে যাওয়ায় প্রসেস বন্ধ হয়েছে।`,
      causeEn: `'${entry}' exceeded available memory and was terminated by the runtime limit.`,
      stepsBn: [
        `ভারী ডিপেন্ডেন্সি বা ইন-মেমোরি ক্যাশ কমিয়ে ফাইল স্ট্রিমিং ব্যবহার করুন।`,
        `ফ্রন্টএন্ড হলে আগে 'npm run build' করে তৈরি হওয়া dist/ ফোল্ডারটি স্ট্যাটিক হিসেবে ডিপ্লয় করুন (RAM খরচ শূন্যের কোঠায় নামবে)।`,
      ],
      stepsEn: [
        `Reduce heavy dependencies or in-memory buffers and stream large files instead.`,
        `For frontend apps, upload the pre-built dist/ folder so it serves statically with near-zero RAM.`,
      ],
    };
  }

  // 7. High Load / Concurrency Limit
  if (/HIGH_LOAD|too many concurrent runtimes|503/i.test(joined)) {
    return {
      titleBn: `সাময়িক ডায়নামিক লোড বেশি (Concurrency Protection)`,
      titleEn: `High concurrent runtime load`,
      causeBn: `একসাথে একাধিক ডায়নামিক ব্যাকএন্ড চালু থাকায় সার্ভার মেমোরি সুরক্ষার জন্য সাময়িকভাবে অপেক্ষায় রেখেছে।`,
      causeEn: `Multiple active Node/Python runtimes are warming concurrently under the 512MB guard.`,
      stepsBn: [
        `৫-১০ সেকেন্ড অপেক্ষা করে আবার রিলোড বা রিস্টার্ট দিন — নিষ্ক্রিয় অ্যাপ স্বয়ংক্রিয়ভাবে স্লিপ হয়ে ফ্রি RAM তৈরি করে।`,
      ],
      stepsEn: [
        `Wait 5–10 seconds and retry; idle apps automatically sleep to free RAM.`,
      ],
    };
  }

  // Default helpful diagnostic
  return {
    titleBn: `অ্যাপ চালুর সময় কোডে সমস্যা হয়েছে`,
    titleEn: `Application failed to start cleanly`,
    causeBn: `'${entry}' চালু হওয়ার পর নিচের লগ অনুযায়ী এরর দিয়ে বন্ধ হয়ে গেছে।`,
    causeEn: `'${entry}' exited before becoming ready to serve HTTP traffic. Inspect the exact traceback below.`,
    stepsBn: [
      `নিচের এরর লগের শেষ কয়েকটি লাইন দেখে নির্দিষ্ট ফাইল ও লাইন নম্বর যাচাই করুন।`,
      `কোনো এক্সটার্নাল API কী বা DATABASE_URL আবশ্যক হলে আপনার প্রজেক্টের .env ফাইলে সেটি যোগ করে আবার আপলোড করুন।`,
      `প্রয়োজনে package.json অথবা requirements.txt ফাইলটি আপলোড/আপডেট করে পুনরায় ডিপ্লয় করুন।`,
    ],
    stepsEn: [
      `Check the last few lines of the log below for the exact file path and exception.`,
      `Add any required environment variables inside a .env file in your project root and re-deploy.`,
      `Verify package.json / requirements.txt lists all third-party libraries used in your code.`,
    ],
  };
}

export interface CloudFootprintAssessment {
  fileCount: number;
  totalSizeBytes: number;
  estimatedRuntimeMb: number;
  needsOptimization: boolean;
  bloatFilesCount: number;
  bloatBytes: number;
  reasonBn: string;
  reasonEn: string;
}

export interface TrimmedProjectResult<T extends { path: string; content: string; size: number; isBinary?: boolean }> {
  files: T[];
  beforeCount: number;
  beforeBytes: number;
  afterCount: number;
  afterBytes: number;
  removedCount: number;
  summaryBn: string;
  summaryEn: string;
}

const NON_RUNTIME_BLOAT_RE =
  /(^|\/)(node_modules|__pycache__|\.pytest_cache|\.git|\.github|\.gitlab|\.vscode|\.idea|docs|doc|tests|test|__tests__|spec|coverage|examples|example|screenshots|storybook|\.storybook|cypress|playwright-report)\/|(\.map|\.d\.ts|\.spec\.[jt]sx?|\.test\.[jt]sx?|\.md|\.mdx|\.psd|\.ai|\.sketch|\.zip|\.tar|\.gz|\.rar|\.7z|\.mp4|\.mov|\.avi|\.mkv|\.bak)$/i;

const ESSENTIAL_ROOT_CONFIG_RE =
  /(^|\/)(index\.html|index\.htm|index\.php|app\.py|main\.py|server\.py|run\.py|wsgi\.py|server\.js|server\.mjs|server\.ts|app\.js|app\.mjs|index\.js|package\.json|requirements\.txt|vercel\.json|render\.yaml|procfile|\.env(\..*)?|\.htaccess)$/i;

function scoreCoreRunnablePriority(filePath: string, size: number, hasBuiltDist: boolean): number {
  const low = filePath.toLowerCase();
  if (ESSENTIAL_ROOT_CONFIG_RE.test(low)) return 0;
  if (hasBuiltDist && (low.startsWith('dist/') || low.startsWith('build/'))) {
    if (low.endsWith('.map')) return 99;
    return 1;
  }
  if (/^(templates|views|static|public|api|netlify\/functions|routes|controllers)\//i.test(low)) {
    return low.endsWith('.html') || low.endsWith('.php') || low.endsWith('.py') || low.endsWith('.js') ? 1 : 2;
  }
  if (/\.(html|htm|php|py|js|mjs|cjs|ts|tsx|jsx|css)$/i.test(low)) return 2;
  if (low.endsWith('.json') || low.endsWith('.svg') || low.endsWith('.ico')) return 3;
  if (size <= 120 * 1024) return 4;
  return 8;
}

/**
 * Estimates total cloud storage & post-build/runtime RAM footprint so large projects
 * prompt the user to optimize to their runnable core instead of crashing with 502.
 */
export function assessProjectCloudFootprint(
  files: Array<{ path: string; content?: string; size: number; isBinary?: boolean }>
): CloudFootprintAssessment {
  let totalSizeBytes = 0;
  let bloatFilesCount = 0;
  let bloatBytes = 0;
  let estimatedRuntimeMb = 8;

  for (const f of files) {
    const sz = Math.max(0, Number(f.size) || 0);
    totalSizeBytes += sz;
    const low = f.path.toLowerCase();
    if (NON_RUNTIME_BLOAT_RE.test(low) || sz > 600 * 1024) {
      bloatFilesCount += 1;
      bloatBytes += sz;
    }

    if (low === 'package.json' && f.content) {
      try {
        const pkg = JSON.parse(f.content) as { dependencies?: Record<string, string>; devDependencies?: Record<string, string> };
        const depCount = Object.keys(pkg.dependencies || {}).length;
        const devCount = Object.keys(pkg.devDependencies || {}).length;
        estimatedRuntimeMb += depCount * 14 + devCount * 12;
        const joinedDeps = JSON.stringify({ ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) }).toLowerCase();
        if (/(next|nuxt|webpack|playwright|puppeteer|electron|three|tensorflow|@mui|antd)/.test(joinedDeps)) {
          estimatedRuntimeMb += 180;
        }
      } catch {
        // ignore invalid package.json
      }
    }

    if (low === 'requirements.txt' && f.content) {
      const lines = f.content.split(/\r?\n/).filter(l => l.trim() && !l.trim().startsWith('#'));
      estimatedRuntimeMb += lines.length * 16;
      if (/(torch|tensorflow|scipy|pandas|numpy|opencv|playwright|selenium|transformers|scikit)/i.test(f.content)) {
        estimatedRuntimeMb += 260;
      }
    }
  }

  const rawMb = totalSizeBytes / (1024 * 1024);
  estimatedRuntimeMb = Math.round(estimatedRuntimeMb + rawMb * 8 + files.length * 1.1);

  const needsOptimization =
    files.length > 85 ||
    totalSizeBytes > 3.2 * 1024 * 1024 ||
    estimatedRuntimeMb >= 200;

  return {
    fileCount: files.length,
    totalSizeBytes,
    estimatedRuntimeMb,
    needsOptimization,
    bloatFilesCount,
    bloatBytes,
    reasonBn: `আপনার বর্তমান ক্লাউড প্ল্যান অনুযায়ী প্রজেক্টটি রান/বিল্ড হওয়ার পর আনুমানিক ~${estimatedRuntimeMb} MB+ (২০০–৫০০ MB+) জায়গা ও মেমোরি দখল করতে পারে। একসাথে সব ফাইল আপলোড করলে সার্ভার চাপ সামলাতে না পারে।`,
    reasonEn: `Under your current plan, this project may require ~${estimatedRuntimeMb} MB+ (200–500 MB+) of build/runtime storage & memory. You can trim non-essential files and launch only the runnable core.`,
  };
}

/**
 * Strips non-runtime bloat (source maps, docs, tests, lockfiles, raw TS sources when dist/ exists,
 * and oversized media) so only the lean runnable core deploys quickly on Render + Supabase.
 */
export function optimizeProjectToRunnableCore<
  T extends { path: string; content: string; size: number; isBinary?: boolean }
>(
  files: T[],
  options: { maxFiles?: number; maxTotalBytes?: number } = {}
): TrimmedProjectResult<T> {
  const maxFiles = options.maxFiles ?? 72;
  const maxTotalBytes = options.maxTotalBytes ?? 2.2 * 1024 * 1024;
  const beforeCount = files.length;
  const beforeBytes = files.reduce((s, f) => s + Math.max(0, Number(f.size) || 0), 0);

  const hasBuiltDist = files.some(f => /^(dist|build)\/index\.html$/i.test(f.path.replace(/^\/+/, '')));

  // Step 1: Drop non-runtime bloat
  const step1 = files.filter(f => {
    const clean = f.path.replace(/^\/+/, '');
    const low = clean.toLowerCase();
    if (ESSENTIAL_ROOT_CONFIG_RE.test(low)) return true;
    if (NON_RUNTIME_BLOAT_RE.test(low)) return false;
    if (/^(package-lock\.json|yarn\.lock|pnpm-lock\.yaml|poetry\.lock|composer\.lock|license(\..*)?|changelog(\..*)?|contributing(\..*)?|readme(\..*)?)$/i.test(low)) {
      return false;
    }
    if (hasBuiltDist && /^src\//i.test(low)) {
      // Keep only if backend file lives under src/
      return /^src\/(server|app|index)\.(js|mjs|ts|py)$/i.test(low);
    }
    return true;
  });

  const baseCandidates = step1.length > 0 ? step1 : [...files];

  // Step 2: Prioritize essential entrypoints, backend scripts, HTML, CSS, JS, and templates within tight budget
  const ranked = [...baseCandidates].sort((a, b) => {
    const pa = scoreCoreRunnablePriority(a.path, a.size, hasBuiltDist);
    const pb = scoreCoreRunnablePriority(b.path, b.size, hasBuiltDist);
    if (pa !== pb) return pa - pb;
    return (a.size || 0) - (b.size || 0);
  });

  const kept: T[] = [];
  let keptBytes = 0;

  for (const item of ranked) {
    const clean = item.path.replace(/^\/+/, '');
    const isEssential = ESSENTIAL_ROOT_CONFIG_RE.test(clean);
    const sz = Math.max(0, Number(item.size) || 0);

    if (!isEssential && kept.length >= maxFiles) continue;
    if (!isEssential && item.isBinary && sz > 320 * 1024 && keptBytes + sz > maxTotalBytes * 0.75) {
      continue;
    }
    if (!isEssential && keptBytes + sz > maxTotalBytes) {
      continue;
    }

    kept.push(item);
    keptBytes += sz;
  }

  const finalFiles = kept.length > 0 ? kept : ranked.slice(0, Math.min(25, ranked.length));
  const afterBytes = finalFiles.reduce((s, f) => s + Math.max(0, Number(f.size) || 0), 0);

  return {
    files: finalFiles,
    beforeCount,
    beforeBytes,
    afterCount: finalFiles.length,
    afterBytes,
    removedCount: Math.max(0, beforeCount - finalFiles.length),
    summaryBn: `প্রজেক্টটি অপ্টিমাইজ করা হয়েছে: ${beforeCount}টি ফাইল থেকে অপ্রয়োজনীয় ${Math.max(0, beforeCount - finalFiles.length)}টি ভারী ফাইল বাদ দিয়ে মূল ${finalFiles.length}টি রানেবল ফাইল রাখা হয়েছে।`,
    summaryEn: `Optimized project: trimmed ${Math.max(0, beforeCount - finalFiles.length)} heavy/non-essential files, keeping ${finalFiles.length} core runnable files.`,
  };
}


