import {
  HostedSite,
  SubAdmin,
  User,
  PlatformConfig,
  ThemeMode,
  AuditLogEntry,
  ServerStorageStats,
  UserPopupMessage,
  UserPageView,
  AdminTab,
  AdminActivityReport,
  SiteFile,
} from '../types';
import {
  normalizeCustomDomain,
  computePoolAllocationSummary,
  DEFAULT_PRIMARY_DOMAIN,
  sanitizeExternalLinkUrl,
  normalizeUserSubdomain,
  formatHttpTransportError,
} from './format';

const USERS_KEY = 'nighthost_users_v4';
const SITES_KEY = 'nighthost_sites_v4';
const SUBADMINS_KEY = 'nighthost_subadmins_v4';
const SESSION_KEY = 'nighthost_session_v4';
const ROUTE_KEY = 'nighthost_current_route_v4';
const DEPLOY_METHOD_KEY = 'nighthost_deploy_method_v4';
const USER_PAGE_KEY = 'nighthost_user_page_v4';
const ADMIN_TAB_KEY = 'nighthost_admin_tab_v4';
const LANG_KEY = 'nighthost_lang_v4';
const CONFIG_KEY = 'nighthost_config_v4';
const THEME_KEY = 'nighthost_theme_v3';
const AUDIT_KEY = 'nighthost_audit_v4';
const POPUP_MSG_KEY = 'nighthost_popup_msgs_v4';
const POPUP_DISMISSED_KEY = 'nighthost_popup_dismissed_v4';

export interface RenderEnvPayload {
  pairs: Array<{ key: string; value: string; isSecret?: boolean }>;
  dotenvText: string;
  poolJson: string;
}

export const DEFAULT_PLATFORM_CONFIG: PlatformConfig = {
  brandName: 'NIGHTHOST',
  tagline: 'High Speed Cloud Web & Microservice Hosting Platform',
  heroSubtitle: '',
  footerNote: '',
  allowRegistration: true,
  serverStorageCapacityMb: 1024,
  masterAdminName: 'NIGHT HEX',
  masterAdminTelegram: 'https://t.me/NightHex_X',
  masterAdminTelegramHandle: '@NightHex_X',
  secretAdminSlug: 'admin',
  defaultStorageMb: 100,
  broadcastMessage: '',
  primaryDomain: DEFAULT_PRIMARY_DOMAIN,
};

const DEFAULT_USERS: User[] = [];

const DEFAULT_SUBADMINS: SubAdmin[] = [];
const DEFAULT_SITES: HostedSite[] = [];

class StorageService {
  private users: User[] = [];
  private sites: HostedSite[] = [];
  private subAdmins: SubAdmin[] = [];
  private auditLogs: AuditLogEntry[] = [];
  private popupMessages: UserPopupMessage[] = [];
  private adminReports: AdminActivityReport[] = [];
  private localDismissedMsgIds: Set<string> = new Set();
  private config: PlatformConfig = { ...DEFAULT_PLATFORM_CONFIG };
  private needsOwnerSetup = false;
  private serverStorage: ServerStorageStats | null = null;
  private theme: ThemeMode = 'dark';
  private currentUser: User | null = null;
  private currentRoute: string = 'dashboard';
  private listeners: (() => void)[] = [];
  private hydrated = false;
  private realtimeReconnectFn: (() => void) | null = null;

  private stripPassword(user: User): User {
    const clean = { ...user };
    delete clean.password;
    return clean;
  }

  private hasStorage(): boolean {
    return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
  }

  private isBrowser(): boolean {
    return typeof window !== 'undefined' && typeof fetch !== 'undefined';
  }

  constructor() {
    this.init();
  }

  private init() {
    try {
      if (!this.hasStorage()) {
        this.users = [...DEFAULT_USERS];
        this.sites = [...DEFAULT_SITES];
        this.subAdmins = [...DEFAULT_SUBADMINS];
        this.needsOwnerSetup = true;
        return;
      }

      // Clean old demo localStorage keys if present
      ['nighthost_users_v3', 'nighthost_sites_v3', 'nighthost_subadmins_v3', 'nighthost_session_v3'].forEach(k => {
        try {
          localStorage.removeItem(k);
        } catch {
          // ignore
        }
      });

      const storedConfig = localStorage.getItem(CONFIG_KEY);
      if (storedConfig) {
        const parsedCfg = JSON.parse(storedConfig) as Partial<PlatformConfig>;
        if (!parsedCfg.masterAdminName || parsedCfg.masterAdminName === 'নাইটহেক্স (NightHex)') {
          parsedCfg.masterAdminName = DEFAULT_PLATFORM_CONFIG.masterAdminName;
        }
        if (!parsedCfg.masterAdminTelegram || parsedCfg.masterAdminTelegram === 'https://t.me/nighthex_admin') {
          parsedCfg.masterAdminTelegram = DEFAULT_PLATFORM_CONFIG.masterAdminTelegram;
        }
        if (!parsedCfg.masterAdminTelegramHandle || parsedCfg.masterAdminTelegramHandle === '@nighthex_admin') {
          parsedCfg.masterAdminTelegramHandle = DEFAULT_PLATFORM_CONFIG.masterAdminTelegramHandle;
        }
        this.config = { ...DEFAULT_PLATFORM_CONFIG, ...parsedCfg };
      } else {
        this.config = { ...DEFAULT_PLATFORM_CONFIG };
        this.saveConfig();
      }

      const storedTheme = localStorage.getItem(THEME_KEY) as ThemeMode | null;
      if (storedTheme === 'light' || storedTheme === 'dark') {
        this.theme = storedTheme;
      }

      const storedUsers = localStorage.getItem(USERS_KEY);
      if (storedUsers) {
        const parsedUsers = JSON.parse(storedUsers) as User[];
        this.users = parsedUsers.map((u) =>
          u.id === 'user_admin' && u.fullName === 'নাইটহেক্স (NightHex)'
            ? { ...u, fullName: 'NIGHT HEX' }
            : u
        );
      } else {
        this.users = [...DEFAULT_USERS];
        this.saveUsers();
      }

      const storedSites = localStorage.getItem(SITES_KEY);
      if (storedSites) {
        this.sites = JSON.parse(storedSites);
      } else {
        this.sites = [...DEFAULT_SITES];
        this.saveSites();
      }

      const storedSub = localStorage.getItem(SUBADMINS_KEY);
      if (storedSub) {
        this.subAdmins = JSON.parse(storedSub);
      } else {
        this.subAdmins = [...DEFAULT_SUBADMINS];
        this.saveSubAdmins();
      }

      const storedAudit = localStorage.getItem(AUDIT_KEY);
      if (storedAudit) {
        this.auditLogs = JSON.parse(storedAudit);
      } else {
        this.auditLogs = [];
        this.saveAuditLogs();
      }

      const storedPopup = localStorage.getItem(POPUP_MSG_KEY);
      if (storedPopup) {
        this.popupMessages = JSON.parse(storedPopup);
      }
      const storedDismissed = localStorage.getItem(POPUP_DISMISSED_KEY);
      if (storedDismissed) {
        this.localDismissedMsgIds = new Set(JSON.parse(storedDismissed));
      }

      const storedSession = localStorage.getItem(SESSION_KEY);
      if (storedSession) {
        const parsed = JSON.parse(storedSession);
        const matched = this.users.find(u => u.id === parsed.id || u.username === parsed.username);
        if (matched) {
          this.currentUser = matched;
        } else if (parsed && parsed.id) {
          this.currentUser = parsed;
        }
      }

      const storedRoute = localStorage.getItem(ROUTE_KEY);
      if (storedRoute) {
        this.currentRoute = storedRoute;
      }
    } catch {
      this.users = [...DEFAULT_USERS];
      this.sites = [...DEFAULT_SITES];
      this.subAdmins = [...DEFAULT_SUBADMINS];
    }
  }

  private applyServerPayload(data: {
    sessionUser?: User | null;
    config?: PlatformConfig;
    needsOwnerSetup?: boolean;
    users?: User[];
    subAdmins?: SubAdmin[];
    sites?: HostedSite[];
    auditLogs?: AuditLogEntry[];
    popupMessages?: UserPopupMessage[];
    serverStorage?: ServerStorageStats;
    adminReports?: AdminActivityReport[];
  }) {
    if (data.config) {
      this.config = { ...DEFAULT_PLATFORM_CONFIG, ...data.config };
      this.saveConfig();
    }
    if (typeof data.needsOwnerSetup === 'boolean') {
      this.needsOwnerSetup = data.needsOwnerSetup;
    }
    if (Array.isArray(data.users)) {
      this.users = data.users.map(u => this.stripPassword(u));
      this.saveUsers();
    }
    if (Array.isArray(data.subAdmins)) {
      this.subAdmins = data.subAdmins;
      this.saveSubAdmins();
    }
    if (Array.isArray(data.sites)) {
      this.sites = data.sites;
      this.saveSites();
    }
    if (Array.isArray(data.auditLogs)) {
      this.auditLogs = data.auditLogs;
      this.saveAuditLogs();
    }
    if (Array.isArray(data.popupMessages)) {
      this.popupMessages = data.popupMessages;
      this.savePopupMessages();
    }
    if (data.serverStorage) {
      this.serverStorage = data.serverStorage;
    }
    if (Array.isArray(data.adminReports)) {
      this.adminReports = data.adminReports;
    }
    if (data.sessionUser !== undefined) {
      if (data.sessionUser) {
        this.currentUser = this.stripPassword(data.sessionUser);
        if (this.hasStorage()) {
          this.safeSetItem(SESSION_KEY, JSON.stringify(this.currentUser));
        }
      } else {
        this.currentUser = null;
        if (this.hasStorage()) {
          try {
            localStorage.removeItem(SESSION_KEY);
          } catch {
            // ignore
          }
        }
      }
    } else if (this.currentUser) {
      const updatedMe = this.users.find(u => u.id === this.currentUser?.id || u.username === this.currentUser?.username);
      if (!updatedMe) {
        this.setCurrentUser(null);
      } else {
        this.currentUser = this.stripPassword(updatedMe);
        if (this.hasStorage()) {
          this.safeSetItem(SESSION_KEY, JSON.stringify(this.currentUser));
        }
      }
    }
    this.hydrated = true;
    this.notify();
  }

  getServerStorageStats(): ServerStorageStats {
    if (this.serverStorage) {
      return { ...this.serverStorage };
    }
    const configuredPoolMb = Math.max(500, Number(this.config.serverStorageCapacityMb) || 1024);
    const defaultQuotaMb = Math.max(10, Number(this.config.defaultStorageMb) || 100);
    const summary = computePoolAllocationSummary(this.users, this.sites, configuredPoolMb, defaultQuotaMb);

    return {
      configuredPoolMb,
      diskTotalMb: null,
      diskFreeMb: null,
      storageSource: 'os-disk',
      supabaseNodesCount: 0,
      supabaseConnectedCount: 0,
      supabaseConnectedMb: 0,
      supabaseNodes: [],
      b2NodesCount: 0,
      b2ConnectedCount: 0,
      b2ConnectedMb: 0,
      b2Nodes: [],
      allocatedMb: summary.allocatedMb,
      usedBySitesMb: summary.usedBySitesMb,
      usedByAvatarsMb: summary.usedByAvatarsMb,
      totalUsedMb: summary.totalUsedMb,
      remainingAllocatableMb: summary.remainingAllocatableMb,
      defaultQuotaMb,
      estimatedRemainingUsers: summary.estimatedRemainingUsers,
      totalUsersCount: summary.totalUsersCount,
      approvedUsersCount: summary.approvedUsersCount,
      pendingUsersCount: summary.pendingUsersCount,
      suspendedUsersCount: summary.suspendedUsersCount,
    };
  }

  async refreshServerStorageAsync(): Promise<ServerStorageStats | null> {
    if (!this.isBrowser()) return null;
    try {
      const res = await fetch('/api/admin/server-storage', { cache: 'no-store' });
      const data = await res.json();
      if (data?.success && data.serverStorage) {
        this.serverStorage = data.serverStorage;
        this.notify();
        return data.serverStorage as ServerStorageStats;
      }
      return null;
    } catch {
      return null;
    }
  }

  async addSupabaseNodeAsync(payload: {
    label: string;
    url: string;
    serviceKey: string;
    bucket: string;
    quotaMb: number;
  }): Promise<{ success: boolean; message?: string; renderEnv?: RenderEnvPayload }> {
    try {
      const res = await fetch('/api/admin/storage/supabase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...payload, actor: this.currentUser?.username || 'admin' }),
      });
      const data = await res.json();
      if (data?.success) {
        this.applyServerPayload(data);
        return { success: true, message: data.message, renderEnv: data.renderEnv };
      }
      return { success: false, message: data?.message || 'Supabase নড যুক্ত করা যায়নি।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async verifySupabaseNodeAsync(
    nodeId: string
  ): Promise<{ success: boolean; message?: string; renderEnv?: RenderEnvPayload }> {
    try {
      const res = await fetch(`/api/admin/storage/supabase/${encodeURIComponent(nodeId)}/verify`, {
        method: 'POST',
      });
      const data = await res.json();
      if (data?.success) {
        this.applyServerPayload(data);
        return { success: true, message: data.message, renderEnv: data.renderEnv };
      }
      if (data?.serverStorage) {
        this.applyServerPayload(data);
      }
      return { success: false, message: data?.message || 'Supabase যাচাই করা যায়নি।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async removeSupabaseNodeAsync(nodeId: string): Promise<{ success: boolean; message?: string }> {
    try {
      const res = await fetch(
        `/api/admin/storage/supabase/${encodeURIComponent(nodeId)}?actor=${encodeURIComponent(this.currentUser?.username || 'admin')}`,
        { method: 'DELETE' }
      );
      const data = await res.json();
      if (data?.success) {
        this.applyServerPayload(data);
        return { success: true, message: data.message };
      }
      return { success: false, message: data?.message || 'Supabase নড রিমুভ করা যায়নি।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async fetchSupabaseRenderEnvAsync(): Promise<{
    success: boolean;
    renderEnv?: RenderEnvPayload;
    connectedCount?: number;
  }> {
    if (!this.isBrowser()) return { success: false };
    try {
      const res = await fetch('/api/admin/storage/supabase/render-env', { cache: 'no-store' });
      const data = await res.json();
      return {
        success: Boolean(data?.success),
        renderEnv: data?.renderEnv,
        connectedCount: data?.connectedCount,
      };
    } catch {
      return { success: false };
    }
  }

  async recheckAllSupabaseNodesAsync(): Promise<{
    success: boolean;
    message?: string;
    renderEnv?: RenderEnvPayload;
  }> {
    if (!this.isBrowser()) return { success: false };
    try {
      const res = await fetch('/api/admin/storage/supabase/recheck-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ actor: this.currentUser?.username || 'admin' }),
      });
      const data = await res.json();
      if (data?.success) {
        this.applyServerPayload(data);
        return { success: true, message: data.message, renderEnv: data.renderEnv };
      }
      return { success: false, message: data?.message || 'Supabase নড পুনরায় যাচাই করা যায়নি।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async syncAllSitesToSupabaseAsync(): Promise<{ success: boolean; message?: string }> {
    if (!this.isBrowser()) return { success: false };
    try {
      const res = await fetch('/api/admin/storage/supabase/sync-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ actor: this.currentUser?.username || 'admin' }),
      });
      const data = await res.json();
      if (data?.success) {
        this.applyServerPayload(data);
        return { success: true, message: data.message };
      }
      return { success: false, message: data?.message || 'সিঙ্ক করা যায়নি।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async addB2NodeAsync(payload: {
    label: string;
    keyId: string;
    applicationKey: string;
    bucketName: string;
    quotaMb: number;
  }): Promise<{ success: boolean; message?: string; renderEnv?: RenderEnvPayload }> {
    try {
      const res = await fetch('/api/admin/storage/b2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data?.success) {
        this.applyServerPayload(data);
        return { success: true, message: data.message || 'Backblaze B2 সংযুক্ত হয়েছে!', renderEnv: data.renderEnv };
      }
      return { success: false, message: data?.message || 'Backblaze B2 নড যুক্ত করা যায়নি।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async verifyB2NodeAsync(
    nodeId: string
  ): Promise<{ success: boolean; message?: string; renderEnv?: RenderEnvPayload }> {
    try {
      const res = await fetch(`/api/admin/storage/b2/${encodeURIComponent(nodeId)}/verify`, {
        method: 'POST',
      });
      const data = await res.json();
      if (data?.success) {
        this.applyServerPayload(data);
        return { success: true, message: data.message, renderEnv: data.renderEnv };
      }
      if (data?.serverStorage) {
        this.applyServerPayload(data);
      }
      return { success: false, message: data?.message || 'Backblaze B2 যাচাই করা যায়নি।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async removeB2NodeAsync(nodeId: string): Promise<{ success: boolean; message?: string }> {
    try {
      const res = await fetch(`/api/admin/storage/b2/${encodeURIComponent(nodeId)}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (data?.success) {
        this.applyServerPayload(data);
        return { success: true, message: data.message };
      }
      return { success: false, message: data?.message || 'Backblaze B2 নড রিমুভ করা যায়নি।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async syncAllSitesToB2Async(): Promise<{ success: boolean; message?: string }> {
    if (!this.isBrowser()) return { success: false };
    try {
      const res = await fetch('/api/admin/storage/b2/sync-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();
      if (data?.success) {
        this.applyServerPayload(data);
        return { success: true, message: data.message };
      }
      return { success: false, message: data?.message || 'B2 সিঙ্ক করা যায়নি।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async fetchCloudflareWorkerTemplateAsync(): Promise<{
    success: boolean;
    primaryDomain?: string;
    renderHost?: string;
    routes?: string[];
    workerCode?: string;
    message?: string;
  }> {
    if (!this.isBrowser()) return { success: false };
    try {
      const res = await fetch('/api/admin/cloudflare-worker', { cache: 'no-store' });
      const data = await res.json();
      return {
        success: Boolean(data?.success),
        primaryDomain: data?.primaryDomain,
        renderHost: data?.renderHost,
        routes: data?.routes,
        workerCode: data?.workerCode,
        message: data?.message,
      };
    } catch {
      return { success: false };
    }
  }

  async triggerAutoHealAsync(siteId: string): Promise<{
    success: boolean;
    healed?: boolean;
    usedEngine?: string;
    message?: string;
    site?: HostedSite;
  }> {
    if (!this.isBrowser()) return { success: false, message: 'Browser required' };
    try {
      const res = await fetch(`/api/sites/${encodeURIComponent(siteId)}/auto-heal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const rawText = await res.text();
      let data: {
        success?: boolean;
        healed?: boolean;
        usedEngine?: string;
        message?: string;
        site?: HostedSite;
        sessionUser?: User | null;
        config?: PlatformConfig;
        needsOwnerSetup?: boolean;
        users?: User[];
        subAdmins?: SubAdmin[];
        sites?: HostedSite[];
        auditLogs?: AuditLogEntry[];
        popupMessages?: UserPopupMessage[];
        serverStorage?: ServerStorageStats;
        adminReports?: AdminActivityReport[];
      } = {};
      try {
        data = JSON.parse(rawText || '{}');
      } catch {
        return { success: false, message: formatHttpTransportError(res.status, rawText) };
      }
      if (res.ok && data.success) {
        this.applyServerPayload(data);
        return {
          success: true,
          healed: Boolean(data.healed),
          usedEngine: data.usedEngine,
          message: data.message,
          site: data.site,
        };
      }
      return {
        success: false,
        message: data.message || formatHttpTransportError(res.status, rawText),
      };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async undoAutoHealAsync(siteId: string): Promise<{
    success: boolean;
    message?: string;
    site?: HostedSite;
  }> {
    if (!this.isBrowser()) return { success: false, message: 'Browser required' };
    try {
      const res = await fetch(`/api/sites/${encodeURIComponent(siteId)}/auto-heal/undo`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const rawText = await res.text();
      let data: {
        success?: boolean;
        message?: string;
        site?: HostedSite;
        sessionUser?: User | null;
        config?: PlatformConfig;
        needsOwnerSetup?: boolean;
        users?: User[];
        subAdmins?: SubAdmin[];
        sites?: HostedSite[];
        auditLogs?: AuditLogEntry[];
        popupMessages?: UserPopupMessage[];
        serverStorage?: ServerStorageStats;
        adminReports?: AdminActivityReport[];
      } = {};
      try {
        data = JSON.parse(rawText || '{}');
      } catch {
        return { success: false, message: formatHttpTransportError(res.status, rawText) };
      }
      if (res.ok && data.success) {
        this.applyServerPayload(data);
        return { success: true, message: data.message, site: data.site };
      }
      return {
        success: false,
        message: data.message || formatHttpTransportError(res.status, rawText),
      };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async approveAllPendingUsersAsync(
    durationHours: number = 24,
    durationLabel: string = '২৪ ঘন্টা (1 Day)',
    quotaMb?: number
  ): Promise<{ success: boolean; approvedCount?: number; message?: string }> {
    if (!this.isBrowser()) {
      let count = 0;
      for (const u of this.users) {
        if (u.role !== 'admin' && u.status === 'pending') {
          if (this.approveUser(u.id, durationHours, durationLabel, quotaMb)) {
            count += 1;
          }
        }
      }
      return { success: true, approvedCount: count };
    }
    try {
      const res = await fetch('/api/admin/users/approve-all-pending', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          durationHours,
          durationLabel,
          quotaMb,
          actor: this.currentUser?.username || 'admin',
        }),
      });
      const data = await res.json();
      if (data?.success) {
        this.applyServerPayload(data);
        return { success: true, approvedCount: data.approvedCount, message: data.message };
      }
      return { success: false, message: data?.message || 'পেন্ডিং ইউজার অনুমোদন করা যায়নি।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async syncFromServer(): Promise<void> {
    if (!this.isBrowser()) return;
    try {
      const [bootRes, meRes] = await Promise.all([
        fetch('/api/bootstrap', { cache: 'no-store' }),
        !this.currentUser ? fetch('/api/auth/me', { cache: 'no-store' }) : Promise.resolve(null),
      ]);
      if (meRes && meRes.ok) {
        const meJson = await meRes.json().catch(() => null);
        if (meJson?.user) {
          this.currentUser = this.stripPassword(meJson.user);
          if (this.hasStorage()) {
            this.safeSetItem(SESSION_KEY, JSON.stringify(this.currentUser));
          }
        }
      }
      if (!bootRes.ok) return;
      const data = await bootRes.json();
      this.applyServerPayload(data);
    } catch {
      // Fallback gracefully to local cache if server unavailable
    }
  }

  reconnectRealtimeSync(): void {
    if (this.realtimeReconnectFn) {
      this.realtimeReconnectFn();
    } else if (this.isBrowser()) {
      this.syncFromServer();
    }
  }

  startRealtimeSync(): () => void {
    if (!this.isBrowser()) return () => {};
    let source: EventSource | null = null;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
    let closed = false;

    const connect = () => {
      if (closed || typeof EventSource === 'undefined') return;
      if (reconnectTimer) {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
      }
      if (source) {
        try {
          source.close();
        } catch {
          // ignore close glitch
        }
        source = null;
      }
      try {
        source = new EventSource('/api/events');
        source.onmessage = (event) => {
          try {
            const parsed = JSON.parse(event.data);
            if (parsed?.type === 'sync' && parsed.payload) {
              this.applyServerPayload(parsed.payload);
            }
          } catch {
            // ignore malformed event
          }
        };
        source.onerror = () => {
          source?.close();
          source = null;
          if (!closed && !reconnectTimer) {
            reconnectTimer = setTimeout(connect, 3500);
          }
        };
      } catch {
        // ignore EventSource errors
      }
    };

    this.realtimeReconnectFn = () => {
      if (closed) return;
      connect();
      this.syncFromServer();
    };

    connect();

    const fallbackInterval = setInterval(() => {
      if (closed || document.visibilityState !== 'visible') return;
      if (!source || source.readyState !== 1) {
        this.syncFromServer();
      }
    }, 5000);

    const handleVisibilityOrFocus = () => {
      if (document.visibilityState === 'visible') {
        this.syncFromServer();
      }
    };
    const handleOnline = () => {
      this.reconnectRealtimeSync();
    };
    window.addEventListener('focus', handleVisibilityOrFocus);
    window.addEventListener('online', handleOnline);
    document.addEventListener('visibilitychange', handleVisibilityOrFocus);

    return () => {
      closed = true;
      this.realtimeReconnectFn = null;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      clearInterval(fallbackInterval);
      source?.close();
      window.removeEventListener('focus', handleVisibilityOrFocus);
      window.removeEventListener('online', handleOnline);
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus);
    };
  }

  isHydrated(): boolean {
    return this.hydrated;
  }

  subscribe(callback: () => void) {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  private notify() {
    for (const cb of this.listeners) {
      cb();
    }
  }

  private safeSetItem(key: string, value: string) {
    if (!this.hasStorage()) return;
    try {
      localStorage.setItem(key, value);
    } catch {
      // Ignore storage quota exceeded errors so login & real-time updates never stall
    }
  }

  private saveUsers() {
    const safeUsers = this.users.map(u => this.stripPassword(u));
    this.safeSetItem(USERS_KEY, JSON.stringify(safeUsers));
  }

  private saveSites() {
    // Store slim site index in localStorage so multi-MB hosted file blobs never block UI or exceed 5MB quota;
    // full `this.sites` remains in memory for instant inspection & runtime previews.
    const slimSites = this.sites.map((s) => {
      const slimFiles: HostedSite['files'] = {};
      for (const [fPath, fileObj] of Object.entries(s.files || {})) {
        slimFiles[fPath] = {
          path: fileObj.path,
          size: fileObj.size,
          isHidden: fileObj.isHidden,
          isBinary: fileObj.isBinary,
          type: fileObj.type,
          content: fileObj.content && fileObj.content.length <= 2048 ? fileObj.content : '',
        };
      }
      return {
        ...s,
        files: slimFiles,
      };
    });
    this.safeSetItem(SITES_KEY, JSON.stringify(slimSites));
  }

  private saveSubAdmins() {
    this.safeSetItem(SUBADMINS_KEY, JSON.stringify(this.subAdmins));
  }

  private saveConfig() {
    this.safeSetItem(CONFIG_KEY, JSON.stringify(this.config));
  }

  private saveAuditLogs() {
    this.safeSetItem(AUDIT_KEY, JSON.stringify(this.auditLogs.slice(0, 150)));
  }

  private savePopupMessages() {
    this.safeSetItem(POPUP_MSG_KEY, JSON.stringify(this.popupMessages.slice(0, 50)));
  }

  private saveLocalDismissedMsgs() {
    this.safeSetItem(POPUP_DISMISSED_KEY, JSON.stringify(Array.from(this.localDismissedMsgIds)));
  }

  // --- UI Persistence across page refresh ---
  getSavedDeployMethod(): 'folder' | 'single' | 'github' | null {
    if (!this.hasStorage()) return null;
    const val = localStorage.getItem(DEPLOY_METHOD_KEY);
    if (val === 'folder' || val === 'single' || val === 'github') return val;
    return null;
  }

  setSavedDeployMethod(method: 'folder' | 'single' | 'github' | null) {
    if (!this.hasStorage()) return;
    if (method) localStorage.setItem(DEPLOY_METHOD_KEY, method);
    else localStorage.removeItem(DEPLOY_METHOD_KEY);
  }

  getSavedUserPage(): UserPageView {
    if (!this.hasStorage()) return 'overview';
    const val = localStorage.getItem(USER_PAGE_KEY);
    if (
      val === 'overview' ||
      val === 'sites' ||
      val === 'deploy-folder' ||
      val === 'deploy-single' ||
      val === 'deploy-github' ||
      val === 'profile' ||
      val === 'guide'
    ) {
      return val;
    }
    // Migrate legacy deploy method if present
    const legacy = this.getSavedDeployMethod();
    if (legacy === 'folder') return 'deploy-folder';
    if (legacy === 'single') return 'deploy-single';
    if (legacy === 'github') return 'deploy-github';
    return 'overview';
  }

  setSavedUserPage(page: UserPageView) {
    if (!this.hasStorage()) return;
    localStorage.setItem(USER_PAGE_KEY, page);
    if (page === 'deploy-folder') localStorage.setItem(DEPLOY_METHOD_KEY, 'folder');
    else if (page === 'deploy-single') localStorage.setItem(DEPLOY_METHOD_KEY, 'single');
    else if (page === 'deploy-github') localStorage.setItem(DEPLOY_METHOD_KEY, 'github');
    else localStorage.removeItem(DEPLOY_METHOD_KEY);
  }

  getSavedAdminTab(): AdminTab {
    if (!this.hasStorage()) return 'overview';
    const val = localStorage.getItem(ADMIN_TAB_KEY);
    if (
      val === 'overview' ||
      val === 'users' ||
      val === 'subadmins' ||
      val === 'sites' ||
      val === 'messages' ||
      val === 'logs' ||
      val === 'settings'
    ) {
      return val;
    }
    return 'overview';
  }

  setSavedAdminTab(tab: AdminTab) {
    if (!this.hasStorage()) return;
    localStorage.setItem(ADMIN_TAB_KEY, tab);
  }

  getSavedLang(): 'bn' | 'en' {
    if (!this.hasStorage()) return 'bn';
    return localStorage.getItem(LANG_KEY) === 'en' ? 'en' : 'bn';
  }

  setSavedLang(lang: 'bn' | 'en') {
    if (!this.hasStorage()) return;
    localStorage.setItem(LANG_KEY, lang);
  }

  // --- Audit Logs ---
  getAuditLogs(): AuditLogEntry[] {
    return [...this.auditLogs];
  }

  addAuditLog(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) {
    const newLog: AuditLogEntry = {
      ...entry,
      id: 'log_' + Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toISOString(),
    };
    this.auditLogs.unshift(newLog);
    if (this.auditLogs.length > 150) {
      this.auditLogs = this.auditLogs.slice(0, 150);
    }
    this.saveAuditLogs();
  }

  clearAuditLogs() {
    this.auditLogs = [];
    this.saveAuditLogs();
    this.notify();
    if (this.isBrowser()) {
      fetch('/api/admin/audit-logs', { method: 'DELETE' }).catch(() => {});
    }
  }

  // --- Theme Mode ---
  getTheme(): ThemeMode {
    return this.theme;
  }

  setTheme(theme: ThemeMode) {
    this.theme = theme;
    if (this.hasStorage()) {
      localStorage.setItem(THEME_KEY, theme);
      if (theme === 'dark') {
        document.documentElement.classList.add('dark');
        document.documentElement.classList.remove('light');
      } else {
        document.documentElement.classList.remove('dark');
        document.documentElement.classList.add('light');
      }
    }
    this.notify();
  }

  // --- Platform Config ---
  getConfig(): PlatformConfig {
    return { ...this.config };
  }

  updateConfig(updates: Partial<PlatformConfig>) {
    this.config = { ...this.config, ...updates };
    this.saveConfig();
    this.addAuditLog({
      actor: this.currentUser?.username || 'admin',
      action: 'CONFIG_UPDATED',
      target: this.config.brandName,
      details: 'Updated platform settings & configuration.',
      category: 'config',
    });
    this.notify();
    if (this.isBrowser()) {
      fetch('/api/admin/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ updates, actor: this.currentUser?.username || 'admin' }),
      })
        .then(r => r.json())
        .then(d => d.success && this.applyServerPayload(d))
        .catch(() => {});
    }
  }

  // --- Auth & Session ---
  getCurrentUser(): User | null {
    if (!this.currentUser) return null;
    const refreshed = this.users.find(u => u.id === this.currentUser?.id);
    if (refreshed) {
      this.currentUser = refreshed;
    }
    return this.currentUser;
  }

  setCurrentUser(user: User | null) {
    this.currentUser = user ? this.stripPassword(user) : null;
    if (this.currentUser && this.hasStorage()) {
      this.safeSetItem(SESSION_KEY, JSON.stringify(this.currentUser));
    } else if (this.hasStorage()) {
      localStorage.removeItem(SESSION_KEY);
      localStorage.removeItem(DEPLOY_METHOD_KEY);
      localStorage.removeItem(USER_PAGE_KEY);
      localStorage.removeItem(ADMIN_TAB_KEY);
    }
    this.notify();
  }

  async logoutAsync(): Promise<void> {
    this.setCurrentUser(null);
    if (this.isBrowser()) {
      try {
        await fetch('/api/auth/logout', { method: 'POST' });
      } catch {
        // ignore logout cookie errors
      }
      this.reconnectRealtimeSync();
    }
  }

  getCurrentRoute(): string {
    return this.currentRoute;
  }

  setCurrentRoute(route: string) {
    this.currentRoute = route;
    if (this.hasStorage()) {
      localStorage.setItem(ROUTE_KEY, route);
    }
    this.notify();
  }

  async loginUserAsync(
    username: string,
    password: string
  ): Promise<{
    success: boolean;
    user?: User;
    code?: string;
    message?: string;
    activeSubAdmins?: SubAdmin[];
    config?: PlatformConfig;
  }> {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const rawText = await res.text();
      let data: {
        success?: boolean;
        user?: User;
        users?: User[];
        code?: string;
        message?: string;
        activeSubAdmins?: SubAdmin[];
        config?: PlatformConfig;
      } = {};
      try {
        data = JSON.parse(rawText || '{}');
      } catch {
        return { success: false, message: formatHttpTransportError(res.status, rawText) };
      }
      if (data.success && data.user) {
        this.setCurrentUser(data.user);
        if (data.config || data.users) {
          this.applyServerPayload(data);
        } else {
          await this.syncFromServer();
        }
        this.reconnectRealtimeSync();
        return { success: true, user: data.user };
      }
      if (data.activeSubAdmins) {
        this.subAdmins = data.activeSubAdmins;
      }
      if (data.config) {
        this.config = data.config;
      }
      return {
        success: false,
        code: data.code,
        message: data.message || (res.status >= 400 ? formatHttpTransportError(res.status, rawText) : undefined),
        activeSubAdmins: data.activeSubAdmins,
        config: data.config,
      };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  getNeedsOwnerSetup(): boolean {
    return this.needsOwnerSetup;
  }

  async getOwnerSetupStatusAsync(): Promise<boolean> {
    if (!this.isBrowser()) return this.needsOwnerSetup;
    try {
      const res = await fetch('/api/auth/setup-status', { cache: 'no-store' });
      const data = await res.json();
      if (data?.success && typeof data.needsOwnerSetup === 'boolean') {
        this.needsOwnerSetup = data.needsOwnerSetup;
        this.notify();
        return data.needsOwnerSetup;
      }
    } catch {
      // ignore network error
    }
    return this.needsOwnerSetup;
  }

  async setupInitialOwnerAsync(payload: {
    username: string;
    fullName: string;
    email: string;
    password: string;
  }): Promise<{ success: boolean; user?: User; message?: string }> {
    try {
      const res = await fetch('/api/auth/setup-owner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const rawText = await res.text();
      let data: {
        success?: boolean;
        user?: User;
        users?: User[];
        config?: PlatformConfig;
        message?: string;
      } = {};
      try {
        data = JSON.parse(rawText || '{}');
      } catch {
        return { success: false, message: formatHttpTransportError(res.status, rawText) };
      }
      if (data.success && data.user) {
        this.needsOwnerSetup = false;
        this.setCurrentUser(data.user);
        this.applyServerPayload(data);
        this.reconnectRealtimeSync();
        return { success: true, user: data.user };
      }
      return {
        success: false,
        message: data.message || (res.status >= 400 ? formatHttpTransportError(res.status, rawText) : undefined),
      };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async adminLoginAsync(
    role: 'admin' | 'subadmin',
    username: string,
    password: string
  ): Promise<{ success: boolean; user?: User; message?: string }> {
    try {
      const res = await fetch('/api/auth/admin-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role, username, password }),
      });
      const rawText = await res.text();
      let data: { success?: boolean; user?: User; message?: string; config?: PlatformConfig; users?: User[] } = {};
      try {
        data = JSON.parse(rawText || '{}');
      } catch {
        return { success: false, message: formatHttpTransportError(res.status, rawText) };
      }
      if (data.success && data.user) {
        this.setCurrentUser(data.user);
        if (data.config || data.users) {
          this.applyServerPayload(data);
        } else {
          await this.syncFromServer();
        }
        this.reconnectRealtimeSync();
        return { success: true, user: data.user };
      }
      return {
        success: false,
        message: data.message || (res.status >= 400 ? formatHttpTransportError(res.status, rawText) : undefined),
      };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async registerUserAsync(
    username: string,
    fullName: string,
    email: string,
    password: string
  ): Promise<{
    success: boolean;
    message: string;
    user?: User;
    activeSubAdmins?: SubAdmin[];
    config?: PlatformConfig;
  }> {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, fullName, email, password }),
      });
      const rawText = await res.text();
      let data: {
        success: boolean;
        message: string;
        user?: User;
        activeSubAdmins?: SubAdmin[];
        config?: PlatformConfig;
      };
      try {
        data = JSON.parse(rawText || '{}');
      } catch {
        return { success: false, message: formatHttpTransportError(res.status, rawText) };
      }
      if (data.success) {
        await this.syncFromServer();
      }
      return data;
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  // Remaining approval time
  getRemainingApprovalTime(
    user: User,
    lang: 'bn' | 'en' = 'bn'
  ): {
    seconds: number;
    isExpired: boolean;
    days: number;
    hours: number;
    minutes: number;
    secs: number;
    label: string;
    formattedCountdown: string;
  } {
    if (!user.expiresAt) {
      return {
        seconds: Infinity,
        isExpired: false,
        days: 999,
        hours: 0,
        minutes: 0,
        secs: 0,
        label: lang === 'en' ? 'Unlimited Access' : 'স্থায়ী অ্যাক্সেস (Unlimited)',
        formattedCountdown: lang === 'en' ? 'Permanent Active' : 'স্থায়ী সক্রিয়',
      };
    }

    const diffMs = new Date(user.expiresAt).getTime() - Date.now();
    if (diffMs <= 0) {
      return {
        seconds: 0,
        isExpired: true,
        days: 0,
        hours: 0,
        minutes: 0,
        secs: 0,
        label: lang === 'en' ? 'Expired' : 'মেয়াদ শেষ (Expired)',
        formattedCountdown: lang === 'en' ? 'Expired' : 'মেয়াদ শেষ',
      };
    }

    const totalSeconds = Math.floor(diffMs / 1000);
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;

    let label = '';
    let formattedCountdown = '';

    if (days > 0) {
      label = lang === 'en' ? `${days}d ${hours}h left` : `${days} দিন ${hours} ঘন্টা`;
      formattedCountdown = `${days}d ${hours}h ${minutes}m`;
    } else if (hours > 0) {
      label = lang === 'en' ? `${hours}h ${minutes}m left` : `${hours} ঘন্টা ${minutes} মিনিট`;
      formattedCountdown = `${hours}h ${minutes}m ${secs}s`;
    } else if (minutes > 0) {
      label = lang === 'en' ? `${minutes}m ${secs}s left` : `${minutes} মিনিট ${secs} সেকেন্ড`;
      formattedCountdown = `${minutes}m ${secs}s`;
    } else {
      label = lang === 'en' ? `${secs}s left` : `${secs} সেকেন্ড বাকি`;
      formattedCountdown = lang === 'en' ? `${secs}s left` : `${secs}s বাকি`;
    }

    return { seconds: totalSeconds, isExpired: false, days, hours, minutes, secs, label, formattedCountdown };
  }

  // --- User Operations ---
  getUsers(): User[] {
    return [...this.users];
  }

  registerUser(
    username: string,
    fullName: string,
    email: string,
    password?: string
  ): { success: boolean; message: string; user?: User } {
    const cleanUsername = username.trim().toLowerCase();
    const cleanPass = String(password || '').trim();
    if (!cleanUsername || !fullName.trim() || !email.trim() || cleanPass.length < 4) {
      return {
        success: false,
        message: 'সঠিক নাম, ইউজারনেম, ইমেইল এবং কমপক্ষে ৪ অক্ষরের পাসওয়ার্ড দিন।',
      };
    }
    if (this.users.some(u => u.username.toLowerCase() === cleanUsername)) {
      return { success: false, message: `ব্যবহারকারী নাম '${username}' ইতিমধ্যে ব্যবহৃত। অন্য নাম নির্বাচন করুন।` };
    }

    const newUser: User = {
      id: 'user_' + Math.random().toString(36).substring(2, 9),
      username: cleanUsername,
      fullName: fullName.trim(),
      email: email.trim().toLowerCase(),
      password: cleanPass,
      role: 'user',
      status: 'pending',
      storageLimitMb: this.config.defaultStorageMb || 100,
      storageUsedMb: 0,
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
    };

    this.users.push(newUser);
    this.saveUsers();
    this.notify();

    return {
      success: true,
      message: 'রেজিস্ট্রেশন সম্পন্ন হয়েছে! অ্যাক্টিভ করার জন্য মালিক বা অ্যাডমিনের সাথে যোগাযোগ করুন।',
      user: newUser,
    };
  }

  approveUser(
    userId: string,
    durationHours: number = -1,
    durationLabel: string = 'স্থায়ী (Permanent)',
    quotaMb?: number
  ): boolean {
    const user = this.users.find(u => u.id === userId);
    if (!user) return false;

    user.status = 'approved';
    user.approvedAt = new Date().toISOString();
    user.approvalDurationLabel = durationLabel;
    if (quotaMb !== undefined) {
      user.storageLimitMb = Math.max(10, Number(quotaMb) || 100);
    }

    if (durationHours > 0) {
      user.expiresAt = new Date(Date.now() + durationHours * 3600 * 1000).toISOString();
    } else {
      delete user.expiresAt;
    }

    this.saveUsers();
    this.addAuditLog({
      actor: this.currentUser?.username || 'admin',
      action: 'USER_APPROVED',
      target: user.username,
      details: `Approved for ${durationLabel} (${user.storageLimitMb} MB)`,
      category: 'user',
    });
    this.notify();

    if (this.isBrowser()) {
      fetch(`/api/admin/users/${encodeURIComponent(userId)}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          durationHours,
          durationLabel,
          quotaMb: user.storageLimitMb,
          actor: this.currentUser?.username || 'admin',
        }),
      })
        .then(r => r.json())
        .then(d => d.success && this.applyServerPayload(d))
        .catch(() => {});
    }
    return true;
  }

  suspendUser(userId: string): boolean {
    const user = this.users.find(u => u.id === userId);
    if (!user) return false;
    user.status = 'suspended';
    this.saveUsers();
    this.addAuditLog({
      actor: this.currentUser?.username || 'admin',
      action: 'USER_SUSPENDED',
      target: user.username,
      details: 'User access suspended.',
      category: 'user',
    });
    this.notify();

    if (this.isBrowser()) {
      fetch(`/api/admin/users/${encodeURIComponent(userId)}/suspend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ actor: this.currentUser?.username || 'admin' }),
      })
        .then(r => r.json())
        .then(d => d.success && this.applyServerPayload(d))
        .catch(() => {});
    }
    return true;
  }

  unsuspendUser(userId: string): boolean {
    const user = this.users.find(u => u.id === userId);
    if (!user) return false;
    user.status = 'approved';
    if (user.expiresAt && new Date(user.expiresAt).getTime() <= Date.now()) {
      delete user.expiresAt;
      user.approvalDurationLabel = 'রিনিউ / স্থায়ী';
    }
    this.saveUsers();
    this.addAuditLog({
      actor: this.currentUser?.username || 'admin',
      action: 'USER_UNSUSPENDED',
      target: user.username,
      details: 'User access restored with all hosted files preserved.',
      category: 'user',
    });
    this.notify();

    if (this.isBrowser()) {
      fetch(`/api/admin/users/${encodeURIComponent(userId)}/unsuspend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ actor: this.currentUser?.username || 'admin' }),
      })
        .then(r => r.json())
        .then(d => d.success && this.applyServerPayload(d))
        .catch(() => {});
    }
    return true;
  }

  setUserStorageLimit(userId: string, limitMb: number): boolean {
    const user = this.users.find(u => u.id === userId);
    if (!user) return false;
    user.storageLimitMb = Math.max(10, limitMb);
    this.saveUsers();
    this.notify();

    if (this.isBrowser()) {
      fetch(`/api/admin/users/${encodeURIComponent(userId)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          storageLimitMb: user.storageLimitMb,
          actor: this.currentUser?.username || 'admin',
        }),
      })
        .then(r => r.json())
        .then(d => d.success && this.applyServerPayload(d))
        .catch(() => {});
    }
    return true;
  }

  updateUser(
    userId: string,
    updates: { fullName?: string; email?: string; password?: string; storageLimitMb?: number }
  ): boolean {
    const user = this.users.find(u => u.id === userId);
    if (!user) return false;
    if (updates.fullName !== undefined && updates.fullName.trim()) {
      user.fullName = updates.fullName.trim();
    }
    if (updates.email !== undefined && updates.email.trim()) {
      user.email = updates.email.trim().toLowerCase();
    }
    if (updates.password !== undefined && updates.password.trim()) {
      user.password = updates.password.trim();
    }
    if (updates.storageLimitMb !== undefined) {
      user.storageLimitMb = Math.max(10, updates.storageLimitMb);
    }
    this.saveUsers();
    this.addAuditLog({
      actor: this.currentUser?.username || 'admin',
      action: 'USER_UPDATED',
      target: user.username,
      details: `Updated user profile/quota (${user.storageLimitMb} MB).`,
      category: 'user',
    });
    this.notify();

    if (this.isBrowser()) {
      fetch(`/api/admin/users/${encodeURIComponent(userId)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...updates, actor: this.currentUser?.username || 'admin' }),
      })
        .then(r => r.json())
        .then(d => d.success && this.applyServerPayload(d))
        .catch(() => {});
    }
    return true;
  }

  async updateProfileAsync(
    userId: string,
    updates: { fullName?: string; email?: string; password?: string; avatarDataUrl?: string | null }
  ): Promise<{ success: boolean; user?: User; message?: string }> {
    try {
      const res = await fetch('/api/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, ...updates }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        if (this.currentUser && this.currentUser.id === data.user.id) {
          this.currentUser = this.stripPassword(data.user);
          if (this.hasStorage()) {
            this.safeSetItem(SESSION_KEY, JSON.stringify(this.currentUser));
          }
        }
        this.applyServerPayload(data);
        return { success: true, user: data.user };
      }
      return { success: false, message: data.message || 'প্রোফাইল আপডেট করতে সমস্যা হয়েছে।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async updateAdminProfileAsync(
    userId: string,
    updates: { username?: string; fullName?: string; email?: string; password?: string; avatarDataUrl?: string | null }
  ): Promise<{ success: boolean; user?: User; message?: string }> {
    try {
      const res = await fetch('/api/admin/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, ...updates }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        if (this.currentUser && this.currentUser.id === data.user.id) {
          this.currentUser = this.stripPassword(data.user);
          if (this.hasStorage()) {
            this.safeSetItem(SESSION_KEY, JSON.stringify(this.currentUser));
          }
        }
        this.applyServerPayload(data);
        return { success: true, user: data.user };
      }
      return { success: false, message: data.message || 'প্রোফাইল আপডেট করতে সমস্যা হয়েছে।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async checkSubdomainAvailabilityAsync(
    rawSubdomain: string
  ): Promise<{ success: boolean; available: boolean; normalized: string; message: string }> {
    const normalized = normalizeUserSubdomain(rawSubdomain);
    if (!this.isBrowser()) {
      const taken = this.users.some(
        u => u.id !== this.currentUser?.id && u.subdomain?.toLowerCase() === normalized
      );
      return {
        success: true,
        available: normalized.length >= 3 && !taken,
        normalized,
        message: taken ? 'ব্যবহৃত' : 'ফ্রি আছে',
      };
    }
    try {
      const res = await fetch(
        `/api/user/subdomain/check?subdomain=${encodeURIComponent(rawSubdomain)}`,
        { cache: 'no-store' }
      );
      const data = await res.json();
      return {
        success: Boolean(data?.success),
        available: Boolean(data?.available),
        normalized: String(data?.normalized || normalized),
        message: String(data?.message || ''),
      };
    } catch {
      return {
        success: false,
        available: false,
        normalized,
        message: 'সার্ভারের সাথে যাচাই করা যায়নি।',
      };
    }
  }

  async saveUserSubdomainAsync(
    rawSubdomain: string
  ): Promise<{ success: boolean; user?: User; message: string }> {
    const normalized = normalizeUserSubdomain(rawSubdomain);
    if (!this.isBrowser()) {
      if (!this.currentUser || normalized.length < 3) {
        return { success: false, message: 'সঠিক সাবডোমেইন দিন।' };
      }
      this.currentUser.subdomain = normalized;
      this.saveUsers();
      this.notify();
      return { success: true, user: this.currentUser, message: `সাবডোমেইন '/u/${normalized}/' সেট হয়েছে!` };
    }
    try {
      const res = await fetch('/api/user/subdomain', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subdomain: rawSubdomain }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        if (this.currentUser && this.currentUser.id === data.user.id) {
          this.currentUser = this.stripPassword(data.user);
          if (this.hasStorage()) {
            this.safeSetItem(SESSION_KEY, JSON.stringify(this.currentUser));
          }
        }
        this.applyServerPayload(data);
        return {
          success: true,
          user: data.user,
          message: data.message || `সাবডোমেইন '/u/${data.user.subdomain}/' সেট হয়েছে!`,
        };
      }
      return { success: false, message: data.message || 'সাবডোমেইন সেভ করা যায়নি।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  deleteUser(userId: string): boolean {
    const target = this.users.find(u => u.id === userId);
    if (!target) return false;
    if (target.role === 'admin') return false;

    this.users = this.users.filter(u => u.id !== userId);
    this.sites = this.sites.filter(s => s.userId !== userId);
    this.subAdmins = this.subAdmins.filter(
      s => s.id !== userId && s.username.toLowerCase() !== target.username.toLowerCase()
    );

    this.saveUsers();
    this.saveSites();
    this.saveSubAdmins();
    this.addAuditLog({
      actor: this.currentUser?.username || 'admin',
      action: 'USER_DELETED',
      target: target.username,
      details: 'Account and all associated sites permanently deleted.',
      category: 'user',
    });
    this.notify();

    if (this.isBrowser()) {
      fetch(`/api/admin/users/${encodeURIComponent(userId)}?actor=${encodeURIComponent(this.currentUser?.username || 'admin')}`, {
        method: 'DELETE',
      })
        .then(r => r.json())
        .then(d => d.success && this.applyServerPayload(d))
        .catch(() => {});
    }
    return true;
  }

  // --- Sub-Admin Operations ---
  getSubAdmins(): SubAdmin[] {
    return [...this.subAdmins];
  }

  getActiveSubAdmins(): SubAdmin[] {
    return this.subAdmins.filter(s => s.active);
  }

  addSubAdmin(
    username: string,
    displayName: string,
    email: string,
    telegramHandle: string,
    password?: string
  ): { success: boolean; message: string; subAdmin?: SubAdmin } {
    const cleanUsername = username.trim().toLowerCase();
    const cleanPassword = String(password || '').trim();
    if (cleanPassword.length < 4) {
      return { success: false, message: 'অ্যাডমিনের জন্য কমপক্ষে ৪ অক্ষরের পাসওয়ার্ড দিন।' };
    }
    if (this.users.some(u => u.username.toLowerCase() === cleanUsername)) {
      return { success: false, message: `ইউজারনেম '${username}' ইতিমধ্যে ব্যবহৃত!` };
    }

    let cleanTg = telegramHandle.trim();
    if (cleanTg.startsWith('@')) {
      cleanTg = cleanTg.substring(1);
    }
    const tgUrl = cleanTg.startsWith('http') ? cleanTg : `https://t.me/${cleanTg}`;
    const tgDisplay = cleanTg.startsWith('http')
      ? `@${cleanTg.split('/').filter(Boolean).pop() || cleanUsername}`
      : `@${cleanTg}`;

    const newSub: SubAdmin = {
      id: 'sub_' + Math.random().toString(36).substring(2, 9),
      username: cleanUsername,
      displayName: displayName.trim() || `অ্যাডমিন (${cleanUsername})`,
      email: email.trim().toLowerCase(),
      telegramUsername: tgDisplay,
      telegramUrl: tgUrl,
      active: true,
      canApproveUsers: true,
      canSetQuota: true,
      canSendMessages: true,
      createdAt: new Date().toISOString(),
      lastActive: new Date().toISOString(),
    };

    const newUserRecord: User = {
      id: newSub.id,
      username: cleanUsername,
      fullName: newSub.displayName,
      email: email.trim().toLowerCase(),
      password: cleanPassword,
      role: 'subadmin',
      status: 'approved',
      storageLimitMb: 1000,
      storageUsedMb: 0,
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      approvalDurationLabel: 'স্থায়ী অ্যাডমিন',
    };

    this.subAdmins.push(newSub);
    this.users.push(newUserRecord);
    this.saveSubAdmins();
    this.saveUsers();
    this.notify();

    return {
      success: true,
      message: `অ্যাডমিন '${cleanUsername}' সফলভাবে যুক্ত হয়েছে! টেলিগ্রাম: ${tgDisplay}`,
      subAdmin: newSub,
    };
  }

  async addSubAdminAsync(
    username: string,
    displayName: string,
    email: string,
    telegramHandle: string,
    password?: string
  ): Promise<{ success: boolean; message: string; subAdmin?: SubAdmin }> {
    try {
      const res = await fetch('/api/admin/subadmins', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username,
          displayName,
          email,
          telegramHandle,
          password,
          actor: this.currentUser?.username || 'admin',
        }),
      });
      const data = await res.json();
      if (data.success) {
        this.applyServerPayload(data);
      }
      return data;
    } catch {
      return { success: false, message: 'অ্যাডমিন যুক্ত করতে সার্ভার ত্রুটি হয়েছে।' };
    }
  }

  toggleSubAdminStatus(subAdminId: string): boolean {
    const sub = this.subAdmins.find(s => s.id === subAdminId);
    if (!sub) return false;
    sub.active = !sub.active;

    const u = this.users.find(user => user.id === subAdminId || user.username === sub.username);
    if (u) {
      u.status = sub.active ? 'approved' : 'suspended';
    }

    this.saveSubAdmins();
    this.saveUsers();
    this.addAuditLog({
      actor: this.currentUser?.username || 'admin',
      action: sub.active ? 'SUBADMIN_ENABLED' : 'SUBADMIN_DISABLED',
      target: sub.username,
      details: `Sub-Admin status toggled to ${sub.active ? 'ACTIVE' : 'DISABLED'}.`,
      category: 'subadmin',
    });
    this.notify();

    if (this.isBrowser()) {
      fetch(`/api/admin/subadmins/${encodeURIComponent(subAdminId)}/toggle`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ actor: this.currentUser?.username || 'admin' }),
      })
        .then(r => r.json())
        .then(d => d.success && this.applyServerPayload(d))
        .catch(() => {});
    }
    return true;
  }

  getAdminActivityReports(): AdminActivityReport[] {
    return [...this.adminReports];
  }

  updateSubAdminPermissions(
    subAdminId: string,
    perms: {
      canApproveUsers?: boolean;
      canSetQuota?: boolean;
      canSendMessages?: boolean;
      canDownloadSource?: boolean;
      canManageAllSites?: boolean;
    }
  ): boolean {
    const sub = this.subAdmins.find(s => s.id === subAdminId);
    if (!sub) return false;
    if (perms.canApproveUsers !== undefined) sub.canApproveUsers = perms.canApproveUsers;
    if (perms.canSetQuota !== undefined) sub.canSetQuota = perms.canSetQuota;
    if (perms.canSendMessages !== undefined) sub.canSendMessages = perms.canSendMessages;
    if (perms.canDownloadSource !== undefined) sub.canDownloadSource = perms.canDownloadSource;
    if (perms.canManageAllSites !== undefined) sub.canManageAllSites = perms.canManageAllSites;
    this.saveSubAdmins();
    this.addAuditLog({
      actor: this.currentUser?.username || 'admin',
      action: 'SUBADMIN_PERMS_UPDATED',
      target: sub.username,
      details: `Permissions: approve=${sub.canApproveUsers}, quota=${sub.canSetQuota}, msg=${sub.canSendMessages !== false}, download=${Boolean(sub.canDownloadSource)}, allSites=${Boolean(sub.canManageAllSites)}`,
      category: 'subadmin',
    });
    this.notify();

    if (this.isBrowser()) {
      fetch(`/api/admin/subadmins/${encodeURIComponent(subAdminId)}/permissions`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...perms, actor: this.currentUser?.username || 'admin' }),
      })
        .then(r => r.json())
        .then(d => d.success && this.applyServerPayload(d))
        .catch(() => {});
    }
    return true;
  }

  // --- One-Time Popup Messages & Notification Inbox (Admin / SubAdmin -> Users) ---
  getPopupMessages(): UserPopupMessage[] {
    return [...this.popupMessages];
  }

  getPopupMessagesForUser(userId: string): UserPopupMessage[] {
    if (!userId) return [];
    return this.popupMessages.filter(
      msg => msg.targetUserId === 'all' || msg.targetUserId === userId
    );
  }

  isPopupMessageDismissedByUser(msg: UserPopupMessage, userId: string): boolean {
    if (!userId) return false;
    const dismissedRemote =
      Array.isArray(msg.dismissedByUserIds) && msg.dismissedByUserIds.includes(userId);
    const dismissedLocal = this.localDismissedMsgIds.has(`${userId}:${msg.id}`);
    return dismissedRemote || dismissedLocal;
  }

  getUnreadPopupMessagesForUser(userId: string): UserPopupMessage[] {
    return this.getPopupMessagesForUser(userId).filter(
      msg => !this.isPopupMessageDismissedByUser(msg, userId)
    );
  }

  async sendPopupMessageAsync(
    targetUserId: 'all' | string,
    title: string,
    message: string,
    senderUsername?: string,
    options?: { linkUrl?: string; linkText?: string; linkMarked?: boolean }
  ): Promise<{ success: boolean; message?: UserPopupMessage; error?: string }> {
    const cleanTitle = String(title || '').trim() || 'অ্যাডমিন বিজ্ঞপ্তি';
    const cleanMsg = String(message || '').trim();
    const actor = senderUsername || this.currentUser?.username || 'admin';
    if (!cleanMsg) {
      return { success: false, error: 'মেসেজের টেক্সট লিখুন।' };
    }

    const rawLinkUrl = String(options?.linkUrl || '').trim();
    const safeLinkUrl = rawLinkUrl ? sanitizeExternalLinkUrl(rawLinkUrl) : '';
    if (rawLinkUrl && !safeLinkUrl) {
      return {
        success: false,
        error: 'সঠিক লিংক দিন (অবশ্যই https:// অথবা http:// দিয়ে শুরু হতে হবে)।',
      };
    }
    const cleanLinkText = String(options?.linkText || '').trim().slice(0, 80);
    const linkMarked = options?.linkMarked !== undefined ? Boolean(options.linkMarked) : true;

    if (!this.isBrowser()) {
      const targetUser = targetUserId !== 'all' ? this.users.find(u => u.id === targetUserId) : undefined;
      const entry: UserPopupMessage = {
        id: 'msg_' + Math.random().toString(36).substring(2, 9),
        title: cleanTitle,
        message: cleanMsg,
        ...(safeLinkUrl
          ? {
              linkUrl: safeLinkUrl,
              linkText: cleanLinkText || safeLinkUrl,
              linkMarked,
            }
          : {}),
        targetUserId,
        targetUsername: targetUser?.username,
        senderUsername: actor,
        createdAt: new Date().toISOString(),
        dismissedByUserIds: [],
      };
      this.popupMessages.unshift(entry);
      this.savePopupMessages();
      this.notify();
      return { success: true, message: entry };
    }

    try {
      const res = await fetch('/api/admin/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: cleanTitle,
          message: cleanMsg,
          ...(safeLinkUrl
            ? {
                linkUrl: safeLinkUrl,
                linkText: cleanLinkText || safeLinkUrl,
                linkMarked,
              }
            : {}),
          targetUserId,
          actor,
        }),
      });
      const data = await res.json();
      if (data.success) {
        this.applyServerPayload(data);
        return { success: true, message: data.messageItem };
      }
      return { success: false, error: data.message };
    } catch {
      return { success: false, error: 'মেসেজ পাঠাতে সার্ভার ত্রুটি হয়েছে।' };
    }
  }

  async dismissPopupMessageAsync(msgId: string, userId: string): Promise<void> {
    this.localDismissedMsgIds.add(`${userId}:${msgId}`);
    this.saveLocalDismissedMsgs();
    const target = this.popupMessages.find(m => m.id === msgId);
    if (target && !target.dismissedByUserIds.includes(userId)) {
      target.dismissedByUserIds.push(userId);
      this.savePopupMessages();
    }
    this.notify();
    if (this.isBrowser()) {
      try {
        const res = await fetch(`/api/messages/${encodeURIComponent(msgId)}/dismiss`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId }),
        });
        const data = await res.json();
        if (data.success) this.applyServerPayload(data);
      } catch {
        // local dismissal still prevents reappearance
      }
    }
  }

  async deletePopupMessageAsync(msgId: string): Promise<void> {
    this.popupMessages = this.popupMessages.filter(m => m.id !== msgId);
    this.savePopupMessages();
    this.notify();
    if (this.isBrowser()) {
      try {
        const res = await fetch(`/api/admin/messages/${encodeURIComponent(msgId)}`, {
          method: 'DELETE',
        });
        const data = await res.json();
        if (data.success) this.applyServerPayload(data);
      } catch {
        // ignore
      }
    }
  }

  removeSubAdmin(subAdminId: string): boolean {
    const sub = this.subAdmins.find(s => s.id === subAdminId);
    if (!sub) return false;
    this.subAdmins = this.subAdmins.filter(s => s.id !== subAdminId);
    this.users = this.users.filter(
      u => u.id !== subAdminId && u.username.toLowerCase() !== sub.username.toLowerCase()
    );
    this.sites = this.sites.filter(s => s.userId !== subAdminId);
    this.saveSubAdmins();
    this.saveUsers();
    this.saveSites();
    this.addAuditLog({
      actor: this.currentUser?.username || 'admin',
      action: 'SUBADMIN_REMOVED',
      target: sub.username,
      details: 'Sub-Admin removed from platform.',
      category: 'subadmin',
    });
    this.notify();

    if (this.isBrowser()) {
      fetch(`/api/admin/subadmins/${encodeURIComponent(subAdminId)}?actor=${encodeURIComponent(this.currentUser?.username || 'admin')}`, {
        method: 'DELETE',
      })
        .then(r => r.json())
        .then(d => d.success && this.applyServerPayload(d))
        .catch(() => {});
    }
    return true;
  }

  // --- Site Operations ---
  getSites(userId?: string): HostedSite[] {
    if (userId) {
      return this.sites.filter(s => s.userId === userId);
    }
    return [...this.sites];
  }

  getSiteBySlug(slug: string): HostedSite | undefined {
    return this.sites.find(
      s => s.slug.toLowerCase() === slug.toLowerCase() || s.customPath?.toLowerCase() === slug.toLowerCase()
    );
  }

  isSlugTaken(slug: string, excludeSiteId?: string): boolean {
    return this.sites.some(s => s.slug.toLowerCase() === slug.toLowerCase() && s.id !== excludeSiteId);
  }

  isDomainTaken(domain: string, excludeSiteId?: string): boolean {
    const normalized = normalizeCustomDomain(domain);
    if (!normalized) return false;
    return this.sites.some(
      s => s.id !== excludeSiteId && normalizeCustomDomain(s.customDomain || '') === normalized
    );
  }

  private recalculateLocalUserStorageMb(userId: string) {
    const user = this.users.find(u => u.id === userId);
    if (!user) return;
    const sitesKb = this.sites
      .filter(s => s.userId === userId)
      .reduce((acc, s) => acc + (Number(s.totalSizeKb) || 0), 0);
    const avatarKb = Number(user.avatarSizeKb) || 0;
    const totalKb = sitesKb + avatarKb;
    user.storageUsedMb = totalKb === 0 ? 0 : Math.round((totalKb / 1024) * 1000) / 1000;
    this.saveUsers();
  }

  createSite(siteData: Omit<HostedSite, 'id' | 'createdAt' | 'updatedAt' | 'visitsCount' | 'bandwidthMb'>): HostedSite {
    const newSite: HostedSite = {
      ...siteData,
      id: 'site_' + Math.random().toString(36).substring(2, 9),
      visitsCount: 1,
      bandwidthMb: 0.1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.sites.unshift(newSite);
    this.saveSites();
    this.recalculateLocalUserStorageMb(siteData.userId);
    this.notify();
    return newSite;
  }

  async createSiteAsync(
    siteData: Omit<HostedSite, 'id' | 'createdAt' | 'updatedAt' | 'visitsCount' | 'bandwidthMb'>
  ): Promise<{ success: boolean; site?: HostedSite; message?: string }> {
    return this.createSiteWithProgressAsync(siteData);
  }

  async createSiteWithProgressAsync(
    siteData: Omit<HostedSite, 'id' | 'createdAt' | 'updatedAt' | 'visitsCount' | 'bandwidthMb'>,
    onProgress?: (pct: number, stageMessage?: string) => void
  ): Promise<{ success: boolean; site?: HostedSite; message?: string }> {
    onProgress?.(10, 'প্রজেক্ট ফাইল বান্ডল ও অটো-রিপেয়ার যাচাই হচ্ছে...');
    if (!this.isBrowser() || typeof XMLHttpRequest === 'undefined') {
      try {
        const res = await fetch('/api/sites', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(siteData),
        });
        const data = await res.json();
        if (data.success && data.site) {
          onProgress?.(100, 'সফলভাবে লাইভ হয়েছে!');
          this.applyServerPayload(data);
          return { success: true, site: data.site };
        }
        return { success: false, message: data.message || 'ডিপ্লয় করতে সমস্যা হয়েছে।' };
      } catch {
        const localSite = this.createSite(siteData);
        onProgress?.(100, 'সফলভাবে লাইভ হয়েছে!');
        return { success: true, site: localSite };
      }
    }

    return new Promise((resolve) => {
      let trickleTimer: ReturnType<typeof setInterval> | null = null;
      const stopTrickle = () => {
        if (trickleTimer) {
          clearInterval(trickleTimer);
          trickleTimer = null;
        }
      };

      try {
        const payload = JSON.stringify(siteData);
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/sites', true);
        xhr.setRequestHeader('Content-Type', 'application/json');

        let currentPct = 14;
        onProgress?.(currentPct, 'প্রজেক্ট প্যাকেজ সার্ভারে পাঠানো হচ্ছে...');

        xhr.upload.onprogress = (ev) => {
          if (ev.lengthComputable && ev.total > 0) {
            const ratio = Math.min(1, ev.loaded / ev.total);
            currentPct = Math.max(currentPct, Math.round(14 + ratio * 68));
            onProgress?.(
              currentPct,
              ratio >= 1
                ? 'ফাইল আপলোড সম্পন্ন, অটো-রিপেয়ার ও রানটাইম কনফিগার হচ্ছে...'
                : `ফাইল আপলোড হচ্ছে (${Math.round(ratio * 100)}%)...`
            );
          }
        };

        xhr.upload.onload = () => {
          currentPct = Math.max(currentPct, 85);
          onProgress?.(currentPct, 'সার্ভারে প্রজেক্ট সেভ, মিসিং ফাইল রিপেয়ার ও পোর্ট চালু হচ্ছে...');
          trickleTimer = setInterval(() => {
            if (currentPct < 99) {
              currentPct = Math.min(99, currentPct + 1);
              onProgress?.(currentPct, 'এজ গেটওয়ে ও রানটাইম হেলথ চূড়ান্ত করা হচ্ছে...');
            }
          }, 220);
        };

        xhr.timeout = 120000;

        xhr.onreadystatechange = () => {
          if (xhr.readyState !== 4) return;
          stopTrickle();
          const rawText = xhr.responseText || '';
          try {
            const data = JSON.parse(rawText || '{}');
            if (xhr.status >= 200 && xhr.status < 300 && data.success && data.site) {
              onProgress?.(100, 'ডিপ্লয়মেন্ট ১০০% সম্পন্ন! লাইভ হচ্ছে...');
              this.applyServerPayload(data);
              resolve({ success: true, site: data.site });
            } else {
              resolve({
                success: false,
                message:
                  data.message ||
                  (xhr.status >= 400
                    ? formatHttpTransportError(xhr.status, rawText)
                    : 'ডিপ্লয় করতে সমস্যা হয়েছে।'),
              });
            }
          } catch {
            resolve({
              success: false,
              message: formatHttpTransportError(xhr.status, rawText),
            });
          }
        };

        xhr.ontimeout = () => {
          stopTrickle();
          resolve({
            success: false,
            message: formatHttpTransportError(504, 'timeout'),
          });
        };

        xhr.onerror = () => {
          stopTrickle();
          resolve({
            success: false,
            message: formatHttpTransportError(xhr.status || 0, xhr.responseText || ''),
          });
        };

        xhr.send(payload);
      } catch {
        stopTrickle();
        const localSite = this.createSite(siteData);
        onProgress?.(100, 'ডিপ্লয়মেন্ট সম্পন্ন!');
        resolve({ success: true, site: localSite });
      }
    });
  }

  async updateSiteSlugAsync(
    siteId: string,
    newSlug: string
  ): Promise<{ success: boolean; message: string }> {
    const cleanSlug = newSlug.trim().toLowerCase().replace(/[^\w-]/g, '-');
    if (!cleanSlug) {
      return { success: false, message: 'স্লাগ খালি হতে পারবে না।' };
    }
    if (this.isSlugTaken(cleanSlug, siteId)) {
      return { success: false, message: `স্লাগ '${cleanSlug}' ইতিমধ্যে অন্য সাইটে ব্যবহৃত।` };
    }

    if (!this.isBrowser()) {
      return this.updateSiteSlug(siteId, cleanSlug);
    }

    try {
      const res = await fetch(`/api/sites/${encodeURIComponent(siteId)}/slug`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newSlug: cleanSlug }),
      });
      const data = await res.json();
      if (res.ok && data?.success) {
        this.applyServerPayload(data);
        return {
          success: true,
          message: data.message || `লিংক সফলভাবে পরিবর্তন করা হয়েছে: /site/${cleanSlug}`,
        };
      }
      return {
        success: false,
        message: data?.message || 'লিংক পরিবর্তন করা যায়নি।',
      };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  updateSiteSlug(siteId: string, newSlug: string): { success: boolean; message: string } {
    const cleanSlug = newSlug.trim().toLowerCase().replace(/[^\w-]/g, '-');
    if (!cleanSlug) {
      return { success: false, message: 'স্লাগ খালি হতে পারবে না।' };
    }

    if (this.isSlugTaken(cleanSlug, siteId)) {
      return { success: false, message: `স্লাগ '${cleanSlug}' ইতিমধ্যে অন্য সাইটে ব্যবহৃত।` };
    }

    const site = this.sites.find(s => s.id === siteId);
    if (!site) return { success: false, message: 'সাইট খুঁজে পাওয়া যায়নি।' };

    site.slug = cleanSlug;
    site.customPath = cleanSlug;
    site.updatedAt = new Date().toISOString();
    this.saveSites();
    this.notify();

    if (this.isBrowser()) {
      fetch(`/api/sites/${encodeURIComponent(siteId)}/slug`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newSlug: cleanSlug }),
      })
        .then(r => r.json())
        .then(d => d.success && this.applyServerPayload(d))
        .catch(() => {});
    }

    return { success: true, message: `লিংক সফলভাবে পরিবর্তন করা হয়েছে: /site/${cleanSlug}` };
  }

  async updateSiteDomainAsync(
    siteId: string,
    customDomain: string
  ): Promise<{ success: boolean; site?: HostedSite; message: string }> {
    const raw = customDomain.trim();
    const normalized = raw ? normalizeCustomDomain(raw) : '';
    if (raw && !normalized) {
      return { success: false, message: 'সঠিক ডোমেইন নাম দিন (যেমন: myapp.nighthost.app)।' };
    }
    if (normalized && this.isDomainTaken(normalized, siteId)) {
      return { success: false, message: `ডোমেইন '${normalized}' ইতিমধ্যে অন্য সাইটে ব্যবহৃত।` };
    }

    const site = this.sites.find(s => s.id === siteId);
    if (!site) return { success: false, message: 'সাইট খুঁজে পাওয়া যায়নি।' };

    if (!this.isBrowser()) {
      site.customDomain = normalized || undefined;
      site.updatedAt = new Date().toISOString();
      this.saveSites();
      this.notify();
      return {
        success: true,
        site,
        message: normalized ? `ডোমেইন সংযুক্ত: /d/${normalized}` : 'কাস্টম ডোমেইন সরানো হয়েছে।',
      };
    }

    try {
      const res = await fetch(`/api/sites/${encodeURIComponent(siteId)}/domain`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customDomain: normalized }),
      });
      const data = await res.json();
      if (data.success) {
        this.applyServerPayload(data);
        return {
          success: true,
          site: data.site,
          message: normalized ? `ডোমেইন সেট হয়েছে: /d/${normalized}` : 'কাস্টম ডোমেইন সরানো হয়েছে।',
        };
      }
      return { success: false, message: data.message || 'ডোমেইন আপডেট করা যায়নি।' };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async fetchSiteFileContentAsync(
    siteId: string,
    filePath: string
  ): Promise<{ success: boolean; file?: SiteFile; message?: string }> {
    try {
      const res = await fetch(
        `/api/sites/${encodeURIComponent(siteId)}/file?path=${encodeURIComponent(filePath)}`,
        { cache: 'no-store' }
      );
      const rawText = await res.text();
      let data: { success?: boolean; file?: SiteFile; message?: string } = {};
      try {
        data = JSON.parse(rawText || '{}');
      } catch {
        return { success: false, message: formatHttpTransportError(res.status, rawText) };
      }
      if (data.success && data.file) {
        return { success: true, file: data.file };
      }
      return {
        success: false,
        message: data.message || (res.status >= 400 ? formatHttpTransportError(res.status, rawText) : 'ফাইল লোড করা যায়নি।'),
      };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  async updateSiteFileAsync(
    siteId: string,
    filePath: string,
    content: string
  ): Promise<{ success: boolean; site?: HostedSite; message?: string }> {
    try {
      const res = await fetch(`/api/sites/${encodeURIComponent(siteId)}/files`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filePath,
          content,
          actor: this.currentUser?.username || 'user',
        }),
      });
      const rawText = await res.text();
      let data: {
        success?: boolean;
        site?: HostedSite;
        sites?: HostedSite[];
        config?: PlatformConfig;
        message?: string;
      } = {};
      try {
        data = JSON.parse(rawText || '{}');
      } catch {
        return { success: false, message: formatHttpTransportError(res.status, rawText) };
      }
      if (data.success && data.site) {
        this.applyServerPayload(data);
        return { success: true, site: data.site };
      }
      return {
        success: false,
        message: data.message || (res.status >= 400 ? formatHttpTransportError(res.status, rawText) : 'ফাইল সেভ করতে সমস্যা হয়েছে।'),
      };
    } catch {
      return { success: false, message: 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে।' };
    }
  }

  deleteSite(siteId: string): boolean {
    const target = this.sites.find(s => s.id === siteId);
    if (!target) return false;

    this.sites = this.sites.filter(s => s.id !== siteId);
    this.saveSites();
    this.recalculateLocalUserStorageMb(target.userId);
    this.notify();

    if (this.isBrowser()) {
      fetch(`/api/sites/${encodeURIComponent(siteId)}`, { method: 'DELETE' })
        .then(r => r.json())
        .then(d => d.success && this.applyServerPayload(d))
        .catch(() => {});
    }
    return true;
  }

  toggleSiteStatus(siteId: string): boolean {
    const site = this.sites.find(s => s.id === siteId);
    if (!site) return false;
    site.status = site.status === 'online' ? 'paused' : 'online';
    site.updatedAt = new Date().toISOString();
    this.saveSites();
    this.notify();

    if (this.isBrowser()) {
      fetch(`/api/sites/${encodeURIComponent(siteId)}/toggle`, { method: 'POST' })
        .then(r => r.json())
        .then(d => d.success && this.applyServerPayload(d))
        .catch(() => {});
    }
    return true;
  }
}

export const storage = new StorageService();
