import fs from 'fs';
import path from 'path';
import net from 'net';
import dns from 'dns/promises';
import crypto from 'crypto';
import { SiteFile } from '../types';

export interface PhpRequestContext {
  method: string;
  path: string;
  queryString: string;
  get: Record<string, any>;
  post: Record<string, any>;
  rawBody: string;
  headers: Record<string, string>;
  cookies: Record<string, string>;
  remoteAddr: string;
  host: string;
  scheme: string;
  scriptName: string;
  siteDir: string;
  siteFiles?: Record<string, SiteFile>;
  siteName?: string;
}

export interface PhpExecutionResult {
  statusCode: number;
  headers: Record<string, string>;
  cookies: string[];
  body: string;
  contentType: string;
  error?: string;
}

class PhpReturnSignal {
  constructor(public value: any) {}
}
class PhpBreakSignal {
  constructor(public levels = 1) {}
}
class PhpContinueSignal {
  constructor(public levels = 1) {}
}
class PhpExitSignal {
  constructor(public code = 0) {}
}
class PhpThrownError {
  constructor(public message: string, public code = 0) {}
}

type TokenType =
  | 'html'
  | 'short_echo'
  | 'var'
  | 'ident'
  | 'number'
  | 'string'
  | 'op'
  | 'punct'
  | 'eof';

interface Token {
  type: TokenType;
  value: string;
  raw?: string;
  doubleQuoted?: boolean;
  line: number;
}

type PhpArray = {
  __isPhpArr: true;
  map: Map<string | number, any>;
  nextIndex: number;
};

function isPhpArray(v: any): v is PhpArray {
  return Boolean(v && typeof v === 'object' && v.__isPhpArr === true);
}

function makePhpArray(entries?: Array<[string | number | null, any]>): PhpArray {
  const arr: PhpArray = { __isPhpArr: true, map: new Map(), nextIndex: 0 };
  if (entries) {
    for (const [k, v] of entries) {
      setPhpArray(arr, k, v);
    }
  }
  return arr;
}

function setPhpArray(arr: PhpArray, key: string | number | null | undefined, val: any) {
  if (key === null || key === undefined) {
    arr.map.set(arr.nextIndex, val);
    arr.nextIndex++;
    return;
  }
  const numKey = typeof key === 'number' ? key : /^-?\d+$/.test(String(key)) ? Number(key) : null;
  if (numKey !== null && Number.isSafeInteger(numKey)) {
    arr.map.set(numKey, val);
    if (numKey >= arr.nextIndex) arr.nextIndex = numKey + 1;
  } else {
    arr.map.set(String(key), val);
  }
}

function getPhpArray(arr: PhpArray, key: string | number): any {
  if (arr.map.has(key)) return arr.map.get(key);
  const numKey = typeof key === 'number' ? key : /^-?\d+$/.test(String(key)) ? Number(key) : null;
  if (numKey !== null && arr.map.has(numKey)) return arr.map.get(numKey);
  if (arr.map.has(String(key))) return arr.map.get(String(key));
  return undefined;
}

function jsToPhpValue(v: any): any {
  if (v === null || v === undefined) return null;
  if (isPhpArray(v)) return v;
  if (Array.isArray(v)) {
    const arr = makePhpArray();
    for (const item of v) {
      setPhpArray(arr, null, jsToPhpValue(item));
    }
    return arr;
  }
  if (typeof v === 'object') {
    const arr = makePhpArray();
    for (const [k, val] of Object.entries(v)) {
      setPhpArray(arr, k, jsToPhpValue(val));
    }
    return arr;
  }
  return v;
}

function phpToJsPlain(v: any): any {
  if (isPhpArray(v)) {
    let isList = true;
    let idx = 0;
    for (const k of v.map.keys()) {
      if (k !== idx) {
        isList = false;
        break;
      }
      idx++;
    }
    if (isList) {
      return Array.from(v.map.values()).map(phpToJsPlain);
    }
    const obj: Record<string, any> = {};
    for (const [k, val] of v.map.entries()) {
      obj[String(k)] = phpToJsPlain(val);
    }
    return obj;
  }
  if (typeof v === 'function') return {};
  return v;
}

function phpTruthy(v: any): boolean {
  if (v === null || v === undefined || v === false || v === 0 || v === '' || v === '0') return false;
  if (isPhpArray(v)) return v.map.size > 0;
  return Boolean(v);
}

function phpToString(v: any): string {
  if (v === null || v === undefined || v === false) return '';
  if (v === true) return '1';
  if (isPhpArray(v)) return 'Array';
  if (typeof v === 'object') {
    if (typeof v.message === 'string') return v.message;
    return 'Object';
  }
  return String(v);
}

function phpToNumber(v: any): number {
  if (typeof v === 'number') return Number.isFinite(v) ? v : 0;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (v === null || v === undefined) return 0;
  if (isPhpArray(v)) return v.map.size > 0 ? 1 : 0;
  const s = String(v).trim();
  const m = s.match(/^[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?/);
  return m ? Number(m[0]) : 0;
}

function phpLooseEqual(a: any, b: any): boolean {
  if (a === b) return true;
  if ((a === null || a === undefined) && (b === null || b === undefined)) return true;
  if (typeof a === 'boolean' || typeof b === 'boolean') return phpTruthy(a) === phpTruthy(b);
  if (typeof a === 'number' || typeof b === 'number') return phpToNumber(a) === phpToNumber(b);
  if (typeof a === 'string' && typeof b === 'string') {
    if (/^-?\d+(\.\d+)?$/.test(a.trim()) && /^-?\d+(\.\d+)?$/.test(b.trim())) {
      return Number(a) === Number(b);
    }
    return a === b;
  }
  return phpToString(a) === phpToString(b);
}

// =========================================================================
// LEXER (Quote-aware across mixed HTML & PHP blocks)
// =========================================================================
function tokenizePhp(src: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  let line = 1;
  const n = src.length;

  const advance = (count = 1) => {
    for (let k = 0; k < count && i < n; k++) {
      if (src[i] === '\n') line++;
      i++;
    }
  };

  while (i < n) {
    // HTML outside PHP tags
    let nextOpen = src.indexOf('<?', i);
    if (nextOpen === -1) {
      const htmlChunk = src.slice(i);
      if (htmlChunk) tokens.push({ type: 'html', value: htmlChunk, line });
      break;
    }
    if (nextOpen > i) {
      const htmlChunk = src.slice(i, nextOpen);
      tokens.push({ type: 'html', value: htmlChunk, line });
      advance(nextOpen - i);
    }

    // Consume opening tag
    let isShortEcho = false;
    if (src.slice(i, i + 5).toLowerCase() === '<?php') {
      advance(5);
    } else if (src.slice(i, i + 3) === '<?=') {
      advance(3);
      isShortEcho = true;
      tokens.push({ type: 'short_echo', value: '<?=', line });
    } else {
      advance(2);
    }

    // Tokenize PHP mode until matching ?>
    while (i < n) {
      const ch = src[i];

      // Whitespace
      if (/\s/.test(ch)) {
        advance(1);
        continue;
      }

      // Close PHP tag
      if (ch === '?' && src[i + 1] === '>') {
        advance(2);
        // Per PHP spec, a single newline immediately following closing tag is consumed
        if (src[i] === '\r' && src[i + 1] === '\n') advance(2);
        else if (src[i] === '\n') advance(1);
        if (isShortEcho) {
          tokens.push({ type: 'punct', value: ';', line });
        }
        break;
      }

      // Line comments // or #
      if ((ch === '/' && src[i + 1] === '/') || ch === '#') {
        while (i < n && src[i] !== '\n') {
          if (src[i] === '?' && src[i + 1] === '>') break;
          advance(1);
        }
        continue;
      }

      // Block comment /* ... */
      if (ch === '/' && src[i + 1] === '*') {
        advance(2);
        while (i < n && !(src[i] === '*' && src[i + 1] === '/')) {
          advance(1);
        }
        if (i < n) advance(2);
        continue;
      }

      // Heredoc / Nowdoc <<<EOF or <<<'EOF' or <<<"EOF"
      if (ch === '<' && src[i + 1] === '<' && src[i + 2] === '<') {
        const startLine = line;
        let j = i + 3;
        while (j < n && (src[j] === ' ' || src[j] === '\t')) j++;
        let quoteChar = '';
        if (src[j] === "'" || src[j] === '"') {
          quoteChar = src[j];
          j++;
        }
        let labelStart = j;
        while (j < n && /[a-zA-Z0-9_]/.test(src[j])) j++;
        const label = src.slice(labelStart, j);
        if (quoteChar && src[j] === quoteChar) j++;
        if (label && (src[j] === '\n' || (src[j] === '\r' && src[j + 1] === '\n'))) {
          advance(j - i);
          if (src[i] === '\r') advance(2);
          else advance(1);
          let body = '';
          while (i < n) {
            const nlIdx = src.indexOf('\n', i);
            const rawLine = nlIdx === -1 ? src.slice(i) : src.slice(i, nlIdx);
            const cleanLine = rawLine.replace(/\r$/, '');
            const trimmedLine = cleanLine.trim();
            if (trimmedLine === label || trimmedLine === `${label};`) {
              advance(label.length);
              // Leave ';' if present
              while (i < n && src[i] !== ';' && src[i] !== '\n') advance(1);
              break;
            }
            body += (nlIdx === -1 ? rawLine : src.slice(i, nlIdx + 1));
            advance(nlIdx === -1 ? rawLine.length : nlIdx + 1 - i);
          }
          tokens.push({
            type: 'string',
            value: body.replace(/\r?\n$/, ''),
            doubleQuoted: quoteChar !== "'",
            line: startLine,
          });
          continue;
        }
      }

      // String literal '...' or "..."
      if (ch === "'" || ch === '"') {
        const q = ch;
        const startLine = line;
        advance(1);
        let strVal = '';
        while (i < n && src[i] !== q) {
          if (src[i] === '\\' && i + 1 < n) {
            const nxt = src[i + 1];
            if (q === "'") {
              if (nxt === "'" || nxt === '\\') {
                strVal += nxt;
                advance(2);
              } else {
                strVal += '\\';
                advance(1);
              }
            } else {
              if (nxt === 'n') strVal += '\n';
              else if (nxt === 'r') strVal += '\r';
              else if (nxt === 't') strVal += '\t';
              else if (nxt === '\\') strVal += '\\';
              else if (nxt === '"') strVal += '"';
              else if (nxt === '$') strVal += '\\$'; // keep escaped $ distinct
              else strVal += '\\' + nxt;
              advance(2);
            }
          } else {
            strVal += src[i];
            advance(1);
          }
        }
        if (i < n && src[i] === q) advance(1);
        tokens.push({
          type: 'string',
          value: strVal,
          doubleQuoted: q === '"',
          line: startLine,
        });
        continue;
      }

      // Variable $name
      if (ch === '$' && i + 1 < n && /[a-zA-Z_]/.test(src[i + 1])) {
        const startLine = line;
        advance(1);
        let name = '';
        while (i < n && /[a-zA-Z0-9_]/.test(src[i])) {
          name += src[i];
          advance(1);
        }
        tokens.push({ type: 'var', value: name, line: startLine });
        continue;
      }

      // Number
      if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(src[i + 1] || ''))) {
        const startLine = line;
        const rest = src.slice(i);
        const m = rest.match(/^(?:0x[0-9a-fA-F_]+|0b[01_]+|(?:\d[\d_]*\.?[\d_]*|\.\d[\d_]*)(?:[eE][+-]?\d+)?)/);
        if (m) {
          const numStr = m[0].replace(/_/g, '');
          advance(m[0].length);
          tokens.push({ type: 'number', value: numStr, line: startLine });
          continue;
        }
      }

      // Identifiers & Keywords
      if (/[a-zA-Z_\x80-\xff]/.test(ch)) {
        const startLine = line;
        let id = '';
        while (i < n && /[a-zA-Z0-9_\x80-\xff]/.test(src[i])) {
          id += src[i];
          advance(1);
        }
        tokens.push({ type: 'ident', value: id, line: startLine });
        continue;
      }

      // Multi-char operators
      const three = src.slice(i, i + 3);
      if (['===', '!==', '<=>', '??=', '...'].includes(three)) {
        tokens.push({ type: 'op', value: three, line });
        advance(3);
        continue;
      }

      const two = src.slice(i, i + 2);
      if (
        [
          '==',
          '!=',
          '<>',
          '<=',
          '>=',
          '&&',
          '||',
          '??',
          '?:',
          '=>',
          '->',
          '::',
          '++',
          '--',
          '+=',
          '-=',
          '*=',
          '/=',
          '%=',
          '.=',
          '**',
          '<<',
          '>>',
        ].includes(two)
      ) {
        tokens.push({ type: 'op', value: two, line });
        advance(2);
        continue;
      }

      // Single-char operators & punctuation
      if ('+-*/%.=<>!&|^~?:@'.includes(ch)) {
        tokens.push({ type: 'op', value: ch, line });
        advance(1);
        continue;
      }

      if ('(){}[];,$\\'.includes(ch)) {
        tokens.push({ type: 'punct', value: ch, line });
        advance(1);
        continue;
      }

      // Skip unknown char safely
      advance(1);
    }
  }

  tokens.push({ type: 'eof', value: '', line });
  return tokens;
}

// =========================================================================
// AST NODES
// =========================================================================
type Stmt =
  | { kind: 'html'; text: string }
  | { kind: 'block'; stmts: Stmt[] }
  | { kind: 'expr'; expr: Expr }
  | { kind: 'echo'; exprs: Expr[] }
  | { kind: 'return'; expr?: Expr }
  | { kind: 'break'; levels: number }
  | { kind: 'continue'; levels: number }
  | { kind: 'exit'; expr?: Expr }
  | { kind: 'global'; vars: string[] }
  | { kind: 'unset'; targets: Expr[] }
  | { kind: 'if'; branches: { cond: Expr; body: Stmt[] }[]; elseBody?: Stmt[] }
  | { kind: 'while'; cond: Expr; body: Stmt[] }
  | { kind: 'doWhile'; body: Stmt[]; cond: Expr }
  | { kind: 'for'; init: Expr[]; cond: Expr[]; step: Expr[]; body: Stmt[] }
  | { kind: 'foreach'; source: Expr; keyVar?: string; valVar: string; body: Stmt[] }
  | { kind: 'switch'; expr: Expr; cases: { test?: Expr; body: Stmt[] }[] }
  | { kind: 'try'; body: Stmt[]; catches: { varName?: string; body: Stmt[] }[]; finallyBody?: Stmt[] }
  | { kind: 'throw'; expr: Expr }
  | { kind: 'funcDecl'; name: string; params: ParamDef[]; body: Stmt[] }
  | { kind: 'include'; expr: Expr; once: boolean };

interface ParamDef {
  name: string;
  defaultExpr?: Expr;
}

type Expr =
  | { kind: 'lit'; value: any }
  | { kind: 'dstring'; value: string }
  | { kind: 'var'; name: string }
  | { kind: 'ident'; name: string }
  | { kind: 'array'; items: { key?: Expr; val: Expr }[] }
  | { kind: 'index'; target: Expr; index?: Expr }
  | { kind: 'prop'; target: Expr; prop: string }
  | { kind: 'assign'; target: Expr; op: string; val: Expr }
  | { kind: 'unary'; op: string; expr: Expr; postfix?: boolean }
  | { kind: 'binary'; op: string; left: Expr; right: Expr }
  | { kind: 'ternary'; cond: Expr; ifTrue?: Expr; ifFalse: Expr }
  | { kind: 'call'; callee: Expr; args: Expr[] }
  | { kind: 'closure'; params: ParamDef[]; uses: string[]; body: Stmt[]; arrowExpr?: Expr }
  | { kind: 'cast'; toType: string; expr: Expr }
  | { kind: 'isset'; targets: Expr[] }
  | { kind: 'empty'; target: Expr }
  | { kind: 'includeExpr'; expr: Expr; once: boolean }
  | { kind: 'suppress'; expr: Expr };

// =========================================================================
// RECURSIVE-DESCENT PARSER
// =========================================================================
class PhpParser {
  private pos = 0;

  constructor(private tokens: Token[]) {}

  private peek(offset = 0): Token {
    return this.tokens[this.pos + offset] || this.tokens[this.tokens.length - 1];
  }

  private next(): Token {
    const t = this.peek();
    if (t.type !== 'eof') this.pos++;
    return t;
  }

  private match(type: TokenType, value?: string): boolean {
    const t = this.peek();
    if (t.type !== type) return false;
    if (value !== undefined && t.value !== value) return false;
    this.next();
    return true;
  }

  private matchKeyword(kw: string): boolean {
    const t = this.peek();
    if (t.type === 'ident' && t.value.toLowerCase() === kw.toLowerCase()) {
      this.next();
      return true;
    }
    return false;
  }

  private isKeyword(kw: string, offset = 0): boolean {
    const t = this.peek(offset);
    return t.type === 'ident' && t.value.toLowerCase() === kw.toLowerCase();
  }

  private consumeSemi() {
    while (this.match('punct', ';')) {
      // consume extra semicolons
    }
  }

  parseProgram(): Stmt[] {
    const stmts: Stmt[] = [];
    while (this.peek().type !== 'eof') {
      const s = this.parseStatement();
      if (s) stmts.push(s);
    }
    return stmts;
  }

  private parseStatementListUntil(stopKeywords: string[]): Stmt[] {
    const stmts: Stmt[] = [];
    while (this.peek().type !== 'eof') {
      if (stopKeywords.some(k => this.isKeyword(k))) break;
      const s = this.parseStatement();
      if (s) stmts.push(s);
    }
    return stmts;
  }

  private parseBlockOrSingle(): Stmt[] {
    if (this.match('punct', '{')) {
      const stmts: Stmt[] = [];
      while (this.peek().type !== 'eof' && !this.match('punct', '}')) {
        const s = this.parseStatement();
        if (s) stmts.push(s);
      }
      return stmts;
    }
    const single = this.parseStatement();
    return single ? [single] : [];
  }

  private parseStatement(): Stmt | null {
    const t = this.peek();
    if (t.type === 'eof') return null;

    if (t.type === 'html') {
      this.next();
      return { kind: 'html', text: t.value };
    }

    if (t.type === 'short_echo') {
      this.next();
      const exprs: Expr[] = [this.parseExpression()];
      while (this.match('punct', ',')) {
        exprs.push(this.parseExpression());
      }
      this.consumeSemi();
      return { kind: 'echo', exprs };
    }

    if (this.match('punct', ';')) {
      return null;
    }

    if (t.type === 'punct' && t.value === '{') {
      return { kind: 'block', stmts: this.parseBlockOrSingle() };
    }

    if (this.isKeyword('echo') || this.isKeyword('print')) {
      this.next();
      const exprs: Expr[] = [];
      if (this.peek().type !== 'punct' || this.peek().value !== ';') {
        exprs.push(this.parseExpression());
        while (this.match('punct', ',')) {
          exprs.push(this.parseExpression());
        }
      }
      this.consumeSemi();
      return { kind: 'echo', exprs };
    }

    if (this.matchKeyword('if')) {
      return this.parseIf();
    }

    if (this.matchKeyword('while')) {
      this.match('punct', '(');
      const cond = this.parseExpression();
      this.match('punct', ')');
      if (this.match('op', ':')) {
        const body = this.parseStatementListUntil(['endwhile']);
        this.matchKeyword('endwhile');
        this.consumeSemi();
        return { kind: 'while', cond, body };
      }
      return { kind: 'while', cond, body: this.parseBlockOrSingle() };
    }

    if (this.matchKeyword('do')) {
      const body = this.parseBlockOrSingle();
      this.matchKeyword('while');
      this.match('punct', '(');
      const cond = this.parseExpression();
      this.match('punct', ')');
      this.consumeSemi();
      return { kind: 'doWhile', body, cond };
    }

    if (this.matchKeyword('for')) {
      this.match('punct', '(');
      const init: Expr[] = [];
      if (!this.match('punct', ';')) {
        init.push(this.parseExpression());
        while (this.match('punct', ',')) init.push(this.parseExpression());
        this.match('punct', ';');
      }
      const cond: Expr[] = [];
      if (!this.match('punct', ';')) {
        cond.push(this.parseExpression());
        while (this.match('punct', ',')) cond.push(this.parseExpression());
        this.match('punct', ';');
      }
      const step: Expr[] = [];
      if (!this.match('punct', ')')) {
        step.push(this.parseExpression());
        while (this.match('punct', ',')) step.push(this.parseExpression());
        this.match('punct', ')');
      }
      if (this.match('op', ':')) {
        const body = this.parseStatementListUntil(['endfor']);
        this.matchKeyword('endfor');
        this.consumeSemi();
        return { kind: 'for', init, cond, step, body };
      }
      return { kind: 'for', init, cond, step, body: this.parseBlockOrSingle() };
    }

    if (this.matchKeyword('foreach')) {
      this.match('punct', '(');
      const source = this.parseExpression();
      this.matchKeyword('as');
      let keyVar: string | undefined;
      let valVar = '_item';
      if (this.peek().type === 'var') {
        const firstVar = this.next().value;
        if (this.match('op', '=>')) {
          keyVar = firstVar;
          if (this.peek().type === 'var') valVar = this.next().value;
        } else {
          valVar = firstVar;
        }
      } else {
        // Fallback consume until ')'
        while (this.peek().type !== 'eof' && this.peek().value !== ')') this.next();
      }
      this.match('punct', ')');
      if (this.match('op', ':')) {
        const body = this.parseStatementListUntil(['endforeach']);
        this.matchKeyword('endforeach');
        this.consumeSemi();
        return { kind: 'foreach', source, keyVar, valVar, body };
      }
      return { kind: 'foreach', source, keyVar, valVar, body: this.parseBlockOrSingle() };
    }

    if (this.matchKeyword('switch')) {
      this.match('punct', '(');
      const expr = this.parseExpression();
      this.match('punct', ')');
      const altSyntax = this.match('op', ':');
      if (!altSyntax) this.match('punct', '{');
      const cases: { test?: Expr; body: Stmt[] }[] = [];
      while (this.peek().type !== 'eof') {
        if (altSyntax ? this.isKeyword('endswitch') : this.peek().value === '}') {
          if (altSyntax) {
            this.next();
            this.consumeSemi();
          } else {
            this.next();
          }
          break;
        }
        if (this.matchKeyword('case')) {
          const test = this.parseExpression();
          this.match('op', ':') || this.match('punct', ';');
          const body = this.parseSwitchCaseBody(altSyntax);
          cases.push({ test, body });
        } else if (this.matchKeyword('default')) {
          this.match('op', ':') || this.match('punct', ';');
          const body = this.parseSwitchCaseBody(altSyntax);
          cases.push({ body });
        } else {
          this.next();
        }
      }
      return { kind: 'switch', expr, cases };
    }

    if (this.matchKeyword('function')) {
      if (this.peek().type === 'ident') {
        const name = this.next().value;
        const params = this.parseParams();
        // Optional return type ': ?string'
        if (this.match('op', ':')) {
          this.match('op', '?');
          if (this.peek().type === 'ident') this.next();
        }
        const body = this.parseBlockOrSingle();
        return { kind: 'funcDecl', name, params, body };
      }
      // Anonymous function expression used as statement
      this.pos--;
    }

    if (this.matchKeyword('return')) {
      let expr: Expr | undefined;
      if (this.peek().type !== 'punct' || this.peek().value !== ';') {
        expr = this.parseExpression();
      }
      this.consumeSemi();
      return { kind: 'return', expr };
    }

    if (this.matchKeyword('break')) {
      let levels = 1;
      if (this.peek().type === 'number') levels = Math.max(1, Number(this.next().value) || 1);
      this.consumeSemi();
      return { kind: 'break', levels };
    }

    if (this.matchKeyword('continue')) {
      let levels = 1;
      if (this.peek().type === 'number') levels = Math.max(1, Number(this.next().value) || 1);
      this.consumeSemi();
      return { kind: 'continue', levels };
    }

    if (this.matchKeyword('exit') || this.matchKeyword('die')) {
      let expr: Expr | undefined;
      if (this.match('punct', '(')) {
        if (!this.match('punct', ')')) {
          expr = this.parseExpression();
          this.match('punct', ')');
        }
      }
      this.consumeSemi();
      return { kind: 'exit', expr };
    }

    if (this.matchKeyword('global')) {
      const vars: string[] = [];
      while (this.peek().type === 'var') {
        vars.push(this.next().value);
        if (!this.match('punct', ',')) break;
      }
      this.consumeSemi();
      return { kind: 'global', vars };
    }

    if (this.matchKeyword('unset')) {
      const targets: Expr[] = [];
      this.match('punct', '(');
      if (!this.match('punct', ')')) {
        targets.push(this.parseExpression());
        while (this.match('punct', ',')) targets.push(this.parseExpression());
        this.match('punct', ')');
      }
      this.consumeSemi();
      return { kind: 'unset', targets };
    }

    if (this.matchKeyword('try')) {
      const body = this.parseBlockOrSingle();
      const catches: { varName?: string; body: Stmt[] }[] = [];
      let finallyBody: Stmt[] | undefined;
      while (this.matchKeyword('catch')) {
        this.match('punct', '(');
        let varName: string | undefined;
        while (this.peek().type !== 'eof' && this.peek().value !== ')') {
          const tk = this.next();
          if (tk.type === 'var') varName = tk.value;
        }
        this.match('punct', ')');
        catches.push({ varName, body: this.parseBlockOrSingle() });
      }
      if (this.matchKeyword('finally')) {
        finallyBody = this.parseBlockOrSingle();
      }
      return { kind: 'try', body, catches, finallyBody };
    }

    if (this.matchKeyword('throw')) {
      const expr = this.parseExpression();
      this.consumeSemi();
      return { kind: 'throw', expr };
    }

    if (
      this.isKeyword('include') ||
      this.isKeyword('include_once') ||
      this.isKeyword('require') ||
      this.isKeyword('require_once')
    ) {
      const kw = this.next().value.toLowerCase();
      const once = kw.endsWith('_once');
      const expr = this.parseExpression();
      this.consumeSemi();
      return { kind: 'include', expr, once };
    }

    // Ignore class / namespace / use definitions gracefully if present
    if (this.matchKeyword('namespace') || this.matchKeyword('use')) {
      while (this.peek().type !== 'eof' && this.peek().value !== ';') this.next();
      this.consumeSemi();
      return null;
    }

    if (this.matchKeyword('const')) {
      if (this.peek().type === 'ident') {
        const cName = this.next().value;
        this.match('op', '=');
        const val = this.parseExpression();
        this.consumeSemi();
        return {
          kind: 'expr',
          expr: {
            kind: 'call',
            callee: { kind: 'ident', name: 'define' },
            args: [{ kind: 'lit', value: cName }, val],
          },
        };
      }
    }

    const expr = this.parseExpression();
    this.consumeSemi();
    return { kind: 'expr', expr };
  }

  private parseSwitchCaseBody(altSyntax: boolean): Stmt[] {
    const stmts: Stmt[] = [];
    while (this.peek().type !== 'eof') {
      if (
        this.isKeyword('case') ||
        this.isKeyword('default') ||
        (altSyntax ? this.isKeyword('endswitch') : this.peek().value === '}')
      ) {
        break;
      }
      const s = this.parseStatement();
      if (s) stmts.push(s);
    }
    return stmts;
  }

  private parseIf(): Stmt {
    this.match('punct', '(');
    const firstCond = this.parseExpression();
    this.match('punct', ')');

    if (this.match('op', ':')) {
      const branches: { cond: Expr; body: Stmt[] }[] = [
        { cond: firstCond, body: this.parseStatementListUntil(['elseif', 'else', 'endif']) },
      ];
      let elseBody: Stmt[] | undefined;
      while (this.matchKeyword('elseif')) {
        this.match('punct', '(');
        const c = this.parseExpression();
        this.match('punct', ')');
        this.match('op', ':');
        branches.push({ cond: c, body: this.parseStatementListUntil(['elseif', 'else', 'endif']) });
      }
      if (this.matchKeyword('else')) {
        this.match('op', ':');
        elseBody = this.parseStatementListUntil(['endif']);
      }
      this.matchKeyword('endif');
      this.consumeSemi();
      return { kind: 'if', branches, elseBody };
    }

    const branches: { cond: Expr; body: Stmt[] }[] = [
      { cond: firstCond, body: this.parseBlockOrSingle() },
    ];
    let elseBody: Stmt[] | undefined;
    while (true) {
      if (this.matchKeyword('elseif')) {
        this.match('punct', '(');
        const c = this.parseExpression();
        this.match('punct', ')');
        branches.push({ cond: c, body: this.parseBlockOrSingle() });
      } else if (this.matchKeyword('else')) {
        if (this.matchKeyword('if')) {
          this.match('punct', '(');
          const c = this.parseExpression();
          this.match('punct', ')');
          branches.push({ cond: c, body: this.parseBlockOrSingle() });
        } else {
          elseBody = this.parseBlockOrSingle();
          break;
        }
      } else {
        break;
      }
    }
    return { kind: 'if', branches, elseBody };
  }

  private parseParams(): ParamDef[] {
    const params: ParamDef[] = [];
    this.match('punct', '(');
    while (this.peek().type !== 'eof' && this.peek().value !== ')') {
      // Skip optional type hint / reference '&'
      while (
        this.peek().type !== 'eof' &&
        this.peek().type !== 'var' &&
        this.peek().value !== ')'
      ) {
        this.next();
      }
      if (this.peek().type === 'var') {
        const name = this.next().value;
        let defaultExpr: Expr | undefined;
        if (this.match('op', '=')) {
          defaultExpr = this.parseTernary();
        }
        params.push({ name, defaultExpr });
      }
      if (!this.match('punct', ',')) break;
    }
    this.match('punct', ')');
    return params;
  }

  private parseExpression(): Expr {
    return this.parseAssign();
  }

  private parseAssign(): Expr {
    const left = this.parseLogicalWordOr();
    const t = this.peek();
    if (
      t.type === 'op' &&
      ['=', '+=', '-=', '*=', '/=', '%=', '.=', '??='].includes(t.value)
    ) {
      const op = this.next().value;
      const val = this.parseAssign();
      return { kind: 'assign', target: left, op, val };
    }
    return left;
  }

  private parseLogicalWordOr(): Expr {
    let left = this.parseLogicalWordXor();
    while (this.isKeyword('or')) {
      this.next();
      const right = this.parseLogicalWordXor();
      left = { kind: 'binary', op: '||', left, right };
    }
    return left;
  }

  private parseLogicalWordXor(): Expr {
    let left = this.parseLogicalWordAnd();
    while (this.isKeyword('xor')) {
      this.next();
      const right = this.parseLogicalWordAnd();
      left = { kind: 'binary', op: 'xor', left, right };
    }
    return left;
  }

  private parseLogicalWordAnd(): Expr {
    let left = this.parseTernary();
    while (this.isKeyword('and')) {
      this.next();
      const right = this.parseTernary();
      left = { kind: 'binary', op: '&&', left, right };
    }
    return left;
  }

  private parseTernary(): Expr {
    let cond = this.parseNullish();
    if (this.match('op', '?:')) {
      const ifFalse = this.parseTernary();
      return { kind: 'ternary', cond, ifFalse };
    }
    if (this.match('op', '?')) {
      const ifTrue = this.parseExpression();
      this.match('op', ':');
      const ifFalse = this.parseTernary();
      return { kind: 'ternary', cond, ifTrue, ifFalse };
    }
    return cond;
  }

  private parseNullish(): Expr {
    let left = this.parseOr();
    while (this.match('op', '??')) {
      const right = this.parseOr();
      left = { kind: 'binary', op: '??', left, right };
    }
    return left;
  }

  private parseOr(): Expr {
    let left = this.parseAnd();
    while (this.match('op', '||')) {
      const right = this.parseAnd();
      left = { kind: 'binary', op: '||', left, right };
    }
    return left;
  }

  private parseAnd(): Expr {
    let left = this.parseBitOr();
    while (this.match('op', '&&')) {
      const right = this.parseBitOr();
      left = { kind: 'binary', op: '&&', left, right };
    }
    return left;
  }

  private parseBitOr(): Expr {
    let left = this.parseBitXor();
    while (this.match('op', '|')) {
      const right = this.parseBitXor();
      left = { kind: 'binary', op: '|', left, right };
    }
    return left;
  }

  private parseBitXor(): Expr {
    let left = this.parseBitAnd();
    while (this.match('op', '^')) {
      const right = this.parseBitAnd();
      left = { kind: 'binary', op: '^', left, right };
    }
    return left;
  }

  private parseBitAnd(): Expr {
    let left = this.parseEquality();
    while (this.match('op', '&')) {
      const right = this.parseEquality();
      left = { kind: 'binary', op: '&', left, right };
    }
    return left;
  }

  private parseEquality(): Expr {
    let left = this.parseComparison();
    while (
      this.peek().type === 'op' &&
      ['==', '===', '!=', '!==', '<>', '<=>'].includes(this.peek().value)
    ) {
      const op = this.next().value;
      const right = this.parseComparison();
      left = { kind: 'binary', op, left, right };
    }
    return left;
  }

  private parseComparison(): Expr {
    let left = this.parseShift();
    while (
      this.peek().type === 'op' &&
      ['<', '<=', '>', '>='].includes(this.peek().value)
    ) {
      const op = this.next().value;
      const right = this.parseShift();
      left = { kind: 'binary', op, left, right };
    }
    return left;
  }

  private parseShift(): Expr {
    let left = this.parseAdditive();
    while (this.peek().type === 'op' && ['<<', '>>'].includes(this.peek().value)) {
      const op = this.next().value;
      const right = this.parseAdditive();
      left = { kind: 'binary', op, left, right };
    }
    return left;
  }

  private parseAdditive(): Expr {
    let left = this.parseMultiplicative();
    while (this.peek().type === 'op' && ['+', '-', '.'].includes(this.peek().value)) {
      const op = this.next().value;
      const right = this.parseMultiplicative();
      left = { kind: 'binary', op, left, right };
    }
    return left;
  }

  private parseMultiplicative(): Expr {
    let left = this.parseUnary();
    while (this.peek().type === 'op' && ['*', '/', '%', '**'].includes(this.peek().value)) {
      const op = this.next().value;
      const right = this.parseUnary();
      left = { kind: 'binary', op, left, right };
    }
    return left;
  }

  private parseUnary(): Expr {
    if (this.match('op', '@')) {
      return { kind: 'suppress', expr: this.parseUnary() };
    }
    if (this.peek().type === 'op' && ['!', '+', '-', '~', '++', '--'].includes(this.peek().value)) {
      const op = this.next().value;
      return { kind: 'unary', op, expr: this.parseUnary(), postfix: false };
    }
    // Cast check: (int), (string), (float), (bool), (array)
    if (
      this.peek().type === 'punct' &&
      this.peek().value === '(' &&
      this.peek(1).type === 'ident' &&
      this.peek(2).type === 'punct' &&
      this.peek(2).value === ')' &&
      ['int', 'integer', 'float', 'double', 'string', 'bool', 'boolean', 'array', 'object'].includes(
        this.peek(1).value.toLowerCase()
      )
    ) {
      this.next();
      const toType = this.next().value.toLowerCase();
      this.next();
      return { kind: 'cast', toType, expr: this.parseUnary() };
    }
    return this.parsePostfix();
  }

  private parsePostfix(): Expr {
    let expr = this.parsePrimary();
    while (true) {
      if (this.match('punct', '(')) {
        const args: Expr[] = [];
        while (this.peek().type !== 'eof' && this.peek().value !== ')') {
          args.push(this.parseExpression());
          if (!this.match('punct', ',')) break;
        }
        this.match('punct', ')');
        expr = { kind: 'call', callee: expr, args };
      } else if (this.match('punct', '[')) {
        if (this.match('punct', ']')) {
          expr = { kind: 'index', target: expr, index: undefined };
        } else {
          const index = this.parseExpression();
          this.match('punct', ']');
          expr = { kind: 'index', target: expr, index };
        }
      } else if (this.match('op', '->')) {
        const prop = this.peek().type === 'ident' ? this.next().value : '';
        expr = { kind: 'prop', target: expr, prop };
      } else if (this.peek().type === 'op' && ['++', '--'].includes(this.peek().value)) {
        const op = this.next().value;
        expr = { kind: 'unary', op, expr, postfix: true };
      } else {
        break;
      }
    }
    return expr;
  }

  private parsePrimary(): Expr {
    const t = this.peek();

    if (t.type === 'number') {
      this.next();
      const val = t.value.startsWith('0x')
        ? parseInt(t.value, 16)
        : t.value.startsWith('0b')
        ? parseInt(t.value.slice(2), 2)
        : Number(t.value);
      return { kind: 'lit', value: val };
    }

    if (t.type === 'string') {
      this.next();
      return t.doubleQuoted ? { kind: 'dstring', value: t.value } : { kind: 'lit', value: t.value };
    }

    if (t.type === 'var') {
      this.next();
      return { kind: 'var', name: t.value };
    }

    // [...] array literal
    if (this.match('punct', '[')) {
      return this.parseArrayLiteral(']');
    }

    // array(...) literal
    if (this.isKeyword('array') && this.peek(1).value === '(') {
      this.next();
      this.next();
      return this.parseArrayLiteral(')');
    }

    // isset(...)
    if (this.matchKeyword('isset')) {
      this.match('punct', '(');
      const targets: Expr[] = [];
      if (!this.match('punct', ')')) {
        targets.push(this.parseExpression());
        while (this.match('punct', ',')) targets.push(this.parseExpression());
        this.match('punct', ')');
      }
      return { kind: 'isset', targets };
    }

    // empty(...)
    if (this.matchKeyword('empty')) {
      this.match('punct', '(');
      const target = this.parseExpression();
      this.match('punct', ')');
      return { kind: 'empty', target };
    }

    // include / require expression
    if (
      this.isKeyword('include') ||
      this.isKeyword('include_once') ||
      this.isKeyword('require') ||
      this.isKeyword('require_once')
    ) {
      const once = this.next().value.toLowerCase().endsWith('_once');
      const expr = this.parseExpression();
      return { kind: 'includeExpr', expr, once };
    }

    // Anonymous function
    if (this.matchKeyword('function')) {
      const params = this.parseParams();
      const uses: string[] = [];
      if (this.matchKeyword('use')) {
        this.match('punct', '(');
        while (this.peek().type !== 'eof' && this.peek().value !== ')') {
          this.match('op', '&');
          if (this.peek().type === 'var') uses.push(this.next().value);
          if (!this.match('punct', ',')) break;
        }
        this.match('punct', ')');
      }
      const body = this.parseBlockOrSingle();
      return { kind: 'closure', params, uses, body };
    }

    // Arrow function fn($x) => expr
    if (this.isKeyword('fn') && this.peek(1).value === '(') {
      this.next();
      const params = this.parseParams();
      this.match('op', '=>');
      const arrowExpr = this.parseTernary();
      return { kind: 'closure', params, uses: [], body: [], arrowExpr };
    }

    // Parenthesized expression
    if (this.match('punct', '(')) {
      const inner = this.parseExpression();
      this.match('punct', ')');
      return inner;
    }

    if (t.type === 'ident') {
      this.next();
      const low = t.value.toLowerCase();
      if (low === 'true') return { kind: 'lit', value: true };
      if (low === 'false') return { kind: 'lit', value: false };
      if (low === 'null') return { kind: 'lit', value: null };
      return { kind: 'ident', name: t.value };
    }

    this.next();
    return { kind: 'lit', value: null };
  }

  private parseArrayLiteral(closing: string): Expr {
    const items: { key?: Expr; val: Expr }[] = [];
    while (this.peek().type !== 'eof' && this.peek().value !== closing) {
      const first = this.parseExpression();
      if (this.match('op', '=>')) {
        const val = this.parseExpression();
        items.push({ key: first, val });
      } else {
        items.push({ val: first });
      }
      if (!this.match('punct', ',')) break;
    }
    this.match('punct', closing);
    return { kind: 'array', items };
  }
}

// =========================================================================
// SANDBOXED FILE & PUBLIC NETWORK SAFETY HELPERS
// =========================================================================
export function resolveSandboxedSitePath(siteDir: string, requestedPath: string): string | null {
  const cleaned = requestedPath.replace(/^file:\/\//i, '').replace(/\\/g, '/');
  if (!cleaned || cleaned.includes('\0')) return null;
  const resolvedRoot = path.resolve(siteDir);
  const candidate = path.isAbsolute(cleaned)
    ? path.resolve(cleaned)
    : path.resolve(resolvedRoot, cleaned);
  if (candidate === resolvedRoot || candidate.startsWith(resolvedRoot + path.sep)) {
    return candidate;
  }
  return null;
}

export function isPrivateOrReservedIp(ip: string): boolean {
  const clean = ip.replace(/^::ffff:/i, '').trim();
  if (clean === '::1' || clean === '0:0:0:0:0:0:0:1' || clean === '::') return true;
  if (/^(fc|fd|fe80)/i.test(clean)) return true;
  const m = clean.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m) return false;
  const [a, b] = [Number(m[1]), Number(m[2])];
  if (a === 127 || a === 10 || a === 0) return true;
  if (a === 169 && b === 254) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  if (a === 192 && b === 168) return true;
  if (a === 100 && b >= 64 && b <= 127) return true;
  return false;
}

export async function isSafePublicUrl(rawUrl: string): Promise<boolean> {
  try {
    const parsed = new URL(rawUrl);
    if (!['http:', 'https:'].includes(parsed.protocol)) return false;
    const host = parsed.hostname.toLowerCase();
    if (!host || host === 'localhost' || host.endsWith('.local') || host.endsWith('.internal')) {
      return false;
    }
    if (net.isIP(host)) {
      return !isPrivateOrReservedIp(host);
    }
    try {
      const addrs = await dns.lookup(host, { all: true });
      if (!addrs || addrs.length === 0) return false;
      return addrs.every(a => !isPrivateOrReservedIp(a.address));
    } catch {
      return false;
    }
  } catch {
    return false;
  }
}

function formatPhpDate(fmt: string, d: Date, utc = false): string {
  const pad = (n: number, w = 2) => String(n).padStart(w, '0');
  const yr = utc ? d.getUTCFullYear() : d.getFullYear();
  const mo = (utc ? d.getUTCMonth() : d.getMonth()) + 1;
  const day = utc ? d.getUTCDate() : d.getDate();
  const hr = utc ? d.getUTCHours() : d.getHours();
  const mn = utc ? d.getUTCMinutes() : d.getMinutes();
  const sc = utc ? d.getUTCSeconds() : d.getSeconds();
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const dow = utc ? d.getUTCDay() : d.getDay();

  let out = '';
  for (let i = 0; i < fmt.length; i++) {
    const c = fmt[i];
    if (c === '\\' && i + 1 < fmt.length) {
      out += fmt[++i];
      continue;
    }
    switch (c) {
      case 'Y': out += String(yr); break;
      case 'y': out += String(yr).slice(-2); break;
      case 'm': out += pad(mo); break;
      case 'n': out += String(mo); break;
      case 'M': out += months[mo - 1].slice(0, 3); break;
      case 'F': out += months[mo - 1]; break;
      case 'd': out += pad(day); break;
      case 'j': out += String(day); break;
      case 'D': out += days[dow].slice(0, 3); break;
      case 'l': out += days[dow]; break;
      case 'H': out += pad(hr); break;
      case 'G': out += String(hr); break;
      case 'h': out += pad(hr % 12 || 12); break;
      case 'g': out += String(hr % 12 || 12); break;
      case 'i': out += pad(mn); break;
      case 's': out += pad(sc); break;
      case 'a': out += hr < 12 ? 'am' : 'pm'; break;
      case 'A': out += hr < 12 ? 'AM' : 'PM'; break;
      case 'U': out += String(Math.floor(d.getTime() / 1000)); break;
      case 'c': out += d.toISOString(); break;
      default: out += c;
    }
  }
  return out;
}

function globMatch(pattern: string, filename: string): boolean {
  const regexStr =
    '^' +
    pattern
      .replace(/[.+^${}()|[\]\\]/g, '\\$&')
      .replace(/\*/g, '.*')
      .replace(/\?/g, '.') +
    '$';
  return new RegExp(regexStr, 'i').test(filename);
}

// =========================================================================
// ASYNC PHP INTERPRETER ENGINE
// =========================================================================
interface CurlHandle {
  url: string;
  method: string;
  headers: Record<string, string>;
  postFields: any;
  timeoutSec: number;
  returnTransfer: boolean;
  followLocation: boolean;
  includeHeaders: boolean;
  nobody: boolean;
  proxy?: string;
  lastInfo: Record<string, any>;
  lastError: string;
  lastErrno: number;
  lastResponse?: string;
}

interface FileHandle {
  filePath: string;
  mode: string;
  pos: number;
  lines?: string[];
  socket?: net.Socket;
  buffer?: Buffer;
  closed?: boolean;
}

export async function executePhpCode(
  code: string,
  ctx: PhpRequestContext
): Promise<PhpExecutionResult> {
  const siteDir = path.resolve(ctx.siteDir);
  if (!fs.existsSync(siteDir)) {
    fs.mkdirSync(siteDir, { recursive: true });
  }

  let statusCode = 200;
  const responseHeaders: Record<string, string> = {
    'Content-Type': 'text/html; charset=utf-8',
  };
  const setCookies: string[] = [];
  const obStack: string[][] = [[]];

  const writeOut = (str: string) => {
    obStack[obStack.length - 1].push(str);
  };

  const constants = new Map<string, any>([
    ['PHP_EOL', '\n'],
    ['PHP_VERSION', '8.3.12'],
    ['DIRECTORY_SEPARATOR', '/'],
    ['__DIR__', siteDir],
    ['__FILE__', path.join(siteDir, ctx.scriptName || 'index.php')],
    ['FILE_APPEND', 8],
    ['LOCK_EX', 2],
    ['JSON_PRETTY_PRINT', 128],
    ['JSON_UNESCAPED_SLASHES', 64],
    ['JSON_UNESCAPED_UNICODE', 256],
    ['ENT_QUOTES', 3],
    ['ENT_HTML5', 48],
    ['CURLOPT_URL', 10002],
    ['CURLOPT_RETURNTRANSFER', 19913],
    ['CURLOPT_POST', 47],
    ['CURLOPT_POSTFIELDS', 10015],
    ['CURLOPT_HTTPHEADER', 10023],
    ['CURLOPT_TIMEOUT', 13],
    ['CURLOPT_TIMEOUT_MS', 155],
    ['CURLOPT_CONNECTTIMEOUT', 78],
    ['CURLOPT_FOLLOWLOCATION', 52],
    ['CURLOPT_SSL_VERIFYPEER', 64],
    ['CURLOPT_SSL_VERIFYHOST', 81],
    ['CURLOPT_USERAGENT', 10018],
    ['CURLOPT_CUSTOMREQUEST', 10036],
    ['CURLOPT_HEADER', 42],
    ['CURLOPT_NOBODY', 44],
    ['CURLOPT_PROXY', 10004],
    ['CURLOPT_PROXYTYPE', 101],
    ['CURLPROXY_HTTP', 0],
    ['CURLPROXY_SOCKS4', 4],
    ['CURLPROXY_SOCKS5', 5],
    ['CURLINFO_HTTP_CODE', 2097154],
    ['CURLINFO_RESPONSE_CODE', 2097154],
    ['CURLINFO_TOTAL_TIME', 3145731],
    ['CURLINFO_EFFECTIVE_URL', 1048577],
    ['FILTER_VALIDATE_IP', 275],
    ['FILTER_VALIDATE_URL', 273],
    ['FILTER_VALIDATE_EMAIL', 274],
    ['CASE_LOWER', 0],
    ['CASE_UPPER', 1],
    ['SORT_REGULAR', 0],
    ['SORT_NUMERIC', 1],
    ['SORT_STRING', 2],
    ['ARRAY_FILTER_USE_KEY', 2],
    ['ARRAY_FILTER_USE_BOTH', 1],
    ['PHP_URL_SCHEME', 0],
    ['PHP_URL_HOST', 1],
    ['PHP_URL_PORT', 2],
    ['PHP_URL_PATH', 5],
    ['PHP_URL_QUERY', 6],
  ]);

  const phpGet = jsToPhpValue(ctx.get || {});
  const phpPost = jsToPhpValue(ctx.post || {});
  const phpCookies = jsToPhpValue(ctx.cookies || {});
  const phpRequest = jsToPhpValue({ ...(ctx.get || {}), ...(ctx.post || {}) });
  const phpSession = makePhpArray();

  const serverMap: Record<string, any> = {
    REQUEST_METHOD: (ctx.method || 'GET').toUpperCase(),
    REQUEST_URI: ctx.path + (ctx.queryString ? `?${ctx.queryString}` : ''),
    QUERY_STRING: ctx.queryString || '',
    SCRIPT_NAME: ctx.scriptName || '/index.php',
    PHP_SELF: ctx.scriptName || '/index.php',
    DOCUMENT_ROOT: siteDir,
    HTTP_HOST: ctx.host || 'nighthost.local',
    HTTP_USER_AGENT: ctx.headers['user-agent'] || 'NIGHTHOST-Client/1.0',
    HTTP_ACCEPT: ctx.headers['accept'] || '*/*',
    HTTP_REFERER: ctx.headers['referer'] || '',
    CONTENT_TYPE: ctx.headers['content-type'] || '',
    REMOTE_ADDR: ctx.remoteAddr || '127.0.0.1',
    SERVER_NAME: ctx.host || 'nighthost.local',
    SERVER_SOFTWARE: 'NIGHTHOST-PHP/8.3',
    SERVER_PROTOCOL: 'HTTP/1.1',
    REQUEST_TIME: Math.floor(Date.now() / 1000),
    REQUEST_TIME_FLOAT: Date.now() / 1000,
    HTTPS: ctx.scheme === 'https' ? 'on' : '',
  };
  for (const [hk, hv] of Object.entries(ctx.headers || {})) {
    const phpHdrKey = 'HTTP_' + hk.toUpperCase().replace(/[^A-Z0-9]/g, '_');
    if (!serverMap[phpHdrKey]) serverMap[phpHdrKey] = hv;
  }

  const globalsScope: Record<string, any> = {
    _GET: phpGet,
    _POST: phpPost,
    _REQUEST: phpRequest,
    _COOKIE: phpCookies,
    _FILES: makePhpArray(),
    _SESSION: phpSession,
    _SERVER: jsToPhpValue(serverMap),
    _ENV: jsToPhpValue(process.env),
  };
  globalsScope['GLOBALS'] = globalsScope;

  const userFuncs = new Map<string, (...args: any[]) => Promise<any>>();
  const includedOnce = new Set<string>();
  const curlHandles = new Map<number, CurlHandle>();
  const curlMultiHandles = new Map<number, Set<number>>();
  const fileHandles = new Map<number, FileHandle>();
  let nextHandleId = 1;
  let sessionStarted = false;
  let activeSessionFile = '';
  let executionSteps = 0;
  const MAX_STEPS = 200000;

  // Helpers for PHP Curl HTTP Request
  const runCurlHandle = async (ch: CurlHandle): Promise<string | boolean> => {
    const startMs = Date.now();
    ch.lastError = '';
    ch.lastErrno = 0;

    if (!ch.url) {
      ch.lastError = 'No URL set';
      ch.lastErrno = 3;
      return false;
    }

    const safe = await isSafePublicUrl(ch.url);
    if (!safe) {
      ch.lastError = 'Blocked unsafe or non-public URL';
      ch.lastErrno = 7;
      ch.lastInfo = { http_code: 0, total_time: 0, url: ch.url };
      return false;
    }

    // If proxy probe requested, verify proxy TCP connectivity first
    if (ch.proxy) {
      const cleanedProxy = ch.proxy.replace(/^[a-z0-9]+:\/\//i, '');
      const [pHost, pPortStr] = cleanedProxy.split(':');
      const pPort = Number(pPortStr) || 8080;
      const tcpOk = await new Promise<boolean>((resolve) => {
        const sock = net.createConnection({ host: pHost, port: pPort, timeout: Math.min(ch.timeoutSec * 1000, 5000) });
        sock.once('connect', () => {
          sock.destroy();
          resolve(true);
        });
        sock.once('error', () => {
          sock.destroy();
          resolve(false);
        });
        sock.once('timeout', () => {
          sock.destroy();
          resolve(false);
        });
      });
      if (!tcpOk) {
        ch.lastError = `Failed to connect to proxy ${pHost}:${pPort}`;
        ch.lastErrno = 7;
        ch.lastInfo = {
          http_code: 0,
          total_time: (Date.now() - startMs) / 1000,
          url: ch.url,
        };
        return false;
      }
      // If proxy connects cleanly and target is HTTP, tunnel HTTP GET through proxy socket
      try {
        const target = new URL(ch.url);
        const proxiedResp = await new Promise<{ statusCode: number; headersRaw: string; body: string } | null>((resolve) => {
          const sock = net.createConnection({ host: pHost, port: pPort, timeout: Math.min(ch.timeoutSec * 1000, 6000) });
          let raw = '';
          sock.once('connect', () => {
            const reqLines = [
              `${ch.method || 'GET'} ${ch.url} HTTP/1.1`,
              `Host: ${target.host}`,
              `User-Agent: ${ch.headers['User-Agent'] || 'NIGHTHOST-PHP-Curl/1.0'}`,
              `Connection: close`,
              '',
              '',
            ];
            sock.write(reqLines.join('\r\n'));
          });
          sock.on('data', (chunk) => {
            raw += chunk.toString('utf-8');
            if (raw.length > 512 * 1024) sock.destroy();
          });
          sock.once('end', () => {
            const sep = raw.indexOf('\r\n\r\n');
            if (sep === -1) {
              resolve(null);
              return;
            }
            const hdrRaw = raw.slice(0, sep);
            const body = raw.slice(sep + 4);
            const statusM = hdrRaw.match(/^HTTP\/\d\.\d\s+(\d+)/);
            resolve({
              statusCode: statusM ? Number(statusM[1]) : 200,
              headersRaw: hdrRaw,
              body,
            });
          });
          sock.once('error', () => {
            sock.destroy();
            resolve(null);
          });
          sock.once('timeout', () => {
            sock.destroy();
            resolve(null);
          });
        });

        if (proxiedResp) {
          ch.lastInfo = {
            http_code: proxiedResp.statusCode,
            total_time: (Date.now() - startMs) / 1000,
            url: ch.url,
          };
          const out = ch.includeHeaders ? `${proxiedResp.headersRaw}\r\n\r\n${proxiedResp.body}` : proxiedResp.body;
          ch.lastResponse = out;
          if (!ch.returnTransfer) {
            writeOut(out);
            return true;
          }
          return out;
        }
      } catch {
        // fall through to failure
      }
      ch.lastError = 'Proxy HTTP relay timeout/error';
      ch.lastErrno = 28;
      ch.lastInfo = { http_code: 0, total_time: (Date.now() - startMs) / 1000, url: ch.url };
      return false;
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), Math.min(Math.max(ch.timeoutSec, 1), 15) * 1000);
    try {
      const hdrs: Record<string, string> = {
        'User-Agent': 'NIGHTHOST-PHP-Curl/8.3',
        ...ch.headers,
      };
      let body: any = undefined;
      if (ch.postFields !== undefined && ch.postFields !== null && ch.method !== 'GET' && ch.method !== 'HEAD') {
        if (isPhpArray(ch.postFields)) {
          const params = new URLSearchParams();
          for (const [k, v] of ch.postFields.map.entries()) {
            params.append(String(k), phpToString(v));
          }
          body = params.toString();
          if (!Object.keys(hdrs).some(k => k.toLowerCase() === 'content-type')) {
            hdrs['Content-Type'] = 'application/x-www-form-urlencoded';
          }
        } else {
          body = phpToString(ch.postFields);
        }
      }

      const fetchRes = await fetch(ch.url, {
        method: ch.nobody ? 'HEAD' : ch.method,
        headers: hdrs,
        body,
        redirect: ch.followLocation ? 'follow' : 'manual',
        signal: controller.signal,
      });

      const respText = ch.nobody ? '' : await fetchRes.text();
      let finalOut = respText;
      if (ch.includeHeaders) {
        const hdrLines = [`HTTP/1.1 ${fetchRes.status} ${fetchRes.statusText}`];
        fetchRes.headers.forEach((v, k) => hdrLines.push(`${k}: ${v}`));
        finalOut = hdrLines.join('\r\n') + '\r\n\r\n' + respText;
      }

      ch.lastInfo = {
        http_code: fetchRes.status,
        total_time: (Date.now() - startMs) / 1000,
        url: fetchRes.url || ch.url,
        content_type: fetchRes.headers.get('content-type') || '',
      };
      ch.lastResponse = finalOut;

      if (!ch.returnTransfer) {
        writeOut(finalOut);
        return true;
      }
      return finalOut;
    } catch (err: any) {
      ch.lastError = err?.message || 'cURL request failed';
      ch.lastErrno = 28;
      ch.lastInfo = {
        http_code: 0,
        total_time: (Date.now() - startMs) / 1000,
        url: ch.url,
      };
      return false;
    } finally {
      clearTimeout(timer);
    }
  };

  // Built-in PHP Standard Library
  const callBuiltin = async (fnName: string, args: any[]): Promise<{ handled: boolean; value: any }> => {
    const fn = fnName.toLowerCase();

    switch (fn) {
      // --- Output & Headers ---
      case 'header': {
        const rawHdr = phpToString(args[0]);
        const replace = args[1] !== undefined ? phpTruthy(args[1]) : true;
        const explicitCode = args[2] !== undefined ? phpToNumber(args[2]) : undefined;
        if (/^HTTP\/\d\.\d\s+(\d+)/i.test(rawHdr)) {
          const m = rawHdr.match(/^HTTP\/\d\.\d\s+(\d+)/i);
          if (m) statusCode = Number(m[1]);
        } else {
          const colonIdx = rawHdr.indexOf(':');
          if (colonIdx > 0) {
            const k = rawHdr.slice(0, colonIdx).trim();
            const v = rawHdr.slice(colonIdx + 1).trim();
            if (k.toLowerCase() === 'set-cookie') {
              setCookies.push(v);
            } else if (replace || !Object.keys(responseHeaders).some(e => e.toLowerCase() === k.toLowerCase())) {
              // Normalize casing if key already exists
              const existingKey = Object.keys(responseHeaders).find(e => e.toLowerCase() === k.toLowerCase());
              if (existingKey) delete responseHeaders[existingKey];
              responseHeaders[k] = v;
              if (k.toLowerCase() === 'location' && statusCode === 200) {
                statusCode = 302;
              }
            }
          }
        }
        if (explicitCode && explicitCode >= 100) statusCode = explicitCode;
        return { handled: true, value: null };
      }
      case 'http_response_code': {
        const prev = statusCode;
        if (args[0] !== undefined) statusCode = phpToNumber(args[0]) || 200;
        return { handled: true, value: prev };
      }
      case 'headers_sent':
        return { handled: true, value: false };
      case 'setcookie': {
        const cname = phpToString(args[0]);
        const cval = encodeURIComponent(phpToString(args[1] ?? ''));
        const expires = args[2] ? Number(args[2]) : 0;
        const cpath = args[3] ? phpToString(args[3]) : '/';
        let str = `${cname}=${cval}; Path=${cpath}`;
        if (expires > 0) str += `; Expires=${new Date(expires * 1000).toUTCString()}`;
        setCookies.push(str);
        return { handled: true, value: true };
      }
      case 'session_start': {
        if (!sessionStarted) {
          sessionStarted = true;
          const sessDir = path.join(siteDir, '.nh_sessions');
          if (!fs.existsSync(sessDir)) fs.mkdirSync(sessDir, { recursive: true });
          let sid = phpToString(getPhpArray(phpCookies, 'PHPSESSID')).replace(/[^a-zA-Z0-9_-]/g, '');
          if (!sid) {
            sid = crypto.randomBytes(12).toString('hex');
            setCookies.push(`PHPSESSID=${sid}; Path=/; HttpOnly; SameSite=Lax`);
            setPhpArray(phpCookies, 'PHPSESSID', sid);
          }
          activeSessionFile = path.join(sessDir, `${sid}.json`);
          if (fs.existsSync(activeSessionFile)) {
            try {
              const saved = JSON.parse(fs.readFileSync(activeSessionFile, 'utf-8'));
              if (saved && typeof saved === 'object') {
                for (const [k, v] of Object.entries(saved)) {
                  setPhpArray(phpSession, k, jsToPhpValue(v));
                }
              }
            } catch {
              // ignore corrupt session file
            }
          }
        }
        return { handled: true, value: true };
      }
      case 'session_destroy': {
        phpSession.map.clear();
        phpSession.nextIndex = 0;
        if (activeSessionFile && fs.existsSync(activeSessionFile)) {
          fs.unlinkSync(activeSessionFile);
        }
        return { handled: true, value: true };
      }
      case 'session_id':
        return { handled: true, value: phpToString(getPhpArray(phpCookies, 'PHPSESSID')) };
      case 'ob_start': {
        obStack.push([]);
        return { handled: true, value: true };
      }
      case 'ob_get_contents':
        return { handled: true, value: obStack[obStack.length - 1].join('') };
      case 'ob_get_clean': {
        if (obStack.length > 1) {
          return { handled: true, value: obStack.pop()!.join('') };
        }
        const content = obStack[0].join('');
        obStack[0] = [];
        return { handled: true, value: content };
      }
      case 'ob_end_clean': {
        if (obStack.length > 1) obStack.pop();
        else obStack[0] = [];
        return { handled: true, value: true };
      }
      case 'flush':
      case 'ob_flush':
      case 'error_reporting':
      case 'ini_set':
      case 'set_time_limit':
      case 'ignore_user_abort':
      case 'date_default_timezone_set':
        return { handled: true, value: true };
      case 'define': {
        constants.set(phpToString(args[0]), args[1]);
        return { handled: true, value: true };
      }
      case 'defined':
        return { handled: true, value: constants.has(phpToString(args[0])) };
      case 'function_exists': {
        const target = phpToString(args[0]).toLowerCase();
        return { handled: true, value: userFuncs.has(target) || BUILTIN_NAMES.has(target) };
      }
      case 'phpversion':
        return { handled: true, value: '8.3.12' };
      case 'print_r': {
        const formatted = JSON.stringify(phpToJsPlain(args[0]), null, 2);
        if (phpTruthy(args[1])) return { handled: true, value: formatted };
        writeOut(formatted);
        return { handled: true, value: true };
      }
      case 'var_dump': {
        for (const a of args) writeOut(JSON.stringify(phpToJsPlain(a)) + '\n');
        return { handled: true, value: null };
      }

      // --- JSON ---
      case 'json_encode': {
        const plain = phpToJsPlain(args[0]);
        const flags = args[1] ? phpToNumber(args[1]) : 0;
        const pretty = (flags & 128) !== 0;
        return {
          handled: true,
          value: JSON.stringify(plain, null, pretty ? 2 : undefined) ?? 'null',
        };
      }
      case 'json_decode': {
        try {
          const parsed = JSON.parse(phpToString(args[0]));
          return { handled: true, value: jsToPhpValue(parsed) };
        } catch {
          return { handled: true, value: null };
        }
      }

      // --- Strings & HTML ---
      case 'strlen':
      case 'mb_strlen':
        return { handled: true, value: phpToString(args[0]).length };
      case 'substr':
      case 'mb_substr': {
        const s = phpToString(args[0]);
        let start = phpToNumber(args[1]);
        if (start < 0) start = Math.max(0, s.length + start);
        if (args[2] === undefined || args[2] === null) return { handled: true, value: s.slice(start) };
        let len = phpToNumber(args[2]);
        if (len < 0) return { handled: true, value: s.slice(start, Math.max(start, s.length + len)) };
        return { handled: true, value: s.slice(start, start + len) };
      }
      case 'strpos':
      case 'mb_strpos': {
        const hay = phpToString(args[0]);
        const needle = phpToString(args[1]);
        const off = args[2] ? phpToNumber(args[2]) : 0;
        const idx = hay.indexOf(needle, off);
        return { handled: true, value: idx === -1 ? false : idx };
      }
      case 'stripos': {
        const hay = phpToString(args[0]).toLowerCase();
        const needle = phpToString(args[1]).toLowerCase();
        const off = args[2] ? phpToNumber(args[2]) : 0;
        const idx = hay.indexOf(needle, off);
        return { handled: true, value: idx === -1 ? false : idx };
      }
      case 'strrpos': {
        const idx = phpToString(args[0]).lastIndexOf(phpToString(args[1]));
        return { handled: true, value: idx === -1 ? false : idx };
      }
      case 'str_contains':
        return { handled: true, value: phpToString(args[0]).includes(phpToString(args[1])) };
      case 'str_starts_with':
        return { handled: true, value: phpToString(args[0]).startsWith(phpToString(args[1])) };
      case 'str_ends_with':
        return { handled: true, value: phpToString(args[0]).endsWith(phpToString(args[1])) };
      case 'str_replace':
      case 'str_ireplace': {
        const ci = fn === 'str_ireplace';
        const subj = args[2];
        const applyReplace = (text: string): string => {
          const searches = isPhpArray(args[0]) ? Array.from(args[0].map.values()).map(phpToString) : [phpToString(args[0])];
          const replaces = isPhpArray(args[1]) ? Array.from(args[1].map.values()).map(phpToString) : [phpToString(args[1])];
          let out = text;
          searches.forEach((s, idx) => {
            if (!s) return;
            const rep = replaces[idx] ?? replaces[0] ?? '';
            const re = new RegExp(s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), ci ? 'gi' : 'g');
            out = out.replace(re, () => rep);
          });
          return out;
        };
        if (isPhpArray(subj)) {
          const outArr = makePhpArray();
          for (const [k, v] of subj.map.entries()) setPhpArray(outArr, k, applyReplace(phpToString(v)));
          return { handled: true, value: outArr };
        }
        return { handled: true, value: applyReplace(phpToString(subj)) };
      }
      case 'trim':
      case 'ltrim':
      case 'rtrim': {
        const s = phpToString(args[0]);
        if (args[1] !== undefined) {
          const chars = phpToString(args[1]).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          if (fn === 'ltrim') return { handled: true, value: s.replace(new RegExp(`^[${chars}]+`), '') };
          if (fn === 'rtrim') return { handled: true, value: s.replace(new RegExp(`[${chars}]+$`), '') };
          return { handled: true, value: s.replace(new RegExp(`^[${chars}]+|[${chars}]+$`, 'g'), '') };
        }
        return { handled: true, value: fn === 'ltrim' ? s.trimStart() : fn === 'rtrim' ? s.trimEnd() : s.trim() };
      }
      case 'strtolower':
      case 'mb_strtolower':
        return { handled: true, value: phpToString(args[0]).toLowerCase() };
      case 'strtoupper':
      case 'mb_strtoupper':
        return { handled: true, value: phpToString(args[0]).toUpperCase() };
      case 'ucfirst': {
        const s = phpToString(args[0]);
        return { handled: true, value: s ? s[0].toUpperCase() + s.slice(1) : '' };
      }
      case 'ucwords':
        return { handled: true, value: phpToString(args[0]).replace(/\b\w/g, c => c.toUpperCase()) };
      case 'str_repeat':
        return { handled: true, value: phpToString(args[0]).repeat(Math.max(0, phpToNumber(args[1]))) };
      case 'str_pad': {
        const s = phpToString(args[0]);
        const len = phpToNumber(args[1]);
        const pad = phpToString(args[2] ?? ' ');
        return { handled: true, value: s.padEnd(len, pad) };
      }
      case 'str_split': {
        const s = phpToString(args[0]);
        const sz = Math.max(1, phpToNumber(args[1] ?? 1));
        const arr = makePhpArray();
        for (let i = 0; i < s.length; i += sz) setPhpArray(arr, null, s.slice(i, i + sz));
        return { handled: true, value: arr };
      }
      case 'explode': {
        const sep = phpToString(args[0]);
        const str = phpToString(args[1]);
        if (!sep) return { handled: true, value: false };
        const parts = str.split(sep);
        const arr = makePhpArray();
        for (const p of parts) setPhpArray(arr, null, p);
        return { handled: true, value: arr };
      }
      case 'implode':
      case 'join': {
        const hasGlue = args.length >= 2;
        const glue = hasGlue ? phpToString(args[0]) : '';
        const targetArr = hasGlue ? args[1] : args[0];
        if (!isPhpArray(targetArr)) return { handled: true, value: phpToString(targetArr) };
        return { handled: true, value: Array.from(targetArr.map.values()).map(phpToString).join(glue) };
      }
      case 'htmlspecialchars':
      case 'htmlentities': {
        const s = phpToString(args[0]);
        return {
          handled: true,
          value: s
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;'),
        };
      }
      case 'htmlspecialchars_decode':
      case 'html_entity_decode': {
        return {
          handled: true,
          value: phpToString(args[0])
            .replace(/&quot;/g, '"')
            .replace(/&#039;/g, "'")
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&amp;/g, '&'),
        };
      }
      case 'strip_tags':
        return { handled: true, value: phpToString(args[0]).replace(/<[^>]*>/g, '') };
      case 'nl2br':
        return { handled: true, value: phpToString(args[0]).replace(/\r?\n/g, '<br />\n') };
      case 'addslashes':
        return { handled: true, value: phpToString(args[0]).replace(/(['"\\])/g, '\\$1') };
      case 'stripslashes':
        return { handled: true, value: phpToString(args[0]).replace(/\\(['"\\])/g, '$1') };
      case 'number_format': {
        const num = phpToNumber(args[0]);
        const dec = args[1] !== undefined ? phpToNumber(args[1]) : 0;
        const decPt = args[2] !== undefined ? phpToString(args[2]) : '.';
        const thouSep = args[3] !== undefined ? phpToString(args[3]) : ',';
        const fixed = num.toFixed(dec);
        const [intPart, fracPart] = fixed.split('.');
        const withSep = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, thouSep);
        return { handled: true, value: fracPart !== undefined ? `${withSep}${decPt}${fracPart}` : withSep };
      }
      case 'sprintf':
      case 'printf': {
        const fmt = phpToString(args[0]);
        let argIdx = 1;
        const out = fmt.replace(/%(?:\.(\d+))?([sdfuxX%])/g, (_m, prec, spec) => {
          if (spec === '%') return '%';
          const v = args[argIdx++];
          if (spec === 's') return phpToString(v);
          if (spec === 'd' || spec === 'u') return String(Math.trunc(phpToNumber(v)));
          if (spec === 'f') return prec ? phpToNumber(v).toFixed(Number(prec)) : String(phpToNumber(v));
          if (spec === 'x') return Math.trunc(phpToNumber(v)).toString(16);
          if (spec === 'X') return Math.trunc(phpToNumber(v)).toString(16).toUpperCase();
          return phpToString(v);
        });
        if (fn === 'printf') {
          writeOut(out);
          return { handled: true, value: out.length };
        }
        return { handled: true, value: out };
      }
      case 'urlencode':
        return { handled: true, value: encodeURIComponent(phpToString(args[0])).replace(/%20/g, '+') };
      case 'rawurlencode':
        return { handled: true, value: encodeURIComponent(phpToString(args[0])) };
      case 'urldecode':
        return { handled: true, value: decodeURIComponent(phpToString(args[0]).replace(/\+/g, ' ')) };
      case 'rawurldecode':
        return { handled: true, value: decodeURIComponent(phpToString(args[0])) };
      case 'base64_encode':
        return { handled: true, value: Buffer.from(phpToString(args[0]), 'utf-8').toString('base64') };
      case 'base64_decode':
        return { handled: true, value: Buffer.from(phpToString(args[0]), 'base64').toString('utf-8') };
      case 'http_build_query': {
        const p = new URLSearchParams();
        if (isPhpArray(args[0])) {
          for (const [k, v] of args[0].map.entries()) p.append(String(k), phpToString(v));
        }
        return { handled: true, value: p.toString() };
      }
      case 'parse_url': {
        try {
          const u = new URL(phpToString(args[0]), 'http://localhost');
          const comp = args[1] !== undefined ? phpToNumber(args[1]) : -1;
          const map: Record<string, any> = {
            scheme: u.protocol.replace(':', ''),
            host: u.hostname,
            port: u.port ? Number(u.port) : undefined,
            path: u.pathname,
            query: u.search ? u.search.slice(1) : undefined,
          };
          if (comp === 0) return { handled: true, value: map.scheme };
          if (comp === 1) return { handled: true, value: map.host };
          if (comp === 2) return { handled: true, value: map.port ?? null };
          if (comp === 5) return { handled: true, value: map.path };
          if (comp === 6) return { handled: true, value: map.query ?? null };
          const cleanObj: Record<string, any> = {};
          for (const [k, v] of Object.entries(map)) {
            if (v !== undefined) cleanObj[k] = v;
          }
          return { handled: true, value: jsToPhpValue(cleanObj) };
        } catch {
          return { handled: true, value: false };
        }
      }

      // --- Regex ---
      case 'preg_match': {
        const rawPat = phpToString(args[0]);
        const subj = phpToString(args[1]);
        const delim = rawPat[0] || '/';
        const endIdx = rawPat.lastIndexOf(delim);
        const body = endIdx > 0 ? rawPat.slice(1, endIdx) : rawPat;
        const flags = endIdx > 0 ? rawPat.slice(endIdx + 1).replace(/[^gimsu]/g, '') : '';
        try {
          const re = new RegExp(body, flags.replace(/g/g, ''));
          const m = subj.match(re);
          return { handled: true, value: m ? 1 : 0 };
        } catch {
          return { handled: true, value: 0 };
        }
      }
      case 'preg_match_all': {
        const rawPat = phpToString(args[0]);
        const subj = phpToString(args[1]);
        const delim = rawPat[0] || '/';
        const endIdx = rawPat.lastIndexOf(delim);
        const body = endIdx > 0 ? rawPat.slice(1, endIdx) : rawPat;
        const flags = (endIdx > 0 ? rawPat.slice(endIdx + 1).replace(/[^imsu]/g, '') : '') + 'g';
        try {
          const re = new RegExp(body, flags);
          const all = Array.from(subj.matchAll(re));
          return { handled: true, value: all.length };
        } catch {
          return { handled: true, value: 0 };
        }
      }
      case 'preg_replace': {
        const rawPat = phpToString(args[0]);
        const repl = phpToString(args[1]);
        const subj = phpToString(args[2]);
        const delim = rawPat[0] || '/';
        const endIdx = rawPat.lastIndexOf(delim);
        const body = endIdx > 0 ? rawPat.slice(1, endIdx) : rawPat;
        const flags = (endIdx > 0 ? rawPat.slice(endIdx + 1).replace(/[^imsu]/g, '') : '') + 'g';
        try {
          const re = new RegExp(body, flags);
          return { handled: true, value: subj.replace(re, repl) };
        } catch {
          return { handled: true, value: subj };
        }
      }
      case 'preg_split': {
        const rawPat = phpToString(args[0]);
        const subj = phpToString(args[1]);
        const delim = rawPat[0] || '/';
        const endIdx = rawPat.lastIndexOf(delim);
        const body = endIdx > 0 ? rawPat.slice(1, endIdx) : rawPat;
        const flags = endIdx > 0 ? rawPat.slice(endIdx + 1).replace(/[^imsu]/g, '') : '';
        try {
          const parts = subj.split(new RegExp(body, flags));
          return { handled: true, value: jsToPhpValue(parts) };
        } catch {
          return { handled: true, value: jsToPhpValue([subj]) };
        }
      }
      case 'preg_quote': {
        const s = phpToString(args[0]).replace(/[.\\+*?[^\]$(){}=!<>|:-]/g, '\\$&');
        return { handled: true, value: s };
      }

      // --- Arrays ---
      case 'count':
      case 'sizeof':
        return { handled: true, value: isPhpArray(args[0]) ? args[0].map.size : args[0] === null || args[0] === undefined ? 0 : 1 };
      case 'in_array': {
        if (!isPhpArray(args[1])) return { handled: true, value: false };
        const strict = phpTruthy(args[2]);
        for (const v of args[1].map.values()) {
          if (strict ? v === args[0] : phpLooseEqual(v, args[0])) return { handled: true, value: true };
        }
        return { handled: true, value: false };
      }
      case 'array_search': {
        if (!isPhpArray(args[1])) return { handled: true, value: false };
        const strict = phpTruthy(args[2]);
        for (const [k, v] of args[1].map.entries()) {
          if (strict ? v === args[0] : phpLooseEqual(v, args[0])) return { handled: true, value: k };
        }
        return { handled: true, value: false };
      }
      case 'array_key_exists':
      case 'key_exists': {
        if (!isPhpArray(args[1])) return { handled: true, value: false };
        return { handled: true, value: getPhpArray(args[1], args[0]) !== undefined || args[1].map.has(args[0]) };
      }
      case 'array_keys': {
        if (!isPhpArray(args[0])) return { handled: true, value: makePhpArray() };
        return { handled: true, value: jsToPhpValue(Array.from(args[0].map.keys())) };
      }
      case 'array_values': {
        if (!isPhpArray(args[0])) return { handled: true, value: makePhpArray() };
        const res = makePhpArray();
        for (const v of args[0].map.values()) setPhpArray(res, null, v);
        return { handled: true, value: res };
      }
      case 'array_merge': {
        const res = makePhpArray();
        for (const a of args) {
          if (!isPhpArray(a)) continue;
          for (const [k, v] of a.map.entries()) {
            setPhpArray(res, typeof k === 'number' ? null : k, v);
          }
        }
        return { handled: true, value: res };
      }
      case 'array_slice': {
        if (!isPhpArray(args[0])) return { handled: true, value: makePhpArray() };
        const entries = Array.from(args[0].map.entries());
        const offset = phpToNumber(args[1]);
        const len = args[2] !== undefined && args[2] !== null ? phpToNumber(args[2]) : undefined;
        const start = offset < 0 ? Math.max(0, entries.length + offset) : offset;
        const sliced = len === undefined ? entries.slice(start) : len < 0 ? entries.slice(start, entries.length + len) : entries.slice(start, start + len);
        const res = makePhpArray();
        for (const [k, v] of sliced) setPhpArray(res, typeof k === 'number' ? null : k, v);
        return { handled: true, value: res };
      }
      case 'array_reverse': {
        if (!isPhpArray(args[0])) return { handled: true, value: makePhpArray() };
        const entries = Array.from(args[0].map.entries()).reverse();
        const res = makePhpArray();
        for (const [k, v] of entries) setPhpArray(res, typeof k === 'number' ? null : k, v);
        return { handled: true, value: res };
      }
      case 'array_unique': {
        if (!isPhpArray(args[0])) return { handled: true, value: makePhpArray() };
        const seen = new Set<string>();
        const res = makePhpArray();
        for (const [k, v] of args[0].map.entries()) {
          const s = phpToString(v);
          if (!seen.has(s)) {
            seen.add(s);
            setPhpArray(res, k, v);
          }
        }
        return { handled: true, value: res };
      }
      case 'array_sum': {
        if (!isPhpArray(args[0])) return { handled: true, value: 0 };
        let sum = 0;
        for (const v of args[0].map.values()) sum += phpToNumber(v);
        return { handled: true, value: sum };
      }
      case 'array_column': {
        if (!isPhpArray(args[0])) return { handled: true, value: makePhpArray() };
        const col = args[1];
        const res = makePhpArray();
        for (const row of args[0].map.values()) {
          if (isPhpArray(row)) setPhpArray(res, null, getPhpArray(row, col));
        }
        return { handled: true, value: res };
      }
      case 'array_chunk': {
        if (!isPhpArray(args[0])) return { handled: true, value: makePhpArray() };
        const sz = Math.max(1, phpToNumber(args[1]));
        const vals = Array.from(args[0].map.values());
        const res = makePhpArray();
        for (let i = 0; i < vals.length; i += sz) {
          const sub = makePhpArray();
          for (const item of vals.slice(i, i + sz)) setPhpArray(sub, null, item);
          setPhpArray(res, null, sub);
        }
        return { handled: true, value: res };
      }
      case 'array_map': {
        const cb = args[0];
        const arr = args[1];
        if (!isPhpArray(arr)) return { handled: true, value: makePhpArray() };
        const res = makePhpArray();
        for (const [k, v] of arr.map.entries()) {
          const mapped = typeof cb === 'function' ? await cb(v) : typeof cb === 'string' ? await invokeByName(cb, [v]) : v;
          setPhpArray(res, k, mapped);
        }
        return { handled: true, value: res };
      }
      case 'array_filter': {
        const arr = args[0];
        const cb = args[1];
        const mode = args[2] ? phpToNumber(args[2]) : 0;
        if (!isPhpArray(arr)) return { handled: true, value: makePhpArray() };
        const res = makePhpArray();
        for (const [k, v] of arr.map.entries()) {
          let keep = false;
          if (!cb) {
            keep = phpTruthy(v);
          } else if (typeof cb === 'function') {
            keep = phpTruthy(mode === 2 ? await cb(k) : mode === 1 ? await cb(v, k) : await cb(v));
          } else if (typeof cb === 'string') {
            keep = phpTruthy(await invokeByName(cb, mode === 2 ? [k] : [v]));
          }
          if (keep) setPhpArray(res, k, v);
        }
        return { handled: true, value: res };
      }
      case 'range': {
        const start = phpToNumber(args[0]);
        const end = phpToNumber(args[1]);
        const step = Math.max(1, Math.abs(phpToNumber(args[2] ?? 1)));
        const res = makePhpArray();
        if (start <= end) {
          for (let v = start; v <= end; v += step) setPhpArray(res, null, v);
        } else {
          for (let v = start; v >= end; v -= step) setPhpArray(res, null, v);
        }
        return { handled: true, value: res };
      }
      case 'sort':
      case 'rsort': {
        if (!isPhpArray(args[0])) return { handled: true, value: false };
        const vals = Array.from(args[0].map.values());
        vals.sort((a, b) => (phpToNumber(a) - phpToNumber(b)) || phpToString(a).localeCompare(phpToString(b)));
        if (fn === 'rsort') vals.reverse();
        args[0].map.clear();
        args[0].nextIndex = 0;
        for (const v of vals) setPhpArray(args[0], null, v);
        return { handled: true, value: true };
      }
      case 'usort': {
        if (!isPhpArray(args[0]) || typeof args[1] !== 'function') return { handled: true, value: false };
        const vals = Array.from(args[0].map.values());
        // Simple insertion sort supporting async comparator
        for (let i = 1; i < vals.length; i++) {
          const cur = vals[i];
          let j = i - 1;
          while (j >= 0 && phpToNumber(await args[1](vals[j], cur)) > 0) {
            vals[j + 1] = vals[j];
            j--;
          }
          vals[j + 1] = cur;
        }
        args[0].map.clear();
        args[0].nextIndex = 0;
        for (const v of vals) setPhpArray(args[0], null, v);
        return { handled: true, value: true };
      }
      case 'shuffle': {
        if (!isPhpArray(args[0])) return { handled: true, value: false };
        const vals = Array.from(args[0].map.values());
        for (let i = vals.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [vals[i], vals[j]] = [vals[j], vals[i]];
        }
        args[0].map.clear();
        args[0].nextIndex = 0;
        for (const v of vals) setPhpArray(args[0], null, v);
        return { handled: true, value: true };
      }

      // --- Type / Math / Date / Crypto / Network ---
      case 'is_array': return { handled: true, value: isPhpArray(args[0]) };
      case 'is_string': return { handled: true, value: typeof args[0] === 'string' };
      case 'is_int':
      case 'is_integer':
      case 'is_long': return { handled: true, value: typeof args[0] === 'number' && Number.isInteger(args[0]) };
      case 'is_float':
      case 'is_double': return { handled: true, value: typeof args[0] === 'number' };
      case 'is_numeric': return { handled: true, value: typeof args[0] === 'number' || (typeof args[0] === 'string' && /^-?\d+(\.\d+)?$/.test(args[0].trim())) };
      case 'is_bool': return { handled: true, value: typeof args[0] === 'boolean' };
      case 'is_null': return { handled: true, value: args[0] === null || args[0] === undefined };
      case 'intval': return { handled: true, value: Math.trunc(phpToNumber(args[0])) };
      case 'floatval': return { handled: true, value: phpToNumber(args[0]) };
      case 'strval': return { handled: true, value: phpToString(args[0]) };
      case 'boolval': return { handled: true, value: phpTruthy(args[0]) };
      case 'gettype': {
        if (args[0] === null || args[0] === undefined) return { handled: true, value: 'NULL' };
        if (isPhpArray(args[0])) return { handled: true, value: 'array' };
        if (typeof args[0] === 'boolean') return { handled: true, value: 'boolean' };
        if (typeof args[0] === 'number') return { handled: true, value: Number.isInteger(args[0]) ? 'integer' : 'double' };
        return { handled: true, value: typeof args[0] };
      }
      case 'abs': return { handled: true, value: Math.abs(phpToNumber(args[0])) };
      case 'round': {
        const p = args[1] ? Math.pow(10, phpToNumber(args[1])) : 1;
        return { handled: true, value: Math.round(phpToNumber(args[0]) * p) / p };
      }
      case 'ceil': return { handled: true, value: Math.ceil(phpToNumber(args[0])) };
      case 'floor': return { handled: true, value: Math.floor(phpToNumber(args[0])) };
      case 'pow': return { handled: true, value: Math.pow(phpToNumber(args[0]), phpToNumber(args[1])) };
      case 'sqrt': return { handled: true, value: Math.sqrt(phpToNumber(args[0])) };
      case 'min': {
        const list = args.length === 1 && isPhpArray(args[0]) ? Array.from(args[0].map.values()) : args;
        return { handled: true, value: list.length ? Math.min(...list.map(phpToNumber)) : null };
      }
      case 'max': {
        const list = args.length === 1 && isPhpArray(args[0]) ? Array.from(args[0].map.values()) : args;
        return { handled: true, value: list.length ? Math.max(...list.map(phpToNumber)) : null };
      }
      case 'rand':
      case 'mt_rand':
      case 'random_int': {
        const min = args[0] !== undefined ? phpToNumber(args[0]) : 0;
        const max = args[1] !== undefined ? phpToNumber(args[1]) : 2147483647;
        return { handled: true, value: Math.floor(Math.random() * (max - min + 1)) + min };
      }
      case 'random_bytes':
        return { handled: true, value: crypto.randomBytes(Math.max(1, phpToNumber(args[0] ?? 16))).toString('latin1') };
      case 'bin2hex':
        return { handled: true, value: Buffer.from(phpToString(args[0]), 'latin1').toString('hex') };
      case 'hex2bin':
        return { handled: true, value: Buffer.from(phpToString(args[0]), 'hex').toString('utf-8') };
      case 'uniqid':
        return { handled: true, value: phpToString(args[0] ?? '') + Date.now().toString(16) + Math.floor(Math.random() * 0xffff).toString(16) };
      case 'md5':
        return { handled: true, value: crypto.createHash('md5').update(phpToString(args[0])).digest('hex') };
      case 'sha1':
        return { handled: true, value: crypto.createHash('sha1').update(phpToString(args[0])).digest('hex') };
      case 'hash': {
        const algo = phpToString(args[0]).toLowerCase();
        return { handled: true, value: crypto.createHash(algo).update(phpToString(args[1])).digest('hex') };
      }
      case 'hash_hmac': {
        const algo = phpToString(args[0]).toLowerCase();
        return { handled: true, value: crypto.createHmac(algo, phpToString(args[2])).update(phpToString(args[1])).digest('hex') };
      }
      case 'time':
        return { handled: true, value: Math.floor(Date.now() / 1000) };
      case 'microtime': {
        const sec = Date.now() / 1000;
        if (phpTruthy(args[0])) return { handled: true, value: sec };
        const whole = Math.floor(sec);
        return { handled: true, value: `${(sec - whole).toFixed(6)} ${whole}` };
      }
      case 'date':
      case 'gmdate': {
        const fmt = phpToString(args[0] ?? 'Y-m-d H:i:s');
        const ts = args[1] !== undefined ? new Date(phpToNumber(args[1]) * 1000) : new Date();
        return { handled: true, value: formatPhpDate(fmt, ts, fn === 'gmdate') };
      }
      case 'strtotime': {
        const ts = Date.parse(phpToString(args[0]));
        return { handled: true, value: Number.isNaN(ts) ? false : Math.floor(ts / 1000) };
      }
      case 'sleep': {
        const s = Math.min(5, Math.max(0, phpToNumber(args[0])));
        await new Promise(r => setTimeout(r, s * 1000));
        return { handled: true, value: 0 };
      }
      case 'usleep': {
        const ms = Math.min(3000, Math.max(0, phpToNumber(args[0]) / 1000));
        await new Promise(r => setTimeout(r, ms));
        return { handled: true, value: null };
      }
      case 'filter_var': {
        const v = phpToString(args[0]);
        const filter = phpToNumber(args[1]);
        if (filter === 275) return { handled: true, value: net.isIP(v) ? v : false };
        if (filter === 273) {
          try {
            new URL(v);
            return { handled: true, value: v };
          } catch {
            return { handled: true, value: false };
          }
        }
        if (filter === 274) {
          return { handled: true, value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? v : false };
        }
        return { handled: true, value: v };
      }
      case 'ip2long': {
        const parts = phpToString(args[0]).split('.').map(Number);
        if (parts.length !== 4 || parts.some(p => Number.isNaN(p) || p < 0 || p > 255)) return { handled: true, value: false };
        return { handled: true, value: ((parts[0] << 24) >>> 0) + (parts[1] << 16) + (parts[2] << 8) + parts[3] };
      }
      case 'long2ip': {
        const n = phpToNumber(args[0]) >>> 0;
        return { handled: true, value: `${(n >>> 24) & 255}.${(n >>> 16) & 255}.${(n >>> 8) & 255}.${n & 255}` };
      }
      case 'gethostbyname': {
        const host = phpToString(args[0]);
        if (net.isIP(host)) return { handled: true, value: host };
        try {
          const res = await dns.lookup(host, { family: 4 });
          return { handled: true, value: res.address };
        } catch {
          return { handled: true, value: host };
        }
      }

      // --- Sandboxed Filesystem + Remote HTTP file_get_contents ---
      case 'file_get_contents': {
        const target = phpToString(args[0]);
        if (/^https?:\/\//i.test(target)) {
          const safe = await isSafePublicUrl(target);
          if (!safe) return { handled: true, value: false };
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 10000);
          try {
            const resp = await fetch(target, {
              headers: { 'User-Agent': 'NIGHTHOST-PHP/8.3' },
              signal: controller.signal,
            });
            return { handled: true, value: await resp.text() };
          } catch {
            return { handled: true, value: false };
          } finally {
            clearTimeout(timer);
          }
        }
        const local = resolveSandboxedSitePath(siteDir, target);
        if (!local || !fs.existsSync(local)) return { handled: true, value: false };
        return { handled: true, value: fs.readFileSync(local, 'utf-8') };
      }
      case 'file_put_contents': {
        const target = phpToString(args[0]);
        const data = isPhpArray(args[1]) ? Array.from(args[1].map.values()).map(phpToString).join('') : phpToString(args[1]);
        const flags = args[2] ? phpToNumber(args[2]) : 0;
        const local = resolveSandboxedSitePath(siteDir, target);
        if (!local) return { handled: true, value: false };
        const parent = path.dirname(local);
        if (!fs.existsSync(parent)) fs.mkdirSync(parent, { recursive: true });
        if ((flags & 8) !== 0 && fs.existsSync(local)) {
          fs.appendFileSync(local, data, 'utf-8');
        } else {
          fs.writeFileSync(local, data, 'utf-8');
        }
        return { handled: true, value: Buffer.byteLength(data, 'utf-8') };
      }
      case 'file': {
        const local = resolveSandboxedSitePath(siteDir, phpToString(args[0]));
        if (!local || !fs.existsSync(local)) return { handled: true, value: false };
        const lines = fs.readFileSync(local, 'utf-8').split(/\r?\n/);
        if (lines.length && lines[lines.length - 1] === '') lines.pop();
        return { handled: true, value: jsToPhpValue(lines) };
      }
      case 'file_exists':
      case 'is_file': {
        const local = resolveSandboxedSitePath(siteDir, phpToString(args[0]));
        return { handled: true, value: Boolean(local && fs.existsSync(local) && (fn === 'file_exists' || fs.statSync(local).isFile())) };
      }
      case 'is_dir': {
        const local = resolveSandboxedSitePath(siteDir, phpToString(args[0]));
        return { handled: true, value: Boolean(local && fs.existsSync(local) && fs.statSync(local).isDirectory()) };
      }
      case 'mkdir': {
        const local = resolveSandboxedSitePath(siteDir, phpToString(args[0]));
        if (!local) return { handled: true, value: false };
        fs.mkdirSync(local, { recursive: true });
        return { handled: true, value: true };
      }
      case 'unlink': {
        const local = resolveSandboxedSitePath(siteDir, phpToString(args[0]));
        if (!local || !fs.existsSync(local)) return { handled: true, value: false };
        fs.unlinkSync(local);
        return { handled: true, value: true };
      }
      case 'rename': {
        const srcP = resolveSandboxedSitePath(siteDir, phpToString(args[0]));
        const dstP = resolveSandboxedSitePath(siteDir, phpToString(args[1]));
        if (!srcP || !dstP || !fs.existsSync(srcP)) return { handled: true, value: false };
        fs.renameSync(srcP, dstP);
        return { handled: true, value: true };
      }
      case 'filesize': {
        const local = resolveSandboxedSitePath(siteDir, phpToString(args[0]));
        if (!local || !fs.existsSync(local)) return { handled: true, value: false };
        return { handled: true, value: fs.statSync(local).size };
      }
      case 'scandir': {
        const local = resolveSandboxedSitePath(siteDir, phpToString(args[0]));
        if (!local || !fs.existsSync(local)) return { handled: true, value: false };
        return { handled: true, value: jsToPhpValue(['.', '..', ...fs.readdirSync(local)]) };
      }
      case 'glob': {
        const pat = phpToString(args[0]);
        const dir = path.dirname(pat);
        const filePat = path.basename(pat);
        const localDir = resolveSandboxedSitePath(siteDir, dir === '.' ? '' : dir);
        if (!localDir || !fs.existsSync(localDir)) return { handled: true, value: makePhpArray() };
        const matched = fs
          .readdirSync(localDir)
          .filter(name => globMatch(filePat, name))
          .map(name => (dir === '.' ? name : `${dir}/${name}`));
        return { handled: true, value: jsToPhpValue(matched) };
      }
      case 'basename':
        return { handled: true, value: path.basename(phpToString(args[0])) };
      case 'dirname':
        return { handled: true, value: path.dirname(phpToString(args[0])) };
      case 'realpath': {
        const local = resolveSandboxedSitePath(siteDir, phpToString(args[0]));
        return { handled: true, value: local && fs.existsSync(local) ? local : false };
      }
      case 'fopen': {
        const target = phpToString(args[0]);
        const mode = phpToString(args[1] || 'r');
        const local = resolveSandboxedSitePath(siteDir, target);
        if (!local) return { handled: true, value: false };
        if (mode.startsWith('r') && !fs.existsSync(local)) return { handled: true, value: false };
        if ((mode.startsWith('w') || mode.startsWith('a')) && !fs.existsSync(path.dirname(local))) {
          fs.mkdirSync(path.dirname(local), { recursive: true });
        }
        if (mode.startsWith('w')) fs.writeFileSync(local, '', 'utf-8');
        else if (mode.startsWith('a') && !fs.existsSync(local)) fs.writeFileSync(local, '', 'utf-8');
        const lines = fs.existsSync(local) ? fs.readFileSync(local, 'utf-8').split(/(?<=\n)/) : [];
        const id = nextHandleId++;
        fileHandles.set(id, { filePath: local, mode, pos: 0, lines });
        return { handled: true, value: id };
      }
      case 'fwrite':
      case 'fputs': {
        const id = phpToNumber(args[0]);
        const h = fileHandles.get(id);
        if (!h || h.closed) return { handled: true, value: false };
        const str = phpToString(args[1]);
        if (h.socket) {
          h.socket.write(str);
          return { handled: true, value: Buffer.byteLength(str) };
        }
        fs.appendFileSync(h.filePath, str, 'utf-8');
        return { handled: true, value: Buffer.byteLength(str) };
      }
      case 'fread':
      case 'fgets': {
        const id = phpToNumber(args[0]);
        const h = fileHandles.get(id);
        if (!h || h.closed) return { handled: true, value: false };
        if (h.socket) {
          const data = await new Promise<string>((resolve) => {
            const sock = h.socket!;
            if (h.buffer && h.buffer.length > 0) {
              const s = h.buffer.toString('utf-8');
              h.buffer = Buffer.alloc(0);
              resolve(s);
              return;
            }
            const timer = setTimeout(() => resolve(''), 3000);
            sock.once('data', (chunk) => {
              clearTimeout(timer);
              resolve(chunk.toString('utf-8'));
            });
            sock.once('end', () => {
              clearTimeout(timer);
              h.closed = true;
              resolve('');
            });
          });
          return { handled: true, value: data || false };
        }
        if (fn === 'fgets') {
          if (!h.lines || h.pos >= h.lines.length) return { handled: true, value: false };
          return { handled: true, value: h.lines[h.pos++] };
        }
        const content = fs.readFileSync(h.filePath, 'utf-8');
        if (h.pos >= content.length) return { handled: true, value: '' };
        const len = args[1] ? phpToNumber(args[1]) : content.length;
        const slice = content.slice(h.pos, h.pos + len);
        h.pos += slice.length;
        return { handled: true, value: slice };
      }
      case 'feof': {
        const h = fileHandles.get(phpToNumber(args[0]));
        if (!h || h.closed) return { handled: true, value: true };
        return { handled: true, value: h.lines ? h.pos >= h.lines.length : true };
      }
      case 'fclose': {
        const id = phpToNumber(args[0]);
        const h = fileHandles.get(id);
        if (!h) return { handled: true, value: false };
        h.closed = true;
        try {
          h.socket?.destroy();
        } catch {
          // ignore
        }
        fileHandles.delete(id);
        return { handled: true, value: true };
      }

      // --- Sockets (for Proxy Checkers & Port Scanners) ---
      case 'fsockopen':
      case 'pfsockopen': {
        const rawHost = phpToString(args[0]).replace(/^(tcp|ssl|tls):\/\//i, '');
        const port = phpToNumber(args[1] ?? 80);
        const timeoutMs = Math.min(8000, Math.max(300, phpToNumber(args[4] ?? 4) * 1000));
        if (!rawHost || port <= 0 || port > 65535) return { handled: true, value: false };
        const allowed = net.isIP(rawHost)
          ? !isPrivateOrReservedIp(rawHost)
          : await isSafePublicUrl(`http://${rawHost}:${port}`);
        if (!allowed) return { handled: true, value: false };

        const sockResult = await new Promise<net.Socket | null>((resolve) => {
          const sock = net.createConnection({ host: rawHost, port, timeout: timeoutMs });
          sock.once('connect', () => resolve(sock));
          sock.once('error', () => {
            sock.destroy();
            resolve(null);
          });
          sock.once('timeout', () => {
            sock.destroy();
            resolve(null);
          });
        });
        if (!sockResult) return { handled: true, value: false };
        const id = nextHandleId++;
        const fh: FileHandle = { filePath: '', mode: 'r+', pos: 0, socket: sockResult, buffer: Buffer.alloc(0) };
        sockResult.on('data', (chunk) => {
          fh.buffer = Buffer.concat([fh.buffer || Buffer.alloc(0), chunk]);
        });
        fileHandles.set(id, fh);
        return { handled: true, value: id };
      }

      // --- cURL & cURL Multi ---
      case 'curl_init': {
        const id = nextHandleId++;
        curlHandles.set(id, {
          url: args[0] ? phpToString(args[0]) : '',
          method: 'GET',
          headers: {},
          postFields: undefined,
          timeoutSec: 10,
          returnTransfer: false,
          followLocation: true,
          includeHeaders: false,
          nobody: false,
          lastInfo: {},
          lastError: '',
          lastErrno: 0,
        });
        return { handled: true, value: id };
      }
      case 'curl_setopt': {
        const ch = curlHandles.get(phpToNumber(args[0]));
        if (!ch) return { handled: true, value: false };
        const opt = phpToNumber(args[1]);
        const val = args[2];
        if (opt === 10002) ch.url = phpToString(val);
        else if (opt === 19913) ch.returnTransfer = phpTruthy(val);
        else if (opt === 47 && phpTruthy(val)) ch.method = 'POST';
        else if (opt === 10015) ch.postFields = val;
        else if (opt === 10036) ch.method = phpToString(val).toUpperCase();
        else if (opt === 13) ch.timeoutSec = Math.max(1, phpToNumber(val));
        else if (opt === 155) ch.timeoutSec = Math.max(1, phpToNumber(val) / 1000);
        else if (opt === 52) ch.followLocation = phpTruthy(val);
        else if (opt === 42) ch.includeHeaders = phpTruthy(val);
        else if (opt === 44) ch.nobody = phpTruthy(val);
        else if (opt === 10018) ch.headers['User-Agent'] = phpToString(val);
        else if (opt === 10004) ch.proxy = phpToString(val);
        else if (opt === 10023 && isPhpArray(val)) {
          for (const hline of val.map.values()) {
            const s = phpToString(hline);
            const idx = s.indexOf(':');
            if (idx > 0) ch.headers[s.slice(0, idx).trim()] = s.slice(idx + 1).trim();
          }
        }
        return { handled: true, value: true };
      }
      case 'curl_setopt_array': {
        const id = phpToNumber(args[0]);
        if (isPhpArray(args[1])) {
          for (const [opt, val] of args[1].map.entries()) {
            await callBuiltin('curl_setopt', [id, opt, val]);
          }
        }
        return { handled: true, value: true };
      }
      case 'curl_exec': {
        const ch = curlHandles.get(phpToNumber(args[0]));
        if (!ch) return { handled: true, value: false };
        return { handled: true, value: await runCurlHandle(ch) };
      }
      case 'curl_getinfo': {
        const ch = curlHandles.get(phpToNumber(args[0]));
        if (!ch) return { handled: true, value: false };
        const opt = args[1] !== undefined ? phpToNumber(args[1]) : 0;
        if (opt === 2097154) return { handled: true, value: ch.lastInfo.http_code ?? 0 };
        if (opt === 3145731) return { handled: true, value: ch.lastInfo.total_time ?? 0 };
        if (opt === 1048577) return { handled: true, value: ch.lastInfo.url ?? ch.url };
        return { handled: true, value: jsToPhpValue(ch.lastInfo) };
      }
      case 'curl_error': {
        const ch = curlHandles.get(phpToNumber(args[0]));
        return { handled: true, value: ch ? ch.lastError : '' };
      }
      case 'curl_errno': {
        const ch = curlHandles.get(phpToNumber(args[0]));
        return { handled: true, value: ch ? ch.lastErrno : 0 };
      }
      case 'curl_close': {
        curlHandles.delete(phpToNumber(args[0]));
        return { handled: true, value: null };
      }
      case 'curl_multi_init': {
        const mid = nextHandleId++;
        curlMultiHandles.set(mid, new Set());
        return { handled: true, value: mid };
      }
      case 'curl_multi_add_handle': {
        const m = curlMultiHandles.get(phpToNumber(args[0]));
        if (m) m.add(phpToNumber(args[1]));
        return { handled: true, value: 0 };
      }
      case 'curl_multi_exec': {
        const m = curlMultiHandles.get(phpToNumber(args[0]));
        if (m) {
          const pending = Array.from(m)
            .map(id => curlHandles.get(id))
            .filter((ch): ch is CurlHandle => Boolean(ch && ch.lastResponse === undefined));
          await Promise.all(pending.map(ch => runCurlHandle(ch)));
        }
        return { handled: true, value: 0 };
      }
      case 'curl_multi_select':
        return { handled: true, value: 0 };
      case 'curl_multi_getcontent': {
        const ch = curlHandles.get(phpToNumber(args[0]));
        return { handled: true, value: ch?.lastResponse ?? '' };
      }
      case 'curl_multi_remove_handle': {
        const m = curlMultiHandles.get(phpToNumber(args[0]));
        if (m) m.delete(phpToNumber(args[1]));
        return { handled: true, value: 0 };
      }
      case 'curl_multi_close': {
        curlMultiHandles.delete(phpToNumber(args[0]));
        return { handled: true, value: null };
      }

      default:
        return { handled: false, value: undefined };
    }
  };

  const invokeByName = async (name: string, args: any[]): Promise<any> => {
    const low = name.toLowerCase();
    const userFn = userFuncs.get(low);
    if (userFn) return userFn(...args);
    const built = await callBuiltin(low, args);
    if (built.handled) return built.value;
    return null;
  };

  // Interpolate variables inside double-quoted strings / heredocs
  const interpolateString = (raw: string, scope: Record<string, any>): string => {
    const TOKEN = '\u0000NH_ESC_DOLLAR\u0000';
    let s = raw.replace(/\\\$/g, TOKEN);
    // {$arr['k']} or {$arr["k"]} or {$var}
    s = s.replace(/\{\$([a-zA-Z_][a-zA-Z0-9_]*)(?:\[(['"]?)([^'"\]]+)\2\])?\}/g, (_m, varName, _q, key) => {
      const val = varName in scope ? scope[varName] : globalsScope[varName];
      if (key !== undefined && isPhpArray(val)) return phpToString(getPhpArray(val, key));
      return phpToString(val);
    });
    // $arr[key] or $var
    s = s.replace(/\$([a-zA-Z_][a-zA-Z0-9_]*)(?:\[(['"]?)([^'"\]]+)\2\])?/g, (_m, varName, _q, key) => {
      const val = varName in scope ? scope[varName] : globalsScope[varName];
      if (key !== undefined && isPhpArray(val)) return phpToString(getPhpArray(val, key));
      return phpToString(val);
    });
    return s.replaceAll(TOKEN, '$');
  };

  const scopeGlobalLinks = new WeakMap<Record<string, any>, Set<string>>();
  const isSuperGlobalName = (name: string) =>
    ['_GET', '_POST', '_REQUEST', '_COOKIE', '_FILES', '_SESSION', '_SERVER', '_ENV', 'GLOBALS'].includes(name);

  const readVar = (name: string, scope: Record<string, any>) => {
    if (isSuperGlobalName(name)) {
      return globalsScope[name];
    }
    if (scope !== globalsScope && scopeGlobalLinks.get(scope)?.has(name)) {
      return globalsScope[name];
    }
    return scope[name];
  };

  const writeVar = (name: string, val: any, scope: Record<string, any>) => {
    if (isSuperGlobalName(name)) {
      globalsScope[name] = val;
      return;
    }
    if (scope !== globalsScope && scopeGlobalLinks.get(scope)?.has(name)) {
      globalsScope[name] = val;
      return;
    }
    scope[name] = val;
  };

  const execInclude = async (fileExprVal: any, once: boolean, scope: Record<string, any>): Promise<any> => {
    const relRaw = phpToString(fileExprVal).replace(/\\/g, '/').replace(/^\.\//, '');
    let incCode: string | null = null;
    let incKey = relRaw;

    const localCandidate = resolveSandboxedSitePath(siteDir, relRaw);
    if (localCandidate && fs.existsSync(localCandidate) && fs.statSync(localCandidate).isFile()) {
      incKey = localCandidate;
      if (once && includedOnce.has(incKey)) return 1;
      includedOnce.add(incKey);
      incCode = fs.readFileSync(localCandidate, 'utf-8');
    } else if (ctx.siteFiles) {
      const target =
        ctx.siteFiles[relRaw] ||
        Object.values(ctx.siteFiles).find(f => f.path.toLowerCase().endsWith('/' + relRaw.toLowerCase()));
      if (target && !target.isBinary) {
        incKey = target.path;
        if (once && includedOnce.has(incKey)) return 1;
        includedOnce.add(incKey);
        incCode = target.content;
      }
    }

    if (incCode === null) return false;
    const incTokens = tokenizePhp(incCode);
    const incAst = new PhpParser(incTokens).parseProgram();
    const res = await execStmtList(incAst, scope);
    if (res instanceof PhpReturnSignal) return res.value;
    return 1;
  };

  const evalLValPath = async (
    target: Expr,
    scope: Record<string, any>
  ): Promise<{ container: any; keys: Array<string | number | null> } | null> => {
    const keys: Array<string | number | null> = [];
    let cur: Expr = target;
    while (cur.kind === 'index') {
      const idx = cur.index ? await evalExpr(cur.index, scope) : null;
      keys.unshift(idx === null ? null : typeof idx === 'number' ? idx : phpToString(idx));
      cur = cur.target;
    }
    if (cur.kind === 'var') {
      return { container: cur.name, keys };
    }
    return null;
  };

  const assignTarget = async (target: Expr, op: string, valExpr: Expr, scope: Record<string, any>): Promise<any> => {
    const lval = await evalLValPath(target, scope);
    if (!lval) return await evalExpr(valExpr, scope);
    const rootName = lval.container as string;

    const applyOp = (curVal: any, rhs: any) => {
      switch (op) {
        case '=': return rhs;
        case '+=': return phpToNumber(curVal) + phpToNumber(rhs);
        case '-=': return phpToNumber(curVal) - phpToNumber(rhs);
        case '*=': return phpToNumber(curVal) * phpToNumber(rhs);
        case '/=': return phpToNumber(rhs) === 0 ? 0 : phpToNumber(curVal) / phpToNumber(rhs);
        case '%=': return phpToNumber(rhs) === 0 ? 0 : phpToNumber(curVal) % phpToNumber(rhs);
        case '.=': return phpToString(curVal) + phpToString(rhs);
        case '??=': return curVal === undefined || curVal === null ? rhs : curVal;
        default: return rhs;
      }
    };

    const rhs = await evalExpr(valExpr, scope);
    if (lval.keys.length === 0) {
      const next = applyOp(readVar(rootName, scope), rhs);
      writeVar(rootName, next, scope);
      return next;
    }

    let rootObj = readVar(rootName, scope);
    if (!isPhpArray(rootObj)) {
      rootObj = makePhpArray();
      writeVar(rootName, rootObj, scope);
    }

    let curArr: PhpArray = rootObj;
    for (let kIdx = 0; kIdx < lval.keys.length - 1; kIdx++) {
      const key = lval.keys[kIdx];
      let child = key !== null ? getPhpArray(curArr, key) : undefined;
      if (!isPhpArray(child)) {
        child = makePhpArray();
        setPhpArray(curArr, key, child);
      }
      curArr = child;
    }
    const lastKey = lval.keys[lval.keys.length - 1];
    const prevVal = lastKey !== null ? getPhpArray(curArr, lastKey) : undefined;
    const finalVal = applyOp(prevVal, rhs);
    setPhpArray(curArr, lastKey, finalVal);
    return finalVal;
  };

  const evalExpr = async (expr: Expr, scope: Record<string, any>): Promise<any> => {
    if (++executionSteps > MAX_STEPS) throw new PhpExitSignal(1);

    switch (expr.kind) {
      case 'lit':
        return expr.value;
      case 'dstring':
        return interpolateString(expr.value, scope);
      case 'var':
        return readVar(expr.name, scope);
      case 'ident':
        return constants.has(expr.name) ? constants.get(expr.name) : expr.name;
      case 'suppress':
        try {
          return await evalExpr(expr.expr, scope);
        } catch {
          return null;
        }
      case 'array': {
        const arr = makePhpArray();
        for (const item of expr.items) {
          const val = await evalExpr(item.val, scope);
          if (item.key) {
            const k = await evalExpr(item.key, scope);
            setPhpArray(arr, typeof k === 'number' ? k : phpToString(k), val);
          } else {
            setPhpArray(arr, null, val);
          }
        }
        return arr;
      }
      case 'index': {
        const target = await evalExpr(expr.target, scope);
        const key = expr.index ? await evalExpr(expr.index, scope) : null;
        if (isPhpArray(target) && key !== null) {
          return getPhpArray(target, typeof key === 'number' ? key : phpToString(key));
        }
        if (typeof target === 'string' && key !== null) {
          return target[phpToNumber(key)] ?? '';
        }
        return undefined;
      }
      case 'prop': {
        const target = await evalExpr(expr.target, scope);
        if (target && typeof target === 'object') {
          if (isPhpArray(target)) return getPhpArray(target, expr.prop);
          return target[expr.prop];
        }
        return undefined;
      }
      case 'assign':
        return assignTarget(expr.target, expr.op, expr.val, scope);
      case 'isset': {
        for (const t of expr.targets) {
          const v = await evalExpr(t, scope);
          if (v === undefined || v === null) return false;
        }
        return true;
      }
      case 'empty': {
        const v = await evalExpr(expr.target, scope);
        return !phpTruthy(v);
      }
      case 'includeExpr': {
        const target = await evalExpr(expr.expr, scope);
        return execInclude(target, expr.once, scope);
      }
      case 'cast': {
        const v = await evalExpr(expr.expr, scope);
        switch (expr.toType) {
          case 'int':
          case 'integer': return Math.trunc(phpToNumber(v));
          case 'float':
          case 'double': return phpToNumber(v);
          case 'string': return phpToString(v);
          case 'bool':
          case 'boolean': return phpTruthy(v);
          case 'array': return isPhpArray(v) ? v : makePhpArray([[null, v]]);
          default: return v;
        }
      }
      case 'unary': {
        if (expr.op === '++' || expr.op === '--') {
          const delta = expr.op === '++' ? 1 : -1;
          const prev = phpToNumber(await evalExpr(expr.expr, scope));
          const next = prev + delta;
          if (expr.expr.kind === 'var') {
            writeVar(expr.expr.name, next, scope);
          } else {
            await assignTarget(expr.expr, '=', { kind: 'lit', value: next }, scope);
          }
          return expr.postfix ? prev : next;
        }
        const v = await evalExpr(expr.expr, scope);
        if (expr.op === '!') return !phpTruthy(v);
        if (expr.op === '-') return -phpToNumber(v);
        if (expr.op === '+') return +phpToNumber(v);
        if (expr.op === '~') return ~phpToNumber(v);
        return v;
      }
      case 'binary': {
        if (expr.op === '&&') {
          if (!phpTruthy(await evalExpr(expr.left, scope))) return false;
          return phpTruthy(await evalExpr(expr.right, scope));
        }
        if (expr.op === '||') {
          if (phpTruthy(await evalExpr(expr.left, scope))) return true;
          return phpTruthy(await evalExpr(expr.right, scope));
        }
        if (expr.op === '??') {
          const l = await evalExpr(expr.left, scope);
          if (l !== undefined && l !== null) return l;
          return evalExpr(expr.right, scope);
        }
        const l = await evalExpr(expr.left, scope);
        const r = await evalExpr(expr.right, scope);
        switch (expr.op) {
          case '.': return phpToString(l) + phpToString(r);
          case '+':
            if (isPhpArray(l) && isPhpArray(r)) {
              const merged = makePhpArray();
              for (const [k, v] of l.map.entries()) setPhpArray(merged, k, v);
              for (const [k, v] of r.map.entries()) {
                if (!merged.map.has(k)) setPhpArray(merged, k, v);
              }
              return merged;
            }
            return phpToNumber(l) + phpToNumber(r);
          case '-': return phpToNumber(l) - phpToNumber(r);
          case '*': return phpToNumber(l) * phpToNumber(r);
          case '/': return phpToNumber(r) === 0 ? 0 : phpToNumber(l) / phpToNumber(r);
          case '%': return phpToNumber(r) === 0 ? 0 : phpToNumber(l) % phpToNumber(r);
          case '**': return Math.pow(phpToNumber(l), phpToNumber(r));
          case '&': return phpToNumber(l) & phpToNumber(r);
          case '|': return phpToNumber(l) | phpToNumber(r);
          case '^': return phpToNumber(l) ^ phpToNumber(r);
          case '<<': return phpToNumber(l) << phpToNumber(r);
          case '>>': return phpToNumber(l) >> phpToNumber(r);
          case '==': return phpLooseEqual(l, r);
          case '!=':
          case '<>': return !phpLooseEqual(l, r);
          case '===': return l === r || ((l === undefined || l === null) && (r === undefined || r === null));
          case '!==': return !(l === r || ((l === undefined || l === null) && (r === undefined || r === null)));
          case '<': return phpToNumber(l) < phpToNumber(r);
          case '<=': return phpToNumber(l) <= phpToNumber(r);
          case '>': return phpToNumber(l) > phpToNumber(r);
          case '>=': return phpToNumber(l) >= phpToNumber(r);
          case '<=>': {
            const nl = phpToNumber(l);
            const nr = phpToNumber(r);
            return nl < nr ? -1 : nl > nr ? 1 : 0;
          }
          case 'xor': return phpTruthy(l) !== phpTruthy(r);
          default: return null;
        }
      }
      case 'ternary': {
        const c = await evalExpr(expr.cond, scope);
        if (!expr.ifTrue) {
          return phpTruthy(c) ? c : await evalExpr(expr.ifFalse, scope);
        }
        return phpTruthy(c) ? await evalExpr(expr.ifTrue, scope) : await evalExpr(expr.ifFalse, scope);
      }
      case 'closure': {
        const captured: Record<string, any> = {};
        if (expr.arrowExpr) {
          Object.assign(captured, scope);
        } else {
          for (const u of expr.uses) {
            captured[u] = readVar(u, scope);
          }
        }
        return async (...callArgs: any[]) => {
          const fnScope: Record<string, any> = { ...captured };
          for (let idx = 0; idx < expr.params.length; idx++) {
            const p = expr.params[idx];
            fnScope[p.name] =
              idx < callArgs.length && callArgs[idx] !== undefined
                ? callArgs[idx]
                : p.defaultExpr
                ? await evalExpr(p.defaultExpr, fnScope)
                : null;
          }
          if (expr.arrowExpr) {
            return evalExpr(expr.arrowExpr, fnScope);
          }
          const sig = await execStmtList(expr.body, fnScope);
          if (sig instanceof PhpReturnSignal) return sig.value;
          return null;
        };
      }
      case 'call': {
        const args: any[] = [];
        for (const a of expr.args) args.push(await evalExpr(a, scope));
        if (expr.callee.kind === 'ident') {
          return invokeByName(expr.callee.name, args);
        }
        const fnVal = await evalExpr(expr.callee, scope);
        if (typeof fnVal === 'function') return fnVal(...args);
        if (typeof fnVal === 'string') return invokeByName(fnVal, args);
        return null;
      }
    }
  };

  const execStmt = async (stmt: Stmt, scope: Record<string, any>): Promise<any> => {
    if (++executionSteps > MAX_STEPS) throw new PhpExitSignal(1);

    switch (stmt.kind) {
      case 'html':
        writeOut(stmt.text);
        return null;
      case 'block':
        return execStmtList(stmt.stmts, scope);
      case 'expr':
        await evalExpr(stmt.expr, scope);
        return null;
      case 'echo':
        for (const e of stmt.exprs) {
          writeOut(phpToString(await evalExpr(e, scope)));
        }
        return null;
      case 'return':
        return new PhpReturnSignal(stmt.expr ? await evalExpr(stmt.expr, scope) : null);
      case 'break':
        return new PhpBreakSignal(stmt.levels);
      case 'continue':
        return new PhpContinueSignal(stmt.levels);
      case 'exit': {
        if (stmt.expr) writeOut(phpToString(await evalExpr(stmt.expr, scope)));
        throw new PhpExitSignal(0);
      }
      case 'global': {
        let links = scopeGlobalLinks.get(scope);
        if (!links) {
          links = new Set<string>();
          scopeGlobalLinks.set(scope, links);
        }
        for (const v of stmt.vars) {
          links.add(v);
        }
        return null;
      }
      case 'unset':
        for (const t of stmt.targets) {
          const lval = await evalLValPath(t, scope);
          if (!lval) continue;
          const rootName = lval.container as string;
          if (lval.keys.length === 0) {
            delete scope[rootName];
          } else {
            let cur = readVar(rootName, scope);
            for (let i = 0; i < lval.keys.length - 1; i++) {
              const k = lval.keys[i];
              if (!isPhpArray(cur) || k === null) {
                cur = null;
                break;
              }
              cur = getPhpArray(cur, k);
            }
            const last = lval.keys[lval.keys.length - 1];
            if (isPhpArray(cur) && last !== null) {
              cur.map.delete(last);
              if (/^-?\d+$/.test(String(last))) cur.map.delete(Number(last));
            }
          }
        }
        return null;
      case 'include': {
        const target = await evalExpr(stmt.expr, scope);
        await execInclude(target, stmt.once, scope);
        return null;
      }
      case 'if': {
        for (const br of stmt.branches) {
          if (phpTruthy(await evalExpr(br.cond, scope))) {
            return execStmtList(br.body, scope);
          }
        }
        if (stmt.elseBody) return execStmtList(stmt.elseBody, scope);
        return null;
      }
      case 'while': {
        while (phpTruthy(await evalExpr(stmt.cond, scope))) {
          const sig = await execStmtList(stmt.body, scope);
          if (sig instanceof PhpReturnSignal) return sig;
          if (sig instanceof PhpBreakSignal) {
            if (sig.levels > 1) return new PhpBreakSignal(sig.levels - 1);
            break;
          }
          if (sig instanceof PhpContinueSignal && sig.levels > 1) {
            return new PhpContinueSignal(sig.levels - 1);
          }
        }
        return null;
      }
      case 'doWhile': {
        do {
          const sig = await execStmtList(stmt.body, scope);
          if (sig instanceof PhpReturnSignal) return sig;
          if (sig instanceof PhpBreakSignal) {
            if (sig.levels > 1) return new PhpBreakSignal(sig.levels - 1);
            break;
          }
          if (sig instanceof PhpContinueSignal && sig.levels > 1) {
            return new PhpContinueSignal(sig.levels - 1);
          }
        } while (phpTruthy(await evalExpr(stmt.cond, scope)));
        return null;
      }
      case 'for': {
        for (const e of stmt.init) await evalExpr(e, scope);
        while (true) {
          let ok = true;
          for (const c of stmt.cond) ok = phpTruthy(await evalExpr(c, scope));
          if (!ok) break;
          const sig = await execStmtList(stmt.body, scope);
          if (sig instanceof PhpReturnSignal) return sig;
          if (sig instanceof PhpBreakSignal) {
            if (sig.levels > 1) return new PhpBreakSignal(sig.levels - 1);
            break;
          }
          if (sig instanceof PhpContinueSignal && sig.levels > 1) {
            return new PhpContinueSignal(sig.levels - 1);
          }
          for (const st of stmt.step) await evalExpr(st, scope);
        }
        return null;
      }
      case 'foreach': {
        const src = await evalExpr(stmt.source, scope);
        if (!isPhpArray(src)) return null;
        for (const [k, v] of Array.from(src.map.entries())) {
          if (stmt.keyVar) writeVar(stmt.keyVar, k, scope);
          writeVar(stmt.valVar, v, scope);
          const sig = await execStmtList(stmt.body, scope);
          if (sig instanceof PhpReturnSignal) return sig;
          if (sig instanceof PhpBreakSignal) {
            if (sig.levels > 1) return new PhpBreakSignal(sig.levels - 1);
            break;
          }
          if (sig instanceof PhpContinueSignal && sig.levels > 1) {
            return new PhpContinueSignal(sig.levels - 1);
          }
        }
        return null;
      }
      case 'switch': {
        const subject = await evalExpr(stmt.expr, scope);
        let matched = false;
        let defCase: { test?: Expr; body: Stmt[] } | undefined;
        for (const c of stmt.cases) {
          if (!c.test) {
            defCase = c;
            continue;
          }
          if (!matched) {
            const tv = await evalExpr(c.test, scope);
            if (!phpLooseEqual(subject, tv)) continue;
            matched = true;
          }
          const sig = await execStmtList(c.body, scope);
          if (sig instanceof PhpReturnSignal) return sig;
          if (sig instanceof PhpBreakSignal) {
            if (sig.levels > 1) return new PhpBreakSignal(sig.levels - 1);
            return null;
          }
        }
        if (!matched && defCase) {
          const sig = await execStmtList(defCase.body, scope);
          if (sig instanceof PhpReturnSignal) return sig;
        }
        return null;
      }
      case 'try': {
        try {
          const sig = await execStmtList(stmt.body, scope);
          if (sig) return sig;
        } catch (err) {
          if (err instanceof PhpExitSignal) throw err;
          if (stmt.catches.length > 0) {
            const caught = stmt.catches[0];
            if (caught.varName) {
              writeVar(caught.varName, { message: err instanceof PhpThrownError ? err.message : String(err) }, scope);
            }
            const sig = await execStmtList(caught.body, scope);
            if (sig) return sig;
          }
        } finally {
          if (stmt.finallyBody) await execStmtList(stmt.finallyBody, scope);
        }
        return null;
      }
      case 'throw': {
        const val = await evalExpr(stmt.expr, scope);
        throw new PhpThrownError(phpToString(val));
      }
      case 'funcDecl': {
        userFuncs.set(stmt.name.toLowerCase(), async (...callArgs: any[]) => {
          const fnScope: Record<string, any> = {};
          for (let idx = 0; idx < stmt.params.length; idx++) {
            const p = stmt.params[idx];
            fnScope[p.name] =
              idx < callArgs.length && callArgs[idx] !== undefined
                ? callArgs[idx]
                : p.defaultExpr
                ? await evalExpr(p.defaultExpr, fnScope)
                : null;
          }
          const sig = await execStmtList(stmt.body, fnScope);
          if (sig instanceof PhpReturnSignal) return sig.value;
          return null;
        });
        return null;
      }
    }
  };

  const execStmtList = async (stmts: Stmt[], scope: Record<string, any>): Promise<any> => {
    // Hoist function declarations so calls before definitions work in PHP
    for (const s of stmts) {
      if (s.kind === 'funcDecl') {
        await execStmt(s, scope);
      }
    }
    for (const s of stmts) {
      if (s.kind === 'funcDecl') continue;
      const sig = await execStmt(s, scope);
      if (
        sig instanceof PhpReturnSignal ||
        sig instanceof PhpBreakSignal ||
        sig instanceof PhpContinueSignal
      ) {
        return sig;
      }
    }
    return null;
  };

  let execError: string | undefined;
  try {
    const tokens = tokenizePhp(code);
    const ast = new PhpParser(tokens).parseProgram();
    await execStmtList(ast, globalsScope);
  } catch (err) {
    if (!(err instanceof PhpExitSignal)) {
      execError = err instanceof Error ? err.message : String(err);
    }
  } finally {
    // Persist PHP session changes if session_start() was used
    if (sessionStarted && activeSessionFile) {
      try {
        fs.writeFileSync(activeSessionFile, JSON.stringify(phpToJsPlain(phpSession)), 'utf-8');
      } catch {
        // ignore
      }
    }
    // Cleanup open sockets/files
    for (const fh of fileHandles.values()) {
      try {
        fh.socket?.destroy();
      } catch {
        // ignore
      }
    }
  }

  const finalBody = obStack.map(buf => buf.join('')).join('');
  const ctKey = Object.keys(responseHeaders).find(k => k.toLowerCase() === 'content-type');
  const contentType = ctKey ? responseHeaders[ctKey] : 'text/html; charset=utf-8';

  return {
    statusCode,
    headers: responseHeaders,
    cookies: setCookies,
    body: finalBody,
    contentType,
    error: execError,
  };
}

const BUILTIN_NAMES = new Set([
  'header','http_response_code','headers_sent','setcookie','session_start','session_destroy','session_id',
  'ob_start','ob_get_contents','ob_get_clean','ob_end_clean','flush','ob_flush','define','defined',
  'function_exists','phpversion','print_r','var_dump','json_encode','json_decode','strlen','mb_strlen',
  'substr','mb_substr','strpos','mb_strpos','stripos','strrpos','str_contains','str_starts_with','str_ends_with',
  'str_replace','str_ireplace','trim','ltrim','rtrim','strtolower','mb_strtolower','strtoupper','mb_strtoupper',
  'ucfirst','ucwords','str_repeat','str_pad','str_split','explode','implode','join','htmlspecialchars',
  'htmlentities','htmlspecialchars_decode','html_entity_decode','strip_tags','nl2br','addslashes','stripslashes',
  'number_format','sprintf','printf','urlencode','rawurlencode','urldecode','rawurldecode','base64_encode',
  'base64_decode','http_build_query','parse_url','preg_match','preg_match_all','preg_replace','preg_split',
  'preg_quote','count','sizeof','in_array','array_search','array_key_exists','key_exists','array_keys',
  'array_values','array_merge','array_slice','array_reverse','array_unique','array_sum','array_column',
  'array_chunk','array_map','array_filter','range','sort','rsort','usort','shuffle','is_array','is_string',
  'is_int','is_integer','is_long','is_float','is_double','is_numeric','is_bool','is_null','intval','floatval',
  'strval','boolval','gettype','abs','round','ceil','floor','pow','sqrt','min','max','rand','mt_rand',
  'random_int','random_bytes','bin2hex','hex2bin','uniqid','md5','sha1','hash','hash_hmac','time','microtime',
  'date','gmdate','strtotime','sleep','usleep','filter_var','ip2long','long2ip','gethostbyname',
  'file_get_contents','file_put_contents','file','file_exists','is_file','is_dir','mkdir','unlink','rename',
  'filesize','scandir','glob','basename','dirname','realpath','fopen','fwrite','fputs','fread','fgets','feof',
  'fclose','fsockopen','pfsockopen','curl_init','curl_setopt','curl_setopt_array','curl_exec','curl_getinfo',
  'curl_error','curl_errno','curl_close','curl_multi_init','curl_multi_add_handle','curl_multi_exec',
  'curl_multi_select','curl_multi_getcontent','curl_multi_remove_handle','curl_multi_close',
  'error_reporting','ini_set','set_time_limit','ignore_user_abort','date_default_timezone_set',
]);
