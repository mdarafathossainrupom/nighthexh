export async function resizeImageFileToDataUrl(
  file: File,
  maxDimension = 360,
  quality = 0.82
): Promise<{ dataUrl: string; sizeKb: number }> {
  const rawDataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.readAsDataURL(file);
  });

  if (!rawDataUrl.startsWith('data:image/')) {
    throw new Error('Invalid image file');
  }

  // Try resizing via HTMLCanvasElement in browser so uploaded avatars stay lightweight & crisp
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('Failed to decode image'));
      el.src = rawDataUrl;
    });

    const ratio = Math.min(1, maxDimension / Math.max(img.width || 1, img.height || 1));
    const width = Math.max(1, Math.round((img.width || maxDimension) * ratio));
    const height = Math.max(1, Math.round((img.height || maxDimension) * ratio));

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(img, 0, 0, width, height);
      const outUrl = canvas.toDataURL('image/webp', quality);
      const finalUrl = outUrl.startsWith('data:image/webp')
        ? outUrl
        : canvas.toDataURL('image/jpeg', quality);
      const b64 = finalUrl.split(',')[1] || '';
      const bytes = Math.ceil((b64.length * 3) / 4);
      return { dataUrl: finalUrl, sizeKb: Math.max(1, Math.round(bytes / 1024)) };
    }
  } catch {
    // Fallback to original data URL if canvas resize isn't supported
  }

  const b64 = rawDataUrl.split(',')[1] || '';
  const bytes = Math.ceil((b64.length * 3) / 4);
  return { dataUrl: rawDataUrl, sizeKb: Math.max(1, Math.round(bytes / 1024)) };
}
