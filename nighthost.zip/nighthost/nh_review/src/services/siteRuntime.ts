import fs from 'fs';
import path from 'path';
import net from 'net';
import { spawn, ChildProcess } from 'child_process';
import { fileURLToPath } from 'url';
import { HostedSite, SiteHealthReport } from '../types';
import { detectProjectRuntime, diagnoseRuntimeError, getMimeType } from './siteEngine';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '../..');
const RUNTIME_BASE_DIR = path.join(ROOT_DIR, 'data', 'sites_runtime');
const PY_SHIM_DIR = path.join(ROOT_DIR, 'data', 'py_shim');
const NODE_SHIM_DIR = path.join(ROOT_DIR, 'data', 'node_shim');

const SAFE_OS_ENV_ALLOWLIST = [
  'PATH',
  'HOME',
  'USER',
  'LOGNAME',
  'SHELL',
  'TMPDIR',
  'TEMP',
  'TMP',
  'LANG',
  'LC_ALL',
  'LC_CTYPE',
  'TZ',
  'SSL_CERT_FILE',
  'SSL_CERT_DIR',
] as const;

const BLOCKED_USER_ENV_KEYS = new Set([
  'PATH',
  'HOME',
  'PORT',
  'HOST',
  'NODE_OPTIONS',
  'NODE_PATH',
  'LD_PRELOAD',
  'LD_LIBRARY_PATH',
  'DYLD_INSERT_LIBRARIES',
  'DYLD_LIBRARY_PATH',
  'PYTHONPATH',
  'PYTHONHOME',
  'NH_AUTOHEAL_DIR',
  '__PROTO__',
  'CONSTRUCTOR',
  'PROTOTYPE',
]);

export function buildIsolatedChildEnv(
  baseEnv: NodeJS.ProcessEnv,
  userEnv: Record<string, string>,
  opts: { port: number; autoHealDir: string; nodePath: string }
): NodeJS.ProcessEnv {
  const isolated: NodeJS.ProcessEnv = {};

  for (const key of SAFE_OS_ENV_ALLOWLIST) {
    const val = baseEnv[key];
    if (typeof val === 'string' && val.length > 0) {
      isolated[key] = val;
    }
  }

  for (const [rawKey, rawVal] of Object.entries(userEnv || {})) {
    const cleanKey = String(rawKey || '').trim();
    if (!cleanKey || !/^[A-Za-z_][A-Za-z0-9_]*$/.test(cleanKey)) continue;
    const upper = cleanKey.toUpperCase();
    if (
      BLOCKED_USER_ENV_KEYS.has(upper) ||
      upper.startsWith('NIGHTHOST_') ||
      upper.startsWith('SUPABASE_') ||
      upper.startsWith('GEMINI_')
    ) {
      continue;
    }
    isolated[cleanKey] = String(rawVal ?? '');
  }

  isolated.PORT = String(opts.port);
  isolated.HOST = '127.0.0.1';
  isolated.NODE_ENV = 'production';
  isolated.PYTHONUNBUFFERED = '1';
  isolated.PYTHONIOENCODING = 'utf-8';
  isolated.NH_AUTOHEAL_DIR = opts.autoHealDir;
  isolated.NODE_PATH = opts.nodePath;

  return isolated;
}

export interface RuntimeProcessState {
  siteId: string;
  runtime: 'node' | 'python';
  entryFile: string;
  port: number;
  status: 'starting' | 'running' | 'error' | 'stopped';
  logs: string[];
  errorMessage?: string;
  lastActivity: number;
  updatedAt: string;
  crashCount?: number;
  lastCrashAt?: number;
  process?: ChildProcess;
  startPromise?: Promise<RuntimeProcessState | null>;
}

const NODE_PRELOAD_SCRIPT = `'use strict';
const net = require('net');
const targetPort = Number(process.env.PORT || 0);
if (targetPort > 0) {
  const origListen = net.Server.prototype.listen;
  net.Server.prototype.listen = function (...args) {
    if (args.length > 0) {
      if (typeof args[0] === 'number' || (typeof args[0] === 'string' && /^\\d+$/.test(args[0]))) {
        const p = Number(args[0]);
        if (p !== targetPort) args[0] = targetPort;
        if (typeof args[1] === 'string' && (args[1] === '0.0.0.0' || args[1] === '::')) {
          args[1] = '127.0.0.1';
        }
      } else if (args[0] && typeof args[0] === 'object' && typeof args[0].port === 'number') {
        if (args[0].port !== targetPort) {
          args[0] = { ...args[0], port: targetPort, host: '127.0.0.1' };
        }
      }
    }
    return origListen.apply(this, args);
  };
}
`;

const PYTHON_LAUNCHER_SCRIPT = `import os, sys, runpy, socketserver

shim_dir = os.path.dirname(os.path.abspath(__file__))
autoheal_dir = os.environ.get("NH_AUTOHEAL_DIR", "")
# Append at the end so real installed site-packages and user project files always take priority
if autoheal_dir and os.path.isdir(autoheal_dir) and autoheal_dir not in sys.path:
    sys.path.append(autoheal_dir)
if shim_dir not in sys.path:
    sys.path.append(shim_dir)

_target_port = int(os.environ.get("PORT", "0") or "0")
if _target_port > 0:
    _orig_tcp_init = socketserver.TCPServer.__init__
    def _nh_tcp_init(self, server_address, RequestHandlerClass, bind_and_activate=True):
        if isinstance(server_address, tuple) and len(server_address) >= 2:
            host, port = server_address[0], server_address[1]
            if isinstance(port, int) and port != _target_port:
                server_address = ("127.0.0.1", _target_port) + tuple(server_address[2:])
        return _orig_tcp_init(self, server_address, RequestHandlerClass, bind_and_activate=bind_and_activate)
    socketserver.TCPServer.__init__ = _nh_tcp_init

entry = sys.argv[1]
work_dir = os.path.dirname(os.path.abspath(entry))
if work_dir not in sys.path:
    sys.path.insert(0, work_dir)
os.chdir(work_dir)
os.environ.setdefault("LOCAL_DATA_DIR", os.path.join(work_dir, ".nh_data"))
sys.argv = [entry] + sys.argv[2:]
ns = runpy.run_path(entry, run_name="__main__")

# Auto-start ASGI/WSGI app instances (FastAPI/Starlette/Flask without explicit __main__ serve)
if _target_port > 0 and isinstance(ns, dict):
    candidate = ns.get("app") or ns.get("application") or ns.get("api")
    if candidate is not None and hasattr(candidate, "run") and callable(candidate.run):
        candidate.run(host="127.0.0.1", port=_target_port)
`;

const FLASK_SHIM_CODE = `import os, re, io, json, secrets, logging, mimetypes, urllib.parse, traceback, threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from types import SimpleNamespace

class HTTPException(Exception):
    def __init__(self, code=500, description=""):
        super().__init__(description)
        self.code = code
        self.description = description

def abort(code, description=""):
    raise HTTPException(code, description)

class _LocalProxy:
    def __init__(self, name="proxy"):
        self._tls = threading.local()
        self._name = name
    def _set(self, val):
        self._tls.current = val
    def _clear(self):
        self._tls.current = None
    def _get(self):
        cur = getattr(self._tls, "current", None)
        if cur is None:
            raise RuntimeError(f"Working outside of {self._name} context")
        return cur
    def __getattr__(self, item):
        return getattr(self._get(), item)
    def __getitem__(self, key):
        return self._get()[key]
    def __setitem__(self, key, val):
        self._get()[key] = val
    def __delitem__(self, key):
        del self._get()[key]
    def __contains__(self, key):
        return key in self._get()
    def __iter__(self):
        return iter(self._get())
    def __len__(self):
        return len(self._get())

request = _LocalProxy("request")
session = _LocalProxy("session")

_SESSIONS = {}
_SESSION_LOCK = threading.Lock()

class _CaseHeaders(dict):
    def get(self, key, default=None):
        lk = str(key).lower()
        for k, v in self.items():
            if str(k).lower() == lk:
                return v
        return default
    def __contains__(self, key):
        lk = str(key).lower()
        return any(str(k).lower() == lk for k in self.keys())

class _UploadedFile:
    def __init__(self, filename, content_bytes, content_type="application/octet-stream", name="file"):
        self.filename = filename or ""
        self.name = name
        self.content_type = content_type
        self._bytes = content_bytes
        self.stream = io.BytesIO(content_bytes)
    def read(self, n=-1):
        return self.stream.read(n)
    def seek(self, offset, whence=0):
        return self.stream.seek(offset, whence)
    def save(self, dst):
        with open(dst, "wb") as f:
            f.write(self._bytes)

def _parse_multipart(content_type, raw_body):
    form = {}
    files = {}
    m = re.search(r'boundary=(?:"([^"]+)"|([^;\\s]+))', content_type, re.I)
    if not m or not raw_body:
        return form, files
    boundary = (m.group(1) or m.group(2)).encode("latin-1")
    delim = b"--" + boundary
    parts = raw_body.split(delim)
    for part in parts[1:]:
        if part.startswith(b"--"):
            break
        if part.startswith(b"\\r\\n"):
            part = part[2:]
        if part.endswith(b"\\r\\n"):
            part = part[:-2]
        sep = part.find(b"\\r\\n\\r\\n")
        if sep == -1:
            continue
        hdr_raw = part[:sep].decode("utf-8", errors="replace")
        body_bytes = part[sep + 4:]
        disp = ""
        part_ct = "application/octet-stream"
        for hline in hdr_raw.split("\\r\\n"):
            if ":" in hline:
                hk, hv = hline.split(":", 1)
                if hk.strip().lower() == "content-disposition":
                    disp = hv.strip()
                elif hk.strip().lower() == "content-type":
                    part_ct = hv.strip()
        nm = re.search(r'name="([^"]*)"', disp)
        if not nm:
            continue
        field_name = nm.group(1)
        fnm = re.search(r'filename="([^"]*)"', disp)
        if fnm:
            files[field_name] = _UploadedFile(fnm.group(1), body_bytes, part_ct, field_name)
        else:
            form[field_name] = body_bytes.decode("utf-8", errors="replace")
    return form, files

class Response:
    def __init__(self, response="", status=200, headers=None, mimetype=None, content_type=None):
        self.data = response.encode("utf-8") if isinstance(response, str) else (response or b"")
        self.status_code = int(status)
        self.headers = dict(headers or {})
        ct = content_type or mimetype
        if ct and not any(k.lower() == "content-type" for k in self.headers):
            self.headers["Content-Type"] = ct
        elif not any(k.lower() == "content-type" for k in self.headers):
            self.headers["Content-Type"] = "text/html; charset=utf-8"
        self._set_cookies = []

def make_response(rv, status=None, headers=None):
    if isinstance(rv, Response):
        if status is not None:
            rv.status_code = int(status)
        if headers:
            rv.headers.update(headers)
        return rv
    if isinstance(rv, tuple):
        body = rv[0]
        st = rv[1] if len(rv) > 1 else 200
        hd = rv[2] if len(rv) > 2 else None
        return make_response(body, st, hd)
    if isinstance(rv, (dict, list)):
        return Response(json.dumps(rv, ensure_ascii=False), status=status or 200, headers=headers, content_type="application/json; charset=utf-8")
    return Response(str(rv if rv is not None else ""), status=status or 200, headers=headers)

def jsonify(*args, **kwargs):
    if args and kwargs:
        raise TypeError("jsonify() behavior undefined when passed both args and kwargs")
    data = args[0] if len(args) == 1 and not kwargs else (list(args) if args else kwargs)
    return Response(json.dumps(data, ensure_ascii=False), status=200, content_type="application/json; charset=utf-8")

def redirect(location, code=302):
    return Response("", status=code, headers={"Location": str(location)})

def url_for(endpoint, **values):
    if endpoint == "static":
        fn = str(values.get("filename", "")).lstrip("/")
        return f"/static/{fn}"
    return "/" + str(endpoint).lstrip("/")

def _eval_jinja_val(raw_expr, ctx):
    expr = raw_expr.strip()
    if (expr.startswith("'") and expr.endswith("'")) or (expr.startswith('"') and expr.endswith('"')):
        return expr[1:-1]
    if expr.startswith("url_for("):
        m = re.search(r"""url_for\\(\\s*['"]([^'"]+)['"](?:\\s*,\\s*filename\\s*=\\s*['"]([^'"]+)['"])?""", expr)
        if m:
            return url_for(m.group(1), filename=m.group(2) or "")
    parts = expr.split(".")
    val = ctx.get(parts[0])
    for p in parts[1:]:
        if isinstance(val, dict):
            val = val.get(p)
        elif hasattr(val, p):
            val = getattr(val, p)
        else:
            val = None
    return val

def _resolve_expr(expr, ctx):
    segs = [s.strip() for s in expr.split("|")]
    val = _eval_jinja_val(segs[0], ctx)
    for flt in segs[1:]:
        f = flt.lower()
        if f == "tojson":
            return json.dumps(val, ensure_ascii=False)
        elif f == "upper" and val is not None:
            val = str(val).upper()
        elif f == "lower" and val is not None:
            val = str(val).lower()
        elif f == "length":
            val = len(val) if val is not None else 0
    return "" if val is None else str(val)

def render_template_string(source, **context):
    ctx = dict(context)
    ctx.setdefault("url_for", url_for)

    def eval_if(m):
        cond = m.group(1).strip()
        truthy = bool(ctx.get(cond))
        return m.group(2) if truthy else (m.group(3) or "")
    out = re.sub(r"\\{%\\s*if\\s+([a-zA-Z0-9_]+)\\s*%\\}([\\s\\S]*?)(?:\\{%\\s*else\\s*%\\}([\\s\\S]*?))?\\{%\\s*endif\\s*%\\}", eval_if, source)
    out = re.sub(r"\\{\\{([\\s\\S]*?)\\}\\}", lambda m: _resolve_expr(m.group(1), ctx), out)
    out = re.sub(r"\\{%[\\s\\S]*?%\\}", "", out)
    return out

def send_from_directory(directory, path, **kwargs):
    safe = os.path.normpath(path.lstrip("/")).replace("\\\\", "/")
    if safe.startswith(".."):
        abort(403)
    full = os.path.join(directory, safe)
    if not os.path.isfile(full):
        abort(404)
    mime, _ = mimetypes.guess_type(full)
    with open(full, "rb") as f:
        return Response(f.read(), status=200, content_type=mime or "application/octet-stream")

def send_file(path_or_file, mimetype=None, as_attachment=False, download_name=None, **kwargs):
    headers = {}
    if as_attachment:
        fname = download_name or (os.path.basename(str(path_or_file)) if isinstance(path_or_file, (str, bytes, os.PathLike)) else "download.bin")
        headers["Content-Disposition"] = f'attachment; filename="{fname}"'
    if isinstance(path_or_file, (str, bytes, os.PathLike)):
        p = str(path_or_file)
        if not os.path.isfile(p):
            abort(404)
        mime = mimetype or mimetypes.guess_type(p)[0] or "application/octet-stream"
        with open(p, "rb") as f:
            return Response(f.read(), status=200, headers=headers, content_type=mime)
    data = path_or_file.read()
    return Response(data, status=200, headers=headers, content_type=mimetype or "application/octet-stream")

_active_app = None

def render_template(template_name, **context):
    tdir = _active_app.template_folder if _active_app else "templates"
    full = os.path.join(tdir, template_name)
    if not os.path.isfile(full):
        abort(404, f"Template {template_name} not found")
    with open(full, "r", encoding="utf-8", errors="replace") as f:
        return render_template_string(f.read(), **context)

class Flask:
    def __init__(self, import_name, static_folder="static", template_folder="templates", static_url_path="/static"):
        global _active_app
        _active_app = self
        self.import_name = import_name
        self.secret_key = ""
        self.root_path = os.getcwd()
        self.static_folder = os.path.join(self.root_path, static_folder) if static_folder and not os.path.isabs(static_folder) else static_folder
        self.template_folder = os.path.join(self.root_path, template_folder) if template_folder and not os.path.isabs(template_folder) else template_folder
        self.static_url_path = static_url_path or "/static"
        self.routes = []
        self.before_funcs = []
        self.after_funcs = []
        self.error_handlers = {}
        self.config = {}
        self.logger = logging.getLogger(import_name)

    def route(self, rule, methods=None, **options):
        allowed = [m.upper() for m in (methods or ["GET"])]
        regex_str = re.sub(r"<(?:[a-zA-Z_]+:)?([a-zA-Z0-9_]+)>", lambda m: f"(?P<{m.group(1)}>[^/]+)", rule)
        regex = re.compile("^" + regex_str + "$")
        def decorator(fn):
            self.routes.append((regex, allowed, fn))
            return fn
        return decorator

    def get(self, rule, **opts): return self.route(rule, methods=["GET"], **opts)
    def post(self, rule, **opts): return self.route(rule, methods=["POST"], **opts)
    def put(self, rule, **opts): return self.route(rule, methods=["PUT"], **opts)
    def delete(self, rule, **opts): return self.route(rule, methods=["DELETE"], **opts)

    def before_request(self, fn):
        self.before_funcs.append(fn)
        return fn

    def after_request(self, fn):
        self.after_funcs.append(fn)
        return fn

    def errorhandler(self, code_or_exc):
        def decorator(fn):
            self.error_handlers[code_or_exc] = fn
            return fn
        return decorator

    def _dispatch(self, req_obj):
        cookie_hdr = req_obj.headers.get("Cookie") or ""
        sid = None
        for part in cookie_hdr.split(";"):
            part = part.strip()
            if part.startswith("nh_py_sid="):
                sid = part.split("=", 1)[1].strip()
                break
        is_new_sid = False
        with _SESSION_LOCK:
            if not sid or sid not in _SESSIONS:
                sid = secrets.token_urlsafe(24)
                _SESSIONS[sid] = {}
                is_new_sid = True
            sess_dict = _SESSIONS[sid]

        request._set(req_obj)
        session._set(sess_dict)
        try:
            for bf in self.before_funcs:
                res = bf()
                if res is not None:
                    resp = make_response(res)
                    if is_new_sid or sess_dict:
                        resp._set_cookies.append(f"nh_py_sid={sid}; Path=/; HttpOnly; SameSite=Lax")
                    return resp

            if self.static_folder and req_obj.path.startswith(self.static_url_path + "/"):
                rel = req_obj.path[len(self.static_url_path) + 1:]
                try:
                    return send_from_directory(self.static_folder, rel)
                except HTTPException:
                    pass

            for regex, allowed, fn in self.routes:
                m = regex.match(req_obj.path)
                if m:
                    if req_obj.method not in allowed and req_obj.method != "HEAD":
                        continue
                    rv = fn(**m.groupdict())
                    resp = make_response(rv)
                    for af in self.after_funcs:
                        resp = make_response(af(resp))
                    if is_new_sid or sess_dict:
                        resp._set_cookies.append(f"nh_py_sid={sid}; Path=/; HttpOnly; SameSite=Lax")
                    return resp

            if self.static_folder and os.path.isdir(self.static_folder):
                rel = req_obj.path.lstrip("/")
                cand = os.path.join(self.static_folder, rel)
                if rel and os.path.isfile(cand):
                    return send_from_directory(self.static_folder, rel)

            abort(404, "Not Found")
        except HTTPException as he:
            if he.code in self.error_handlers:
                return make_response(self.error_handlers[he.code](he), he.code)
            return Response(json.dumps({"error": he.description or "HTTP Error", "status": he.code}), status=he.code, content_type="application/json")
        except Exception as exc:
            traceback.print_exc()
            return Response(json.dumps({"error": str(exc)}), status=500, content_type="application/json")
        finally:
            session._clear()
            request._clear()

    def run(self, host="127.0.0.1", port=5000, debug=False, **kwargs):
        bind_port = int(os.environ.get("PORT", port))
        flask_app = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                pass

            def _handle(self):
                parsed = urllib.parse.urlparse(self.path)
                length = int(self.headers.get("Content-Length", "0") or "0")
                raw_body = self.rfile.read(length) if length > 0 else b""
                qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
                args_flat = {k: v[0] if v else "" for k, v in qs.items()}
                ct = (self.headers.get("Content-Type") or "")
                ct_low = ct.lower()
                form_flat = {}
                files_map = {}
                if "multipart/form-data" in ct_low and raw_body:
                    form_flat, files_map = _parse_multipart(ct, raw_body)
                elif "application/x-www-form-urlencoded" in ct_low and raw_body:
                    fqs = urllib.parse.parse_qs(raw_body.decode("utf-8", errors="replace"))
                    form_flat = {k: v[0] if v else "" for k, v in fqs.items()}

                def get_json(force=False, silent=True):
                    try:
                        if not raw_body:
                            return None
                        return json.loads(raw_body.decode("utf-8", errors="replace"))
                    except Exception:
                        if silent:
                            return None
                        raise

                hdrs = _CaseHeaders(dict(self.headers))
                req_obj = SimpleNamespace(
                    method=self.command.upper(),
                    path=parsed.path,
                    full_path=self.path,
                    url=f"http://127.0.0.1:{bind_port}{self.path}",
                    args=args_flat,
                    form=form_flat,
                    data=raw_body,
                    headers=hdrs,
                    remote_addr=(hdrs.get("X-Forwarded-For") or (self.client_address[0] if self.client_address else "127.0.0.1")),
                    get_json=get_json,
                    json=get_json(silent=True),
                    files=files_map,
                )
                resp = flask_app._dispatch(req_obj)
                self.send_response(resp.status_code)
                for hk, hv in resp.headers.items():
                    if hk.lower() in ("transfer-encoding", "connection", "content-length"):
                        continue
                    self.send_header(hk, str(hv))
                for sc in getattr(resp, "_set_cookies", []):
                    self.send_header("Set-Cookie", sc)
                self.send_header("Content-Length", str(len(resp.data)))
                self.end_headers()
                if self.command.upper() != "HEAD":
                    self.wfile.write(resp.data)

            def do_GET(self): self._handle()
            def do_POST(self): self._handle()
            def do_PUT(self): self._handle()
            def do_PATCH(self): self._handle()
            def do_DELETE(self): self._handle()
            def do_OPTIONS(self): self._handle()
            def do_HEAD(self): self._handle()

        server = ThreadingHTTPServer(("127.0.0.1", bind_port), Handler)
        print(f"NIGHTHOST Python Runtime listening on 127.0.0.1:{bind_port}", flush=True)
        server.serve_forever()
`;

const FLASK_CORS_SHIM_CODE = `def CORS(app, **kwargs):
    return app
def cross_origin(*args, **kwargs):
    def dec(fn):
        return fn
    return dec
`;

const REQUESTS_SHIM_CODE = `import json as _json, re as _re, ssl, time as _time, urllib.request, urllib.parse, urllib.error
from types import SimpleNamespace

class exceptions:
    class RequestException(Exception): pass
    class HTTPError(RequestException): pass
    class Timeout(RequestException): pass
    class ConnectionError(RequestException): pass
    class SSLError(RequestException): pass
    class TooManyRedirects(RequestException): pass

RequestException = exceptions.RequestException
HTTPError = exceptions.HTTPError
Timeout = exceptions.Timeout
ConnectionError = exceptions.ConnectionError

class _CIDict(dict):
    def get(self, key, default=None):
        lk = str(key).lower()
        for k, v in self.items():
            if str(k).lower() == lk:
                return v
        return default
    def __contains__(self, key):
        lk = str(key).lower()
        return any(str(k).lower() == lk for k in self.keys())

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

class _Resp:
    def __init__(self, status_code, headers, content, url, elapsed_s=0.05):
        self.status_code = status_code
        self.headers = _CIDict(headers or {})
        self.content = content or b""
        self.url = url
        self.ok = 200 <= status_code < 400
        self.elapsed = SimpleNamespace(total_seconds=lambda: elapsed_s)
        ct = self.headers.get("content-type", "")
        m = _re.search(r"charset=([a-zA-Z0-9_-]+)", ct, _re.I)
        self.encoding = m.group(1) if m else "utf-8"
    def __enter__(self):
        return self
    def __exit__(self, *args):
        return False
    def iter_content(self, chunk_size=8192):
        for i in range(0, len(self.content), chunk_size):
            yield self.content[i:i + chunk_size]
    @property
    def text(self):
        return self.content.decode(self.encoding or "utf-8", errors="replace")
    def json(self):
        return _json.loads(self.text)
    def raise_for_status(self):
        if self.status_code >= 400:
            raise exceptions.HTTPError(f"HTTP {self.status_code}")

def request(method, url, params=None, data=None, json=None, headers=None, timeout=12, verify=True, allow_redirects=True, **kwargs):
    if isinstance(timeout, (tuple, list)):
        timeout = timeout[-1] if timeout else 12
    if params:
        sep = "&" if "?" in url else "?"
        url = url + sep + urllib.parse.urlencode(params)
    hdrs = dict(headers or {})
    hdrs.setdefault("User-Agent", "Mozilla/5.0 NIGHTHOST-Scanner/1.0")
    body = None
    if json is not None:
        body = _json.dumps(json).encode("utf-8")
        hdrs.setdefault("Content-Type", "application/json")
    elif data is not None:
        if isinstance(data, dict):
            body = urllib.parse.urlencode(data).encode("utf-8")
            hdrs.setdefault("Content-Type", "application/x-www-form-urlencoded")
        elif isinstance(data, str):
            body = data.encode("utf-8")
        else:
            body = data
    handlers = []
    if not verify:
        handlers.append(urllib.request.HTTPSHandler(context=ssl._create_unverified_context()))
    else:
        handlers.append(urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    if not allow_redirects:
        handlers.append(_NoRedirect())
    opener = urllib.request.build_opener(*handlers)
    req = urllib.request.Request(url, data=body, headers=hdrs, method=method.upper())
    t0 = _time.monotonic()
    try:
        with opener.open(req, timeout=timeout) as resp:
            return _Resp(resp.status, dict(resp.headers), resp.read(), resp.geturl(), _time.monotonic() - t0)
    except urllib.error.HTTPError as he:
        hdr_dict = dict(he.headers or {})
        raw = b""
        try:
            raw = he.read()
        except Exception:
            pass
        return _Resp(he.code, hdr_dict, raw, url, _time.monotonic() - t0)
    except Exception as ex:
        raise exceptions.RequestException(str(ex))

def get(url, **kw): return request("GET", url, **kw)
def post(url, **kw): return request("POST", url, **kw)
def put(url, **kw): return request("PUT", url, **kw)
def delete(url, **kw): return request("DELETE", url, **kw)
def head(url, **kw): return request("HEAD", url, **kw)

class Session:
    def __init__(self):
        self.headers = {}
        self.trust_env = True
    def __enter__(self):
        return self
    def __exit__(self, *args):
        return False
    def request(self, method, url, **kw):
        merged = dict(self.headers)
        merged.update(kw.pop("headers", {}) or {})
        return request(method, url, headers=merged, **kw)
    def get(self, url, **kw): return self.request("GET", url, **kw)
    def post(self, url, **kw): return self.request("POST", url, **kw)
    def put(self, url, **kw): return self.request("PUT", url, **kw)
    def delete(self, url, **kw): return self.request("DELETE", url, **kw)
    def head(self, url, **kw): return self.request("HEAD", url, **kw)
`;

const BS4_SHIM_CODE = `import re
from html.parser import HTMLParser

VOID_TAGS = {
    "area", "base", "br", "col", "embed", "hr", "img", "input",
    "link", "meta", "param", "source", "track", "wbr"
}

class Tag:
    def __init__(self, name, attrs=None, parent=None):
        self.name = name
        self.attrs = dict(attrs or {})
        self.parent = parent
        self.children = []
        self._text_parts = []

    def get(self, key, default=None):
        return self.attrs.get(key, default)

    def __getitem__(self, key):
        return self.attrs[key]

    def __contains__(self, key):
        return key in self.attrs

    @property
    def text(self):
        return self.get_text()

    @property
    def string(self):
        txt = self.get_text()
        return txt if txt else None

    def get_text(self, separator="", strip=False):
        parts = []
        for child in self.children:
            if isinstance(child, str):
                parts.append(child)
            elif isinstance(child, Tag):
                parts.append(child.get_text(separator=separator, strip=False))
        joined = separator.join(parts)
        return joined.strip() if strip else joined

    def _matches(self, name, attrs, kwargs):
        if name is not None:
            if isinstance(name, str):
                if self.name != name.lower():
                    return False
            elif isinstance(name, (list, tuple, set)):
                if self.name not in [str(x).lower() for x in name]:
                    return False
            elif hasattr(name, "search"):
                if not name.search(self.name or ""):
                    return False
            elif callable(name):
                if not name(self):
                    return False

        conds = {}
        if isinstance(attrs, dict):
            conds.update(attrs)
        conds.update(kwargs)

        for k, expected in conds.items():
            attr_name = "class" if k == "class_" else k
            actual = self.attrs.get(attr_name)
            if expected is True:
                if actual is None:
                    return False
            elif expected is False or expected is None:
                if actual is not None:
                    return False
            elif hasattr(expected, "search"):
                if actual is None or not expected.search(str(actual)):
                    return False
            elif callable(expected):
                if not expected(actual):
                    return False
            else:
                if actual is None:
                    return False
                if attr_name == "class":
                    tokens = str(actual).split()
                    if str(expected) not in tokens and str(actual) != str(expected):
                        return False
                elif str(actual) != str(expected):
                    return False
        return True

    def find_all(self, name=None, attrs=None, recursive=True, limit=None, **kwargs):
        out = []
        for child in self.children:
            if isinstance(child, Tag):
                if child._matches(name, attrs, kwargs):
                    out.append(child)
                    if limit and len(out) >= limit:
                        return out
                if recursive:
                    out.extend(child.find_all(name=name, attrs=attrs, recursive=True, limit=None if not limit else limit - len(out), **kwargs))
                    if limit and len(out) >= limit:
                        return out[:limit]
        return out

    findAll = find_all

    def find(self, name=None, attrs=None, recursive=True, **kwargs):
        res = self.find_all(name=name, attrs=attrs, recursive=recursive, limit=1, **kwargs)
        return res[0] if res else None

    def _match_simple_selector(self, tag, sel):
        sel = sel.strip()
        if not sel:
            return True
        tag_m = re.match(r"^([a-zA-Z0-9_-]+)", sel)
        if tag_m and tag.name != tag_m.group(1).lower():
            return False
        for cls_m in re.finditer(r"\\.([a-zA-Z0-9_-]+)", sel):
            if cls_m.group(1) not in str(tag.get("class") or "").split():
                return False
        id_m = re.search(r"#([a-zA-Z0-9_-]+)", sel)
        if id_m and tag.get("id") != id_m.group(1):
            return False
        for attr_m in re.finditer(r"\\[([a-zA-Z0-9_-]+)(?:=[\\x22\\x27]?([^\\x22\\x27\\]]+)[\\x22\\x27]?)?\\]", sel):
            an, av = attr_m.group(1), attr_m.group(2)
            if av is None and an not in tag.attrs:
                return False
            if av is not None and tag.get(an) != av:
                return False
        return True

    def select(self, selector):
        results = []
        for branch in selector.split(","):
            parts = [p for p in branch.strip().split() if p]
            if not parts:
                continue
            pool = [self]
            for part in parts:
                next_pool = []
                for root in pool:
                    for desc in root.find_all():
                        if self._match_simple_selector(desc, part) and desc not in next_pool:
                            next_pool.append(desc)
                pool = next_pool
            for item in pool:
                if item not in results:
                    results.append(item)
        return results

    def select_one(self, selector):
        res = self.select(selector)
        return res[0] if res else None

class _SoupHTMLParser(HTMLParser):
    def __init__(self, root):
        super().__init__(convert_charrefs=True)
        self.stack = [root]

    def handle_starttag(self, tag, attrs):
        t = Tag(tag.lower(), dict(attrs), parent=self.stack[-1])
        self.stack[-1].children.append(t)
        if t.name not in VOID_TAGS:
            self.stack.append(t)

    def handle_startendtag(self, tag, attrs):
        t = Tag(tag.lower(), dict(attrs), parent=self.stack[-1])
        self.stack[-1].children.append(t)

    def handle_endtag(self, tag):
        low = tag.lower()
        for idx in range(len(self.stack) - 1, 0, -1):
            if self.stack[idx].name == low:
                del self.stack[idx:]
                break

    def handle_data(self, data):
        if data:
            self.stack[-1].children.append(data)

class BeautifulSoup(Tag):
    def __init__(self, markup="", features="html.parser", **kwargs):
        super().__init__("[document]", {}, None)
        text = markup.decode("utf-8", errors="replace") if isinstance(markup, bytes) else str(markup or "")
        parser = _SoupHTMLParser(self)
        try:
            parser.feed(text)
            parser.close()
        except Exception:
            pass
`;

const WERKZEUG_UTILS_SHIM_CODE = `import re, unicodedata

def secure_filename(filename):
    filename = unicodedata.normalize("NFKD", str(filename or "")).encode("ascii", "ignore").decode("ascii")
    for sep in ("/", "\\\\"):
        filename = filename.replace(sep, " ")
    filename = "_".join(filename.split())
    filename = re.sub(r"[^A-Za-z0-9_.-]", "", filename).strip("._")
    return filename or "file"
`;

const DOTENV_SHIM_CODE = `import os

def load_dotenv(dotenv_path=None, override=False, **kwargs):
    target = dotenv_path or os.path.join(os.getcwd(), ".env")
    if not os.path.isfile(target):
        return False
    with open(target, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#") or "=" not in s:
                continue
            k, v = s.split("=", 1)
            k = k.strip()
            v = v.strip().strip('"').strip("'")
            if override or k not in os.environ:
                os.environ[k] = v
    return True
`;

const REPORTLAB_INIT_CODE = ``;
const REPORTLAB_COLORS_CODE = `black = "#000000"
white = "#ffffff"
grey = "#64748b"
HexColor = lambda x: x
`;
const REPORTLAB_PAGESIZES_CODE = `A4 = (595.27, 841.89)
letter = (612.0, 792.0)
`;
const REPORTLAB_UNITS_CODE = `mm = 72.0 / 25.4
cm = 72.0 / 2.54
inch = 72.0
`;
const REPORTLAB_STYLES_CODE = `class ParagraphStyle(dict):
    def __init__(self, name="Normal", parent=None, **kw):
        super().__init__(name=name, parent=parent, **kw)
        self.name = name

class _StyleSheet(dict):
    def add(self, style, alias=None):
        key = alias or getattr(style, "name", None) or (style.get("name") if isinstance(style, dict) else None)
        if key:
            self[key] = style

def getSampleStyleSheet():
    s = _StyleSheet()
    for n, sz in [("Title", 16), ("Heading1", 14), ("Heading2", 13), ("Heading3", 11), ("Heading4", 10), ("BodyText", 9), ("Normal", 9), ("Code", 8)]:
        s.add(ParagraphStyle(n, fontSize=sz))
    return s
`;
const REPORTLAB_PLATYPUS_CODE = `import re, html as _html, textwrap

def _strip_tags(s):
    clean = re.sub(r"<[^>]+>", "", str(s or ""))
    return _html.unescape(clean)

class Paragraph:
    def __init__(self, text, style=None):
        self.text = _strip_tags(text)
        self.style = style

class Preformatted:
    def __init__(self, text, style=None):
        self.text = str(text or "")
        self.style = style

class Spacer:
    def __init__(self, w, h):
        self.w = w
        self.h = h

class Table:
    def __init__(self, data, **kw):
        self.data = data

class TableStyle:
    def __init__(self, cmds):
        self.cmds = cmds

def _pdf_escape(s):
    s = s.encode("latin-1", "replace").decode("latin-1")
    return s.replace("\\\\", "\\\\\\\\").replace("(", "\\\\(").replace(")", "\\\\)")

class SimpleDocTemplate:
    def __init__(self, filename_or_buf, **kwargs):
        self.target = filename_or_buf

    def build(self, story):
        lines = []
        for item in story:
            if isinstance(item, (Paragraph, Preformatted)):
                for raw_line in item.text.splitlines() or [""]:
                    lines.extend(textwrap.wrap(raw_line, width=88) or [""])
            elif isinstance(item, Table):
                for row in item.data:
                    lines.append(" | ".join(str(c) for c in row))

        per_page = 52
        pages = [lines[i:i + per_page] for i in range(0, max(1, len(lines)), per_page)]
        objects = []
        objects.append(b"1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\\n")
        page_refs = []
        obj_idx = 4
        page_objs = []
        for page_lines in pages:
            content_cmds = ["BT", "/F1 9 Tf", "42 790 Td", "14 TL"]
            for idx, ln in enumerate(page_lines):
                if idx == 0:
                    content_cmds.append(f"({_pdf_escape(ln)}) Tj")
                else:
                    content_cmds.append(f"T* ({_pdf_escape(ln)}) Tj")
            content_cmds.append("ET")
            stream_bytes = "\\n".join(content_cmds).encode("latin-1")
            c_idx = obj_idx
            p_idx = obj_idx + 1
            obj_idx += 2
            page_refs.append(f"{p_idx} 0 R")
            page_objs.append((c_idx, stream_bytes, p_idx))

        kids = " ".join(page_refs)
        objects.append(f"2 0 obj << /Type /Pages /Kids [ {kids} ] /Count {len(pages)} >> endobj\\n".encode("latin-1"))
        objects.append(b"3 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj\\n")
        for c_idx, stream_bytes, p_idx in page_objs:
            objects.append(
                f"{c_idx} 0 obj << /Length {len(stream_bytes)} >> stream\\n".encode("latin-1")
                + stream_bytes
                + b"\\nendstream endobj\\n"
            )
            objects.append(
                f"{p_idx} 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents {c_idx} 0 R >> endobj\\n".encode("latin-1")
            )

        out = bytearray(b"%PDF-1.4\\n")
        offsets = []
        for obj in objects:
            offsets.append(len(out))
            out.extend(obj)
        xref_pos = len(out)
        out.extend(f"xref\\n0 {len(objects) + 1}\\n0000000000 65535 f \\n".encode("latin-1"))
        for off in offsets:
            out.extend(f"{off:010d} 00000 n \\n".encode("latin-1"))
        out.extend(f"trailer << /Size {len(objects) + 1} /Root 1 0 R >>\\nstartxref\\n{xref_pos}\\n%%EOF\\n".encode("latin-1"))
        pdf_bytes = bytes(out)
        if hasattr(self.target, "write"):
            self.target.write(pdf_bytes)
        else:
            with open(self.target, "wb") as f:
                f.write(pdf_bytes)
`;

const DNS_RESOLVER_SHIM_CODE = `import json, socket, urllib.request, urllib.parse

class NXDOMAIN(Exception): pass
class NoAnswer(Exception): pass
class Timeout(Exception): pass
class NoNameservers(Exception): pass

class _Rdata:
    def __init__(self, text):
        self._text = str(text)
    def to_text(self):
        return self._text
    def __str__(self):
        return self._text

class _Answer:
    def __init__(self, records):
        self._records = [_Rdata(r) for r in records]
        self.rrset = self._records if self._records else None
    def __iter__(self):
        return iter(self._records)
    def __len__(self):
        return len(self._records)

class Resolver:
    def __init__(self):
        self.lifetime = 3.0
        self.nameservers = ["8.8.8.8", "1.1.1.1"]

    def resolve(self, qname, rdtype="A", raise_on_no_answer=True, **kwargs):
        domain = str(qname).strip().rstrip(".")
        typ = str(rdtype or "A").upper()
        records = []
        status = 0
        if domain.lower() == "localhost" and typ in ("A", "AAAA"):
            try:
                fam = socket.AF_INET6 if typ == "AAAA" else socket.AF_INET
                infos = socket.getaddrinfo(domain, None, fam, socket.SOCK_STREAM)
                records = sorted({info[4][0] for info in infos})
            except socket.gaierror:
                records = ["127.0.0.1"] if typ == "A" else ["::1"]
            if records:
                return _Answer(records)
        url = f"https://dns.google/resolve?name={urllib.parse.quote(domain)}&type={urllib.parse.quote(typ)}"
        try:
            req = urllib.request.Request(url, headers={"Accept": "application/dns-json", "User-Agent": "NIGHTHOST-DNS/1.0"})
            with urllib.request.urlopen(req, timeout=float(self.lifetime or 3.0)) as resp:
                data = json.loads(resp.read().decode("utf-8", errors="replace"))
            status = int(data.get("Status", 0) or 0)
            for ans in data.get("Answer") or []:
                val = ans.get("data")
                if val is not None:
                    records.append(str(val))
        except Exception:
            pass
        if not records and typ in ("A", "AAAA"):
            fam = socket.AF_INET6 if typ == "AAAA" else socket.AF_INET
            try:
                infos = socket.getaddrinfo(domain, None, fam, socket.SOCK_STREAM)
                records = sorted({info[4][0] for info in infos})
            except socket.gaierror:
                pass
        if not records and status == 3:
            raise NXDOMAIN(f"DNS name does not exist: {domain}")
        if not records and raise_on_no_answer:
            raise NoAnswer(f"No {typ} answer for {domain}")
        return _Answer(records)

def resolve(qname, rdtype="A", raise_on_no_answer=True, **kwargs):
    return Resolver().resolve(qname, rdtype, raise_on_no_answer=raise_on_no_answer, **kwargs)
`;

const DNS_INIT_SHIM_CODE = `from . import resolver, reversename, exception, inet, name
__all__ = ["resolver", "reversename", "exception", "inet", "name"]
`;

const DNS_EXCEPTION_SHIM_CODE = `class DNSException(Exception): pass
class SyntaxError(DNSException): pass
class FormError(DNSException): pass
class Timeout(DNSException): pass
class NXDOMAIN(DNSException): pass
class NoAnswer(DNSException): pass
class NoNameservers(DNSException): pass
`;

const DNS_INET_SHIM_CODE = `import socket
AF_INET = socket.AF_INET
AF_INET6 = socket.AF_INET6

def af_for_address(text):
    t = str(text or "").strip()
    if ":" in t:
        return AF_INET6
    return AF_INET

def inet_pton(family, text):
    return socket.inet_pton(family, str(text).strip())

def inet_ntop(family, packed):
    return socket.inet_ntop(family, packed)

def is_multicast(text):
    import ipaddress
    try:
        return ipaddress.ip_address(str(text).strip()).is_multicast
    except Exception:
        return False
`;

const DNS_NAME_SHIM_CODE = `class Name:
    def __init__(self, labels):
        if isinstance(labels, str):
            labels = [p for p in labels.strip().rstrip(".").split(".") if p]
        self.labels = tuple(labels or ())
    def to_text(self, omit_final_dot=False):
        joined = ".".join(self.labels)
        return joined if omit_final_dot else (joined + "." if joined else ".")
    def __str__(self):
        return self.to_text()
    def __repr__(self):
        return f"<DNS name {self.to_text()}>"

root = Name(())

def from_text(text, origin=None):
    return Name(str(text or ""))
`;

const DNS_REVERSENAME_SHIM_CODE = `import ipaddress
from . import name as _name

ipv4_reverse_domain = _name.from_text("in-addr.arpa.")
ipv6_reverse_domain = _name.from_text("ip6.arpa.")

def from_address(text, v4_origin=ipv4_reverse_domain, v6_origin=ipv6_reverse_domain):
    ip_obj = ipaddress.ip_address(str(text or "").strip())
    ptr = ip_obj.reverse_pointer
    if not ptr.endswith("."):
        ptr += "."
    return _name.from_text(ptr)

def to_address(name_obj, v4_origin=ipv4_reverse_domain, v6_origin=ipv6_reverse_domain):
    s = str(name_obj).strip().rstrip(".").lower()
    if s.endswith(".in-addr.arpa"):
        parts = s[:-len(".in-addr.arpa")].split(".")
        return ".".join(reversed(parts))
    if s.endswith(".ip6.arpa"):
        nibbles = list(reversed(s[:-len(".ip6.arpa")].split(".")))
        groups = ["".join(nibbles[i:i+4]) for i in range(0, len(nibbles), 4)]
        return str(ipaddress.IPv6Address(":".join(groups)))
    raise ValueError(f"Invalid reverse DNS name: {name_obj}")
`;

const HTTPX_SHIM_CODE = `import asyncio, json as _json, ssl, urllib.request, urllib.parse, urllib.error

class RequestError(Exception): pass
class TimeoutException(RequestError): pass
class ConnectError(RequestError): pass
class HTTPStatusError(Exception): pass

class Timeout:
    def __init__(self, timeout=5.0, connect=None, read=None, write=None, pool=None):
        self.timeout = float(read or timeout or 5.0)
        self.connect = float(connect or self.timeout)

class Limits:
    def __init__(self, **kwargs):
        self.kwargs = kwargs

class _Headers(dict):
    def __init__(self, raw_items=None):
        super().__init__()
        self._pairs = []
        if isinstance(raw_items, dict):
            raw_items = list(raw_items.items())
        for k, v in (raw_items or []):
            ks = str(k)
            vs = str(v)
            self._pairs.append((ks.lower(), vs))
            self[ks.lower()] = vs
    def get(self, key, default=None):
        lk = str(key).lower()
        for k, v in self._pairs:
            if k == lk:
                return v
        return default
    def get_list(self, key, split_commas=False):
        lk = str(key).lower()
        out = [v for k, v in self._pairs if k == lk]
        if split_commas:
            expanded = []
            for item in out:
                expanded.extend([x.strip() for x in item.split(",") if x.strip()])
            return expanded
        return out

class Request:
    def __init__(self, method, url, headers=None, params=None, data=None, json=None, content=None):
        self.method = str(method).upper()
        self.url = str(url)
        if params:
            sep = "&" if "?" in self.url else "?"
            self.url += sep + urllib.parse.urlencode(params)
        self.headers = dict(headers or {})
        self.data = data
        self.json = json
        self.content = content

class Response:
    def __init__(self, status_code, header_pairs, content_bytes, url):
        self.status_code = int(status_code)
        self.headers = _Headers(header_pairs)
        self.content = content_bytes or b""
        self.url = str(url)
    @property
    def text(self):
        return self.content.decode("utf-8", errors="replace")
    def json(self):
        return _json.loads(self.text)
    def raise_for_status(self):
        if self.status_code >= 400:
            raise HTTPStatusError(f"HTTP {self.status_code}")
    def close(self):
        pass
    async def aclose(self):
        pass
    async def aiter_text(self, chunk_size=4096):
        t = self.text
        for i in range(0, len(t), chunk_size):
            yield t[i:i + chunk_size]

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

def _sync_send(base_headers, follow_redirects, timeout_val, verify, request):
    hdrs = dict(base_headers or {})
    hdrs.update(request.headers or {})
    hdrs.setdefault("User-Agent", "NIGHTHOST-HTTPX/1.0")
    body = request.content
    if body is None and request.json is not None:
        body = _json.dumps(request.json).encode("utf-8")
        hdrs.setdefault("Content-Type", "application/json")
    elif body is None and request.data is not None:
        if isinstance(request.data, dict):
            body = urllib.parse.urlencode(request.data).encode("utf-8")
            hdrs.setdefault("Content-Type", "application/x-www-form-urlencoded")
        elif isinstance(request.data, str):
            body = request.data.encode("utf-8")
        else:
            body = request.data
    elif isinstance(body, str):
        body = body.encode("utf-8")

    handlers = []
    if not verify:
        handlers.append(urllib.request.HTTPSHandler(context=ssl._create_unverified_context()))
    else:
        handlers.append(urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    if not follow_redirects:
        handlers.append(_NoRedirect())
    opener = urllib.request.build_opener(*handlers)
    req = urllib.request.Request(request.url, data=body, headers=hdrs, method=request.method)
    try:
        with opener.open(req, timeout=timeout_val) as resp:
            pairs = list(resp.headers.items()) if hasattr(resp.headers, "items") else []
            return Response(resp.status, pairs, resp.read(), resp.geturl())
    except urllib.error.HTTPError as he:
        pairs = list(he.headers.items()) if hasattr(he.headers, "items") else []
        raw = b""
        try:
            raw = he.read()
        except Exception:
            pass
        return Response(he.code, pairs, raw, request.url)
    except TimeoutError as te:
        raise TimeoutException(str(te))
    except Exception as exc:
        raise RequestError(str(exc))

class _BaseClient:
    def __init__(self, follow_redirects=False, timeout=10.0, verify=True, trust_env=True, headers=None, **kwargs):
        self.follow_redirects = follow_redirects
        self.timeout_val = float(timeout.timeout if isinstance(timeout, Timeout) else (timeout or 10.0))
        self.verify = bool(verify)
        self.headers = dict(headers or {})
    def build_request(self, method, url, headers=None, params=None, data=None, json=None, content=None):
        return Request(method, url, headers=headers, params=params, data=data, json=json, content=content)

class Client(_BaseClient):
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def send(self, req, stream=False):
        return _sync_send(self.headers, self.follow_redirects, self.timeout_val, self.verify, req)
    def request(self, method, url, **kw):
        return self.send(self.build_request(method, url, **kw))
    def get(self, url, **kw): return self.request("GET", url, **kw)
    def post(self, url, **kw): return self.request("POST", url, **kw)
    def put(self, url, **kw): return self.request("PUT", url, **kw)
    def delete(self, url, **kw): return self.request("DELETE", url, **kw)
    def head(self, url, **kw): return self.request("HEAD", url, **kw)

class AsyncClient(_BaseClient):
    async def __aenter__(self): return self
    async def __aexit__(self, *args): return False
    async def aclose(self): pass
    async def send(self, req, stream=False):
        return await asyncio.to_thread(_sync_send, self.headers, self.follow_redirects, self.timeout_val, self.verify, req)
    async def request(self, method, url, **kw):
        return await self.send(self.build_request(method, url, **kw))
    async def get(self, url, **kw): return await self.request("GET", url, **kw)
    async def post(self, url, **kw): return await self.request("POST", url, **kw)
    async def put(self, url, **kw): return await self.request("PUT", url, **kw)
    async def delete(self, url, **kw): return await self.request("DELETE", url, **kw)
    async def head(self, url, **kw): return await self.request("HEAD", url, **kw)
`;

const PYDANTIC_SHIM_CODE = `_SENTINEL = object()

class ValidationError(ValueError):
    pass

class _FieldInfo:
    def __init__(self, default=_SENTINEL, default_factory=None, min_length=None, max_length=None, ge=None, le=None, gt=None, lt=None, **extra):
        self.default = default
        self.default_factory = default_factory
        self.min_length = min_length
        self.max_length = max_length
        self.ge = ge
        self.le = le
        self.gt = gt
        self.lt = lt

def Field(default=_SENTINEL, **kwargs):
    return _FieldInfo(default=default, **kwargs)

def field_validator(*fields, **kwargs):
    def decorator(fn):
        func = fn.__func__ if isinstance(fn, classmethod) else fn
        setattr(func, "_nh_val_fields", fields)
        return classmethod(func)
    return decorator

validator = field_validator

class BaseModel:
    def __init__(self, **data):
        cls = self.__class__
        ann = {}
        for base in reversed(cls.__mro__):
            ann.update(getattr(base, "__annotations__", {}) or {})

        validators = {}
        for name in dir(cls):
            attr = getattr(cls, name, None)
            func = getattr(attr, "__func__", attr)
            vfields = getattr(func, "_nh_val_fields", None)
            if vfields:
                for vf in vfields:
                    validators.setdefault(vf, []).append(getattr(cls, name))

        for field_name in ann:
            finfo = getattr(cls, field_name, _SENTINEL)
            if field_name in data:
                val = data[field_name]
            elif isinstance(finfo, _FieldInfo):
                if finfo.default is not _SENTINEL:
                    val = finfo.default
                elif finfo.default_factory is not None:
                    val = finfo.default_factory()
                else:
                    raise ValidationError(f"Missing required field: {field_name}")
            elif finfo is not _SENTINEL:
                val = finfo
            else:
                raise ValidationError(f"Missing required field: {field_name}")

            if isinstance(finfo, _FieldInfo):
                if isinstance(val, str):
                    if finfo.min_length is not None and len(val) < finfo.min_length:
                        raise ValidationError(f"{field_name} shorter than {finfo.min_length}")
                    if finfo.max_length is not None and len(val) > finfo.max_length:
                        raise ValidationError(f"{field_name} longer than {finfo.max_length}")
                if isinstance(val, (int, float)) and not isinstance(val, bool):
                    if finfo.ge is not None and val < finfo.ge:
                        raise ValidationError(f"{field_name} must be >= {finfo.ge}")
                    if finfo.le is not None and val > finfo.le:
                        raise ValidationError(f"{field_name} must be <= {finfo.le}")
                    if finfo.gt is not None and val <= finfo.gt:
                        raise ValidationError(f"{field_name} must be > {finfo.gt}")
                    if finfo.lt is not None and val >= finfo.lt:
                        raise ValidationError(f"{field_name} must be < {finfo.lt}")

            for vfn in validators.get(field_name, []):
                val = vfn(val)

            setattr(self, field_name, val)

        self._fields = list(ann.keys())

    def model_dump(self):
        return {k: getattr(self, k) for k in getattr(self, "_fields", [])}

    def dict(self):
        return self.model_dump()

    @classmethod
    def model_validate(cls, obj):
        if isinstance(obj, cls):
            return obj
        return cls(**dict(obj))
`;

const FASTAPI_RESPONSES_SHIM_CODE = `import json as _json

class _HeaderDict(dict):
    def setdefault(self, key, default=None):
        lk = str(key).lower()
        for existing in list(self.keys()):
            if str(existing).lower() == lk:
                return self[existing]
        self[str(key)] = default
        return default
    def get(self, key, default=None):
        lk = str(key).lower()
        for k, v in self.items():
            if str(k).lower() == lk:
                return v
        return default

class Response:
    def __init__(self, content=b"", status_code=200, headers=None, media_type=None):
        if isinstance(content, bytes):
            self.body = content
        elif content is None:
            self.body = b""
        else:
            self.body = str(content).encode("utf-8")
        self.status_code = int(status_code)
        self.headers = _HeaderDict(headers or {})
        self.media_type = media_type
        if media_type and self.headers.get("Content-Type") is None:
            self.headers["Content-Type"] = media_type if "charset" in media_type else (f"{media_type}; charset=utf-8" if media_type.startswith("text/") or "json" in media_type else media_type)
        self._set_cookies = []

    def set_cookie(self, key, value="", max_age=None, path="/", httponly=False, secure=False, samesite="lax", **kwargs):
        parts = [f"{key}={value}", f"Path={path or '/'}"]
        if max_age is not None:
            parts.append(f"Max-Age={int(max_age)}")
        if httponly:
            parts.append("HttpOnly")
        if samesite:
            parts.append(f"SameSite={str(samesite).capitalize()}")
        self._set_cookies.append("; ".join(parts))

    def delete_cookie(self, key, path="/", **kwargs):
        self._set_cookies.append(f"{key}=; Path={path or '/'}; Max-Age=0")

class HTMLResponse(Response):
    def __init__(self, content="", status_code=200, headers=None, **kwargs):
        super().__init__(content=content, status_code=status_code, headers=headers, media_type="text/html")

class JSONResponse(Response):
    def __init__(self, content=None, status_code=200, headers=None, **kwargs):
        encoded = _json.dumps(content, ensure_ascii=False, default=str)
        super().__init__(content=encoded, status_code=status_code, headers=headers, media_type="application/json")

class PlainTextResponse(Response):
    def __init__(self, content="", status_code=200, headers=None, **kwargs):
        super().__init__(content=content, status_code=status_code, headers=headers, media_type="text/plain")

class RedirectResponse(Response):
    def __init__(self, url, status_code=307, headers=None, **kwargs):
        hdrs = dict(headers or {})
        hdrs["Location"] = str(url)
        super().__init__(content="", status_code=status_code, headers=hdrs)
`;

const FASTAPI_STATICFILES_SHIM_CODE = `import os

class StaticFiles:
    def __init__(self, directory="static", html=False, **kwargs):
        self.directory = directory
        self.html = bool(html)
`;

const FASTAPI_SHIM_CODE = `import asyncio, inspect, json, mimetypes, os, re, traceback, urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from types import SimpleNamespace
from .responses import Response, HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse

class HTTPException(Exception):
    def __init__(self, status_code=500, detail=None, headers=None):
        super().__init__(str(detail or ""))
        self.status_code = int(status_code)
        self.detail = detail if detail is not None else "HTTP Error"
        self.headers = headers or {}

def Query(default=None, **kw): return default
def Body(default=None, **kw): return default
def Header(default=None, **kw): return default
def Path(default=None, **kw): return default
def Form(default=None, **kw): return default
def File(default=None, **kw): return default
def Depends(dependency=None): return dependency

class UploadFile:
    pass

class _CIHeaders(dict):
    def get(self, key, default=None):
        lk = str(key).lower()
        for k, v in self.items():
            if str(k).lower() == lk:
                return v
        return default
    def __contains__(self, key):
        lk = str(key).lower()
        return any(str(k).lower() == lk for k in self.keys())

class Request:
    def __init__(self, method, full_path, headers, raw_body, client_host="127.0.0.1"):
        parsed = urllib.parse.urlparse(full_path)
        self.method = method.upper()
        self.url = SimpleNamespace(path=parsed.path, query=parsed.query, scheme="http")
        self.headers = _CIHeaders(headers or {})
        self.query_params = {k: v[0] if v else "" for k, v in urllib.parse.parse_qs(parsed.query, keep_blank_values=True).items()}
        self.path_params = {}
        self.client = SimpleNamespace(host=client_host)
        self._body = raw_body or b""
        self.cookies = {}
        cookie_hdr = self.headers.get("cookie") or ""
        for part in cookie_hdr.split(";"):
            if "=" in part:
                ck, cv = part.split("=", 1)
                self.cookies[ck.strip()] = cv.strip()
    async def body(self):
        return self._body
    async def json(self):
        if not self._body:
            return None
        return json.loads(self._body.decode("utf-8", errors="replace"))
    async def form(self):
        if not self._body:
            return {}
        qs = urllib.parse.parse_qs(self._body.decode("utf-8", errors="replace"))
        return {k: v[0] if v else "" for k, v in qs.items()}

def _resolve_annotation(fn, param):
    ann = param.annotation
    if isinstance(ann, str) and hasattr(fn, "__globals__"):
        ann = fn.__globals__.get(ann, ann)
    return ann

def _coerce_response(rv, default_cls=JSONResponse, default_status=200):
    if isinstance(rv, Response):
        return rv
    if isinstance(rv, (dict, list, bool, int, float)) or rv is None:
        return JSONResponse(rv, status_code=default_status)
    if default_cls is HTMLResponse:
        return HTMLResponse(str(rv), status_code=default_status)
    return default_cls(rv, status_code=default_status)

class FastAPI:
    def __init__(self, title="FastAPI", version="0.1.0", **kwargs):
        self.title = title
        self.version = version
        self.routes = []
        self.mounts = []
        self.middlewares = []
        self.exception_handlers = {}

    def mount(self, path_prefix, app_obj, name=None):
        pref = "/" + str(path_prefix).strip("/")
        self.mounts.append((pref, app_obj))

    def middleware(self, middleware_type="http"):
        def decorator(fn):
            self.middlewares.append(fn)
            return fn
        return decorator

    def exception_handler(self, exc_cls):
        def decorator(fn):
            self.exception_handlers[exc_cls] = fn
            return fn
        return decorator

    def add_api_route(self, path_rule, endpoint, methods=None, response_class=None, status_code=200, **kwargs):
        allowed = [m.upper() for m in (methods or ["GET"])]
        regex_str = re.sub(r"\\{([a-zA-Z0-9_]+)(?::path)?\\}", lambda m: f"(?P<{m.group(1)}>[^/]+)", path_rule)
        regex = re.compile("^" + regex_str + "$")
        self.routes.append((regex, allowed, endpoint, response_class or JSONResponse, int(status_code or 200)))

    def get(self, path_rule, **kw):
        def dec(fn):
            self.add_api_route(path_rule, fn, methods=["GET"], **kw)
            return fn
        return dec
    def post(self, path_rule, **kw):
        def dec(fn):
            self.add_api_route(path_rule, fn, methods=["POST"], **kw)
            return fn
        return dec
    def put(self, path_rule, **kw):
        def dec(fn):
            self.add_api_route(path_rule, fn, methods=["PUT"], **kw)
            return fn
        return dec
    def delete(self, path_rule, **kw):
        def dec(fn):
            self.add_api_route(path_rule, fn, methods=["DELETE"], **kw)
            return fn
        return dec
    def patch(self, path_rule, **kw):
        def dec(fn):
            self.add_api_route(path_rule, fn, methods=["PATCH"], **kw)
            return fn
        return dec

    async def _call_endpoint(self, fn, req_obj, path_vars, resp_cls, default_status):
        sig = inspect.signature(fn)
        kwargs = {}
        body_json = None
        body_loaded = False
        for pname, param in sig.parameters.items():
            if pname in path_vars:
                kwargs[pname] = path_vars[pname]
                continue
            ann = _resolve_annotation(fn, param)
            if ann is Request or pname == "request":
                kwargs[pname] = req_obj
                continue
            if inspect.isclass(ann) and (hasattr(ann, "model_validate") or hasattr(ann, "model_dump")):
                if not body_loaded:
                    try:
                        body_json = await req_obj.json()
                    except Exception:
                        raise HTTPException(400, "Invalid JSON request body")
                    body_loaded = True
                if not isinstance(body_json, dict):
                    raise HTTPException(422, "Request body must be a JSON object")
                try:
                    kwargs[pname] = ann(**body_json)
                except Exception as ve:
                    raise HTTPException(422, str(ve))
                continue
            if pname in req_obj.query_params:
                kwargs[pname] = req_obj.query_params[pname]
            elif param.default is not inspect.Parameter.empty:
                kwargs[pname] = param.default

        rv = fn(**kwargs)
        if inspect.isawaitable(rv):
            rv = await rv
        return _coerce_response(rv, resp_cls, default_status)

    def _serve_mounted_static(self, req_path, include_root=True, only_root=False):
        for pref, obj in self.mounts:
            is_root = (pref == "/")
            if only_root and not is_root:
                continue
            if not include_root and is_root:
                continue
            directory = getattr(obj, "directory", None)
            if not directory:
                continue
            if is_root:
                rel = req_path.lstrip("/")
            elif req_path == pref or req_path.startswith(pref + "/"):
                rel = req_path[len(pref):].lstrip("/")
            else:
                continue
            safe = os.path.normpath(rel).replace("\\\\", "/") if rel else "."
            if safe.startswith(".."):
                return Response(b"Forbidden", status_code=403)
            full = os.path.join(directory, safe)
            if os.path.isdir(full) and getattr(obj, "html", False):
                idx_file = os.path.join(full, "index.html")
                if os.path.isfile(idx_file):
                    full = idx_file
            if os.path.isfile(full):
                mime, _ = mimetypes.guess_type(full)
                with open(full, "rb") as f:
                    return Response(f.read(), status_code=200, media_type=mime or "application/octet-stream")
        return None

    async def _handle_async(self, req_obj):
        async def base_call(request_arg):
            req_path = request_arg.url.path
            non_root_resp = self._serve_mounted_static(req_path, include_root=False, only_root=False)
            if non_root_resp is not None:
                return non_root_resp
            try:
                for regex, allowed, fn, resp_cls, default_status in self.routes:
                    m = regex.match(req_path)
                    if m and (request_arg.method in allowed or request_arg.method == "HEAD"):
                        request_arg.path_params = m.groupdict()
                        return await self._call_endpoint(fn, request_arg, m.groupdict(), resp_cls, default_status)
                root_resp = self._serve_mounted_static(req_path, include_root=True, only_root=True)
                if root_resp is not None:
                    return root_resp
                return JSONResponse({"detail": "Not Found"}, status_code=404)
            except HTTPException as he:
                return JSONResponse({"detail": he.detail}, status_code=he.status_code, headers=he.headers)
            except Exception as exc:
                traceback.print_exc()
                return JSONResponse({"detail": str(exc)}, status_code=500)

        chain = base_call
        for mw in reversed(self.middlewares):
            prev_next = chain
            async def wrapped(request_arg, _mw=mw, _next=prev_next):
                res = _mw(request_arg, _next)
                if inspect.isawaitable(res):
                    return await res
                return res
            chain = wrapped

        return await chain(req_obj)

    def run(self, host="127.0.0.1", port=8000, **kwargs):
        bind_port = int(os.environ.get("PORT", port))
        fastapi_app = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                pass
            def _handle(self):
                length = int(self.headers.get("Content-Length", "0") or "0")
                raw_body = self.rfile.read(length) if length > 0 else b""
                client_host = (self.headers.get("X-Forwarded-For") or (self.client_address[0] if self.client_address else "127.0.0.1")).split(",")[0].strip()
                req_obj = Request(self.command, self.path, dict(self.headers), raw_body, client_host)
                try:
                    resp = asyncio.run(fastapi_app._handle_async(req_obj))
                except Exception as exc:
                    traceback.print_exc()
                    resp = JSONResponse({"detail": str(exc)}, status_code=500)
                self.send_response(resp.status_code)
                for hk, hv in resp.headers.items():
                    if hk.lower() in ("transfer-encoding", "connection", "content-length"):
                        continue
                    self.send_header(hk, str(hv))
                for sc in getattr(resp, "_set_cookies", []):
                    self.send_header("Set-Cookie", sc)
                self.send_header("Content-Length", str(len(resp.body)))
                self.end_headers()
                if self.command.upper() != "HEAD":
                    self.wfile.write(resp.body)
            def do_GET(self): self._handle()
            def do_POST(self): self._handle()
            def do_PUT(self): self._handle()
            def do_PATCH(self): self._handle()
            def do_DELETE(self): self._handle()
            def do_OPTIONS(self): self._handle()
            def do_HEAD(self): self._handle()

        server = ThreadingHTTPServer(("127.0.0.1", bind_port), Handler)
        print(f"NIGHTHOST Python FastAPI Runtime listening on 127.0.0.1:{bind_port}", flush=True)
        server.serve_forever()
`;

const UVICORN_SHIM_CODE = `import importlib, os

def run(app, host="127.0.0.1", port=8000, **kwargs):
    target_port = int(os.environ.get("PORT", port))
    if isinstance(app, str) and ":" in app:
        mod_name, attr_name = app.split(":", 1)
        mod = importlib.import_module(mod_name)
        app = getattr(mod, attr_name)
    if hasattr(app, "run"):
        app.run(host="127.0.0.1", port=target_port)
`;

const PSYCOPG_SHIM_CODE = `def connect(*args, **kwargs):
    raise RuntimeError("psycopg database driver requires PostgreSQL connection; unset DATABASE_URL to use SQLite.")
`;

const PSYCOPG_ROWS_SHIM_CODE = `def dict_row(cursor):
    return None
`;

const NODE_COMPAT_SHIMS: Record<string, { cjs: string; mjs: string }> = {
  cors: {
    cjs: `module.exports = function cors(opts) {
  const origin = (opts && opts.origin) || '*';
  return function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', typeof origin === 'string' ? origin : (req.headers.origin || '*'));
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS,HEAD');
    res.setHeader('Access-Control-Allow-Headers', req.headers['access-control-request-headers'] || 'Content-Type, Authorization');
    if (opts && opts.credentials) res.setHeader('Access-Control-Allow-Credentials', 'true');
    if (req.method === 'OPTIONS') return res.status(204).end();
    next();
  };
};`,
    mjs: `export default function cors(opts) {
  const origin = (opts && opts.origin) || '*';
  return function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', typeof origin === 'string' ? origin : (req.headers.origin || '*'));
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS,HEAD');
    res.setHeader('Access-Control-Allow-Headers', req.headers['access-control-request-headers'] || 'Content-Type, Authorization');
    if (opts && opts.credentials) res.setHeader('Access-Control-Allow-Credentials', 'true');
    if (req.method === 'OPTIONS') return res.status(204).end();
    next();
  };
}`,
  },
  'cookie-parser': {
    cjs: `module.exports = function cookieParser() {
  return function(req, _res, next) {
    const out = {};
    const raw = req.headers.cookie || '';
    for (const part of raw.split(';')) {
      const idx = part.indexOf('=');
      if (idx > 0) {
        const k = part.slice(0, idx).trim();
        const v = part.slice(idx + 1).trim();
        try { out[k] = decodeURIComponent(v); } catch { out[k] = v; }
      }
    }
    req.cookies = out;
    next();
  };
};`,
    mjs: `export default function cookieParser() {
  return function(req, _res, next) {
    const out = {};
    const raw = req.headers.cookie || '';
    for (const part of raw.split(';')) {
      const idx = part.indexOf('=');
      if (idx > 0) {
        const k = part.slice(0, idx).trim();
        const v = part.slice(idx + 1).trim();
        try { out[k] = decodeURIComponent(v); } catch { out[k] = v; }
      }
    }
    req.cookies = out;
    next();
  };
}`,
  },
  morgan: {
    cjs: `module.exports = function morgan() { return function(_req, _res, next) { next(); }; };`,
    mjs: `export default function morgan() { return function(_req, _res, next) { next(); }; }`,
  },
  helmet: {
    cjs: `module.exports = function helmet() { return function(_req, _res, next) { next(); }; };`,
    mjs: `export default function helmet() { return function(_req, _res, next) { next(); }; }`,
  },
  compression: {
    cjs: `module.exports = function compression() { return function(_req, _res, next) { next(); }; };`,
    mjs: `export default function compression() { return function(_req, _res, next) { next(); }; }`,
  },
  'node-fetch': {
    cjs: `module.exports = (...args) => globalThis.fetch(...args); module.exports.default = module.exports;`,
    mjs: `export default (...args) => globalThis.fetch(...args);`,
  },
  uuid: {
    cjs: `const { randomUUID } = require('crypto'); module.exports = { v4: randomUUID };`,
    mjs: `import { randomUUID } from 'crypto'; export const v4 = randomUUID; export default { v4: randomUUID };`,
  },
  'body-parser': {
    cjs: `const express = require('express');
module.exports = {
  json: (...a) => express.json(...a),
  urlencoded: (...a) => express.urlencoded(...a),
  text: (...a) => (typeof express.text === 'function' ? express.text(...a) : (_req, _res, next) => next()),
  raw: (...a) => (typeof express.raw === 'function' ? express.raw(...a) : (_req, _res, next) => next()),
};`,
    mjs: `import express from 'express';
export const json = (...a) => express.json(...a);
export const urlencoded = (...a) => express.urlencoded(...a);
export const text = (...a) => (typeof express.text === 'function' ? express.text(...a) : (_req, _res, next) => next());
export const raw = (...a) => (typeof express.raw === 'function' ? express.raw(...a) : (_req, _res, next) => next());
export default { json, urlencoded, text, raw };`,
  },
  dotenv: {
    cjs: `const fs = require('fs');
const path = require('path');
function parse(src) {
  const out = {};
  for (const line of String(src || '').split(/\\r?\\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq <= 0) continue;
    const k = trimmed.slice(0, eq).trim();
    let v = trimmed.slice(eq + 1).trim();
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    out[k] = v;
  }
  return out;
}
function config(opts) {
  try {
    const target = (opts && opts.path) || path.join(process.cwd(), '.env');
    if (fs.existsSync(target)) {
      const parsed = parse(fs.readFileSync(target, 'utf-8'));
      for (const [k, v] of Object.entries(parsed)) {
        if (process.env[k] === undefined || (opts && opts.override)) process.env[k] = v;
      }
      return { parsed };
    }
  } catch (err) {
    return { error: err };
  }
  return { parsed: {} };
}
module.exports = { config, parse };`,
    mjs: `import fs from 'fs';
import path from 'path';
export function parse(src) {
  const out = {};
  for (const line of String(src || '').split(/\\r?\\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq <= 0) continue;
    const k = trimmed.slice(0, eq).trim();
    let v = trimmed.slice(eq + 1).trim();
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    out[k] = v;
  }
  return out;
}
export function config(opts) {
  try {
    const target = (opts && opts.path) || path.join(process.cwd(), '.env');
    if (fs.existsSync(target)) {
      const parsed = parse(fs.readFileSync(target, 'utf-8'));
      for (const [k, v] of Object.entries(parsed)) {
        if (process.env[k] === undefined || (opts && opts.override)) process.env[k] = v;
      }
      return { parsed };
    }
  } catch (err) {
    return { error: err };
  }
  return { parsed: {} };
}
export default { config, parse };`,
  },
  '@supabase/supabase-js': {
    cjs: `function createClient(supabaseUrl, supabaseKey, options) {
  const baseUrl = String(supabaseUrl || '').replace(/\\/+$/, '');
  const apiKey = String(supabaseKey || '');
  const extraHeaders = (options && options.global && options.global.headers) || {};
  const hasConfig = /^https?:\\/\\//i.test(baseUrl) && apiKey.length > 0;

  function buildHeaders(authBearer, extra) {
    const h = {
      apikey: apiKey,
      Authorization: 'Bearer ' + (authBearer || apiKey),
      'Content-Type': 'application/json',
      ...extraHeaders,
      ...(extra || {}),
    };
    return h;
  }

  async function requestJson(url, init) {
    if (!hasConfig) {
      return { data: null, error: { message: 'Supabase URL or API key not configured in .env', status: 400 } };
    }
    try {
      const res = await fetch(url, init);
      const ct = res.headers.get('content-type') || '';
      const body = ct.includes('application/json') ? await res.json().catch(() => null) : await res.text().catch(() => null);
      if (!res.ok) {
        const msg = (body && (body.msg || body.message || body.error_description || body.error)) || ('HTTP ' + res.status);
        return { data: null, error: { message: msg, status: res.status } };
      }
      return { data: body, error: null, headers: res.headers, status: res.status };
    } catch (err) {
      return { data: null, error: { message: err && err.message ? err.message : 'Supabase network error', status: 500 } };
    }
  }

  const auth = {
    async getUser(jwt) {
      if (!hasConfig) return { data: { user: null }, error: { message: 'Supabase URL or API key not configured in .env' } };
      const r = await requestJson(baseUrl + '/auth/v1/user', { method: 'GET', headers: buildHeaders(jwt) });
      if (r.error) return { data: { user: null }, error: r.error };
      return { data: { user: r.data }, error: null };
    },
    async getSession() {
      return { data: { session: null }, error: null };
    },
    async signInWithPassword(creds) {
      const r = await requestJson(baseUrl + '/auth/v1/token?grant_type=password', {
        method: 'POST',
        headers: buildHeaders(),
        body: JSON.stringify({ email: creds && creds.email, password: creds && creds.password }),
      });
      if (r.error) return { data: { user: null, session: null }, error: r.error };
      return { data: { user: (r.data && r.data.user) || null, session: r.data || null }, error: null };
    },
    async signUp(creds) {
      const r = await requestJson(baseUrl + '/auth/v1/signup', {
        method: 'POST',
        headers: buildHeaders(),
        body: JSON.stringify(creds || {}),
      });
      if (r.error) return { data: { user: null, session: null }, error: r.error };
      return { data: { user: (r.data && r.data.user) || r.data || null, session: (r.data && r.data.session) || null }, error: null };
    },
    async signOut() {
      return { error: null };
    },
    admin: {
      async getUserById(uid) {
        const r = await requestJson(baseUrl + '/auth/v1/admin/users/' + encodeURIComponent(uid), {
          method: 'GET',
          headers: buildHeaders(),
        });
        if (r.error) return { data: { user: null }, error: r.error };
        return { data: { user: r.data }, error: null };
      },
      async updateUserById(uid, attrs) {
        const r = await requestJson(baseUrl + '/auth/v1/admin/users/' + encodeURIComponent(uid), {
          method: 'PUT',
          headers: buildHeaders(),
          body: JSON.stringify(attrs || {}),
        });
        if (r.error) return { data: { user: null }, error: r.error };
        return { data: { user: r.data }, error: null };
      },
      async deleteUser(uid) {
        const r = await requestJson(baseUrl + '/auth/v1/admin/users/' + encodeURIComponent(uid), {
          method: 'DELETE',
          headers: buildHeaders(),
        });
        return { data: r.data, error: r.error };
      },
      async listUsers(params) {
        const page = (params && params.page) || 1;
        const perPage = (params && params.perPage) || 50;
        const r = await requestJson(baseUrl + '/auth/v1/admin/users?page=' + page + '&per_page=' + perPage, {
          method: 'GET',
          headers: buildHeaders(),
        });
        if (r.error) return { data: { users: [] }, error: r.error };
        const users = Array.isArray(r.data && r.data.users) ? r.data.users : (Array.isArray(r.data) ? r.data : []);
        return { data: { users }, error: null };
      },
    },
  };

  function from(table) {
    let op = 'select';
    let selectCols = '*';
    let selectOpts = {};
    let payload = null;
    const filters = [];
    let orderParam = '';
    let limitCount = null;
    let isSingle = false;

    const builder = {
      select(cols, opts) {
        selectCols = cols || '*';
        selectOpts = opts || {};
        return builder;
      },
      insert(vals) {
        op = 'insert';
        payload = vals;
        return builder;
      },
      update(vals) {
        op = 'update';
        payload = vals;
        return builder;
      },
      upsert(vals) {
        op = 'upsert';
        payload = vals;
        return builder;
      },
      delete() {
        op = 'delete';
        return builder;
      },
      eq(col, val) { filters.push(encodeURIComponent(col) + '=eq.' + encodeURIComponent(val)); return builder; },
      neq(col, val) { filters.push(encodeURIComponent(col) + '=neq.' + encodeURIComponent(val)); return builder; },
      gt(col, val) { filters.push(encodeURIComponent(col) + '=gt.' + encodeURIComponent(val)); return builder; },
      gte(col, val) { filters.push(encodeURIComponent(col) + '=gte.' + encodeURIComponent(val)); return builder; },
      lt(col, val) { filters.push(encodeURIComponent(col) + '=lt.' + encodeURIComponent(val)); return builder; },
      lte(col, val) { filters.push(encodeURIComponent(col) + '=lte.' + encodeURIComponent(val)); return builder; },
      like(col, val) { filters.push(encodeURIComponent(col) + '=like.' + encodeURIComponent(val)); return builder; },
      ilike(col, val) { filters.push(encodeURIComponent(col) + '=ilike.' + encodeURIComponent(val)); return builder; },
      is(col, val) { filters.push(encodeURIComponent(col) + '=is.' + encodeURIComponent(val)); return builder; },
      in(col, vals) {
        const list = Array.isArray(vals) ? vals.map(v => JSON.stringify(v)).join(',') : String(vals || '');
        filters.push(encodeURIComponent(col) + '=in.(' + list + ')');
        return builder;
      },
      order(col, opts) {
        orderParam = col + (opts && opts.ascending === false ? '.desc' : '.asc');
        return builder;
      },
      limit(n) { limitCount = Number(n); return builder; },
      range(fromIdx, toIdx) { limitCount = Math.max(1, Number(toIdx) - Number(fromIdx) + 1); return builder; },
      single() { isSingle = true; return builder; },
      maybeSingle() { isSingle = true; return builder; },
      async execute() {
        if (!hasConfig) {
          return { data: isSingle ? null : [], count: 0, error: { message: 'Supabase URL or key not configured in .env' } };
        }
        const qs = [];
        qs.push('select=' + encodeURIComponent(selectCols));
        for (const f of filters) qs.push(f);
        if (orderParam) qs.push('order=' + encodeURIComponent(orderParam));
        if (limitCount !== null) qs.push('limit=' + limitCount);
        const target = baseUrl + '/rest/v1/' + encodeURIComponent(table) + (qs.length ? '?' + qs.join('&') : '');
        const method = op === 'select' ? (selectOpts.head ? 'HEAD' : 'GET') : op === 'delete' ? 'DELETE' : op === 'update' ? 'PATCH' : 'POST';
        const hdrs = buildHeaders();
        if (selectOpts.count) hdrs.Prefer = 'count=' + selectOpts.count;
        if (op === 'upsert') hdrs.Prefer = (hdrs.Prefer ? hdrs.Prefer + ',' : '') + 'resolution=merge-duplicates,return=representation';
        else if (op !== 'select') hdrs.Prefer = (hdrs.Prefer ? hdrs.Prefer + ',' : '') + 'return=representation';
        if (isSingle) hdrs.Accept = 'application/vnd.pgrst.object+json';
        const r = await requestJson(target, {
          method,
          headers: hdrs,
          body: method === 'GET' || method === 'HEAD' || method === 'DELETE' ? undefined : JSON.stringify(payload),
        });
        let count = null;
        if (r.headers && typeof r.headers.get === 'function') {
          const cr = r.headers.get('content-range');
          if (cr && cr.includes('/')) {
            const total = Number(cr.split('/').pop());
            if (Number.isFinite(total)) count = total;
          }
        }
        return { data: r.data, count, error: r.error };
      },
      then(resolve, reject) {
        return builder.execute().then(resolve, reject);
      },
    };
    return builder;
  }

  return { auth, from };
}
module.exports = { createClient };`,
    mjs: `export function createClient(supabaseUrl, supabaseKey, options) {
  const baseUrl = String(supabaseUrl || '').replace(/\\/+$/, '');
  const apiKey = String(supabaseKey || '');
  const extraHeaders = (options && options.global && options.global.headers) || {};
  const hasConfig = /^https?:\\/\\//i.test(baseUrl) && apiKey.length > 0;

  function buildHeaders(authBearer, extra) {
    return {
      apikey: apiKey,
      Authorization: 'Bearer ' + (authBearer || apiKey),
      'Content-Type': 'application/json',
      ...extraHeaders,
      ...(extra || {}),
    };
  }

  async function requestJson(url, init) {
    if (!hasConfig) {
      return { data: null, error: { message: 'Supabase URL or API key not configured in .env', status: 400 } };
    }
    try {
      const res = await fetch(url, init);
      const ct = res.headers.get('content-type') || '';
      const body = ct.includes('application/json') ? await res.json().catch(() => null) : await res.text().catch(() => null);
      if (!res.ok) {
        const msg = (body && (body.msg || body.message || body.error_description || body.error)) || ('HTTP ' + res.status);
        return { data: null, error: { message: msg, status: res.status } };
      }
      return { data: body, error: null, headers: res.headers, status: res.status };
    } catch (err) {
      return { data: null, error: { message: err && err.message ? err.message : 'Supabase network error', status: 500 } };
    }
  }

  const auth = {
    async getUser(jwt) {
      if (!hasConfig) return { data: { user: null }, error: { message: 'Supabase URL or API key not configured in .env' } };
      const r = await requestJson(baseUrl + '/auth/v1/user', { method: 'GET', headers: buildHeaders(jwt) });
      if (r.error) return { data: { user: null }, error: r.error };
      return { data: { user: r.data }, error: null };
    },
    async getSession() {
      return { data: { session: null }, error: null };
    },
    async signInWithPassword(creds) {
      const r = await requestJson(baseUrl + '/auth/v1/token?grant_type=password', {
        method: 'POST',
        headers: buildHeaders(),
        body: JSON.stringify({ email: creds && creds.email, password: creds && creds.password }),
      });
      if (r.error) return { data: { user: null, session: null }, error: r.error };
      return { data: { user: (r.data && r.data.user) || null, session: r.data || null }, error: null };
    },
    async signUp(creds) {
      const r = await requestJson(baseUrl + '/auth/v1/signup', {
        method: 'POST',
        headers: buildHeaders(),
        body: JSON.stringify(creds || {}),
      });
      if (r.error) return { data: { user: null, session: null }, error: r.error };
      return { data: { user: (r.data && r.data.user) || r.data || null, session: (r.data && r.data.session) || null }, error: null };
    },
    async signOut() {
      return { error: null };
    },
    admin: {
      async getUserById(uid) {
        const r = await requestJson(baseUrl + '/auth/v1/admin/users/' + encodeURIComponent(uid), {
          method: 'GET',
          headers: buildHeaders(),
        });
        if (r.error) return { data: { user: null }, error: r.error };
        return { data: { user: r.data }, error: null };
      },
      async updateUserById(uid, attrs) {
        const r = await requestJson(baseUrl + '/auth/v1/admin/users/' + encodeURIComponent(uid), {
          method: 'PUT',
          headers: buildHeaders(),
          body: JSON.stringify(attrs || {}),
        });
        if (r.error) return { data: { user: null }, error: r.error };
        return { data: { user: r.data }, error: null };
      },
      async deleteUser(uid) {
        const r = await requestJson(baseUrl + '/auth/v1/admin/users/' + encodeURIComponent(uid), {
          method: 'DELETE',
          headers: buildHeaders(),
        });
        return { data: r.data, error: r.error };
      },
      async listUsers(params) {
        const page = (params && params.page) || 1;
        const perPage = (params && params.perPage) || 50;
        const r = await requestJson(baseUrl + '/auth/v1/admin/users?page=' + page + '&per_page=' + perPage, {
          method: 'GET',
          headers: buildHeaders(),
        });
        if (r.error) return { data: { users: [] }, error: r.error };
        const users = Array.isArray(r.data && r.data.users) ? r.data.users : (Array.isArray(r.data) ? r.data : []);
        return { data: { users }, error: null };
      },
    },
  };

  function from(table) {
    let op = 'select';
    let selectCols = '*';
    let selectOpts = {};
    let payload = null;
    const filters = [];
    let orderParam = '';
    let limitCount = null;
    let isSingle = false;

    const builder = {
      select(cols, opts) { selectCols = cols || '*'; selectOpts = opts || {}; return builder; },
      insert(vals) { op = 'insert'; payload = vals; return builder; },
      update(vals) { op = 'update'; payload = vals; return builder; },
      upsert(vals) { op = 'upsert'; payload = vals; return builder; },
      delete() { op = 'delete'; return builder; },
      eq(col, val) { filters.push(encodeURIComponent(col) + '=eq.' + encodeURIComponent(val)); return builder; },
      neq(col, val) { filters.push(encodeURIComponent(col) + '=neq.' + encodeURIComponent(val)); return builder; },
      gt(col, val) { filters.push(encodeURIComponent(col) + '=gt.' + encodeURIComponent(val)); return builder; },
      gte(col, val) { filters.push(encodeURIComponent(col) + '=gte.' + encodeURIComponent(val)); return builder; },
      lt(col, val) { filters.push(encodeURIComponent(col) + '=lt.' + encodeURIComponent(val)); return builder; },
      lte(col, val) { filters.push(encodeURIComponent(col) + '=lte.' + encodeURIComponent(val)); return builder; },
      like(col, val) { filters.push(encodeURIComponent(col) + '=like.' + encodeURIComponent(val)); return builder; },
      ilike(col, val) { filters.push(encodeURIComponent(col) + '=ilike.' + encodeURIComponent(val)); return builder; },
      is(col, val) { filters.push(encodeURIComponent(col) + '=is.' + encodeURIComponent(val)); return builder; },
      in(col, vals) {
        const list = Array.isArray(vals) ? vals.map(v => JSON.stringify(v)).join(',') : String(vals || '');
        filters.push(encodeURIComponent(col) + '=in.(' + list + ')');
        return builder;
      },
      order(col, opts) { orderParam = col + (opts && opts.ascending === false ? '.desc' : '.asc'); return builder; },
      limit(n) { limitCount = Number(n); return builder; },
      range(fromIdx, toIdx) { limitCount = Math.max(1, Number(toIdx) - Number(fromIdx) + 1); return builder; },
      single() { isSingle = true; return builder; },
      maybeSingle() { isSingle = true; return builder; },
      async execute() {
        if (!hasConfig) {
          return { data: isSingle ? null : [], count: 0, error: { message: 'Supabase URL or key not configured in .env' } };
        }
        const qs = [];
        qs.push('select=' + encodeURIComponent(selectCols));
        for (const f of filters) qs.push(f);
        if (orderParam) qs.push('order=' + encodeURIComponent(orderParam));
        if (limitCount !== null) qs.push('limit=' + limitCount);
        const target = baseUrl + '/rest/v1/' + encodeURIComponent(table) + (qs.length ? '?' + qs.join('&') : '');
        const method = op === 'select' ? (selectOpts.head ? 'HEAD' : 'GET') : op === 'delete' ? 'DELETE' : op === 'update' ? 'PATCH' : 'POST';
        const hdrs = buildHeaders();
        if (selectOpts.count) hdrs.Prefer = 'count=' + selectOpts.count;
        if (op === 'upsert') hdrs.Prefer = (hdrs.Prefer ? hdrs.Prefer + ',' : '') + 'resolution=merge-duplicates,return=representation';
        else if (op !== 'select') hdrs.Prefer = (hdrs.Prefer ? hdrs.Prefer + ',' : '') + 'return=representation';
        if (isSingle) hdrs.Accept = 'application/vnd.pgrst.object+json';
        const r = await requestJson(target, {
          method,
          headers: hdrs,
          body: method === 'GET' || method === 'HEAD' || method === 'DELETE' ? undefined : JSON.stringify(payload),
        });
        let count = null;
        if (r.headers && typeof r.headers.get === 'function') {
          const cr = r.headers.get('content-range');
          if (cr && cr.includes('/')) {
            const total = Number(cr.split('/').pop());
            if (Number.isFinite(total)) count = total;
          }
        }
        return { data: r.data, count, error: r.error };
      },
      then(resolve, reject) {
        return builder.execute().then(resolve, reject);
      },
    };
    return builder;
  }

  return { auth, from };
}
export default { createClient };`,
  },
};

const FLASK_LIMITER_SHIM_CODE = `from functools import wraps

class RateLimitExceeded(Exception):
    code = 429

class Limiter:
    def __init__(self, key_func=None, app=None, default_limits=None, storage_uri=None, strategy=None, **kwargs):
        self.key_func = key_func
        self.app = app
        self.default_limits = default_limits or []
        self.storage_uri = storage_uri or "memory://"
        self.enabled = True
        if app is not None and callable(getattr(app, "route", None)):
            self.init_app(app)

    def init_app(self, app):
        self.app = app
        if hasattr(app, "extensions") and isinstance(app.extensions, dict):
            app.extensions["limiter"] = self

    def limit(self, *args, **kwargs):
        if args and callable(args[0]) and len(args) == 1 and not kwargs:
            return args[0]
        def decorator(fn):
            @wraps(fn)
            def wrapper(*a, **kw):
                return fn(*a, **kw)
            return wrapper
        return decorator

    def shared_limit(self, *args, **kwargs):
        return self.limit(*args, **kwargs)

    def exempt(self, fn):
        return fn

    def request_filter(self, fn):
        return fn
`;

const FLASK_LIMITER_UTIL_CODE = `def get_remote_address():
    try:
        from flask import request
        fwd = request.headers.get("X-Forwarded-For", "")
        if fwd:
            return fwd.split(",")[0].strip()
        return getattr(request, "remote_addr", None) or "127.0.0.1"
    except Exception:
        return "127.0.0.1"
`;

const FLASK_LOGIN_SHIM_CODE = `from functools import wraps

class AnonymousUserMixin:
    is_authenticated = False
    is_active = False
    is_anonymous = True
    def get_id(self):
        return None

class UserMixin:
    is_authenticated = True
    is_active = True
    is_anonymous = False
    def get_id(self):
        return str(getattr(self, "id", "1"))

current_user = AnonymousUserMixin()

class LoginManager:
    def __init__(self, app=None):
        self.login_view = None
        self.login_message = "Please log in."
        self._user_callback = None
        if app is not None:
            self.init_app(app)
    def init_app(self, app):
        self.app = app
    def user_loader(self, callback):
        self._user_callback = callback
        return callback
    def unauthorized_handler(self, callback):
        return callback

def login_user(user, remember=False, duration=None, force=False, fresh=True):
    global current_user
    current_user = user
    return True

def logout_user():
    global current_user
    current_user = AnonymousUserMixin()
    return True

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        return fn(*args, **kwargs)
    return wrapper

fresh_login_required = login_required
`;

const FLASK_SQLALCHEMY_SHIM_CODE = `class _DummyQuery:
    def filter(self, *a, **kw): return self
    def filter_by(self, **kw): return self
    def order_by(self, *a, **kw): return self
    def limit(self, n): return self
    def offset(self, n): return self
    def all(self): return []
    def first(self): return None
    def one_or_none(self): return None
    def count(self): return 0
    def get(self, ident): return None

class _DummyColumn:
    def __init__(self, *a, **kw): pass
    def __eq__(self, other): return True
    def __ne__(self, other): return True

class _BaseModel:
    query = _DummyQuery()
    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

class _Session:
    def add(self, obj): pass
    def add_all(self, objs): pass
    def delete(self, obj): pass
    def commit(self): pass
    def rollback(self): pass
    def flush(self): pass
    def close(self): pass
    def query(self, *a, **kw): return _DummyQuery()

class SQLAlchemy:
    def __init__(self, app=None, **kwargs):
        self.Model = _BaseModel
        self.session = _Session()
        self.Column = _DummyColumn
        self.Integer = int
        self.String = lambda *a, **kw: str
        self.Text = str
        self.Boolean = bool
        self.Float = float
        self.DateTime = str
        self.JSON = dict
        self.ForeignKey = lambda *a, **kw: None
        self.relationship = lambda *a, **kw: None
        if app is not None:
            self.init_app(app)
    def init_app(self, app):
        self.app = app
    def create_all(self): pass
    def drop_all(self): pass
`;

const FLASK_WTF_SHIM_CODE = `class CSRFProtect:
    def __init__(self, app=None):
        if app is not None:
            self.init_app(app)
    def init_app(self, app):
        self.app = app
    def exempt(self, view):
        return view

class FlaskForm:
    def __init__(self, *args, **kwargs):
        self.errors = {}
    def validate_on_submit(self):
        return True
    def validate(self):
        return True
`;

const PYJWT_SHIM_CODE = `import base64, hashlib, hmac, json, time

class PyJWTError(Exception): pass
class InvalidTokenError(PyJWTError): pass
class ExpiredSignatureError(InvalidTokenError): pass
class DecodeError(InvalidTokenError): pass

def _b64u_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")

def _b64u_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode((s + pad).encode("ascii"))

def encode(payload, key, algorithm="HS256", headers=None):
    hdr = {"typ": "JWT", "alg": algorithm}
    if headers:
        hdr.update(headers)
    s_hdr = _b64u_encode(json.dumps(hdr, separators=(",", ":")).encode("utf-8"))
    s_pay = _b64u_encode(json.dumps(payload, separators=(",", ":"), default=str).encode("utf-8"))
    signing_input = f"{s_hdr}.{s_pay}".encode("ascii")
    secret = key.encode("utf-8") if isinstance(key, str) else (key or b"")
    sig = hmac.new(secret, signing_input, hashlib.sha256).digest()
    return f"{s_hdr}.{s_pay}.{_b64u_encode(sig)}"

def decode(token, key="", algorithms=None, options=None, **kwargs):
    try:
        parts = str(token).split(".")
        if len(parts) != 3:
            raise DecodeError("Not enough segments")
        s_hdr, s_pay, s_sig = parts
        opts = options or {}
        if opts.get("verify_signature", True) and key:
            signing_input = f"{s_hdr}.{s_pay}".encode("ascii")
            secret = key.encode("utf-8") if isinstance(key, str) else key
            expected = _b64u_encode(hmac.new(secret, signing_input, hashlib.sha256).digest())
            if not hmac.compare_digest(expected, s_sig):
                raise InvalidTokenError("Signature verification failed")
        payload = json.loads(_b64u_decode(s_pay).decode("utf-8"))
        if opts.get("verify_exp", True) and isinstance(payload, dict) and "exp" in payload:
            if float(payload["exp"]) < time.time():
                raise ExpiredSignatureError("Token expired")
        return payload
    except PyJWTError:
        raise
    except Exception as exc:
        raise DecodeError(str(exc))
`;

const COLORAMA_SHIM_CODE = `def init(*args, **kwargs): pass
def deinit(): pass
def reinit(): pass

class _Fore:
    BLACK = "\\x1b[30m"; RED = "\\x1b[31m"; GREEN = "\\x1b[32m"; YELLOW = "\\x1b[33m"
    BLUE = "\\x1b[34m"; MAGENTA = "\\x1b[35m"; CYAN = "\\x1b[36m"; WHITE = "\\x1b[37m"
    RESET = "\\x1b[39m"; LIGHTRED_EX = "\\x1b[91m"; LIGHTGREEN_EX = "\\x1b[92m"
    LIGHTYELLOW_EX = "\\x1b[93m"; LIGHTBLUE_EX = "\\x1b[94m"; LIGHTCYAN_EX = "\\x1b[96m"

class _Back:
    BLACK = "\\x1b[40m"; RED = "\\x1b[41m"; GREEN = "\\x1b[42m"; YELLOW = "\\x1b[43m"
    BLUE = "\\x1b[44m"; MAGENTA = "\\x1b[45m"; CYAN = "\\x1b[46m"; WHITE = "\\x1b[47m"
    RESET = "\\x1b[49m"

class _Style:
    DIM = "\\x1b[2m"; NORMAL = "\\x1b[22m"; BRIGHT = "\\x1b[1m"; RESET_ALL = "\\x1b[0m"

Fore = _Fore()
Back = _Back()
Style = _Style()
`;

const USER_AGENTS_SHIM_CODE = `from types import SimpleNamespace

class UserAgent:
    def __init__(self, ua_string=""):
        self.ua_string = str(ua_string or "")
        low = self.ua_string.lower()
        self.is_bot = any(b in low for b in ("bot", "crawler", "spider", "curl", "python-requests"))
        self.is_tablet = any(t in low for t in ("ipad", "tablet"))
        self.is_mobile = (not self.is_tablet) and any(m in low for m in ("mobile", "android", "iphone"))
        self.is_pc = not self.is_mobile and not self.is_tablet and not self.is_bot
        browser = "Chrome" if "chrome" in low else ("Firefox" if "firefox" in low else ("Safari" if "safari" in low else "Unknown"))
        os_name = "Android" if "android" in low else ("iOS" if ("iphone" in low or "ipad" in low) else ("Windows" if "windows" in low else ("macOS" if "mac os" in low else "Linux")))
        device = "Mobile" if self.is_mobile else ("Tablet" if self.is_tablet else "PC")
        self.browser = SimpleNamespace(family=browser, version=(), version_string="")
        self.os = SimpleNamespace(family=os_name, version=(), version_string="")
        self.device = SimpleNamespace(family=device, brand=None, model=None)
    def __str__(self):
        return f"{self.device.family} / {self.os.family} / {self.browser.family}"

def parse(ua_string):
    return UserAgent(ua_string)
`;

const QRCODE_SHIM_CODE = `import base64

_MINI_PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
)

class _QrImage:
    def save(self, stream, format="PNG"):
        if hasattr(stream, "write"):
            stream.write(_MINI_PNG)
        elif isinstance(stream, str):
            with open(stream, "wb") as f:
                f.write(_MINI_PNG)

class QRCode:
    def __init__(self, *args, **kwargs):
        self.data = []
    def add_data(self, data):
        self.data.append(data)
    def make(self, fit=True):
        pass
    def make_image(self, *args, **kwargs):
        return _QrImage()

def make(data, *args, **kwargs):
    return _QrImage()
`;

const BLEACH_SHIM_CODE = `import html, re

def clean(text, tags=None, attributes=None, strip=False, **kwargs):
    s = str(text or "")
    if strip:
        return re.sub(r"<[^>]+>", "", s)
    return html.escape(s)

def linkify(text, **kwargs):
    return str(text or "")
`;

const MARKDOWN_SHIM_CODE = `import html, re

class Markdown:
    def __init__(self, *args, **kwargs): pass
    def convert(self, text):
        return markdown(text)

def markdown(text, *args, **kwargs):
    lines = []
    for raw in str(text or "").splitlines():
        line = html.escape(raw)
        if line.startswith("### "):
            lines.append(f"<h3>{line[4:]}</h3>")
        elif line.startswith("## "):
            lines.append(f"<h2>{line[3:]}</h2>")
        elif line.startswith("# "):
            lines.append(f"<h1>{line[2:]}</h1>")
        elif line.strip():
            line = re.sub(r"\\*\\*(.+?)\\*\\*", r"<strong>\\1</strong>", line)
            lines.append(f"<p>{line}</p>")
    return "\\n".join(lines)
`;

const PASSLIB_HASH_SHIM_CODE = `import hashlib, hmac, secrets

class _Hasher:
    def __init__(self, name="pbkdf2"):
        self.name = name
    def hash(self, secret):
        salt = secrets.token_hex(8)
        dk = hashlib.pbkdf2_hmac("sha256", str(secret).encode("utf-8"), salt.encode("utf-8"), 10000).hex()
        return "$nh$" + str(self.name) + "$" + salt + "$" + dk
    def verify(self, secret, hashed):
        parts = str(hashed or "").split("$")
        if len(parts) == 5 and parts[1] == "nh":
            dk = hashlib.pbkdf2_hmac("sha256", str(secret).encode("utf-8"), parts[3].encode("utf-8"), 10000).hex()
            return hmac.compare_digest(dk, parts[4])
        return False

pbkdf2_sha256 = _Hasher("pbkdf2_sha256")
bcrypt = _Hasher("bcrypt")
sha256_crypt = _Hasher("sha256_crypt")
`;

const CRYPTOGRAPHY_FERNET_SHIM_CODE = `import base64, hashlib, hmac, os

class InvalidToken(Exception):
    pass

class Fernet:
    def __init__(self, key):
        raw = key.encode("utf-8") if isinstance(key, str) else bytes(key)
        self._key = hashlib.sha256(raw).digest()

    @staticmethod
    def generate_key():
        return base64.urlsafe_b64encode(os.urandom(32))

    def _xor(self, data: bytes, iv: bytes) -> bytes:
        out = bytearray(len(data))
        counter = 0
        pos = 0
        while pos < len(data):
            block = hashlib.sha256(self._key + iv + counter.to_bytes(4, "big")).digest()
            for b in block:
                if pos >= len(data):
                    break
                out[pos] = data[pos] ^ b
                pos += 1
            counter += 1
        return bytes(out)

    def encrypt(self, data: bytes) -> bytes:
        raw = data.encode("utf-8") if isinstance(data, str) else bytes(data)
        iv = os.urandom(16)
        ct = self._xor(raw, iv)
        mac = hmac.new(self._key, iv + ct, hashlib.sha256).digest()
        return base64.urlsafe_b64encode(iv + ct + mac)

    def decrypt(self, token, ttl=None) -> bytes:
        try:
            raw = base64.urlsafe_b64decode(token.encode("utf-8") if isinstance(token, str) else token)
            if len(raw) < 48:
                raise InvalidToken("Invalid token")
            iv, ct, mac = raw[:16], raw[16:-32], raw[-32:]
            expected = hmac.new(self._key, iv + ct, hashlib.sha256).digest()
            if not hmac.compare_digest(mac, expected):
                raise InvalidToken("MAC mismatch")
            return self._xor(ct, iv)
        except InvalidToken:
            raise
        except Exception as exc:
            raise InvalidToken(str(exc))
`;

function ensureRuntimeShims() {
  const dirs = [
    PY_SHIM_DIR,
    path.join(PY_SHIM_DIR, 'flask'),
    path.join(PY_SHIM_DIR, 'flask_limiter'),
    path.join(PY_SHIM_DIR, 'flask_login'),
    path.join(PY_SHIM_DIR, 'flask_sqlalchemy'),
    path.join(PY_SHIM_DIR, 'flask_wtf'),
    path.join(PY_SHIM_DIR, 'jwt'),
    path.join(PY_SHIM_DIR, 'colorama'),
    path.join(PY_SHIM_DIR, 'user_agents'),
    path.join(PY_SHIM_DIR, 'qrcode'),
    path.join(PY_SHIM_DIR, 'bleach'),
    path.join(PY_SHIM_DIR, 'markdown'),
    path.join(PY_SHIM_DIR, 'passlib'),
    path.join(PY_SHIM_DIR, 'cryptography'),
    path.join(PY_SHIM_DIR, 'bs4'),
    path.join(PY_SHIM_DIR, 'werkzeug'),
    path.join(PY_SHIM_DIR, 'dotenv'),
    path.join(PY_SHIM_DIR, 'reportlab'),
    path.join(PY_SHIM_DIR, 'reportlab', 'lib'),
    path.join(PY_SHIM_DIR, 'dns'),
    path.join(PY_SHIM_DIR, 'pydantic'),
    path.join(PY_SHIM_DIR, 'fastapi'),
    path.join(PY_SHIM_DIR, 'psycopg'),
    NODE_SHIM_DIR,
  ];
  for (const d of dirs) {
    if (!fs.existsSync(d)) {
      fs.mkdirSync(d, { recursive: true });
    }
  }

  fs.writeFileSync(path.join(NODE_SHIM_DIR, 'nighthost_node_preload.cjs'), NODE_PRELOAD_SCRIPT, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'nighthost_py_launcher.py'), PYTHON_LAUNCHER_SCRIPT, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'flask', '__init__.py'), FLASK_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'flask_cors.py'), FLASK_CORS_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'flask_limiter', '__init__.py'), FLASK_LIMITER_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'flask_limiter', 'util.py'), FLASK_LIMITER_UTIL_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'flask_login', '__init__.py'), FLASK_LOGIN_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'flask_sqlalchemy', '__init__.py'), FLASK_SQLALCHEMY_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'flask_wtf', '__init__.py'), FLASK_WTF_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'jwt', '__init__.py'), PYJWT_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'colorama', '__init__.py'), COLORAMA_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'user_agents', '__init__.py'), USER_AGENTS_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'qrcode', '__init__.py'), QRCODE_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'bleach', '__init__.py'), BLEACH_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'markdown', '__init__.py'), MARKDOWN_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'passlib', '__init__.py'), '', 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'passlib', 'hash.py'), PASSLIB_HASH_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'cryptography', '__init__.py'), '', 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'cryptography', 'fernet.py'), CRYPTOGRAPHY_FERNET_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'requests.py'), REQUESTS_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'bs4', '__init__.py'), BS4_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'werkzeug', '__init__.py'), '', 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'werkzeug', 'utils.py'), WERKZEUG_UTILS_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'dotenv', '__init__.py'), DOTENV_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'reportlab', '__init__.py'), REPORTLAB_INIT_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'reportlab', 'platypus.py'), REPORTLAB_PLATYPUS_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'reportlab', 'lib', '__init__.py'), '', 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'reportlab', 'lib', 'colors.py'), REPORTLAB_COLORS_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'reportlab', 'lib', 'pagesizes.py'), REPORTLAB_PAGESIZES_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'reportlab', 'lib', 'units.py'), REPORTLAB_UNITS_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'reportlab', 'lib', 'styles.py'), REPORTLAB_STYLES_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'dns', '__init__.py'), DNS_INIT_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'dns', 'exception.py'), DNS_EXCEPTION_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'dns', 'inet.py'), DNS_INET_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'dns', 'name.py'), DNS_NAME_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'dns', 'reversename.py'), DNS_REVERSENAME_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'dns', 'resolver.py'), DNS_RESOLVER_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'httpx.py'), HTTPX_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'pydantic', '__init__.py'), PYDANTIC_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'fastapi', '__init__.py'), FASTAPI_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'fastapi', 'responses.py'), FASTAPI_RESPONSES_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'fastapi', 'staticfiles.py'), FASTAPI_STATICFILES_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'uvicorn.py'), UVICORN_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'psycopg', '__init__.py'), PSYCOPG_SHIM_CODE, 'utf-8');
  fs.writeFileSync(path.join(PY_SHIM_DIR, 'psycopg', 'rows.py'), PSYCOPG_ROWS_SHIM_CODE, 'utf-8');
}

function parseDotEnv(content: string): Record<string, string> {
  const vars: Record<string, string> = {};
  for (const line of content.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eqIdx = trimmed.indexOf('=');
    if (eqIdx <= 0) continue;
    const key = trimmed.slice(0, eqIdx).trim();
    let val = trimmed.slice(eqIdx + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    vars[key] = val;
  }
  return vars;
}

function findFreePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.unref();
    srv.on('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const addr = srv.address();
      const port = typeof addr === 'object' && addr ? addr.port : 4300;
      srv.close(() => resolve(port));
    });
  });
}

function waitForPort(port: number, timeoutMs = 6000, isExited: () => boolean): Promise<boolean> {
  const deadline = Date.now() + timeoutMs;
  return new Promise((resolve) => {
    const attempt = () => {
      if (isExited()) {
        resolve(false);
        return;
      }
      const sock = new net.Socket();
      sock.setTimeout(350);
      sock.once('connect', () => {
        sock.destroy();
        resolve(true);
      });
      const fail = () => {
        sock.destroy();
        if (Date.now() >= deadline) {
          resolve(false);
        } else {
          setTimeout(attempt, 150);
        }
      };
      sock.once('error', fail);
      sock.once('timeout', fail);
      sock.connect(port, '127.0.0.1');
    };
    attempt();
  });
}

class SiteRuntimeManager {
  private runtimes = new Map<string, RuntimeProcessState>();

  getSiteRuntimeDir(siteId: string): string {
    return path.join(RUNTIME_BASE_DIR, siteId);
  }

  materializeSiteFiles(site: HostedSite): string {
    const siteDir = this.getSiteRuntimeDir(site.id);
    if (!fs.existsSync(RUNTIME_BASE_DIR)) {
      fs.mkdirSync(RUNTIME_BASE_DIR, { recursive: true });
    }
    if (!fs.existsSync(siteDir)) {
      fs.mkdirSync(siteDir, { recursive: true });
    }

    for (const fileObj of Object.values(site.files)) {
      const cleanRel = fileObj.path.replace(/^\/+/, '').replace(/\\/g, '/');
      if (!cleanRel || cleanRel.includes('..')) continue;
      const dest = path.join(siteDir, cleanRel);
      const resolvedDest = path.resolve(dest);
      if (!resolvedDest.startsWith(path.resolve(siteDir))) continue;

      const parent = path.dirname(resolvedDest);
      if (!fs.existsSync(parent)) {
        fs.mkdirSync(parent, { recursive: true });
      }

      if (fileObj.isBinary) {
        fs.writeFileSync(resolvedDest, Buffer.from(fileObj.content, 'base64'));
      } else {
        fs.writeFileSync(resolvedDest, fileObj.content, 'utf-8');
      }
    }

    // Isolate Node module resolution from NIGHTHOST's parent package.json ("type": "module")
    const pkgPath = path.join(siteDir, 'package.json');
    if (!fs.existsSync(pkgPath)) {
      const jsFiles = Object.values(site.files).filter(f => f.path.toLowerCase().endsWith('.js') && !f.isBinary);
      const usesEsm = jsFiles.some(f => /(^|\n)\s*(import\s+[\w*{]|export\s+(default|const|function|class))/m.test(f.content));
      const usesCjs = jsFiles.some(f => /\b(require\s*\(|module\.exports|exports\.)/.test(f.content));
      fs.writeFileSync(
        pkgPath,
        JSON.stringify({
          name: site.slug || 'nighthost-site',
          private: true,
          type: usesEsm && !usesCjs ? 'module' : 'commonjs',
        }, null, 2),
        'utf-8'
      );
    }

    // Link host node_modules packages and write dual ESM+CJS compatibility shims so Node ESM sites resolve cleanly
    const siteNodeModules = path.join(siteDir, 'node_modules');
    const rootNodeModules = path.join(ROOT_DIR, 'node_modules');
    try {
      if (!fs.existsSync(siteNodeModules)) {
        fs.mkdirSync(siteNodeModules, { recursive: true });
      }
      if (fs.existsSync(rootNodeModules)) {
        for (const entryName of fs.readdirSync(rootNodeModules)) {
          if (entryName.startsWith('.')) continue;
          const srcPkg = path.join(rootNodeModules, entryName);
          const dstPkg = path.join(siteNodeModules, entryName);
          if (!fs.existsSync(dstPkg)) {
            try {
              fs.symlinkSync(srcPkg, dstPkg, 'dir');
            } catch {
              // ignore individual symlink conflict
            }
          }
        }
      }
      for (const [pkgName, shim] of Object.entries(NODE_COMPAT_SHIMS)) {
        const shimPkgDir = path.join(siteNodeModules, ...pkgName.split('/'));
        const pkgJsonFile = path.join(shimPkgDir, 'package.json');
        let shouldWriteShim = !fs.existsSync(shimPkgDir);
        if (!shouldWriteShim && fs.existsSync(pkgJsonFile)) {
          try {
            const existingPkg = JSON.parse(fs.readFileSync(pkgJsonFile, 'utf-8'));
            if (existingPkg.version === '1.0.0-nighthost-shim') {
              shouldWriteShim = true;
            }
          } catch {
            shouldWriteShim = true;
          }
        } else if (!shouldWriteShim) {
          shouldWriteShim = true;
        }
        if (shouldWriteShim) {
          fs.mkdirSync(shimPkgDir, { recursive: true });
          const exportsMap: Record<string, unknown> = {
            '.': {
              import: './index.mjs',
              require: './index.cjs',
              default: './index.cjs',
            },
          };
          if (pkgName === 'dotenv') {
            exportsMap['./config'] = {
              import: './config.mjs',
              require: './config.cjs',
              default: './config.cjs',
            };
          }
          fs.writeFileSync(
            pkgJsonFile,
            JSON.stringify({
              name: pkgName,
              version: '1.0.0-nighthost-shim',
              main: './index.cjs',
              module: './index.mjs',
              exports: exportsMap,
            }),
            'utf-8'
          );
          fs.writeFileSync(path.join(shimPkgDir, 'index.cjs'), shim.cjs, 'utf-8');
          fs.writeFileSync(path.join(shimPkgDir, 'index.mjs'), shim.mjs, 'utf-8');
          if (pkgName === 'dotenv') {
            fs.writeFileSync(path.join(shimPkgDir, 'config.cjs'), `require('./index.cjs').config();`, 'utf-8');
            fs.writeFileSync(path.join(shimPkgDir, 'config.mjs'), `import { config } from './index.mjs'; config();`, 'utf-8');
          }
        }
      }
    } catch {
      // ignore non-fatal node_modules link errors
    }

    return siteDir;
  }

  getSiteRuntimeMeta(site: HostedSite): {
    hasBackend: boolean;
    runtime: 'static' | 'php' | 'node' | 'python';
    backendEntry: string | null;
    state?: Omit<RuntimeProcessState, 'process' | 'startPromise'>;
  } {
    const detected = detectProjectRuntime(
      Object.values(site.files).map(f => ({ path: f.path, content: f.isBinary ? '' : f.content }))
    );
    const hasHydratedContent = Object.values(site.files).some(f => !f.isBinary && Boolean(f.content));
    const effectiveRuntime =
      !hasHydratedContent && (site.runtimeType === 'node' || site.runtimeType === 'python')
        ? site.runtimeType
        : detected.runtime;
    const existing = this.runtimes.get(site.id);
    return {
      hasBackend: Boolean(
        (detected.backendEntry || !hasHydratedContent) &&
          (effectiveRuntime === 'node' || effectiveRuntime === 'python')
      ),
      runtime: effectiveRuntime,
      backendEntry: detected.backendEntry,
      state: existing
        ? {
            siteId: existing.siteId,
            runtime: existing.runtime,
            entryFile: existing.entryFile,
            port: existing.port,
            status: existing.status,
            logs: [...existing.logs],
            errorMessage: existing.errorMessage,
            lastActivity: existing.lastActivity,
            updatedAt: existing.updatedAt,
          }
        : undefined,
    };
  }

  private evictIdleRuntimesIfNeeded(maxWarm = 4) {
    const now = Date.now();
    const idleTimeoutMs = 5 * 60 * 1000;
    for (const [id, r] of this.runtimes.entries()) {
      if ((r.status === 'running' || r.status === 'starting') && now - (r.lastActivity || now) > idleTimeoutMs) {
        this.stopSite(id);
      }
    }
    const runningEntries = Array.from(this.runtimes.values())
      .filter(r => r.status === 'running' || r.status === 'starting')
      .sort((a, b) => (a.lastActivity || 0) - (b.lastActivity || 0));
    while (runningEntries.length >= maxWarm) {
      const oldest = runningEntries.shift();
      if (!oldest) break;
      this.stopSite(oldest.siteId);
    }
  }

  async ensureRunning(site: HostedSite, autoHealAttempt = 0): Promise<RuntimeProcessState | null> {
    const detected = detectProjectRuntime(
      Object.values(site.files).map(f => ({ path: f.path, content: f.isBinary ? '' : f.content }))
    );
    if (!detected.backendEntry || (detected.runtime !== 'node' && detected.runtime !== 'python')) {
      return null;
    }

    const existing = this.runtimes.get(site.id);
    if (existing && existing.updatedAt === site.updatedAt && autoHealAttempt === 0) {
      if (existing.status === 'running') {
        existing.lastActivity = Date.now();
        return existing;
      }
      if (existing.startPromise) {
        return existing.startPromise;
      }
    }

    const prevCrashCount =
      existing && existing.lastCrashAt && Date.now() - existing.lastCrashAt < 120000
        ? existing.crashCount || 0
        : 0;

    if (existing) {
      this.stopSite(site.id);
    } else if (autoHealAttempt === 0) {
      this.evictIdleRuntimesIfNeeded(4);
    }

    const siteDir = this.materializeSiteFiles(site);
    const port = await findFreePort();

    const envExampleFile = Object.values(site.files).find(f => f.path.toLowerCase() === '.env.example');
    const envFile = Object.values(site.files).find(f => f.path.toLowerCase() === '.env');
    const exampleEnv = envExampleFile && !envExampleFile.isBinary ? parseDotEnv(envExampleFile.content) : {};
    const customEnv = envFile && !envFile.isBinary ? parseDotEnv(envFile.content) : {};
    const mergedEnv = { ...exampleEnv, ...customEnv };

    // Auto-copy .env.example to siteDir/.env if missing so dotenv packages find variables cleanly
    const siteDotEnvPath = path.join(siteDir, '.env');
    if (!fs.existsSync(siteDotEnvPath) && envExampleFile && !envExampleFile.isBinary) {
      try {
        fs.writeFileSync(siteDotEnvPath, envExampleFile.content, 'utf-8');
      } catch {
        // ignore non-fatal .env copy issue
      }
    }

    const state: RuntimeProcessState = {
      siteId: site.id,
      runtime: detected.runtime,
      entryFile: detected.backendEntry,
      port,
      status: 'starting',
      logs: [`[${new Date().toLocaleTimeString()}] Starting ${detected.runtime.toUpperCase()} backend (${detected.backendEntry}) on internal port ${port}...`],
      lastActivity: Date.now(),
      updatedAt: site.updatedAt,
      crashCount: prevCrashCount,
    };

    const appendLog = (line: string) => {
      for (const l of line.split(/\r?\n/)) {
        const clean = l.trimEnd();
        if (!clean) continue;
        state.logs.push(clean);
        if (state.logs.length > 80) {
          state.logs.shift();
        }
      }
    };

    const startPromise = (async () => {
      ensureRuntimeShims();
      const entryFull = path.join(siteDir, detected.backendEntry!);
      const preloadPath = path.join(NODE_SHIM_DIR, 'nighthost_node_preload.cjs');
      let child: ChildProcess;

      const autoHealDir = path.join(siteDir, '__nh_autoheal');
      const childEnv = buildIsolatedChildEnv(process.env, mergedEnv, {
        port,
        autoHealDir,
        nodePath: path.join(ROOT_DIR, 'node_modules'),
      });

      if (detected.runtime === 'python') {
        const launcher = path.join(PY_SHIM_DIR, 'nighthost_py_launcher.py');
        child = spawn('python3', [launcher, entryFull], {
          cwd: siteDir,
          env: childEnv,
        });
      } else if (detected.backendEntry!.toLowerCase().endsWith('.ts')) {
        const tsxBin = path.join(ROOT_DIR, 'node_modules', '.bin', 'tsx');
        child = spawn(tsxBin, ['-r', preloadPath, entryFull], {
          cwd: siteDir,
          env: childEnv,
        });
      } else {
        child = spawn('node', ['--max-old-space-size=160', '-r', preloadPath, entryFull], {
          cwd: siteDir,
          env: childEnv,
        });
      }

      state.process = child;
      let exited = false;

      child.stdout?.on('data', d => appendLog(d.toString()));
      child.stderr?.on('data', d => appendLog(`[ERR] ${d.toString()}`));
      child.on('exit', (code, signal) => {
        if (state.status !== 'stopped') {
          const wasRunning = state.status === 'running';
          state.status = 'error';
          state.crashCount = (state.crashCount || 0) + 1;
          state.lastCrashAt = Date.now();
          const isOom =
            code === 137 ||
            signal === 'SIGKILL' ||
            /heap out of memory|MemoryError|ENOMEM/i.test(state.logs.join('\n'));
          state.errorMessage = isOom
            ? 'RENDER_OOM: অ্যাপের মেমোরি ব্যবহার Render 512MB / 160MB সীমা অতিক্রম করায় প্রসেস বন্ধ হয়েছে।'
            : `Backend exited with code ${code}`;
          appendLog(
            isOom
              ? `[EXIT] RENDER_OOM (SIGKILL / exit code ${code}): Memory cap exceeded under dynamic load`
              : `[EXIT] Process terminated with exit code ${code}`
          );
          // Bounded always-on recovery if process had booted successfully and crashed unexpectedly
          if (wasRunning && site.status === 'online' && state.crashCount <= 3) {
            const delayMs = Math.min(4000, state.crashCount * 1000);
            appendLog(`[AUTO-RECOVERY] Restarting backend in ${delayMs}ms (attempt ${state.crashCount}/3)...`);
            setTimeout(() => {
              const latest = this.runtimes.get(site.id);
              if (latest === state && state.status === 'error' && site.status === 'online') {
                this.ensureRunning(site).catch(() => {});
              }
            }, delayMs).unref?.();
          }
        }
      });
      child.on('close', () => {
        exited = true;
      });
      child.on('error', err => {
        exited = true;
        state.status = 'error';
        state.errorMessage = err.message;
        appendLog(`[SPAWN ERROR] ${err.message}`);
      });

      const ready = await waitForPort(port, 8500, () => exited);
      if (ready) {
        state.status = 'running';
        state.crashCount = 0;
        appendLog(`[READY] Backend listening and ready to proxy requests.`);
      } else {
        // Auto-Heal 1: Fix ESM / CommonJS package.json mismatch and retry once automatically
        const combinedLogs = state.logs.join('\n');
        const isEsmMismatch =
          detected.runtime === 'node' &&
          autoHealAttempt === 0 &&
          /require is not defined in ES module scope|ERR_REQUIRE_ESM|Cannot use import statement outside a module/i.test(combinedLogs);

        if (isEsmMismatch) {
          const pkgPath = path.join(siteDir, 'package.json');
          try {
            const pkgJson = fs.existsSync(pkgPath)
              ? JSON.parse(fs.readFileSync(pkgPath, 'utf-8'))
              : { name: site.slug || 'nighthost-site', private: true };
            const nextType = /Cannot use import statement outside a module/i.test(combinedLogs)
              ? 'module'
              : 'commonjs';
            if (pkgJson.type !== nextType) {
              pkgJson.type = nextType;
              fs.writeFileSync(pkgPath, JSON.stringify(pkgJson, null, 2), 'utf-8');
              appendLog(`[AUTO-HEAL] Switched runtime package.json module type to "${nextType}" and retrying startup...`);
              state.status = 'stopped';
              try {
                child.kill('SIGTERM');
              } catch {
                // ignore
              }
              this.runtimes.delete(site.id);
              return this.ensureRunning(site, 1);
            }
          } catch {
            // fall through to normal error reporting
          }
        }

        // Auto-Heal 2: Synthesize missing unknown Python packages/modules dynamically (max 3 attempts)
        if (detected.runtime === 'python' && autoHealAttempt < 3) {
          const modMatch =
            combinedLogs.match(/ModuleNotFoundError:\s+No module named\s+['"]([^'"]+)['"]/i) ||
            combinedLogs.match(/ImportError:\s+No module named\s+([^\s'"]+)/i);
          const importSymMatch = combinedLogs.match(/ImportError:\s+cannot import name\s+['"]([^'"]+)['"]\s+from\s+['"]([^'"]+)['"]/i);
          const missingMod = modMatch ? modMatch[1].trim() : importSymMatch ? importSymMatch[2].trim() : '';
          if (missingMod && /^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(missingMod)) {
            const topPkg = missingMod.split('.')[0];
            const userFileExists =
              fs.existsSync(path.join(siteDir, `${topPkg}.py`)) ||
              fs.existsSync(path.join(siteDir, topPkg, '__init__.py'));
            if (!userFileExists) {
              try {
                const segs = missingMod.split('.');
                const pkgRoot = path.join(autoHealDir, ...segs);
                fs.mkdirSync(pkgRoot, { recursive: true });
                const stubBody = [
                  '# NIGHTHOST Auto-Heal dynamic Python compatibility stub',
                  'class _NHAutoStub:',
                  '    def __init__(self, name="stub", *args, **kwargs):',
                  '        self._name = name',
                  '    def __call__(self, *args, **kwargs):',
                  '        if args and callable(args[0]) and len(args) == 1 and not kwargs:',
                  '            return args[0]',
                  '        return _NHAutoStub(self._name)',
                  '    def __getattr__(self, item):',
                  '        if item.startswith("__") and item.endswith("__"):',
                  '            raise AttributeError(item)',
                  '        return _NHAutoStub(item)',
                  '    def __getitem__(self, key): return _NHAutoStub(str(key))',
                  '    def __iter__(self): return iter(())',
                  '    def __bool__(self): return True',
                  '    def __enter__(self): return self',
                  '    def __exit__(self, *a): return False',
                  '    def __str__(self): return ""',
                  'def __getattr__(name):',
                  '    if name.startswith("__") and name.endswith("__"):',
                  '        raise AttributeError(name)',
                  '    return _NHAutoStub(name)',
                  '',
                ].join('\n');
                // Ensure every parent package has an __init__.py with PEP-562 __getattr__
                let curDir = autoHealDir;
                for (const seg of segs) {
                  curDir = path.join(curDir, seg);
                  fs.mkdirSync(curDir, { recursive: true });
                  const initFile = path.join(curDir, '__init__.py');
                  if (!fs.existsSync(initFile)) {
                    fs.writeFileSync(initFile, stubBody, 'utf-8');
                  }
                }
                if (importSymMatch && importSymMatch[1]) {
                  const symName = importSymMatch[1].trim();
                  if (/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(symName)) {
                    const targetInit = path.join(pkgRoot, '__init__.py');
                    const curTxt = fs.readFileSync(targetInit, 'utf-8');
                    if (!curTxt.includes(`${symName} =`)) {
                      fs.appendFileSync(targetInit, `\n${symName} = _NHAutoStub(${JSON.stringify(symName)})\n`, 'utf-8');
                    }
                  }
                }
                appendLog(`[AUTO-HEAL] Synthesized compatibility stub for Python module '${missingMod}' (attempt ${autoHealAttempt + 1}/3)...`);
                state.status = 'stopped';
                try {
                  child.kill('SIGTERM');
                } catch {
                  // ignore
                }
                this.runtimes.delete(site.id);
                return this.ensureRunning(site, autoHealAttempt + 1);
              } catch {
                // fall through to normal error reporting
              }
            }
          }
        }

        state.status = 'error';
        if (!state.errorMessage) {
          state.errorMessage = 'Backend did not open HTTP port within timeout.';
        }
        appendLog(`[TIMEOUT] ${state.errorMessage}`);
      }
      state.startPromise = undefined;
      return state;
    })();

    state.startPromise = startPromise;
    this.runtimes.set(site.id, state);
    return startPromise;
  }

  async getSiteHealth(site: HostedSite): Promise<SiteHealthReport> {
    const meta = this.getSiteRuntimeMeta(site);
    const hasEntryHtmlOrPhp = Object.values(site.files || {}).some(f => {
      const p = f.path.toLowerCase();
      return p === 'index.html' || p === 'index.php' || p.endsWith('/index.html') || p.endsWith('.php');
    });

    if (!meta.hasBackend) {
      const ok = site.status === 'online' && Object.keys(site.files || {}).length > 0;
      return {
        overall: ok ? 'healthy' : 'down',
        frontendOk: ok,
        backendOk: ok,
        runtime: meta.runtime,
        summaryBn: ok
          ? 'আপনার ওয়েবসাইট সম্পূর্ণভাবে সচল ও অনলাইনে রয়েছে।'
          : 'ওয়েবসাইটটি বর্তমানে বন্ধ বা পজ অবস্থায় আছে।',
        summaryEn: ok
          ? 'Your website is live and operating normally.'
          : 'This website is currently paused or offline.',
      };
    }

    const rt = await this.ensureRunning(site);
    if (!rt || rt.status !== 'running') {
      const logs = rt?.logs || meta.state?.logs || [];
      const diag = diagnoseRuntimeError(logs, meta.runtime, meta.backendEntry);
      const errSnippet = rt?.errorMessage || diag.causeBn;
      return {
        overall: hasEntryHtmlOrPhp ? 'partial' : 'down',
        frontendOk: hasEntryHtmlOrPhp,
        backendOk: false,
        runtime: meta.runtime,
        summaryBn: hasEntryHtmlOrPhp
          ? 'ফ্রন্টএন্ড সচল, কিন্তু আপনার ব্যাকএন্ড / API কাজ করছে না।'
          : 'ওয়েবসাইট ও ব্যাকএন্ড চালু হচ্ছে না।',
        summaryEn: hasEntryHtmlOrPhp
          ? 'Frontend files exist, but your Backend / API server is failing to respond.'
          : 'Website and backend server failed to start.',
        detailBn: `${diag.titleBn}: ${errSnippet}`,
        detailEn: `${diag.titleEn}: ${diag.causeEn}`,
        errorText: logs.slice(-25).join('\n') || rt?.errorMessage || 'Backend failed to bind HTTP port',
      };
    }

    // Probe localhost runtime HTTP server
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 3500);
      const probeRes = await fetch(`http://127.0.0.1:${rt.port}/`, { signal: controller.signal });
      clearTimeout(timer);
      const frontendOk = probeRes.status < 500 || hasEntryHtmlOrPhp;
      const backendOk = probeRes.status < 500;
      if (frontendOk && backendOk) {
        return {
          overall: 'healthy',
          frontendOk: true,
          backendOk: true,
          runtime: meta.runtime,
          summaryBn: 'আপনার ওয়েবসাইট ও ব্যাকএন্ড API সম্পূর্ণভাবে সচল।',
          summaryEn: 'Frontend and Backend API are both healthy and online.',
        };
      }
      return {
        overall: hasEntryHtmlOrPhp ? 'partial' : 'down',
        frontendOk,
        backendOk: false,
        runtime: meta.runtime,
        summaryBn: 'ফ্রন্টএন্ড সচল, কিন্তু আপনার ব্যাকএন্ড / API HTTP ৫০০ এরর দিচ্ছে।',
        summaryEn: 'Frontend reachable, but Backend API returned an internal server error.',
        detailBn: `HTTP Status: ${probeRes.status}`,
        errorText: (rt.logs || []).slice(-20).join('\n') || `HTTP ${probeRes.status}`,
      };
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Health probe failed';
      return {
        overall: hasEntryHtmlOrPhp ? 'partial' : 'down',
        frontendOk: hasEntryHtmlOrPhp,
        backendOk: false,
        runtime: meta.runtime,
        summaryBn: 'ফ্রন্টএন্ড সচল, কিন্তু আপনার ব্যাকএন্ড / API-তে সাড়া পাওয়া যাচ্ছে না।',
        summaryEn: 'Frontend files present, but Backend API is unresponsive.',
        detailBn: msg,
        errorText: (rt.logs || []).slice(-20).join('\n') || msg,
      };
    }
  }

  async restartSite(site: HostedSite): Promise<RuntimeProcessState | null> {
    this.stopSite(site.id);
    return this.ensureRunning(site);
  }

  stopSite(siteId: string) {
    const state = this.runtimes.get(siteId);
    if (!state) return;
    state.status = 'stopped';
    try {
      state.process?.kill('SIGTERM');
    } catch {
      // ignore
    }
    this.runtimes.delete(siteId);
  }

  stopAll() {
    for (const siteId of this.runtimes.keys()) {
      this.stopSite(siteId);
    }
  }
}

export const siteRuntime = new SiteRuntimeManager();
export { getMimeType, ensureRuntimeShims };
