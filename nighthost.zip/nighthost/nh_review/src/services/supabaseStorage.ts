import { HostedSite, SupabasePoolNode } from '../types';

export function normalizeSupabaseUrl(raw: string): string {
  return String(raw || '')
    .trim()
    .replace(/\/+$/, '');
}

export function maskSupabaseKey(key?: string): string {
  const raw = String(key || '').trim();
  if (!raw) return '';
  if (raw.length <= 12) return '****';
  return `${raw.slice(0, 6)}...${raw.slice(-6)}`;
}

export function sanitizeSupabaseNodeForClient(node: SupabasePoolNode): SupabasePoolNode {
  return {
    id: node.id,
    label: node.label,
    url: node.url,
    serviceRoleKeyMasked: node.serviceRoleKeyMasked || maskSupabaseKey(node.serviceRoleKey),
    bucketName: node.bucketName,
    quotaMb: Math.max(50, Number(node.quotaMb) || 1024),
    usedMb: node.usedMb || 0,
    status: node.status,
    source: node.source,
    lastCheckedAt: node.lastCheckedAt,
    errorMessage: node.errorMessage,
  };
}

/**
 * Parses 1..N Supabase Storage accounts configured via Render/Server Environment Variables:
 * - SUPABASE_POOL_JSON='[{"label":"Acc1","url":"https://x.supabase.co","key":"...","bucket":"nighthost-sites","quotaMb":1024}]'
 * - Primary: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY / SUPABASE_KEY, SUPABASE_BUCKET, SUPABASE_STORAGE_MB
 * - Numbered: SUPABASE_URL_1..10, SUPABASE_KEY_1..10 / SUPABASE_SERVICE_ROLE_KEY_1..10, SUPABASE_BUCKET_1..10, SUPABASE_STORAGE_MB_1..10
 */
export function parseSupabaseEnvNodes(env: Record<string, string | undefined> = process.env): SupabasePoolNode[] {
  const nodes: SupabasePoolNode[] = [];
  const seen = new Set<string>();

  const pushUnique = (candidate: Omit<SupabasePoolNode, 'id' | 'status' | 'source'> & { id?: string }) => {
    const cleanUrl = normalizeSupabaseUrl(candidate.url);
    const cleanKey = String(candidate.serviceRoleKey || '').trim();
    const bucket = String(candidate.bucketName || 'nighthost-sites').trim() || 'nighthost-sites';
    if (!cleanUrl || !cleanKey) return;
    const dedupKey = `${cleanUrl.toLowerCase()}::${bucket.toLowerCase()}`;
    if (seen.has(dedupKey)) return;
    seen.add(dedupKey);

    nodes.push({
      id: candidate.id || `env_sb_${nodes.length + 1}`,
      label: candidate.label || `Supabase Env #${nodes.length + 1}`,
      url: cleanUrl,
      serviceRoleKey: cleanKey,
      serviceRoleKeyMasked: maskSupabaseKey(cleanKey),
      bucketName: bucket,
      quotaMb: Math.max(50, Number(candidate.quotaMb) || 1024),
      status: 'connected',
      source: 'env',
    });
  };

  const poolJsonRaw = env.SUPABASE_POOL_JSON;
  if (poolJsonRaw) {
    try {
      const parsed = JSON.parse(poolJsonRaw);
      if (Array.isArray(parsed)) {
        parsed.forEach((item, idx) => {
          if (item && typeof item === 'object') {
            pushUnique({
              id: `env_sb_json_${idx + 1}`,
              label: String(item.label || `Supabase Node #${idx + 1}`),
              url: String(item.url || ''),
              serviceRoleKey: String(item.serviceRoleKey || item.key || ''),
              bucketName: String(item.bucketName || item.bucket || 'nighthost-sites'),
              quotaMb: Number(item.quotaMb || item.storageMb || 1024),
            });
          }
        });
      }
    } catch {
      // ignore invalid JSON env
    }
  }

  if (env.SUPABASE_URL && (env.SUPABASE_SERVICE_ROLE_KEY || env.SUPABASE_KEY)) {
    pushUnique({
      id: 'env_sb_primary',
      label: env.SUPABASE_LABEL || 'Primary Supabase Pool',
      url: env.SUPABASE_URL,
      serviceRoleKey: env.SUPABASE_SERVICE_ROLE_KEY || env.SUPABASE_KEY || '',
      bucketName: env.SUPABASE_BUCKET || 'nighthost-sites',
      quotaMb: Number(env.SUPABASE_STORAGE_MB) || 1024,
    });
  }

  for (let i = 1; i <= 15; i++) {
    const u = env[`SUPABASE_URL_${i}`];
    const k = env[`SUPABASE_SERVICE_ROLE_KEY_${i}`] || env[`SUPABASE_KEY_${i}`];
    if (u && k) {
      pushUnique({
        id: `env_sb_${i}`,
        label: env[`SUPABASE_LABEL_${i}`] || `Supabase Pool #${i}`,
        url: u,
        serviceRoleKey: k,
        bucketName: env[`SUPABASE_BUCKET_${i}`] || 'nighthost-sites',
        quotaMb: Number(env[`SUPABASE_STORAGE_MB_${i}`]) || 1024,
      });
    }
  }

  return nodes;
}

export function mergeSupabaseNodes(
  envNodes: SupabasePoolNode[],
  manualNodes: SupabasePoolNode[]
): SupabasePoolNode[] {
  const merged: SupabasePoolNode[] = [];
  const seen = new Set<string>();

  for (const node of [...envNodes, ...manualNodes]) {
    const cleanUrl = normalizeSupabaseUrl(node.url);
    const bucket = String(node.bucketName || 'nighthost-sites').trim() || 'nighthost-sites';
    if (!cleanUrl) continue;
    const key = `${cleanUrl.toLowerCase()}::${bucket.toLowerCase()}`;
    if (seen.has(key)) continue;
    seen.add(key);
    merged.push({
      ...node,
      url: cleanUrl,
      bucketName: bucket,
      serviceRoleKeyMasked: node.serviceRoleKeyMasked || maskSupabaseKey(node.serviceRoleKey),
    });
  }

  return merged;
}

export function calculatePoolCapacitySummary(nodes: SupabasePoolNode[]): {
  nodesCount: number;
  connectedCount: number;
  connectedMb: number;
} {
  const connected = nodes.filter(n => n.status === 'connected');
  const connectedMb = connected.reduce((sum, n) => sum + Math.max(0, Number(n.quotaMb) || 0), 0);
  return {
    nodesCount: nodes.length,
    connectedCount: connected.length,
    connectedMb: Math.round(connectedMb * 10) / 10,
  };
}

/**
 * Verifies real Supabase Storage REST connectivity & ensures target bucket exists.
 */
export async function verifyAndEnsureSupabaseBucket(
  url: string,
  serviceRoleKey: string,
  bucketName: string
): Promise<{ ok: boolean; error?: string }> {
  const cleanUrl = normalizeSupabaseUrl(url);
  const cleanKey = String(serviceRoleKey || '').trim();
  const bucket = String(bucketName || 'nighthost-sites').trim() || 'nighthost-sites';

  if (!/^https:\/\/[a-z0-9.-]+/i.test(cleanUrl)) {
    return { ok: false, error: 'সঠিক https://xxxx.supabase.co প্রজেক্ট URL দিন।' };
  }
  if (!cleanKey) {
    return { ok: false, error: 'Supabase Service Role Key বা Secret Key প্রদান করুন।' };
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5500);
  try {
    const headers: Record<string, string> = {
      apikey: cleanKey,
      Authorization: `Bearer ${cleanKey}`,
    };

    const getRes = await fetch(`${cleanUrl}/storage/v1/bucket/${encodeURIComponent(bucket)}`, {
      method: 'GET',
      headers,
      signal: controller.signal,
    });

    if (getRes.ok) {
      return { ok: true };
    }

    if (getRes.status === 404 || getRes.status === 400) {
      const createRes = await fetch(`${cleanUrl}/storage/v1/bucket`, {
        method: 'POST',
        headers: {
          ...headers,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: bucket,
          name: bucket,
          public: false,
        }),
        signal: controller.signal,
      });

      if (createRes.ok || createRes.status === 409) {
        return { ok: true };
      }
      const errText = await createRes.text().catch(() => '');
      return {
        ok: false,
        error: `Bucket তৈরি করতে ব্যর্থ (${createRes.status}): ${errText.slice(0, 120) || 'Unauthorized'}`,
      };
    }

    if (getRes.status === 401 || getRes.status === 403) {
      return {
        ok: false,
        error: 'Supabase Service Role Key সঠিক নয় বা স্টোরেজ অ্যাক্সেস ডিনাইড হয়েছে (401/403)।',
      };
    }

    return {
      ok: false,
      error: `Supabase Storage সংযোগ ত্রুটি (HTTP ${getRes.status})।`,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Network error';
    return {
      ok: false,
      error: `Supabase সার্ভারে সংযোগ করা যায়নি: ${msg}`,
    };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Mirrors hosted site bundle manifest + files to the first active Supabase Storage node
 * with available quota (non-blocking background backup & pool replication).
 */
export async function syncSiteToSupabasePool(
  nodes: SupabasePoolNode[],
  site: HostedSite
): Promise<{ uploadedToNodeId?: string; uploadedFiles: number }> {
  const activeNodes = nodes.filter(n => n.status === 'connected' && n.serviceRoleKey);
  if (activeNodes.length === 0) {
    return { uploadedFiles: 0 };
  }

  // Pick node with highest remaining estimated capacity
  const targetNode = [...activeNodes].sort(
    (a, b) => (b.quotaMb - (b.usedMb || 0)) - (a.quotaMb - (a.usedMb || 0))
  )[0];
  if (!targetNode || !targetNode.serviceRoleKey) {
    return { uploadedFiles: 0 };
  }

  const baseHeaders = {
    apikey: targetNode.serviceRoleKey,
    Authorization: `Bearer ${targetNode.serviceRoleKey}`,
    'x-upsert': 'true',
  };

  let uploadedFiles = 0;
  try {
    const manifestObj = {
      id: site.id,
      slug: site.slug,
      customDomain: site.customDomain || null,
      name: site.name,
      runtimeType: site.runtimeType || 'static',
      totalFiles: site.totalFiles,
      totalSizeKb: site.totalSizeKb,
      updatedAt: site.updatedAt,
      files: site.files,
    };

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    try {
      const bundleUrl = `${targetNode.url}/storage/v1/object/${encodeURIComponent(
        targetNode.bucketName
      )}/sites/${encodeURIComponent(site.slug)}/site-bundle.json`;
      const res = await fetch(bundleUrl, {
        method: 'POST',
        headers: {
          ...baseHeaders,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(manifestObj),
        signal: controller.signal,
      });
      if (res.ok) {
        uploadedFiles = Object.keys(site.files || {}).length || 1;
      }
    } finally {
      clearTimeout(timer);
    }
  } catch {
    // non-fatal mirror failure
  }

  return {
    uploadedToNodeId: uploadedFiles > 0 ? targetNode.id : undefined,
    uploadedFiles,
  };
}

export async function fetchSiteBundleFromSupabase(
  nodes: SupabasePoolNode[],
  slug: string,
  siteId?: string
): Promise<HostedSite['files'] | null> {
  const activeNodes = nodes.filter(n => n.status === 'connected' && n.serviceRoleKey);
  if (activeNodes.length === 0) return null;

  const objectPaths = [
    `sites/${encodeURIComponent(slug)}/site-bundle.json`,
    ...(siteId ? [`sites/${encodeURIComponent(siteId)}/site-bundle.json`] : []),
  ];

  for (const node of activeNodes) {
    if (!node.serviceRoleKey) continue;
    const headers = {
      apikey: node.serviceRoleKey,
      Authorization: `Bearer ${node.serviceRoleKey}`,
    };
    for (const objPath of objectPaths) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      try {
        const res = await fetch(
          `${normalizeSupabaseUrl(node.url)}/storage/v1/object/${encodeURIComponent(node.bucketName)}/${objPath}`,
          { method: 'GET', headers, signal: controller.signal }
        );
        if (!res.ok) continue;
        const json = (await res.json()) as { files?: HostedSite['files'] };
        if (json?.files && typeof json.files === 'object' && Object.keys(json.files).length > 0) {
          return json.files;
        }
      } catch {
        // try next node
      } finally {
        clearTimeout(timer);
      }
    }
  }
  return null;
}

export async function deleteSiteBundleFromSupabase(
  nodes: SupabasePoolNode[],
  slug: string,
  siteId?: string
): Promise<void> {
  const activeNodes = nodes.filter(n => n.status === 'connected' && n.serviceRoleKey);
  if (activeNodes.length === 0) return;

  const prefixes = [
    `sites/${slug}/site-bundle.json`,
    ...(siteId ? [`sites/${siteId}/site-bundle.json`] : []),
  ];

  await Promise.all(
    activeNodes.map(async (node) => {
      if (!node.serviceRoleKey) return;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 5000);
      try {
        await fetch(
          `${normalizeSupabaseUrl(node.url)}/storage/v1/object/${encodeURIComponent(node.bucketName)}`,
          {
            method: 'DELETE',
            headers: {
              apikey: node.serviceRoleKey,
              Authorization: `Bearer ${node.serviceRoleKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ prefixes }),
            signal: controller.signal,
          }
        );
      } catch {
        // ignore cleanup error
      } finally {
        clearTimeout(timer);
      }
    })
  );
}

export async function syncCoreStateToSupabase(
  nodes: SupabasePoolNode[],
  coreState: Record<string, unknown>
): Promise<boolean> {
  const activeNodes = nodes.filter(n => n.status === 'connected' && n.serviceRoleKey);
  if (activeNodes.length === 0) return false;
  const targetNode = activeNodes[0];
  if (!targetNode?.serviceRoleKey) return false;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 7000);
  try {
    const res = await fetch(
      `${normalizeSupabaseUrl(targetNode.url)}/storage/v1/object/${encodeURIComponent(
        targetNode.bucketName
      )}/nighthost-core/state.json`,
      {
        method: 'POST',
        headers: {
          apikey: targetNode.serviceRoleKey,
          Authorization: `Bearer ${targetNode.serviceRoleKey}`,
          'x-upsert': 'true',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(coreState),
        signal: controller.signal,
      }
    );
    return res.ok;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

export async function fetchCoreStateFromSupabase<T = Record<string, unknown>>(
  nodes: SupabasePoolNode[]
): Promise<T | null> {
  const activeNodes = nodes.filter(n => n.status === 'connected' && n.serviceRoleKey);
  if (activeNodes.length === 0) return null;

  for (const node of activeNodes) {
    if (!node.serviceRoleKey) continue;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 6500);
    try {
      const res = await fetch(
        `${normalizeSupabaseUrl(node.url)}/storage/v1/object/${encodeURIComponent(
          node.bucketName
        )}/nighthost-core/state.json`,
        {
          method: 'GET',
          headers: {
            apikey: node.serviceRoleKey,
            Authorization: `Bearer ${node.serviceRoleKey}`,
          },
          signal: controller.signal,
        }
      );
      if (!res.ok) continue;
      const parsed = (await res.json()) as T;
      if (parsed && typeof parsed === 'object') {
        return parsed;
      }
    } catch {
      // try next node
    } finally {
      clearTimeout(timer);
    }
  }
  return null;
}

/**
 * Fetches real used storage (MB) inside a Supabase Storage bucket via Storage REST API.
 */
export async function fetchSupabaseBucketUsageMb(
  url: string,
  serviceRoleKey: string,
  bucketName: string
): Promise<number | null> {
  const cleanUrl = normalizeSupabaseUrl(url);
  const cleanKey = String(serviceRoleKey || '').trim();
  const bucket = String(bucketName || 'nighthost-sites').trim() || 'nighthost-sites';
  if (!cleanUrl || !cleanKey) return null;

  const headers = {
    apikey: cleanKey,
    Authorization: `Bearer ${cleanKey}`,
    'Content-Type': 'application/json',
  };

  let totalBytes = 0;

  const walkPrefix = async (prefix: string, depth: number) => {
    if (depth > 3) return;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    try {
      const res = await fetch(`${cleanUrl}/storage/v1/object/list/${encodeURIComponent(bucket)}`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          prefix,
          limit: 100,
          offset: 0,
        }),
        signal: controller.signal,
      });
      if (!res.ok) return;
      const items = (await res.json()) as Array<{
        name?: string;
        id?: string | null;
        metadata?: { size?: number } | null;
      }>;
      if (!Array.isArray(items)) return;

      for (const item of items) {
        if (!item?.name) continue;
        if (item.metadata && typeof item.metadata.size === 'number') {
          totalBytes += Math.max(0, item.metadata.size);
        } else if (!item.id) {
          const nextPrefix = prefix ? `${prefix.replace(/\/$/, '')}/${item.name}` : item.name;
          await walkPrefix(nextPrefix, depth + 1);
        }
      }
    } finally {
      clearTimeout(timer);
    }
  };

  try {
    await walkPrefix('', 0);
    return Math.round((totalBytes / (1024 * 1024)) * 100) / 100;
  } catch {
    return null;
  }
}

export interface RenderEnvVarPair {
  key: string;
  value: string;
}

/**
 * Generates exact Render Environment Variables from connected Supabase pool nodes
 * so admin settings survive Render container restarts/redeploys.
 */
export function generateRenderEnvVariables(
  nodes: SupabasePoolNode[],
  includeSecrets = true
): {
  pairs: RenderEnvVarPair[];
  dotenvText: string;
  poolJson: string;
} {
  const validNodes = nodes.filter((n) => n.url && n.bucketName);
  const pairs: RenderEnvVarPair[] = [];
  const lines: string[] = [];

  validNodes.forEach((node, idx) => {
    const n = idx + 1;
    const keyVal = includeSecrets
      ? node.serviceRoleKey || node.serviceRoleKeyMasked || '<PASTE_SERVICE_ROLE_KEY>'
      : node.serviceRoleKeyMasked || '<PASTE_SERVICE_ROLE_KEY>';

    const nodePairs: RenderEnvVarPair[] = [
      { key: `SUPABASE_LABEL_${n}`, value: node.label || `Supabase Pool #${n}` },
      { key: `SUPABASE_URL_${n}`, value: normalizeSupabaseUrl(node.url) },
      { key: `SUPABASE_SERVICE_ROLE_KEY_${n}`, value: keyVal },
      { key: `SUPABASE_BUCKET_${n}`, value: node.bucketName || 'nighthost-sites' },
      { key: `SUPABASE_STORAGE_MB_${n}`, value: String(Math.max(50, Number(node.quotaMb) || 1024)) },
    ];
    pairs.push(...nodePairs);
    if (idx > 0) lines.push('');
    lines.push(`# Account #${n}: ${node.label || node.bucketName}`);
    for (const p of nodePairs) {
      lines.push(`${p.key}=${p.value}`);
    }
  });

  const compactPool = validNodes.map((node, idx) => ({
    label: node.label || `Supabase Pool #${idx + 1}`,
    url: normalizeSupabaseUrl(node.url),
    key: includeSecrets ? node.serviceRoleKey || node.serviceRoleKeyMasked || '' : node.serviceRoleKeyMasked || '',
    bucket: node.bucketName || 'nighthost-sites',
    quotaMb: Math.max(50, Number(node.quotaMb) || 1024),
  }));

  const poolJson = JSON.stringify(compactPool);
  return {
    pairs,
    dotenvText: lines.join('\n'),
    poolJson,
  };
}

