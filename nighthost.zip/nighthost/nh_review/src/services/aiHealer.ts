import { GoogleGenAI, Type } from '@google/genai';
import { AutoFixReport, SiteFile } from '../types/index.js';
import { getFileType, getMimeType, isPathHidden } from './siteEngine.js';

export interface HealOperationResult {
  healed: boolean;
  files: Record<string, SiteFile>;
  reports: AutoFixReport[];
  usedEngine: 'gemini-ai' | 'auto-rule' | 'none';
}

const SKIP_AI_PATH_RE = /(^|\/)(\.env(\..*)?|node_modules\/|__pycache__\/|\.git\/)/i;
const REDACTED_DOTENV_KEYS_RE = /^([A-Z0-9_]*(?:KEY|SECRET|TOKEN|PASSWORD|PASS|AUTH)[A-Z0-9_]*)\s*=\s*.+$/gim;

function makeReport(
  engine: 'gemini-ai' | 'auto-rule',
  filePath: string,
  issueBn: string,
  fixAppliedBn: string,
  summaryBn: string
): AutoFixReport {
  return {
    id: 'fix_' + Math.random().toString(36).substring(2, 9),
    timestamp: new Date().toISOString(),
    engine,
    filePath,
    summaryBn,
    issueBn,
    fixAppliedBn,
  };
}

function updateSiteFileContent(
  files: Record<string, SiteFile>,
  filePath: string,
  newContent: string
): void {
  const existing = files[filePath];
  const bytes = Buffer.byteLength(newContent, 'utf-8');
  files[filePath] = {
    path: filePath,
    content: newContent,
    size: bytes,
    isHidden: isPathHidden(filePath),
    isBinary: false,
    mimeType: existing?.mimeType || getMimeType(filePath),
    type: existing?.type || getFileType(filePath),
  };
}

/**
 * Layer 1: Deterministic fast auto-healing rules (runs instantaneously without API keys or network).
 * Fixes common hosting pitfalls: JSON trailing commas, ESM/CJS mismatch, hardcoded localhost ports,
 * 127.0.0.1 Flask/FastAPI host bindings, and HTML asset casing/typo links.
 */
export function applyDeterministicHealRules(
  inputFiles: Record<string, SiteFile>,
  errorLogs: string[] = []
): { files: Record<string, SiteFile>; reports: AutoFixReport[] } {
  const working: Record<string, SiteFile> = {};
  for (const [k, f] of Object.entries(inputFiles)) {
    working[k] = { ...f };
  }
  const reports: AutoFixReport[] = [];
  const joinedLogs = errorLogs.join('\n');

  // 1. Fix invalid JSON trailing commas in package.json or *.json
  for (const [filePath, file] of Object.entries(working)) {
    if (file.isBinary || !filePath.toLowerCase().endsWith('.json')) continue;
    try {
      JSON.parse(file.content);
    } catch {
      const cleanedJson = file.content.replace(/,\s*([}\]])/g, '$1');
      try {
        JSON.parse(cleanedJson);
        updateSiteFileContent(working, filePath, cleanedJson);
        reports.push(
          makeReport(
            'auto-rule',
            filePath,
            `'${filePath}' ফাইলে অতিরিক্ত কমা (trailing comma) থাকায় JSON পার্স এরর হচ্ছিল।`,
            `অবৈধ কমাগুলো সরিয়ে বৈধ JSON ফরম্যাটে রূপান্তর করা হয়েছে।`,
            `${filePath}-এর JSON সিনট্যাক্স ত্রুটি স্বয়ংক্রিয়ভাবে ঠিক করা হয়েছে।`
          )
        );
      } catch {
        // leave deeper JSON errors for AI layer
      }
    }
  }

  // 2. Fix ESM / CommonJS mismatch in package.json
  const pkgFile = working['package.json'];
  const backendJsEntry =
    working['server.js'] || working['app.js'] || working['index.js'] || working['src/server.js'];
  if (backendJsEntry && !backendJsEntry.isBinary) {
    const code = backendJsEntry.content;
    const usesRequire = /\brequire\s*\(/.test(code) || /\bmodule\.exports\b/.test(code);
    const usesEsmImport = /^\s*(import\s+[\s\S]*?from\s+['"]|export\s+(default|const|function))/m.test(code);
    const logSaysCjsInEsm = /require is not defined in ES module scope|ERR_REQUIRE_ESM/i.test(joinedLogs);
    const logSaysEsmInCjs = /Cannot use import statement outside a module/i.test(joinedLogs);

    if (pkgFile && !pkgFile.isBinary) {
      try {
        const pkg = JSON.parse(pkgFile.content) as Record<string, unknown>;
        if ((logSaysCjsInEsm || (usesRequire && !usesEsmImport)) && pkg.type === 'module') {
          pkg.type = 'commonjs';
          updateSiteFileContent(working, 'package.json', JSON.stringify(pkg, null, 2));
          reports.push(
            makeReport(
              'auto-rule',
              'package.json',
              `${backendJsEntry.path}-এ require() ব্যবহার করা হয়েছে কিন্তু package.json-এ "type": "module" ছিল।`,
              `package.json-এর "type" ফিল্ডটি "commonjs"-এ পরিবর্তন করা হয়েছে।`,
              `Node.js CommonJS মডিউল কনফ্লিক্ট স্বয়ংক্রিয়ভাবে সমাধান করা হয়েছে।`
            )
          );
        } else if ((logSaysEsmInCjs || (usesEsmImport && !usesRequire)) && pkg.type !== 'module') {
          pkg.type = 'module';
          updateSiteFileContent(working, 'package.json', JSON.stringify(pkg, null, 2));
          reports.push(
            makeReport(
              'auto-rule',
              'package.json',
              `${backendJsEntry.path}-এ ES Module import/export ব্যবহার করা হয়েছে কিন্তু package.json-এ "type": "module" ছিল না।`,
              `package.json-এ "type": "module" যুক্ত করা হয়েছে।`,
              `Node.js ESM মডিউল কনফিগারেশন স্বয়ংক্রিয়ভাবে ঠিক করা হয়েছে।`
            )
          );
        }
      } catch {
        // ignore parse issue
      }
    } else if (usesEsmImport && !usesRequire && logSaysEsmInCjs) {
      const createdPkg = JSON.stringify({ name: 'nighthost-app', private: true, type: 'module' }, null, 2);
      updateSiteFileContent(working, 'package.json', createdPkg);
      reports.push(
        makeReport(
          'auto-rule',
          'package.json',
          `প্রজেক্টে import/export সিনট্যাক্স ব্যবহার হলেও কোনো package.json ছিল না।`,
          `"type": "module" সহ নতুন package.json তৈরি করা হয়েছে।`,
          `ESM চালানোর জন্য package.json অটো-তৈরি করা হয়েছে।`
        )
      );
    }
  }

  // 3. Fix hardcoded HTTP port & 127.0.0.1 host binding in Node / Python entry scripts
  for (const [filePath, file] of Object.entries(working)) {
    if (file.isBinary) continue;
    const low = filePath.toLowerCase();
    if (/node_modules\//.test(low)) continue;

    if (/\.(js|mjs|cjs)$/.test(low) && /\.\s*listen\s*\(\s*(\d{3,5})\s*[,)]/.test(file.content) && !/process\.env\.PORT/.test(file.content)) {
      const patched = file.content.replace(
        /(\.\s*listen\s*\()\s*(\d{3,5})(\s*[,)])/g,
        '$1process.env.PORT || $2$3'
      );
      if (patched !== file.content) {
        updateSiteFileContent(working, filePath, patched);
        reports.push(
          makeReport(
            'auto-rule',
            filePath,
            `'${filePath}' ফাইলে হার্ডকোডেড পোর্ট নম্বর দিয়ে listen() করা ছিল, ক্লাউড process.env.PORT ব্যবহার করা হয়নি।`,
            `listen(...) কলটি process.env.PORT || <port> এ আপডেট করা হয়েছে।`,
            `${filePath}-এ ক্লাউড ডাইনামিক PORT সাপোর্ট যুক্ত করা হয়েছে।`
          )
        );
      }
    }

    if (low.endsWith('.py')) {
      let py = file.content;
      let pyChanged = false;
      if (/host\s*=\s*['"](?:127\.0\.0\.1|localhost)['"]/.test(py)) {
        py = py.replace(/host\s*=\s*['"](?:127\.0\.0\.1|localhost)['"]/g, `host="0.0.0.0"`);
        pyChanged = true;
      }
      if (/app\.run\([^)]*port\s*=\s*(\d{3,5})/.test(py) && !/os\.environ/.test(py)) {
        const importOs = /^\s*import\s+os\b/m.test(py) ? '' : 'import os\n';
        py =
          importOs +
          py.replace(/(app\.run\([^)]*port\s*=\s*)(\d{3,5})/, '$1int(os.environ.get("PORT", $2))');
        pyChanged = true;
      }
      if (pyChanged && py !== file.content) {
        updateSiteFileContent(working, filePath, py);
        reports.push(
          makeReport(
            'auto-rule',
            filePath,
            `Python ফাইলে লোকালহোস্ট (127.0.0.1) বা স্থির পোর্ট ব্যবহার করায় প্রক্সি থেকে কানেক্ট হচ্ছিল না।`,
            `host="0.0.0.0" এবং os.environ.get("PORT") ডায়নামিক পোর্ট কনফিগার করা হয়েছে।`,
            `${filePath}-এর ক্লাউড হোস্ট ও পোর্ট বাইন্ডিং ঠিক করা হয়েছে।`
          )
        );
      }
    }

    // 4. Fix unclosed <script>/<style> or missing asset filename case mismatch in HTML
    if (/\.html?$/.test(low)) {
      let html = file.content;
      let htmlFixReason: string[] = [];

      // Case mismatch / obvious href/src normalization against uploaded files
      const existingPathsLower = new Map<string, string>();
      for (const p of Object.keys(working)) {
        existingPathsLower.set(p.toLowerCase(), p);
      }
      html = html.replace(/(href|src)=["']\.?\/?([^"'#?:]+\.(?:css|js|png|jpg|jpeg|svg|webp))["']/gi, (full, attr, rel) => {
        if (working[rel]) return full;
        const exactMatch = existingPathsLower.get(rel.toLowerCase());
        if (exactMatch && exactMatch !== rel) {
          htmlFixReason.push(`'${rel}' পাথকে সঠিক কেস '${exactMatch}'-এ সংশোধন`);
          return `${attr}="${exactMatch}"`;
        }
        return full;
      });

      // Unclosed script tag safety
      const openScripts = (html.match(/<script\b[^>]*>/gi) || []).length;
      const closeScripts = (html.match(/<\/script>/gi) || []).length;
      if (openScripts > closeScripts) {
        html += '\n</script>';
        htmlFixReason.push('অসম্পূর্ণ <script> ট্যাগ বন্ধ করা হয়েছে');
      }

      if (html !== file.content) {
        updateSiteFileContent(working, filePath, html);
        reports.push(
          makeReport(
            'auto-rule',
            filePath,
            `${filePath}-এ পাথ বা HTML ট্যাগ গঠনগত সমস্যা ছিল।`,
            htmlFixReason.join('; '),
            `${filePath}-এর HTML রেফারেন্স ও ট্যাগ স্বয়ংক্রিয়ভাবে ঠিক করা হয়েছে।`
          )
        );
      }
    }
  }

  return { files: working, reports };
}

function selectRelevantFilesForAi(
  files: Record<string, SiteFile>,
  rootFile?: string,
  errorLogs: string[] = []
): Array<{ path: string; content: string }> {
  const joinedLogs = errorLogs.join('\n').toLowerCase();
  const candidates = Object.values(files)
    .filter(f => !f.isBinary && !SKIP_AI_PATH_RE.test(f.path) && (f.content?.length || 0) > 0)
    .map(f => {
      const low = f.path.toLowerCase();
      let score = 10;
      if (rootFile && f.path === rootFile) score = 0;
      else if (joinedLogs.includes(low)) score = 1;
      else if (/^(package\.json|requirements\.txt|index\.html|server\.[jt]s|app\.(py|js)|main\.(py|js)|index\.php)$/i.test(low)) {
        score = 2;
      } else if (/\.(html|js|mjs|ts|py|php|css)$/i.test(low)) {
        score = 4;
      }
      return { file: f, score };
    })
    .sort((a, b) => a.score - b.score || a.file.size - b.file.size);

  const selected: Array<{ path: string; content: string }> = [];
  let totalChars = 0;
  const maxChars = 42000;

  for (const { file } of candidates) {
    if (selected.length >= 12) break;
    let safeContent = file.content.replace(REDACTED_DOTENV_KEYS_RE, '$1=<REDACTED>');
    if (safeContent.length > 10000) {
      safeContent = safeContent.slice(0, 10000) + '\n/* ... truncated ... */';
    }
    if (totalChars + safeContent.length > maxChars && selected.length > 0) continue;
    selected.push({ path: file.path, content: safeContent });
    totalChars += safeContent.length;
  }

  return selected;
}

/**
 * Layer 2: Automatic server-side Gemini ('gemini-4-hydrogen') AI Code Auto-Healer.
 * Uses process.env.GEMINI_API_KEY automatically — zero user API key prompt needed.
 */
async function runGeminiAiAutoHeal(params: {
  files: Record<string, SiteFile>;
  rootFile?: string;
  runtimeType?: string;
  errorLogs?: string[];
  errorMessage?: string;
}): Promise<{ files: Record<string, SiteFile>; reports: AutoFixReport[] }> {
  const apiKey = String(process.env.GEMINI_API_KEY || '').trim();
  if (!apiKey) {
    return { files: params.files, reports: [] };
  }

  const relevantFiles = selectRelevantFilesForAi(
    params.files,
    params.rootFile,
    params.errorLogs || []
  );
  if (relevantFiles.length === 0) {
    return { files: params.files, reports: [] };
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
  });

  const errorSection = [
    params.errorMessage ? `Error Message: ${params.errorMessage}` : '',
    params.errorLogs && params.errorLogs.length > 0
      ? `Runtime / Startup Logs:\n${params.errorLogs.slice(-25).join('\n')}`
      : 'No crash logs provided — inspect uploaded code for syntax bugs, broken imports/paths, missing PORT binding, or misconfigured entrypoints.',
  ]
    .filter(Boolean)
    .join('\n\n');

  const filesText = relevantFiles
    .map(f => `--- FILE: ${f.path} ---\n${f.content}`)
    .join('\n\n');

  const prompt = `You are NIGHTHOST AI Auto-Healer, an expert web & backend code repair engineer.
Analyze the hosted project (${params.runtimeType || 'web'}, entry: ${params.rootFile || 'index.html'}).
Only fix genuine syntax errors, broken relative paths, runtime crash causes, module/import mismatches, or cloud PORT/0.0.0.0 binding issues.
Do NOT invent unrelated features or alter working UI design. Only output files you actually changed.
Every report explanation (issueBn, fixAppliedBn, summaryBn) MUST be written in clear, friendly Bengali (বাংলা).

${errorSection}

Project Files:
${filesText}`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: prompt,
      config: {
        systemInstruction:
          'Return strict JSON matching the schema. Only patch real bugs with complete updated file contents. Write all Bengali explanations clearly.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            fixes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  filePath: { type: Type.STRING },
                  updatedContent: { type: Type.STRING },
                  issueBn: { type: Type.STRING },
                  fixAppliedBn: { type: Type.STRING },
                  summaryBn: { type: Type.STRING },
                },
                required: ['filePath', 'updatedContent', 'issueBn', 'fixAppliedBn', 'summaryBn'],
              },
            },
          },
          required: ['fixes'],
        },
      },
    });

    const rawText = response.text || '';
    if (!rawText) return { files: params.files, reports: [] };

    const parsed = JSON.parse(rawText) as {
      fixes?: Array<{
        filePath?: string;
        updatedContent?: string;
        issueBn?: string;
        fixAppliedBn?: string;
        summaryBn?: string;
      }>;
    };

    const working: Record<string, SiteFile> = { ...params.files };
    const reports: AutoFixReport[] = [];

    for (const fix of parsed.fixes || []) {
      const targetPath = String(fix.filePath || '').trim().replace(/^\/+/, '').replace(/\\/g, '/');
      if (
        !targetPath ||
        targetPath.includes('..') ||
        SKIP_AI_PATH_RE.test(targetPath) ||
        typeof fix.updatedContent !== 'string' ||
        !fix.updatedContent.trim()
      ) {
        continue;
      }
      const existing = working[targetPath];
      if (existing?.isBinary) continue;
      if (existing && existing.content === fix.updatedContent) continue;

      updateSiteFileContent(working, targetPath, fix.updatedContent);
      reports.push(
        makeReport(
          'gemini-ai',
          targetPath,
          String(fix.issueBn || `${targetPath}-এ ত্রুটি পাওয়া গেছে।`),
          String(fix.fixAppliedBn || `${targetPath} সংশোধন করা হয়েছে।`),
          String(fix.summaryBn || `AI অটো-হিলার '${targetPath}' ফাইলটি ঠিক করেছে।`)
        )
      );
    }

    return { files: working, reports };
  } catch (err) {
    console.warn('Gemini Auto-Heal fallback (non-fatal):', err instanceof Error ? err.message : err);
    return { files: params.files, reports: [] };
  }
}

/**
 * Full 2-Layer Auto-Heal Entry Point:
 * 1) Deterministic fast code rules
 * 2) Gemini 'gemini-4-hydrogen' AI patcher when needed / requested
 */
export async function runSiteAutoHeal(params: {
  files: Record<string, SiteFile>;
  rootFile?: string;
  runtimeType?: 'static' | 'php' | 'node' | 'python';
  errorLogs?: string[];
  errorMessage?: string;
  preferAi?: boolean;
}): Promise<HealOperationResult> {
  const ruleResult = applyDeterministicHealRules(params.files, params.errorLogs || []);
  const allReports: AutoFixReport[] = [...ruleResult.reports];
  let currentFiles = ruleResult.files;

  const shouldCallAi =
    Boolean(process.env.GEMINI_API_KEY) &&
    params.preferAi !== false &&
    ((params.errorLogs && params.errorLogs.length > 0) || Boolean(params.errorMessage) || params.preferAi === true);

  let usedGemini = false;
  if (shouldCallAi) {
    const aiResult = await runGeminiAiAutoHeal({
      files: currentFiles,
      rootFile: params.rootFile,
      runtimeType: params.runtimeType,
      errorLogs: params.errorLogs,
      errorMessage: params.errorMessage,
    });
    if (aiResult.reports.length > 0) {
      currentFiles = aiResult.files;
      allReports.push(...aiResult.reports);
      usedGemini = true;
    }
  }

  return {
    healed: allReports.length > 0,
    files: currentFiles,
    reports: allReports,
    usedEngine: usedGemini ? 'gemini-ai' : allReports.length > 0 ? 'auto-rule' : 'none',
  };
}
