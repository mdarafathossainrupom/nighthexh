export type UserRole = 'admin' | 'subadmin' | 'user';

export type UserStatus = 'pending' | 'approved' | 'suspended' | 'expired';

export interface User {
  id: string;
  username: string;
  fullName: string;
  email: string;
  password?: string;
  role: UserRole;
  status: UserStatus;
  subdomain?: string;
  approvedAt?: string;
  approvedBy?: string;
  approvedByRole?: 'admin' | 'subadmin';
  expiresAt?: string;
  approvalDurationLabel?: string;
  storageLimitMb: number;
  storageUsedMb: number;
  avatarDataUrl?: string;
  avatarSizeKb?: number;
  createdAt: string;
  lastLoginAt: string;
}

export type SiteType = 'folder' | 'single-file' | 'github';
export type SiteStatus = 'online' | 'building' | 'error' | 'paused';

export interface SiteFile {
  path: string;
  content: string; // UTF-8 text or base64 data when isBinary is true
  size: number;
  isHidden: boolean;
  isBinary?: boolean;
  mimeType?: string;
  type: string; // 'html' | 'css' | 'js' | 'php' | 'json' | 'image' | 'font' | 'config' | 'other'
}

export interface DeploymentLog {
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success';
  message: string;
}

export interface AutoFixReport {
  id: string;
  timestamp: string;
  engine: 'gemini-ai' | 'auto-rule';
  filePath: string;
  summaryBn: string;
  issueBn: string;
  fixAppliedBn: string;
}

export interface PreHealBackupEntry {
  createdAt: string;
  reasonBn: string;
  files: Record<string, SiteFile>;
  rootFile: string;
}

export interface HostedSite {
  id: string;
  userId: string;
  username: string;
  ownerSubdomain?: string;
  name: string;
  slug: string;
  customPath?: string;
  customDomain?: string;
  repairedFilesCount?: number;
  description: string;
  type: SiteType;
  status: SiteStatus;
  rootFile: string;
  totalFiles: number;
  totalSizeKb: number;
  hiddenFilesCount: number;
  errorLog?: string[];
  deploymentLogs: DeploymentLog[];
  autoFixReports?: AutoFixReport[];
  preHealBackup?: PreHealBackupEntry;
  files: Record<string, SiteFile>;
  githubConfig?: {
    repoUrl: string;
    branch: string;
    isPrivate: boolean;
    token?: string;
    autoDeploy: boolean;
  };
  singleFileConfig?: {
    language: 'html' | 'php' | 'javascript' | 'css' | 'java';
    rawContent: string;
  };
  visitsCount: number;
  bandwidthMb: number;
  runtimeType?: 'static' | 'php' | 'node' | 'python';
  createdAt: string;
  updatedAt: string;
}

export interface SubAdmin {
  id: string;
  username: string;
  displayName: string;
  email: string;
  telegramUsername: string;
  telegramUrl: string;
  active: boolean;
  canApproveUsers: boolean;
  canSetQuota: boolean;
  canSendMessages?: boolean;
  canDownloadSource?: boolean;
  canManageAllSites?: boolean;
  createdAt: string;
  lastActive: string;
  avatarDataUrl?: string;
}

export interface AdminActivityReport {
  adminId: string;
  username: string;
  displayName: string;
  active: boolean;
  approvedUsersCount: number;
  approvedUsernames: string[];
  actionsCount: number;
  messagesSentCount: number;
  sitesCount: number;
  lastActionAt?: string;
}

export interface UserPopupMessage {
  id: string;
  title: string;
  message: string;
  linkUrl?: string;
  linkText?: string;
  linkMarked?: boolean;
  targetUserId: 'all' | string;
  targetUsername?: string;
  senderUsername: string;
  createdAt: string;
  dismissedByUserIds: string[];
}

export interface SiteHealthReport {
  overall: 'healthy' | 'partial' | 'down';
  frontendOk: boolean;
  backendOk: boolean;
  runtime: 'static' | 'php' | 'node' | 'python';
  summaryBn: string;
  summaryEn: string;
  detailBn?: string;
  detailEn?: string;
  errorText?: string;
}

export interface SupabasePoolNode {
  id: string;
  label: string;
  url: string;
  serviceRoleKey?: string;
  serviceRoleKeyMasked?: string;
  bucketName: string;
  quotaMb: number;
  usedMb?: number;
  status: 'connected' | 'error' | 'checking';
  source: 'env' | 'manual';
  lastCheckedAt?: string;
  errorMessage?: string;
}

export interface B2PoolNode {
  id: string;
  label: string;
  keyId: string;
  applicationKey?: string;
  bucketName: string;
  quotaMb: number;
  usedMb?: number;
  status: 'connected' | 'error' | 'checking';
  source: 'env' | 'manual';
  lastCheckedAt?: string;
  errorMessage?: string;
}

export interface PlatformConfig {
  brandName: string;
  tagline: string;
  heroSubtitle?: string;
  footerNote?: string;
  allowRegistration?: boolean;
  serverStorageCapacityMb?: number;
  masterAdminName: string;
  masterAdminTelegram: string;
  masterAdminTelegramHandle: string;
  masterAdminAvatarDataUrl?: string;
  secretAdminSlug: string;
  defaultStorageMb: number;
  broadcastMessage?: string;
  primaryDomain?: string;
}

export interface ServerStorageStats {
  configuredPoolMb: number;
  storageSource: 'b2-pool' | 'supabase-pool' | 'hybrid-cloud-pool' | 'os-disk';
  supabaseNodesCount: number;
  supabaseConnectedCount?: number;
  supabaseConnectedMb: number;
  supabaseNodes: SupabasePoolNode[];
  b2NodesCount?: number;
  b2ConnectedCount?: number;
  b2ConnectedMb?: number;
  b2Nodes?: B2PoolNode[];
  diskTotalMb: number | null;
  diskFreeMb: number | null;
  allocatedMb: number;
  usedBySitesMb: number;
  usedByAvatarsMb: number;
  totalUsedMb: number;
  remainingAllocatableMb: number;
  defaultQuotaMb: number;
  estimatedRemainingUsers: number;
  totalUsersCount: number;
  approvedUsersCount?: number;
  pendingUsersCount?: number;
  suspendedUsersCount?: number;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  target: string;
  details: string;
  category: 'user' | 'site' | 'subadmin' | 'config';
}

export interface ScanResult {
  fileCount: number;
  hiddenCount: number;
  totalSizeBytes: number;
  entryPointFound: string | null;
  detectedRuntime?: 'static' | 'php' | 'node' | 'python';
  warnings: string[];
  errors: string[];
  fileTree: { path: string; size: number; isHidden: boolean; type: string }[];
  checksum: string;
}

export type ThemeMode = 'dark' | 'light';

export type UserPageView =
  | 'overview'
  | 'sites'
  | 'deploy-folder'
  | 'deploy-single'
  | 'deploy-github'
  | 'profile'
  | 'guide';

export type AdminTab =
  | 'overview'
  | 'users'
  | 'subadmins'
  | 'sites'
  | 'messages'
  | 'logs'
  | 'settings';

