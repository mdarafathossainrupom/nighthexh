import React, { useState, useEffect } from 'react';
import { User, ThemeMode, PlatformConfig, UserPageView, AdminTab } from './types';
import { storage } from './services/storage';
import { Navbar } from './components/Navbar';
import { UserDashboard } from './components/UserDashboard';
import { AdminPanel } from './components/AdminPanel';
import { AdminLoginGateway } from './components/AdminLoginGateway';
import { AuthModal } from './components/AuthModal';
import {
  FolderUp,
  FileCode2,
  FolderGit2,
  ArrowRight,
  Sparkles,
  Send,
  ShieldCheck,
  Clock,
  AlertTriangle,
  LogOut,
  BellRing,
  X,
  Check,
  Loader2,
  ExternalLink,
  Link2,
  Globe,
} from 'lucide-react';
import { normalizeUserSubdomain, sanitizeExternalLinkUrl } from './services/format';

export default function App() {
  const [user, setUser] = useState<User | null>(() => storage.getCurrentUser());
  const [config, setConfig] = useState<PlatformConfig>(() => storage.getConfig());
  const [currentView, setCurrentView] = useState<string>(() => {
    const path = window.location.pathname.replace(/\/$/, '') || '/';
    const cfg = storage.getConfig();
    if (path === `/${cfg.secretAdminSlug}` || path === '/admin' || path === '/admin-portal') {
      return 'admin';
    }
    return 'dashboard';
  });
  const [lang, setLang] = useState<'bn' | 'en'>(() => storage.getSavedLang());
  const [theme, setTheme] = useState<ThemeMode>(() => storage.getTheme());

  const [userPage, setUserPage] = useState<UserPageView>(() => storage.getSavedUserPage());
  const [adminTab, setAdminTab] = useState<AdminTab>(() => storage.getSavedAdminTab());
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');
  const [profileOpenTick, setProfileOpenTick] = useState(0);
  const [dismissingMsgId, setDismissingMsgId] = useState<string | null>(null);
  const [, setExpiryTick] = useState(0);
  const [subdomainDraft, setSubdomainDraft] = useState('');
  const [subdomainCheck, setSubdomainCheck] = useState<{
    checking: boolean;
    available?: boolean;
    normalized?: string;
    message?: string;
  }>({ checking: false });
  const [savingSubdomain, setSavingSubdomain] = useState(false);
  const [subdomainError, setSubdomainError] = useState<string | null>(null);

  useEffect(() => {
    const initialTheme = storage.getTheme();
    setTheme(initialTheme);
    storage.setTheme(initialTheme);

    const unsubscribe = storage.subscribe(() => {
      const u = storage.getCurrentUser();
      setUser(u ? { ...u } : null);
      setConfig(storage.getConfig());
    });

    storage.syncFromServer().then(() => {
      const latestConfig = storage.getConfig();
      const path = window.location.pathname.replace(/\/$/, '') || '/';
      if (
        path === `/${latestConfig.secretAdminSlug}` ||
        path === '/admin' ||
        path === '/admin-portal'
      ) {
        setCurrentView('admin');
        storage.setCurrentRoute('admin');
      } else {
        setCurrentView('dashboard');
        storage.setCurrentRoute('dashboard');
      }
    });

    const handlePopState = () => {
      const path = window.location.pathname.replace(/\/$/, '') || '/';
      const cfg = storage.getConfig();
      if (path === `/${cfg.secretAdminSlug}` || path === '/admin' || path === '/admin-portal') {
        setCurrentView('admin');
        storage.setCurrentRoute('admin');
      } else {
        setCurrentView('dashboard');
        storage.setCurrentRoute('dashboard');
      }
    };
    window.addEventListener('popstate', handlePopState);

    const stopRealtime = storage.startRealtimeSync();

    return () => {
      unsubscribe();
      stopRealtime();
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  useEffect(() => {
    if (!user || user.role === 'admin' || !user.expiresAt) return;
    const id = window.setInterval(() => setExpiryTick((t) => t + 1), 1000);
    return () => window.clearInterval(id);
  }, [user]);

  const toggleTheme = () => {
    const nextTheme: ThemeMode = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    storage.setTheme(nextTheme);
  };

  const toggleLang = () => {
    const next = lang === 'bn' ? 'en' : 'bn';
    setLang(next);
    storage.setSavedLang(next);
  };

  const handleNavigate = (view: string) => {
    setCurrentView(view);
    storage.setCurrentRoute(view);
    if (view === 'admin') {
      const targetPath = `/${config.secretAdminSlug || 'admin'}`;
      if (window.location.pathname !== targetPath) {
        window.history.pushState({}, '', targetPath);
      }
    } else if (window.location.pathname !== '/') {
      window.history.pushState({}, '', '/');
    }
  };

  const handleSelectUserPage = (page: UserPageView) => {
    setUserPage(page);
    storage.setSavedUserPage(page);
    if (currentView !== 'dashboard') {
      handleNavigate('dashboard');
    }
  };

  const handleSelectAdminTab = (tab: AdminTab) => {
    setAdminTab(tab);
    storage.setSavedAdminTab(tab);
    if (currentView !== 'admin') {
      handleNavigate('admin');
    }
  };

  const handleOpenAuth = (mode: 'login' | 'register' = 'login') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  };

  const handleUserAuthSuccess = (authenticatedUser: User) => {
    storage.setSavedDeployMethod(null);
    storage.setSavedUserPage('overview');
    setUserPage('overview');
    setUser(authenticatedUser);
    setAuthModalOpen(false);
    handleNavigate('dashboard');
  };

  const handleAdminAuthSuccess = (authenticatedUser: User) => {
    storage.setSavedAdminTab('overview');
    setAdminTab('overview');
    setUser(authenticatedUser);
    setAuthModalOpen(false);
    handleNavigate('admin');
  };

  const isViewingAdminRoute = currentView === 'admin';
  const isAdminAuthenticated = Boolean(user && (user.role === 'admin' || user.role === 'subadmin'));

  const isAccountSuspended = Boolean(user && user.role !== 'admin' && user.status === 'suspended');
  const isAccountPending = Boolean(user && user.role !== 'admin' && user.status === 'pending');
  const isAccountExpired = Boolean(
    user &&
      user.role !== 'admin' &&
      user.status === 'approved' &&
      storage.getRemainingApprovalTime(user, lang).isExpired
  );
  const isAccountLocked = isAccountSuspended || isAccountPending || isAccountExpired;

  const activeSubAdmins = storage.getActiveSubAdmins();
  const unreadMessages =
    user && !isAccountLocked ? storage.getUnreadPopupMessagesForUser(user.id) : [];
  const activePopupMsg = unreadMessages.length > 0 ? unreadMessages[0] : null;
  const safePopupUrl = activePopupMsg?.linkUrl ? sanitizeExternalLinkUrl(activePopupMsg.linkUrl) : '';

  const needsSubdomainOnboarding = Boolean(
    user &&
      user.role !== 'admin' &&
      !isAccountLocked &&
      !user.subdomain &&
      currentView !== 'admin' &&
      !activePopupMsg
  );

  useEffect(() => {
    if (!needsSubdomainOnboarding || !user) return;
    setSubdomainDraft((prev) => prev || normalizeUserSubdomain(user.username || ''));
    setSubdomainError(null);
  }, [needsSubdomainOnboarding, user]);

  useEffect(() => {
    if (!needsSubdomainOnboarding) return;
    const candidate = normalizeUserSubdomain(subdomainDraft);
    if (!candidate || candidate.length < 3) {
      setSubdomainCheck({
        checking: false,
        available: false,
        normalized: candidate,
        message:
          lang === 'bn'
            ? 'কমপক্ষে ৩ অক্ষরের ইংরেজি অক্ষর বা সংখ্যা দিন।'
            : 'Must be at least 3 lowercase letters or numbers.',
      });
      return;
    }
    let cancelled = false;
    setSubdomainCheck((prev) => ({ ...prev, checking: true, normalized: candidate }));
    const timer = window.setTimeout(async () => {
      const res = await storage.checkSubdomainAvailabilityAsync(candidate);
      if (!cancelled) {
        setSubdomainCheck({
          checking: false,
          available: res.available,
          normalized: res.normalized,
          message: res.message,
        });
      }
    }, 260);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [needsSubdomainOnboarding, subdomainDraft, lang]);

  const handleClaimSubdomain = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || savingSubdomain) return;
    setSubdomainError(null);
    setSavingSubdomain(true);
    try {
      const res = await storage.saveUserSubdomainAsync(subdomainDraft);
      if (!res.success) {
        setSubdomainError(res.message);
      }
    } finally {
      setSavingSubdomain(false);
    }
  };

  const handleDismissPopupMsg = async () => {
    if (!activePopupMsg || !user || dismissingMsgId) return;
    setDismissingMsgId(activePopupMsg.id);
    try {
      await storage.dismissPopupMessageAsync(activePopupMsg.id, user.id);
    } finally {
      setDismissingMsgId(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/80 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-white transition-colors duration-200 overflow-x-hidden">
      {isViewingAdminRoute && !user ? (
        <AdminLoginGateway
          onSuccess={handleAdminAuthSuccess}
          onGoHome={() => handleNavigate('dashboard')}
          lang={lang}
          theme={theme}
          onToggleTheme={toggleTheme}
        />
      ) : (
        <>
          <Navbar
            user={user}
            currentView={currentView}
            userPage={userPage}
            onSelectUserPage={handleSelectUserPage}
            adminTab={adminTab}
            onSelectAdminTab={handleSelectAdminTab}
            theme={theme}
            onToggleTheme={toggleTheme}
            onNavigate={handleNavigate}
            onOpenAuth={handleOpenAuth}
            onOpenProfile={() => {
              if (currentView === 'admin') {
                setProfileOpenTick((t) => t + 1);
              } else {
                handleSelectUserPage('profile');
              }
            }}
            lang={lang}
            onToggleLang={toggleLang}
          />

          <main className="flex-1 pb-12">
            {user && currentView === 'admin' && isAdminAuthenticated && !isAccountLocked ? (
              <AdminPanel
                currentUser={user}
                activeTab={adminTab}
                onChangeTab={handleSelectAdminTab}
                onNavigateHome={() => {
                  handleSelectUserPage('overview');
                }}
                externalProfileTrigger={profileOpenTick}
                lang={lang}
              />
            ) : user ? (
              <UserDashboard
                user={user}
                lang={lang}
                activePage={userPage}
                onChangePage={handleSelectUserPage}
                externalProfileTrigger={profileOpenTick}
                onOpenAdminPanel={
                  isAdminAuthenticated && !isAccountLocked
                    ? () => {
                        handleSelectAdminTab('overview');
                      }
                    : undefined
                }
              />
            ) : (
              <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 sm:pt-16 space-y-12">
                {config.broadcastMessage && (
                  <div className="max-w-3xl mx-auto flex items-center justify-center gap-2.5 px-4 py-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-500/40 text-amber-800 dark:text-amber-200 text-xs font-medium shadow-sm">
                    <ShieldCheck className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                    <span>{config.broadcastMessage}</span>
                  </div>
                )}

                <div className="text-center max-w-3xl mx-auto space-y-5">
                  <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-cyan-50 dark:bg-cyan-950/70 border border-cyan-200 dark:border-cyan-500/40 text-cyan-700 dark:text-cyan-300 text-xs font-semibold shadow-sm">
                    <Sparkles className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                    <span>{config.brandName} Cloud Engine</span>
                  </div>

                  <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight text-slate-900 dark:text-white">
                    {lang === 'bn' ? (
                      <>
                        দ্রুত ও নিরাপদ ওয়েব হোস্টিং{' '}
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-600 via-indigo-600 to-blue-600 dark:from-cyan-400 dark:via-indigo-400 dark:to-blue-500">
                          {config.brandName}
                        </span>{' '}
                        এ
                      </>
                    ) : (
                      <>
                        Fast Web & Code Hosting on{' '}
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-600 via-indigo-600 to-blue-600 dark:from-cyan-400 dark:via-indigo-400 dark:to-blue-500">
                          {config.brandName}
                        </span>
                      </>
                    )}
                  </h1>

                  <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 leading-relaxed max-w-2xl mx-auto">
                    {config.heroSubtitle?.trim()
                      ? config.heroSubtitle
                      : lang === 'bn'
                      ? 'সম্পূর্ণ ফোল্ডার (হিডেন ও .env ফাইল সহ), সিঙ্গেল PHP/HTML/JS/CSS/Java ফাইল অথবা GitHub রিপোজিটরি থেকে সরাসরি ওয়েবসাইট হোস্ট করুন।'
                      : 'Deploy web projects effortlessly via folder picker, standalone PHP/HTML runner, or GitHub repository sync.'}
                  </p>

                  <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => handleOpenAuth('login')}
                      className="px-6 py-3 rounded-2xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-lg shadow-cyan-600/20 flex items-center gap-2 transition"
                    >
                      <span>{lang === 'bn' ? 'লগইন করে শুরু করুন' : 'Sign In & Launch'}</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>

                    {config.allowRegistration !== false ? (
                      <button
                        type="button"
                        onClick={() => handleOpenAuth('register')}
                        className="px-6 py-3 rounded-2xl bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 font-semibold text-xs transition shadow-sm"
                      >
                        {lang === 'bn' ? 'নতুন অ্যাকাউন্ট খুলুন' : 'Create Account'}
                      </button>
                    ) : (
                      <span className="px-4 py-3 rounded-2xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-medium text-xs">
                        {lang === 'bn' ? 'রেজিস্ট্রেশন সাময়িক বন্ধ' : 'Registration Paused'}
                      </span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  <div className="p-6 rounded-3xl bg-white dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
                    <div className="w-11 h-11 rounded-2xl bg-cyan-50 dark:bg-cyan-950/70 border border-cyan-200 dark:border-cyan-500/30 flex items-center justify-center text-cyan-600 dark:text-cyan-400">
                      <FolderUp className="w-5 h-5" />
                    </div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      {lang === 'bn' ? '১. সম্পূর্ণ ফোল্ডার হোস্টিং' : '1. Full Folder Deployment'}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {lang === 'bn'
                        ? 'আপনার সম্পূর্ণ প্রজেক্ট ফোল্ডার সিলেক্ট বা ড্র্যাগ-ড্রপ করুন। .env ও .htaccess সহ সব হিডেন ফাইল সুরক্ষিত থাকবে।'
                        : 'Upload an entire folder. All internal subdirectories and hidden configurations (.env, .htaccess) are preserved.'}
                    </p>
                  </div>

                  <div className="p-6 rounded-3xl bg-white dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
                    <div className="w-11 h-11 rounded-2xl bg-indigo-50 dark:bg-indigo-950/70 border border-indigo-200 dark:border-indigo-500/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                      <FileCode2 className="w-5 h-5" />
                    </div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      {lang === 'bn' ? '২. সিঙ্গেল ফাইল (PHP / HTML)' : '2. Single File (PHP / HTML)'}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {lang === 'bn'
                        ? 'শুধুমাত্র একটি PHP, HTML, JS, CSS বা Java ফাইল আপলোড বা পেস্ট করে সরাসরি লাইভ রান করুন।'
                        : 'Run single dynamic PHP 8.3 files or static HTML5 pages with built-in code editor & live preview.'}
                    </p>
                  </div>

                  <div className="p-6 rounded-3xl bg-white dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
                    <div className="w-11 h-11 rounded-2xl bg-blue-50 dark:bg-blue-950/70 border border-blue-200 dark:border-blue-500/30 flex items-center justify-center text-blue-600 dark:text-blue-400">
                      <FolderGit2 className="w-5 h-5" />
                    </div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      {lang === 'bn' ? '৩. গিটহাব সিঙ্ক (Public / Private)' : '3. GitHub Repository Sync'}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {lang === 'bn'
                        ? 'পাবলিক রিপোজিটরি অথবা Personal Access Token (PAT) দিয়ে সুরক্ষিত প্রাইভেট রিপোজিটরি সরাসরি যুক্ত করুন।'
                        : 'Link public or private repositories with live file fetching and branch selection.'}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </main>

          {/* Clean Copyright & Developer Telegram Footer */}
          <footer className="border-t border-slate-200 dark:border-slate-800/80 bg-white dark:bg-slate-950 py-5 px-4 transition-colors">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-400">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 font-medium">
                <ShieldCheck className="w-4 h-4 text-cyan-600 dark:text-cyan-400 shrink-0" />
                <span>
                  © {new Date().getFullYear()} <strong className="text-slate-900 dark:text-white">{config.brandName}</strong>{' '}
                  {lang === 'bn' ? '• সর্বস্বত্ব সংরক্ষিত' : '• All Rights Reserved'}
                  {config.footerNote?.trim() ? ` • ${config.footerNote.trim()}` : ''}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span>{lang === 'bn' ? 'ডেভেলপার:' : 'Developer:'}</span>
                <a
                  href={config.masterAdminTelegram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-50 dark:bg-cyan-950/70 border border-cyan-200 dark:border-cyan-500/30 text-cyan-700 dark:text-cyan-300 font-bold hover:bg-cyan-100 dark:hover:bg-cyan-900/60 transition"
                >
                  <Send className="w-3 h-3" />
                  <span>{config.masterAdminName}</span>
                </a>
              </div>
            </div>
          </footer>

          {authModalOpen && (
            <AuthModal
              initialMode={authModalMode}
              onClose={() => setAuthModalOpen(false)}
              onSuccess={handleUserAuthSuccess}
              lang={lang}
            />
          )}

          {/* Persistent Centered Account Expiry / Suspension Renewal Contact Modal */}
          {user && isAccountLocked && (
            <div className="fixed inset-0 z-[65] min-h-[100dvh] flex items-center justify-center p-4 bg-slate-900/65 dark:bg-slate-950/85 backdrop-blur-md">
              <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4 max-h-[88dvh] overflow-y-auto">
                <div className="flex items-start gap-3">
                  <div
                    className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 border ${
                      isAccountSuspended
                        ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-500/40 text-rose-600 dark:text-rose-400'
                        : 'bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-500/40 text-amber-600 dark:text-amber-400'
                    }`}
                  >
                    {isAccountSuspended ? (
                      <AlertTriangle className="w-5 h-5" />
                    ) : (
                      <Clock className="w-5 h-5" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <h2 className="text-base font-extrabold text-slate-900 dark:text-white leading-snug">
                      {isAccountSuspended
                        ? lang === 'bn'
                          ? 'অ্যাকাউন্ট সাময়িক সাসপেন্ড রয়েছে'
                          : 'Account Temporarily Suspended'
                        : isAccountPending
                        ? lang === 'bn'
                          ? 'অ্যাকাউন্ট অনুমোদনের অপেক্ষায়'
                          : 'Account Pending Approval'
                        : lang === 'bn'
                        ? 'আপনার অ্যাকাউন্টের মেয়াদ শেষ হয়েছে'
                        : 'Your Account Validity Has Expired'}
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      @{user.username} • {user.email}
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                  {lang === 'bn'
                    ? 'আপনার সকল হোস্টকৃত ওয়েবসাইট, কোড ও ফাইল সম্পূর্ণ সুরক্ষিত রয়েছে। অ্যাকাউন্ট পুনরায় রিনিউ বা আনসাসপেন্ড করতে নিচের মালিক বা অ্যাডমিনের সাথে যোগাযোগ করুন — অনুমোদন দেওয়ার সাথে সাথেই প্যানেল আনলক হয়ে যাবে।'
                    : 'All of your hosted websites and files remain safely preserved. Contact the Owner or an active Admin below to renew or reactivate your access — your dashboard will unlock live automatically.'}
                </div>

                <div className="space-y-2">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 font-mono">
                    {lang === 'bn' ? 'সাপোর্ট ও রিনিউয়াল যোগাযোগ:' : 'Renewal & Support Contacts:'}
                  </div>

                  <a
                    href={config.masterAdminTelegram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between gap-3 p-3 rounded-2xl bg-cyan-50 dark:bg-cyan-950/50 border border-cyan-200 dark:border-cyan-500/30 hover:bg-cyan-100 dark:hover:bg-cyan-900/50 transition"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {config.masterAdminAvatarDataUrl ? (
                        <img
                          src={config.masterAdminAvatarDataUrl}
                          alt={config.masterAdminName}
                          referrerPolicy="no-referrer"
                          className="w-9 h-9 rounded-xl object-cover border border-rose-300 dark:border-rose-500/40 shrink-0"
                        />
                      ) : (
                        <div className="w-9 h-9 rounded-xl bg-rose-100 dark:bg-rose-950 border border-rose-300 dark:border-rose-500/40 flex items-center justify-center text-rose-700 dark:text-rose-400 font-bold text-xs shrink-0">
                          {(config.masterAdminName || 'O').charAt(0).toUpperCase()}
                        </div>
                      )}
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
                          {config.masterAdminName}{' '}
                          <span className="text-[10px] font-mono text-rose-600 dark:text-rose-400">
                            ({lang === 'bn' ? 'মালিক' : 'Owner'})
                          </span>
                        </div>
                        <div className="text-[11px] font-mono text-cyan-700 dark:text-cyan-400">
                          {config.masterAdminTelegramHandle}
                        </div>
                      </div>
                    </div>
                    <span className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-cyan-600 text-white text-[11px] font-bold shrink-0">
                      <Send className="w-3 h-3" />
                      <span>Telegram</span>
                    </span>
                  </a>

                  {activeSubAdmins.map((sub) => (
                    <a
                      key={sub.id}
                      href={sub.telegramUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-between gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 hover:border-cyan-400 transition"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {sub.avatarDataUrl ? (
                          <img
                            src={sub.avatarDataUrl}
                            alt={sub.displayName || sub.username}
                            referrerPolicy="no-referrer"
                            className="w-9 h-9 rounded-xl object-cover border border-cyan-300 dark:border-cyan-500/40 shrink-0"
                          />
                        ) : (
                          <div className="w-9 h-9 rounded-xl bg-cyan-100 dark:bg-cyan-950 border border-cyan-300 dark:border-cyan-500/30 flex items-center justify-center text-cyan-700 dark:text-cyan-400 font-bold text-xs shrink-0">
                            {sub.username.charAt(0).toUpperCase()}
                          </div>
                        )}
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {sub.displayName || sub.username}{' '}
                            <span className="text-[10px] font-mono text-amber-600 dark:text-amber-400">
                              ({lang === 'bn' ? 'অ্যাডমিন' : 'Admin'})
                            </span>
                          </div>
                          <div className="text-[11px] font-mono text-cyan-600 dark:text-cyan-400">
                            {sub.telegramUsername}
                          </div>
                        </div>
                      </div>
                      <span className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-800 dark:bg-slate-800 text-white text-[11px] font-semibold shrink-0">
                        <Send className="w-3 h-3" />
                        <span>Telegram</span>
                      </span>
                    </a>
                  ))}
                </div>

                <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end">
                  <button
                    type="button"
                    onClick={() => storage.logoutAsync()}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold transition"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>{lang === 'bn' ? 'সাইন আউট করুন' : 'Sign Out'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Single-Show One-Time Popup Message Modal */}
          {activePopupMsg && user && (
            <div className="fixed inset-0 z-[64] min-h-[100dvh] flex items-center justify-center p-4 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-md">
              <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-cyan-200 dark:border-cyan-500/40 shadow-2xl p-5 sm:p-6 space-y-4 max-h-[85dvh] overflow-y-auto">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-10 h-10 rounded-2xl bg-cyan-50 dark:bg-cyan-950/70 border border-cyan-200 dark:border-cyan-500/30 flex items-center justify-center text-cyan-600 dark:text-cyan-400 shrink-0">
                      <BellRing className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-[10px] font-mono uppercase text-cyan-700 dark:text-cyan-400 font-bold">
                        {lang === 'bn' ? 'অ্যাডমিন বার্তা' : 'Admin Notice'} • @{activePopupMsg.senderUsername}
                      </div>
                      <h3 className="text-base font-extrabold text-slate-900 dark:text-white truncate">
                        {activePopupMsg.title}
                      </h3>
                    </div>
                  </div>
                  <button
                    type="button"
                    aria-label={lang === 'bn' ? 'বার্তা বন্ধ করুন' : 'Dismiss notice'}
                    disabled={dismissingMsgId === activePopupMsg.id}
                    onClick={handleDismissPopupMsg}
                    className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white transition"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed whitespace-pre-wrap break-words space-y-3">
                  <div>{activePopupMsg.message}</div>
                  {safePopupUrl && activePopupMsg.linkMarked === false && (
                    <div className="pt-1">
                      <a
                        href={safePopupUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-medium text-cyan-700 dark:text-cyan-400 underline underline-offset-4 hover:opacity-80 break-all"
                      >
                        <Link2 className="w-3.5 h-3.5 shrink-0" />
                        <span>{activePopupMsg.linkText || safePopupUrl}</span>
                        <ExternalLink className="w-3 h-3 shrink-0" />
                      </a>
                    </div>
                  )}
                </div>

                {safePopupUrl && activePopupMsg.linkMarked !== false && (
                  <a
                    href={safePopupUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-between gap-2 px-4 py-3 rounded-2xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs sm:text-sm font-bold shadow-md transition"
                  >
                    <span className="inline-flex items-center gap-2 min-w-0 truncate">
                      <Link2 className="w-4 h-4 shrink-0" />
                      <span className="truncate">{activePopupMsg.linkText || safePopupUrl}</span>
                    </span>
                    <ExternalLink className="w-4 h-4 shrink-0" />
                  </a>
                )}

                <div className="flex items-center justify-between gap-2 pt-1 text-[11px] text-slate-500 dark:text-slate-400">
                  <span className="tabular-nums">{new Date(activePopupMsg.createdAt).toLocaleString()}</span>
                  <button
                    type="button"
                    disabled={dismissingMsgId === activePopupMsg.id}
                    onClick={handleDismissPopupMsg}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-sm transition disabled:opacity-60"
                  >
                    {dismissingMsgId === activePopupMsg.id ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Check className="w-3.5 h-3.5" />
                    )}
                    <span>{lang === 'bn' ? 'ঠিক আছে / বন্ধ করুন' : 'Got It / Dismiss'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* One-Time Personal Subdomain Onboarding Modal */}
          {needsSubdomainOnboarding && user && (
            <div
              className="fixed inset-0 z-[63] min-h-[100dvh] flex items-center justify-center p-4 bg-slate-900/65 dark:bg-slate-950/85 backdrop-blur-md"
              role="dialog"
              aria-modal="true"
              aria-labelledby="subdomain-onboarding-title"
            >
              <form
                onSubmit={handleClaimSubdomain}
                className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-5 sm:p-6 space-y-4 max-h-[88dvh] overflow-y-auto"
              >
                <div className="flex items-start gap-3">
                  {user.avatarDataUrl ? (
                    <img
                      src={user.avatarDataUrl}
                      alt={user.username}
                      referrerPolicy="no-referrer"
                      className="w-11 h-11 rounded-2xl object-cover border border-cyan-200 dark:border-cyan-500/40 shrink-0"
                    />
                  ) : (
                    <div className="w-11 h-11 rounded-2xl bg-cyan-50 dark:bg-cyan-950/70 border border-cyan-200 dark:border-cyan-500/30 flex items-center justify-center text-cyan-600 dark:text-cyan-400 shrink-0">
                      <Globe className="w-5 h-5" />
                    </div>
                  )}
                  <div className="min-w-0">
                    <h2
                      id="subdomain-onboarding-title"
                      className="text-base font-extrabold text-slate-900 dark:text-white leading-snug"
                    >
                      {lang === 'bn'
                        ? 'আপনার নিজস্ব সাবডোমেইন সেট করুন'
                        : 'Claim Your Personal Subdomain'}
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      {lang === 'bn'
                        ? 'একবার সেট করলে আপনার সব ডিপ্লয়কৃত সাইট এই পার্সোনাল URL প্রিফিক্সে লাইভ থাকবে।'
                        : 'All of your deployed sites will automatically mount under this personal URL prefix.'}
                    </p>
                  </div>
                </div>

                {subdomainError && (
                  <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300 text-xs">
                    {subdomainError}
                  </div>
                )}

                <div className="space-y-2">
                  <label
                    htmlFor="onboarding-subdomain-input"
                    className="block text-xs font-bold text-slate-700 dark:text-slate-300"
                  >
                    {lang === 'bn' ? 'সাবডোমেইন নাম (ইংরেজি অক্ষর / সংখ্যা / -)' : 'Subdomain Name (a-z, 0-9, -)'}
                  </label>
                  <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2.5">
                    <span className="text-xs font-mono text-slate-500 dark:text-slate-400 shrink-0">/u/</span>
                    <input
                      id="onboarding-subdomain-input"
                      type="text"
                      value={subdomainDraft}
                      onChange={(e) => setSubdomainDraft(e.target.value.toLowerCase())}
                      placeholder={normalizeUserSubdomain(user.username || 'my-brand')}
                      className="w-full bg-transparent text-sm font-mono font-bold text-cyan-700 dark:text-cyan-400 focus:outline-none ml-1 min-w-0"
                      autoFocus
                      required
                    />
                  </div>

                  <div className="flex items-center justify-between text-[11px] min-h-[18px]">
                    {subdomainCheck.checking ? (
                      <span className="inline-flex items-center gap-1 text-slate-500 dark:text-slate-400">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        <span>{lang === 'bn' ? 'যাচাই হচ্ছে...' : 'Checking availability...'}</span>
                      </span>
                    ) : subdomainCheck.message ? (
                      <span
                        className={
                          subdomainCheck.available
                            ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
                            : 'text-rose-600 dark:text-rose-400 font-semibold'
                        }
                      >
                        {subdomainCheck.message}
                      </span>
                    ) : (
                      <span />
                    )}
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 space-y-1.5 text-[11px] font-mono">
                  <div className="text-slate-500 dark:text-slate-400 font-sans font-semibold">
                    {lang === 'bn' ? 'লাইভ ইউআরএল প্রিভিউ:' : 'Live URL Preview:'}
                  </div>
                  <div className="text-emerald-700 dark:text-emerald-400 font-bold break-all">
                    https://{subdomainCheck.normalized || normalizeUserSubdomain(subdomainDraft) || 'name'}.{config.primaryDomain || 'nighthostcloud.dpdns.org'}/my-site
                  </div>
                  <div className="text-cyan-700 dark:text-cyan-400 break-all">
                    /u/{subdomainCheck.normalized || normalizeUserSubdomain(subdomainDraft) || 'name'}/my-site
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="submit"
                    disabled={savingSubdomain || subdomainCheck.checking || subdomainCheck.available === false}
                    className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-sm transition disabled:opacity-60"
                  >
                    {savingSubdomain ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Check className="w-4 h-4" />
                    )}
                    <span>
                      {lang === 'bn' ? 'সাবডোমেইন সংরক্ষণ করে ড্যাশবোর্ডে যান' : 'Save Subdomain & Continue'}
                    </span>
                  </button>
                </div>
              </form>
            </div>
          )}
        </>
      )}
    </div>
  );
}
