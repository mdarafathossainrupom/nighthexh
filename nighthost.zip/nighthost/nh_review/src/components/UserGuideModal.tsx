import React from 'react';
import {
  X,
  FolderUp,
  FileCode2,
  FolderGit2,
  Link2,
  ShieldCheck,
  Terminal,
  Send,
  Info,
} from 'lucide-react';
import { storage } from '../services/storage';

interface UserGuideModalProps {
  lang: 'bn' | 'en';
  onClose: () => void;
}

export const UserGuideModal: React.FC<UserGuideModalProps> = ({ lang, onClose }) => {
  const config = storage.getConfig();

  const sections = [
    {
      icon: FolderUp,
      color: 'text-cyan-600 dark:text-cyan-400 bg-cyan-50 dark:bg-cyan-950/60 border-cyan-200 dark:border-cyan-500/30',
      titleBn: '১. ফোল্ডার হোস্টিং (Full Folder Hosting)',
      titleEn: '1. Full Folder Hosting',
      bodyBn:
        'আপনার সম্পূর্ণ ওয়েব প্রজেক্ট ফোল্ডার ড্র্যাগ-ড্রপ বা সিলেক্ট করুন। HTML, CSS, JS, PHP, Python (Flask/FastAPI), Node.js অ্যাপ এবং .env / .htaccess সহ সকল হিডেন ও মিডিয়া ফাইল স্বয়ংক্রিয়ভাবে রান ও হোস্ট হয়।',
      bodyEn:
        'Select or drag-and-drop an entire project folder. Supports HTML, CSS, JS, PHP, Python (Flask/FastAPI), Node.js backends, media assets, plus .env and .htaccess hidden configs.',
    },
    {
      icon: FileCode2,
      color: 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-500/30',
      titleBn: '২. সিঙ্গেল ফাইল হোস্টিং (PHP 8.3 / HTML / JS / CSS)',
      titleEn: '2. Single-File Hosting (PHP / HTML / JS / CSS)',
      bodyBn:
        'কোনো ফোল্ডার বা জিপ ছাড়াই একটি মাত্র index.php বা index.html ফাইল আপলোড বা পেস্ট করে লাইভ করুন। PHP ফর্ম সাবমিশন (POST/GET), সেশন, ফাইল স্টোরেজ ও API রিকোয়েস্ট রিয়েল-টাইমে কাজ করে।',
      bodyEn:
        'Deploy a single index.php or index.html script instantly. Full server-side PHP execution supports POST/GET forms, sessions, local file persistence, and external API calls.',
    },
    {
      icon: FolderGit2,
      color: 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-500/30',
      titleBn: '৩. GitHub রিপোজিটরি সিঙ্ক (Public & Private PAT)',
      titleEn: '3. GitHub Repository Sync (Public & Private)',
      bodyBn:
        'পাবলিক রিপোর URL দিন অথবা প্রাইভেট রিপোর জন্য GitHub Personal Access Token (PAT) যুক্ত করে ব্রাঞ্চ সিঙ্ক করুন। রিপোর মিসিং ওয়েল-নোন ডিপেন্ডেন্সি অটো-অডিট হয়ে চালু হবে।',
      bodyEn:
        'Paste any public GitHub repo URL, or attach a Personal Access Token (PAT) for private repositories. Files and backend entry points are audited and launched automatically.',
    },
    {
      icon: Link2,
      color: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-500/30',
      titleBn: '৪. নিজস্ব লাইভ সাবডোমেইন (<নাম>.nighthostcloud.dpdns.org) ও স্লাগ',
      titleEn: '4. Live Personal Subdomain (<name>.nighthostcloud.dpdns.org) & Slug',
      bodyBn:
        'আপনার অ্যাকাউন্টের ইউনিক সাবডোমেইনের অধীনে <name>.nighthostcloud.dpdns.org/<slug>, /u/<name>/<slug> এবং সরাসরি /site/<slug> — তিনটি লিংকেই প্রতিটি প্রজেক্ট অটো-হোস্ট হয়।',
      bodyEn:
        'Every project automatically mounts on <name>.nighthostcloud.dpdns.org/<slug>, /u/<name>/<slug>, and direct /site/<slug> endpoints for instant opening and sharing.',
    },
    {
      icon: Terminal,
      color: 'text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/60 border-purple-200 dark:border-purple-500/30',
      titleBn: '৫. ✨ AI অটো-হিল, ১-ক্লিক Undo, লাইভ কোড ও .env এডিটর',
      titleEn: '5. ✨ AI Auto-Heal, 1-Click Undo, Live Code & .env Editor',
      bodyBn:
        'ডিপ্লয়ের সময় বা রানটাইম ক্র্যাশ করলে সিস্টেম পোর্ট/হোস্ট/JSON এরর স্বয়ংক্রিয়ভাবে ঠিক করে ও বাংলা রিপোর্ট দেয়। চাইলে ইন্সপেক্টর থেকে "✨ অটো-হিল" বা ১ ক্লিকে "↩ পূর্বের কোডে ফিরুন" ব্যবহার করতে পারবেন এবং .env ও .zip ব্যাকআপ নিতে পারবেন।',
      bodyEn:
        'Auto-Heal fixes port/host/JSON issues with clear explanations and 1-click Undo restore. You can also edit code or .env live, restart Node/Python runtimes, or download a .zip backup.',
    },
    {
      icon: ShieldCheck,
      color: 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-500/30',
      titleBn: '৬. অ্যাকাউন্ট অনুমোদন, মেয়াদ, স্টোরেজ কোটা ও সাপোর্ট',
      titleEn: '6. Account Approval, Validity, Quotas & Support',
      bodyBn:
        'অ্যাকাউন্ট অনুমোদনের পর আপনার নির্ধারিত স্টোরেজ কোটা ও মেয়াদ অনুযায়ী হোস্টিং চলবে। মেয়াদ শেষ হলে বা সাসপেন্ড হলে ব্র্যান্ডেড নোটিশ দেখাবে এবং অনুমোদন পেলে সব ফাইলসহ পুনরায় লাইভ হবে।',
      bodyEn:
        'After Owner or Admin approval, hosting runs continuously within your quota and validity window. If paused, expired, or suspended, files stay preserved until reinstated.',
    },
  ];

  return (
    <div
      className="fixed inset-0 z-[70] min-h-[100dvh] flex items-center justify-center p-4 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-labelledby="nighthost-user-guide-title"
    >
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative z-10 w-full max-w-xl rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[85dvh] my-auto">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-950/70">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-cyan-50 dark:bg-cyan-950/70 border border-cyan-200 dark:border-cyan-500/40 flex items-center justify-center text-cyan-600 dark:text-cyan-400 shrink-0">
              <Info className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h2
                id="nighthost-user-guide-title"
                className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white truncate"
              >
                {lang === 'bn'
                  ? `${config.brandName} ব্যবহার নির্দেশিকা ও ফিচারসমূহ`
                  : `${config.brandName} User Guide & Features`}
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                {lang === 'bn'
                  ? 'হোস্টিং প্ল্যাটফর্মের প্রতিটি অপশন কীভাবে ব্যবহার করবেন'
                  : 'Complete overview of hosting workflows & runtime capabilities'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label={lang === 'bn' ? 'নির্দেশিকা বন্ধ করুন' : 'Close User Guide'}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-5 space-y-3 overflow-y-auto">
          {sections.map((sec, idx) => {
            const Icon = sec.icon;
            return (
              <div
                key={idx}
                className="p-3.5 rounded-2xl bg-slate-50/70 dark:bg-slate-950/60 border border-slate-200/80 dark:border-slate-800 flex items-start gap-3"
              >
                <div className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 ${sec.color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="min-w-0 space-y-1">
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                    {lang === 'bn' ? sec.titleBn : sec.titleEn}
                  </h3>
                  <p className="text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {lang === 'bn' ? sec.bodyBn : sec.bodyEn}
                  </p>
                </div>
              </div>
            );
          })}

          <div className="p-3.5 rounded-2xl bg-cyan-50/60 dark:bg-cyan-950/30 border border-cyan-200/70 dark:border-cyan-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs text-cyan-900 dark:text-cyan-200">
              <Terminal className="w-4 h-4 text-cyan-600 dark:text-cyan-400 shrink-0" />
              <span>
                {lang === 'bn'
                  ? 'সহায়তা বা অ্যাকাউন্ট অনুমোদনের জন্য টেলিগ্রামে যোগাযোগ করুন:'
                  : 'Need support or account approval? Reach out on Telegram:'}
              </span>
            </div>
            <a
              href={config.masterAdminTelegram}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition shrink-0"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{config.masterAdminName}</span>
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-950/60 flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 dark:bg-cyan-600 hover:bg-slate-800 dark:hover:bg-cyan-500 text-white text-xs font-bold transition"
          >
            {lang === 'bn' ? 'ফিরুন / ঠিক আছে' : 'Back / Got It'}
          </button>
        </div>
      </div>
    </div>
  );
};
