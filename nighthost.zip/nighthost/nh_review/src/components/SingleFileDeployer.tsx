import React, { useState } from 'react';
import { User, HostedSite } from '../types';
import { slugify, bundleSiteForExecution } from '../services/siteEngine';
import { storage } from '../services/storage';
import { CyberScanner } from './CyberScanner';
import { FileCode2, Upload, ArrowRight, Eye, ChevronDown, ChevronUp, Copy, Check, CheckCircle2, Globe } from 'lucide-react';

interface SingleFileDeployerProps {
  user: User;
  onDeploySuccess: (site: HostedSite) => void;
  onCancel: () => void;
  lang: 'bn' | 'en';
}

type LangOption = 'html' | 'php' | 'javascript' | 'css' | 'java';

const STARTER_TEMPLATES: Record<LangOption, { filename: string; code: string; desc: string }> = {
  html: {
    filename: 'index.html',
    desc: 'Standalone Modern Responsive HTML5 Web Page',
    code: `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Single File HTML5 App</title>
  <style>
    body {
      margin: 0;
      font-family: system-ui, -apple-system, sans-serif;
      background: radial-gradient(circle at top, #1e1b4b, #030712);
      color: #f8fafc;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .box {
      max-width: 520px;
      background: rgba(17, 24, 39, 0.85);
      border: 1px solid rgba(255, 255, 255, 0.1);
      padding: 36px;
      border-radius: 20px;
      text-align: center;
      box-shadow: 0 20px 40px -10px rgba(0,0,0,0.5);
    }
    h1 { color: #38bdf8; margin-top: 0; }
    p { color: #94a3b8; line-height: 1.6; }
    .btn {
      background: linear-gradient(135deg, #06b6d4, #3b82f6);
      color: white;
      border: none;
      padding: 12px 24px;
      border-radius: 12px;
      font-weight: 600;
      cursor: pointer;
      margin-top: 16px;
    }
  </style>
</head>
<body>
  <div class="box">
    <h1>🚀 সিঙ্গেল ফাইল HTML5 হোস্টিং</h1>
    <p>এটি একটি স্বতন্ত্র HTML ফাইল যা সরাসরি লাইভ সার্ভারে চলছে।</p>
    <button class="btn" onclick="document.getElementById('msg').textContent='স্বাগতম! আপনার সাইট লাইভ!'">ক্লিক করে টেস্ট করুন</button>
    <p id="msg" style="color:#34d399;font-weight:600;margin-top:12px;"></p>
  </div>
</body>
</html>`,
  },
  php: {
    filename: 'index.php',
    desc: 'PHP 8.3 Dynamic Web Script & API Gateway',
    code: `<?php
$siteName = "PHP 8.3 Web Service";
$serverTime = date("Y-m-d H:i:s");

echo "<!DOCTYPE html>";
echo "<html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>" . $siteName . "</title>";
echo "<style>body{font-family:system-ui,sans-serif;background:#050814;color:#38bdf8;padding:40px;line-height:1.6;}</style>";
echo "</head><body>";
echo "<h2>🐘 " . $siteName . "</h2>";
echo "<p><strong>Status:</strong> Active & Serving Traffic</p>";
echo "<p><strong>Server Time:</strong> " . $serverTime . "</p>";
echo "</body></html>";
?>`,
  },
  javascript: {
    filename: 'app.js',
    desc: 'Web JavaScript Execution Script',
    code: `console.log("⚡ JavaScript Runner started.");
function computeMetrics() {
  return {
    status: "Healthy",
    timestamp: new Date().toISOString()
  };
}
console.log("Execution Report:", computeMetrics());`,
  },
  css: {
    filename: 'styles.css',
    desc: 'Modern CSS3 Stylesheet',
    code: `body {
  background: #090d16;
  color: #f1f5f9;
  font-family: system-ui, sans-serif;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  margin: 0;
}`,
  },
  java: {
    filename: 'Main.java',
    desc: 'Java Microservice Source',
    code: `public class Main {
    public static void main(String[] args) {
        System.out.println("Java Web Microservice Ready");
    }
}`,
  },
};

export const SingleFileDeployer: React.FC<SingleFileDeployerProps> = ({
  user,
  onDeploySuccess,
  onCancel,
  lang,
}) => {
  const [selectedLang, setSelectedLang] = useState<LangOption>('html');
  const [projectName, setProjectName] = useState('Single HTML Page');
  const [customSlug, setCustomSlug] = useState('single-html-' + Math.floor(100 + Math.random() * 900));
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [code, setCode] = useState(STARTER_TEMPLATES['html'].code);
  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('editor');
  const [showCodePanel, setShowCodePanel] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanStage, setScanStage] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  const handleCopyCode = () => {
    navigator.clipboard?.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleLangSelect = (l: LangOption) => {
    setSelectedLang(l);
    setUploadedFileName(null);
    setCode(STARTER_TEMPLATES[l].code);
    const suggested =
      l === 'php'
        ? 'PHP Web Script'
        : l === 'java'
        ? 'Java Endpoint'
        : l === 'javascript'
        ? 'Node Script'
        : l === 'css'
        ? 'CSS Stylesheet'
        : 'Single HTML Page';
    setProjectName(suggested);
    setCustomSlug(slugify(suggested) + '-' + Math.floor(100 + Math.random() * 900));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const lower = file.name.toLowerCase();
    let detected: LangOption = 'html';
    if (lower.endsWith('.php')) detected = 'php';
    else if (lower.endsWith('.js') || lower.endsWith('.ts')) detected = 'javascript';
    else if (lower.endsWith('.css')) detected = 'css';
    else if (lower.endsWith('.java')) detected = 'java';

    setSelectedLang(detected);
    setUploadedFileName(file.name);
    const baseName = file.name.replace(/\.[^/.]+$/, '');
    setProjectName(baseName);
    setCustomSlug(slugify(baseName));

    const reader = new FileReader();
    reader.onload = () => {
      setCode((reader.result as string) || '');
    };
    reader.readAsText(file);
  };

  const handleDeploy = async () => {
    setErrorMsg(null);
    if (!code.trim()) {
      setErrorMsg(lang === 'bn' ? 'কোড বা ফাইল খালি হতে পারবে না।' : 'Code content cannot be empty.');
      return;
    }

    const finalSlug = slugify(customSlug || projectName);
    if (storage.isSlugTaken(finalSlug)) {
      setErrorMsg(
        lang === 'bn'
          ? `স্লাগ '${finalSlug}' ইতিমধ্যে ব্যবহৃত। অন্য একটি নাম দিন।`
          : `Slug '${finalSlug}' is already in use. Please choose another.`
      );
      return;
    }

    setScanProgress(10);
    setScanStage(lang === 'bn' ? 'সিঙ্গেল ফাইল রানটাইম প্রস্তুত করা হচ্ছে...' : 'Preparing single-file sandbox...');
    setIsScanning(true);
    setIsDeploying(true);

    const sizeBytes = new Blob([code]).size;
    const sizeKb = Math.max(1, Math.ceil(sizeBytes / 1024));

    const res = await storage.createSiteWithProgressAsync(
      {
        userId: user.id,
        username: user.username,
        ownerSubdomain: user.subdomain,
        name: projectName,
        slug: finalSlug,
        customPath: finalSlug,
        description: `Single-file runnable web project (${selectedLang.toUpperCase()})`,
        type: 'single-file',
        status: 'online',
        rootFile: STARTER_TEMPLATES[selectedLang].filename,
        totalFiles: 1,
        totalSizeKb: sizeKb,
        hiddenFilesCount: 0,
        singleFileConfig: {
          language: selectedLang,
          rawContent: code,
        },
        deploymentLogs: [
          { timestamp: new Date().toISOString(), level: 'info', message: `Single runnable file (${selectedLang}) compiled.` },
          {
            timestamp: new Date().toISOString(),
            level: 'success',
            message: `Live at ${user.subdomain ? `/u/${user.subdomain}/${finalSlug} & ` : ''}/site/${finalSlug}`,
          },
        ],
        files: {
          [STARTER_TEMPLATES[selectedLang].filename]: {
            path: STARTER_TEMPLATES[selectedLang].filename,
            content: code,
            size: sizeBytes,
            isHidden: false,
            type:
              selectedLang === 'php'
                ? 'php'
                : selectedLang === 'css'
                ? 'css'
                : selectedLang === 'javascript'
                ? 'js'
                : 'html',
          },
        },
      },
      (pct, stageMsg) => {
        setScanProgress(pct);
        if (stageMsg) setScanStage(stageMsg);
      }
    );

    if (res.success && res.site) {
      setScanProgress(100);
      setIsDeploying(false);
      await new Promise((r) => setTimeout(r, 180));
      setIsScanning(false);
      onDeploySuccess(res.site);
    } else {
      setIsDeploying(false);
      setIsScanning(false);
      setErrorMsg(res.message || (lang === 'bn' ? 'ডিপ্লয় করতে সমস্যা হয়েছে।' : 'Failed to deploy file.'));
    }
  };

  const previewSite: HostedSite = {
    id: 'preview_temp',
    userId: user.id,
    username: user.username,
    name: projectName,
    slug: customSlug,
    description: '',
    type: 'single-file',
    status: 'online',
    rootFile: STARTER_TEMPLATES[selectedLang].filename,
    totalFiles: 1,
    totalSizeKb: 1,
    hiddenFilesCount: 0,
    deploymentLogs: [],
    singleFileConfig: {
      language: selectedLang,
      rawContent: code,
    },
    files: {},
    visitsCount: 0,
    bandwidthMb: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const previewHtml = bundleSiteForExecution(previewSite);

  const codeSizeBytes = new Blob([code]).size;
  const codeSizeLabel =
    codeSizeBytes >= 1024 ? `${(codeSizeBytes / 1024).toFixed(1)} KB` : `${codeSizeBytes} B`;
  const codeLineCount = code ? code.split(/\r\n|\r|\n/).length : 0;
  const activeFilename = uploadedFileName || STARTER_TEMPLATES[selectedLang].filename;

  return (
    <div className="max-w-4xl mx-auto space-y-3 animate-panel-enter">
      {isScanning ? (
        <CyberScanner
          mode="deploy"
          title="SINGLE-FILE EXECUTION SANDBOX SCAN"
          subtitle={`Verifying ${selectedLang.toUpperCase()} runtime syntax and security isolation...`}
          progress={scanProgress}
          currentStepMessage={scanStage}
          checksum="0x3f9e11bc"
          filesCount={1}
          hiddenCount={0}
          isBusy={isDeploying}
          busyMessage={
            lang === 'bn'
              ? `সার্ভারে সিঙ্গেল ফাইল ও /site/${slugify(customSlug || projectName)} রুট তৈরি হচ্ছে...`
              : `Deploying file & provisioning /site/${slugify(customSlug || projectName)}...`
          }
        />
      ) : (
        <>
          <div className="flex flex-wrap justify-between items-center gap-3 p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="min-w-0">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/80 border border-indigo-200 dark:border-indigo-500/30 text-indigo-700 dark:text-indigo-300 text-[11px] font-semibold mb-1">
                <FileCode2 className="w-3 h-3" />
                {lang === 'bn' ? 'সিঙ্গেল ফাইল হোস্টিং' : 'Single File Hosting'}
              </div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-snug">
                {lang === 'bn' ? 'একক ফাইল সরাসরি লাইভ করুন' : 'Run Single File (HTML, PHP, JS, CSS, Java)'}
              </h2>
            </div>

            <button
              type="button"
              onClick={onCancel}
              className="text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 shrink-0"
            >
              {lang === 'bn' ? 'বাতিল' : 'Cancel'}
            </button>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300 text-xs">
              {errorMsg}
            </div>
          )}

          {/* Language + Prominent Friendly Upload Button */}
          <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <label
              className={`w-full flex flex-col sm:flex-row items-center justify-between gap-3 p-3.5 rounded-2xl border-2 cursor-pointer transition ${
                uploadedFileName
                  ? 'border-solid border-emerald-300 dark:border-emerald-500/40 bg-emerald-50/70 dark:bg-emerald-950/30 hover:bg-emerald-100/60 dark:hover:bg-emerald-950/45'
                  : 'border-dashed border-cyan-300 dark:border-cyan-500/40 bg-cyan-50/70 dark:bg-cyan-950/30 hover:bg-cyan-100/70 dark:hover:bg-cyan-950/50'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className={`w-10 h-10 rounded-xl text-white flex items-center justify-center shrink-0 shadow-sm ${
                    uploadedFileName ? 'bg-emerald-600' : 'bg-cyan-600'
                  }`}
                >
                  {uploadedFileName ? <CheckCircle2 className="w-5 h-5" /> : <Upload className="w-5 h-5" />}
                </div>
                <div className="text-left min-w-0">
                  <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                    {uploadedFileName
                      ? (lang === 'bn' ? `আপলোড সম্পন্ন: ${uploadedFileName}` : `Uploaded: ${uploadedFileName}`)
                      : (lang === 'bn' ? 'ডিভাইস থেকে PHP / HTML / JS ফাইল আপলোড করুন' : 'Upload PHP / HTML / JS File from Device')}
                  </div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400">
                    {uploadedFileName
                      ? (lang === 'bn' ? 'ফাইল রেডি — নিচে প্রজেক্ট নাম বা স্লাগ যাচাই করে ডিপ্লয় করুন' : 'File ready — verify title/slug below and deploy')
                      : (lang === 'bn' ? 'ক্লিক করে ফাইল সিলেক্ট করুন (.html, .php, .js, .css, .java)' : 'Click to pick a file (.html, .php, .js, .css, .java)')}
                  </div>
                </div>
              </div>
              <span
                className={`px-4 py-2 rounded-xl text-xs font-bold shrink-0 whitespace-nowrap transition ${
                  uploadedFileName
                    ? 'border border-emerald-400/60 dark:border-emerald-500/50 bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/50'
                    : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-sm'
                }`}
              >
                {uploadedFileName
                  ? (lang === 'bn' ? 'ফাইল পরিবর্তন করুন' : 'Change File')
                  : (lang === 'bn' ? 'ফাইল বাছুন' : 'Choose File')}
              </span>
              <input
                type="file"
                accept=".html,.htm,.php,.js,.ts,.css,.java,.txt"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>

            <div className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">
              {lang === 'bn' ? 'অথবা দ্রুত টেমপ্লেট ভাষা নির্বাচন করুন:' : 'Or choose starter runtime:'}
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
              {(['html', 'php', 'javascript', 'css', 'java'] as LangOption[]).map((l) => (
                <button
                  type="button"
                  key={l}
                  onClick={() => handleLangSelect(l)}
                  className={`px-2.5 py-2 rounded-xl border text-left transition ${
                    selectedLang === l
                      ? 'bg-cyan-50 dark:bg-cyan-950/60 border-cyan-500 text-cyan-700 dark:text-cyan-300 shadow-sm'
                      : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[11px] font-bold uppercase">{l === 'javascript' ? 'JS' : l}</span>
                    <span className="text-xs">
                      {l === 'html' ? '🌐' : l === 'php' ? '🐘' : l === 'javascript' ? '⚡' : l === 'css' ? '🎨' : '☕'}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block truncate mt-0.5">
                    {STARTER_TEMPLATES[l].filename}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Project Title, Custom Slug & Primary Top Deploy CTA */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'প্রজেক্টের নাম' : 'Project Title'}
                </label>
                <input
                  type="text"
                  value={projectName}
                  onChange={(e) => {
                    setProjectName(e.target.value);
                    if (!customSlug) setCustomSlug(slugify(e.target.value));
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500 font-sans"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'কাস্টম স্লাগ লিংক' : 'Custom URL Slug'}
                </label>
                <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2 text-sm">
                  <span className="text-slate-500 dark:text-slate-400 font-mono text-xs">/site/</span>
                  <input
                    type="text"
                    value={customSlug}
                    onChange={(e) => setCustomSlug(e.target.value)}
                    className="w-full bg-transparent text-cyan-700 dark:text-cyan-400 focus:outline-none font-mono text-sm ml-1"
                  />
                </div>
                {user.subdomain && (
                  <div className="mt-1 text-[11px] font-mono text-emerald-700 dark:text-emerald-400 space-y-0.5 truncate">
                    <div className="flex items-center gap-1 truncate font-bold">
                      <Globe className="w-3 h-3 shrink-0" />
                      <span className="truncate">
                        https://{user.subdomain}.{storage.getConfig().primaryDomain || 'nighthostcloud.dpdns.org'}/{slugify(customSlug || projectName)}
                      </span>
                    </div>
                    <div className="pl-4 text-[10px] opacity-80 truncate">
                      /u/{user.subdomain}/{slugify(customSlug || projectName)}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 text-[11px] font-mono text-slate-600 dark:text-slate-400">
                <span className="px-2 py-0.5 rounded bg-cyan-50 dark:bg-cyan-950/60 border border-cyan-200 dark:border-cyan-500/30 text-cyan-700 dark:text-cyan-300 font-bold">
                  {activeFilename}
                </span>
                <span>{codeSizeLabel}</span>
                <span>• {codeLineCount} {lang === 'bn' ? 'লাইন' : 'lines'}</span>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={onCancel}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white text-xs font-medium"
                >
                  {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>

                <button
                  type="button"
                  onClick={handleDeploy}
                  className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-bold shadow-md transition flex-1 sm:flex-initial"
                >
                  <span>{lang === 'bn' ? 'সিঙ্গেল ফাইল হোস্ট করুন' : 'Deploy Single File'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Collapsible Code Editor / Live Preview Drawer */}
          <div className="rounded-2xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 bg-slate-50 dark:bg-slate-950/60">
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-xs font-mono text-cyan-700 dark:text-cyan-400 font-semibold truncate">
                  {activeFilename}
                </span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200/80 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono uppercase">
                  {selectedLang}
                </span>
              </div>

              <div className="flex items-center gap-1.5 flex-wrap">
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-cyan-500 transition"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? (lang === 'bn' ? 'কপি হয়েছে' : 'Copied') : (lang === 'bn' ? 'কোড কপি' : 'Copy Code')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (showCodePanel && activeTab === 'editor') {
                      setShowCodePanel(false);
                    } else {
                      setActiveTab('editor');
                      setShowCodePanel(true);
                    }
                  }}
                  aria-expanded={showCodePanel && activeTab === 'editor'}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition ${
                    showCodePanel && activeTab === 'editor'
                      ? 'bg-cyan-600 border-cyan-600 text-white'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-cyan-500'
                  }`}
                >
                  <FileCode2 className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? 'কোড এডিটর' : 'Code Editor'}</span>
                  {showCodePanel && activeTab === 'editor' ? (
                    <ChevronUp className="w-3.5 h-3.5" />
                  ) : (
                    <ChevronDown className="w-3.5 h-3.5" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (showCodePanel && activeTab === 'preview') {
                      setShowCodePanel(false);
                    } else {
                      setActiveTab('preview');
                      setShowCodePanel(true);
                    }
                  }}
                  aria-expanded={showCodePanel && activeTab === 'preview'}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition ${
                    showCodePanel && activeTab === 'preview'
                      ? 'bg-cyan-600 border-cyan-600 text-white'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-cyan-500'
                  }`}
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? 'লাইভ প্রিভিউ' : 'Live Preview'}</span>
                  {showCodePanel && activeTab === 'preview' ? (
                    <ChevronUp className="w-3.5 h-3.5" />
                  ) : (
                    <ChevronDown className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>

            {showCodePanel && (
              <div className="border-t border-slate-200 dark:border-slate-800">
                {activeTab === 'editor' ? (
                  <textarea
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    rows={10}
                    className="w-full bg-slate-950 p-4 font-mono text-xs text-slate-200 focus:outline-none resize-y selection:bg-cyan-500/30 block"
                    spellCheck={false}
                  />
                ) : (
                  <div className="p-4 bg-slate-100 dark:bg-slate-950">
                    <div className="w-full h-72 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white shadow-inner">
                      {code.trim() ? (
                        <iframe
                          title="Live Code Preview"
                          srcDoc={previewHtml}
                          className="w-full h-full border-0 bg-white"
                          sandbox="allow-scripts allow-same-origin allow-modals allow-forms"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-xs text-slate-500">
                          {lang === 'bn'
                            ? 'প্রিভিউ দেখার জন্য কোড লিখুন বা ফাইল আপলোড করুন।'
                            : 'Write code or upload a file to preview.'}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};
