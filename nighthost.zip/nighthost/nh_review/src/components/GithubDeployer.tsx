import React, { useMemo, useState } from 'react';
import { User, HostedSite } from '../types';
import {
  slugify,
  isPathHidden,
  assessProjectCloudFootprint,
  optimizeProjectToRunnableCore,
  auditFolderFiles,
} from '../services/siteEngine';
import { storage } from '../services/storage';
import { formatStorageFromMb, formatStorageFromKb, formatHttpTransportError } from '../services/format';
import { CyberScanner } from './CyberScanner';
import {
  GitBranch,
  Lock,
  Globe,
  Key,
  AlertCircle,
  ArrowRight,
  HelpCircle,
  FolderGit2,
  FileCheck,
  FileCode,
  RefreshCw,
  Loader2,
  Cpu,
  Eye,
  EyeOff,
  ChevronDown,
  ChevronUp,
  Minimize2,
  CheckCircle2,
} from 'lucide-react';

interface GithubDeployerProps {
  user: User;
  onDeploySuccess: (site: HostedSite) => void;
  onCancel: () => void;
  lang: 'bn' | 'en';
}

export const GithubDeployer: React.FC<GithubDeployerProps> = ({
  user,
  onDeploySuccess,
  onCancel,
  lang,
}) => {
  const [repoType, setRepoType] = useState<'public' | 'private'>('public');
  const [repoUrl, setRepoUrl] = useState('');
  const [branch, setBranch] = useState('main');
  const [token, setToken] = useState('');
  const [projectName, setProjectName] = useState('');
  const [customSlug, setCustomSlug] = useState('');
  const [autoDeploy, setAutoDeploy] = useState(true);
  const [isCloning, setIsCloning] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanStage, setScanStage] = useState('');
  const [showTokenHelp, setShowTokenHelp] = useState(false);
  const [showToken, setShowToken] = useState(false);
  const [showFileList, setShowFileList] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [trimSummary, setTrimSummary] = useState<string | null>(null);
  const isOwner = user.role === 'admin';
  const [importedPayload, setImportedPayload] = useState<{
    files: HostedSite['files'];
    rootFile: string;
    runtimeType?: 'static' | 'php' | 'node' | 'python';
    totalFiles: number;
    hiddenFilesCount: number;
    totalSizeKb: number;
    branch: string;
    warnings?: string[];
  } | null>(null);

  const footprint = useMemo(() => {
    if (!importedPayload) return null;
    return assessProjectCloudFootprint(
      Object.values(importedPayload.files).map(f => ({
        path: f.path,
        content: f.isBinary ? '' : f.content,
        size: f.size,
        isBinary: f.isBinary,
      }))
    );
  }, [importedPayload]);

  const handleRepoUrlChange = (url: string) => {
    setRepoUrl(url);
    const stripped = url.trim().split('#')[0].split('?')[0].replace(/\/+$/, '').replace(/\.git$/i, '');
    const treeMatch = stripped.match(/github\.com\/[^/]+\/([^/]+)\/(?:tree|blob)\/([^/]+)/i);
    if (treeMatch && treeMatch[1]) {
      const cleanRepo = treeMatch[1];
      setProjectName(cleanRepo);
      setCustomSlug(slugify(cleanRepo));
      if (treeMatch[2]) {
        try {
          setBranch(decodeURIComponent(treeMatch[2]));
        } catch {
          setBranch(treeMatch[2]);
        }
      }
      return;
    }
    const match =
      stripped.match(/github\.com\/[^/]+\/([^/]+)/i) ||
      stripped.match(/^[a-zA-Z0-9_.-]+\/([a-zA-Z0-9_.-]+)$/);
    if (match && match[1]) {
      const cleanRepo = match[1];
      setProjectName(cleanRepo);
      setCustomSlug(slugify(cleanRepo));
    }
  };

  const handleFetchAndAudit = async () => {
    setErrorMsg(null);
    if (!repoUrl.trim()) {
      setErrorMsg(
        lang === 'bn' ? 'গিটহাব রিপোজিটরি লিংক প্রদান করুন।' : 'Please enter a GitHub repository URL.'
      );
      return;
    }

    if (repoType === 'private' && !token.trim()) {
      setErrorMsg(
        lang === 'bn'
          ? 'প্রাইভেট রিপোজিটরির জন্য GitHub Personal Access Token (PAT) আবশ্যক।'
          : 'A GitHub Personal Access Token (PAT) is required for private repositories.'
      );
      return;
    }

    setIsCloning(true);
    try {
      const res = await fetch('/api/github/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          repoUrl: repoUrl.trim(),
          branch: branch.trim(),
          token: repoType === 'private' ? token.trim() : undefined,
        }),
      });
      const rawText = await res.text();
      let data: {
        success?: boolean;
        message?: string;
        totalSizeKb?: number;
        repoName?: string;
        files?: HostedSite['files'];
        rootFile?: string;
        runtimeType?: 'static' | 'php' | 'node' | 'python';
        totalFiles?: number;
        hiddenFilesCount?: number;
        branch?: string;
        warnings?: string[];
      } = {};
      try {
        data = JSON.parse(rawText || '{}');
      } catch {
        setIsCloning(false);
        setErrorMsg(formatHttpTransportError(res.status, rawText));
        return;
      }
      setIsCloning(false);

      if (!res.ok || !data.success || !data.files) {
        setErrorMsg(
          data.message ||
            (res.status >= 400
              ? formatHttpTransportError(res.status, rawText)
              : lang === 'bn'
              ? 'GitHub রিপোজিটরি ক্লোন করা সম্ভব হয়নি।'
              : 'Failed to clone GitHub repository.')
        );
        return;
      }

      const addedMb = (data.totalSizeKb || 1) / 1024;
      if (!isOwner && user.storageUsedMb + addedMb > user.storageLimitMb) {
        const rem = Math.max(0, user.storageLimitMb - user.storageUsedMb);
        setErrorMsg(
          lang === 'bn'
            ? `স্টোরেজ সীমা অতিক্রম করেছে! অবশিষ্ট কোটা ${formatStorageFromMb(rem)}।`
            : `Storage limit exceeded! Remaining quota is ${formatStorageFromMb(rem)}.`
        );
        return;
      }

      if (!projectName.trim() && data.repoName) {
        setProjectName(data.repoName);
      }
      if (!customSlug.trim() && data.repoName) {
        setCustomSlug(slugify(data.repoName));
      }
      if (data.branch) {
        setBranch(data.branch);
      }

      setTrimSummary(null);
      setImportedPayload({
        files: data.files,
        rootFile: data.rootFile || 'index.html',
        runtimeType: data.runtimeType,
        totalFiles: data.totalFiles || Object.keys(data.files).length,
        hiddenFilesCount: data.hiddenFilesCount || 0,
        totalSizeKb: data.totalSizeKb || 1,
        branch: data.branch || branch || 'main',
        warnings: data.warnings || [],
      });
    } catch {
      setIsCloning(false);
      setErrorMsg(
        lang === 'bn'
          ? 'সার্ভারের সাথে সংযোগ করতে সমস্যা হয়েছে। ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।'
          : 'Could not connect to server.'
      );
    }
  };

  const applyRunnableTrim = () => {
    if (!importedPayload) return null;
    const trimmed = optimizeProjectToRunnableCore(Object.values(importedPayload.files));
    const nextFilesRecord: HostedSite['files'] = {};
    for (const f of trimmed.files) {
      nextFilesRecord[f.path] = f;
    }
    const audit = auditFolderFiles(
      trimmed.files.map(f => ({ path: f.path, content: f.isBinary ? '' : f.content, size: f.size }))
    );
    const nextPayload = {
      ...importedPayload,
      files: nextFilesRecord,
      rootFile: audit.entryPointFound || importedPayload.rootFile,
      runtimeType: audit.detectedRuntime || importedPayload.runtimeType,
      totalFiles: trimmed.afterCount,
      hiddenFilesCount: trimmed.files.filter(f => f.isHidden).length,
      totalSizeKb: Math.max(1, Math.ceil(trimmed.afterBytes / 1024)),
    };
    setImportedPayload(nextPayload);
    setTrimSummary(lang === 'bn' ? trimmed.summaryBn : trimmed.summaryEn);
    setErrorMsg(null);
    return nextPayload;
  };

  const handleLaunchAfterAudit = async (payloadOverride?: typeof importedPayload) => {
    const activePayload = payloadOverride || importedPayload;
    if (!activePayload) return;
    setErrorMsg(null);
    const finalSlug = slugify(customSlug || projectName || 'github-project');
    if (storage.isSlugTaken(finalSlug)) {
      setErrorMsg(
        lang === 'bn'
          ? `স্লাগ '${finalSlug}' ইতিমধ্যে ব্যবহৃত! অনুগ্রহ করে অন্য নাম নির্বাচন করুন।`
          : `Slug '${finalSlug}' is already in use. Please choose another.`
      );
      return;
    }

    setScanProgress(8);
    setScanStage(lang === 'bn' ? 'GitHub রিপোজিটরি প্যাকেজ সার্ভারে আপলোড হচ্ছে...' : 'Uploading repository bundle to cloud runtime...');
    setIsScanning(true);
    setIsDeploying(true);

    const res = await storage.createSiteWithProgressAsync(
      {
        userId: user.id,
        username: user.username,
        ownerSubdomain: user.subdomain,
        name: projectName || finalSlug,
        slug: finalSlug,
        customPath: finalSlug,
        description: `Deployed from GitHub (${repoType}) [${activePayload.branch}]`,
        type: 'github',
        status: 'online',
        rootFile: activePayload.rootFile,
        runtimeType: activePayload.runtimeType,
        totalFiles: activePayload.totalFiles,
        totalSizeKb: activePayload.totalSizeKb,
        hiddenFilesCount: activePayload.hiddenFilesCount,
        githubConfig: {
          repoUrl: repoUrl.trim(),
          branch: activePayload.branch,
          isPrivate: repoType === 'private',
          token: repoType === 'private' ? 'ghp_****' + token.slice(-4) : undefined,
          autoDeploy,
        },
        deploymentLogs: [
          { timestamp: new Date().toISOString(), level: 'info', message: `Fetched ${activePayload.totalFiles} real files from ${repoUrl}` },
          { timestamp: new Date().toISOString(), level: 'info', message: `Entry point: ${activePayload.rootFile} (runtime: ${(activePayload.runtimeType || 'static').toUpperCase()})` },
          {
            timestamp: new Date().toISOString(),
            level: 'success',
            message: `Deployed live at ${user.subdomain ? `/u/${user.subdomain}/${finalSlug} & ` : ''}/site/${finalSlug}`,
          },
        ],
        files: activePayload.files,
      },
      (pct, stageMsg) => {
        setScanProgress(pct);
        if (stageMsg) setScanStage(stageMsg);
      }
    );

    if (res.success && res.site) {
      setScanProgress(100);
      setIsDeploying(false);
      await new Promise((r) => setTimeout(r, 180));
      setIsScanning(false);
      onDeploySuccess(res.site);
    } else {
      setIsDeploying(false);
      setIsScanning(false);
      setErrorMsg(res.message || (lang === 'bn' ? 'ডিপ্লয় করতে সমস্যা হয়েছে।' : 'Failed to deploy site.'));
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-3 animate-panel-enter">
      {isScanning && importedPayload ? (
        <CyberScanner
          mode="deploy"
          title="GITHUB REPOSITORY REALTIME SYNC"
          subtitle={`Deploying ${importedPayload.totalFiles} repository files from '${importedPayload.branch}'...`}
          progress={scanProgress}
          currentStepMessage={scanStage}
          checksum="0x9a8f220d"
          filesCount={importedPayload.totalFiles}
          hiddenCount={importedPayload.hiddenFilesCount}
          isBusy={isDeploying}
          busyMessage={
            lang === 'bn'
              ? 'সার্ভারে ফাইল সংরক্ষণ ও ব্যাকএন্ড/হোস্টিং চালু হচ্ছে...'
              : 'Saving repository files & starting runtime container...'
          }
        />
      ) : (
        <>
          <div className="flex flex-wrap justify-between items-center gap-3 p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="min-w-0">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-[11px] font-semibold mb-1">
                <FolderGit2 className="w-3 h-3 text-cyan-600 dark:text-cyan-400" />
                {lang === 'bn' ? 'গিটহাব রিপোজিটরি হোস্টিং' : 'GitHub Sync'}
              </div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-snug">
                {lang === 'bn' ? 'পাবলিক অথবা প্রাইভেট গিটহাব দিয়ে সাইট চালান' : 'Deploy from Public / Private GitHub'}
              </h2>
            </div>

            <button
              type="button"
              onClick={onCancel}
              className="text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 shrink-0"
            >
              {lang === 'bn' ? 'বাতিল' : 'Cancel'}
            </button>
          </div>

          {errorMsg && (
            <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300 text-xs space-y-2.5">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-500 flex-shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
              {importedPayload && /502|503|504|413|রিস্টার্ট|টাইমআউট|সীমা|পার্চ|সমস্যা/i.test(errorMsg) && (
                <div className="flex flex-wrap items-center gap-2 pl-6">
                  <button
                    type="button"
                    onClick={() => {
                      const trimmedPayload = applyRunnableTrim();
                      if (trimmedPayload) handleLaunchAfterAudit(trimmedPayload);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-[11px] font-bold shadow-sm transition"
                  >
                    <Minimize2 className="w-3.5 h-3.5" />
                    <span>
                      {lang === 'bn'
                        ? 'হ্যাঁ, অপ্রয়োজনীয় ফাইল বাদ দিয়ে ছোট করে রান করুন'
                        : 'Trim & Launch Runnable Core'}
                    </span>
                  </button>
                </div>
              )}
            </div>
          )}

          {!importedPayload ? (
            <>
              <div className="p-5 rounded-2xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-sm">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-3">
                  {lang === 'bn' ? 'রিপোজিটরির ধরন নির্বাচন করুন:' : 'Repository Visibility:'}
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setRepoType('public');
                      setErrorMsg(null);
                    }}
                    className={`flex items-start gap-3 p-4 rounded-xl border text-left transition ${
                      repoType === 'public'
                        ? 'bg-cyan-50 dark:bg-cyan-950/50 border-cyan-500 shadow-sm'
                        : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 hover:border-slate-400'
                    }`}
                  >
                    <Globe className={`w-5 h-5 mt-0.5 ${repoType === 'public' ? 'text-cyan-600 dark:text-cyan-400' : 'text-slate-400'}`} />
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white">
                        {lang === 'bn' ? 'পাবলিক রিপোজিটরি (Public)' : 'Public Repository'}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        {lang === 'bn' ? 'কোনো টোকেন লাগবে না, শুধুমাত্র রিপো লিংক দিলেই হবে।' : 'No auth required for public repos.'}
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setRepoType('private');
                      setErrorMsg(null);
                    }}
                    className={`flex items-start gap-3 p-4 rounded-xl border text-left transition ${
                      repoType === 'private'
                        ? 'bg-amber-50 dark:bg-amber-950/50 border-amber-500 shadow-sm'
                        : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 hover:border-slate-400'
                    }`}
                  >
                    <Lock className={`w-5 h-5 mt-0.5 ${repoType === 'private' ? 'text-amber-600 dark:text-amber-400' : 'text-slate-400'}`} />
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white">
                        {lang === 'bn' ? 'প্রাইভেট রিপোজিটরি (Private)' : 'Private Repository'}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        {lang === 'bn' ? 'Personal Access Token (PAT) দিয়ে নিরাপদ সংযোগ।' : 'Secure access with Personal Access Token.'}
                      </div>
                    </div>
                  </button>
                </div>
              </div>

              <div className="p-6 rounded-2xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    GitHub Repository URL
                  </label>
                  <input
                    type="text"
                    value={repoUrl}
                    onChange={(e) => handleRepoUrlChange(e.target.value)}
                    placeholder="https://github.com/username/project-repo (or username/repo)"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'bn' ? 'টার্গেট ব্রাঞ্চ (Branch)' : 'Target Branch'}
                    </label>
                    <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2 text-sm">
                      <GitBranch className="w-4 h-4 text-cyan-600 dark:text-cyan-400 mr-2 flex-shrink-0" />
                      <input
                        type="text"
                        value={branch}
                        onChange={(e) => setBranch(e.target.value)}
                        placeholder="main"
                        className="w-full bg-transparent text-slate-900 dark:text-white focus:outline-none font-mono text-sm"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'bn' ? 'কাস্টম স্লাগ লিংক' : 'Custom URL Slug'}
                    </label>
                    <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2 text-sm">
                      <span className="text-slate-500 dark:text-slate-400 font-mono text-xs">/site/</span>
                      <input
                        type="text"
                        value={customSlug}
                        onChange={(e) => setCustomSlug(e.target.value)}
                        placeholder="github-app"
                        className="w-full bg-transparent text-cyan-700 dark:text-cyan-400 focus:outline-none font-mono text-sm ml-1"
                      />
                    </div>
                  </div>
                </div>

                {repoType === 'private' && (
                  <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-500/30 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-semibold text-amber-800 dark:text-amber-300">
                        <Key className="w-4 h-4" />
                        <span>{lang === 'bn' ? 'GitHub Personal Access Token (PAT)' : 'GitHub Access Token'}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowTokenHelp(!showTokenHelp)}
                        className="text-[11px] text-amber-700 dark:text-amber-400 hover:underline flex items-center gap-1"
                      >
                        <HelpCircle className="w-3.5 h-3.5" />
                        <span>{lang === 'bn' ? 'টোকেন তৈরি করবেন কীভাবে?' : 'How to get token?'}</span>
                      </button>
                    </div>

                    <div className="flex items-center rounded-xl bg-white dark:bg-slate-950 border border-amber-300 dark:border-amber-500/40 px-3.5 py-2">
                      <input
                        type={showToken ? 'text' : 'password'}
                        value={token}
                        onChange={(e) => setToken(e.target.value)}
                        placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                        className="w-full bg-transparent text-slate-900 dark:text-white focus:outline-none font-mono text-xs"
                      />
                      <button
                        type="button"
                        onClick={() => setShowToken(!showToken)}
                        aria-label={showToken ? (lang === 'bn' ? 'টোকেন লুকান' : 'Hide token') : (lang === 'bn' ? 'টোকেন দেখুন' : 'Show token')}
                        className="ml-2 p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition shrink-0"
                      >
                        {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>

                    {showTokenHelp && (
                      <div className="p-3 rounded-lg bg-white dark:bg-slate-950/80 border border-amber-200 dark:border-amber-500/20 text-xs text-slate-700 dark:text-slate-300 space-y-1.5 leading-relaxed">
                        <p className="font-semibold text-amber-700 dark:text-amber-300">
                          {lang === 'bn' ? 'গিটহাব টোকেন তৈরির নিয়মাবলী:' : 'How to generate a GitHub Token:'}
                        </p>
                        <p>
                          {lang === 'bn'
                            ? '১. গিটহাব অ্যাকাউন্টে লগইন করে Settings → Developer settings → Personal access tokens এ যান।'
                            : '1. Go to GitHub Settings → Developer settings → Personal access tokens.'}
                        </p>
                        <p>
                          {lang === 'bn'
                            ? '২. "Generate new token (classic)" এ ক্লিক করে repo স্কোপ সিলেক্ট করুন।'
                            : '2. Click "Generate new token (classic)" and check the repo scope.'}
                        </p>
                        <p>
                          {lang === 'bn'
                            ? '৩. টোকেনটি কপি করে উপরের বক্সে পেস্ট করুন।'
                            : '3. Copy the token and paste it above.'}
                        </p>
                      </div>
                    )}
                  </div>
                )}

                <label className="flex items-center gap-2.5 cursor-pointer pt-2 select-none">
                  <input
                    type="checkbox"
                    checked={autoDeploy}
                    onChange={(e) => setAutoDeploy(e.target.checked)}
                    className="rounded border-slate-300 dark:border-slate-700 text-cyan-600 focus:ring-cyan-500"
                  />
                  <span className="text-xs text-slate-700 dark:text-slate-300 font-medium">
                    {lang === 'bn' ? 'অটো-ডিপ্লয় কনফিগারেশন সক্রিয় রাখুন' : 'Enable auto-deploy config'}
                  </span>
                </label>

                {isCloning && (
                  <div className="p-4 rounded-xl bg-cyan-50 dark:bg-cyan-950/50 border border-cyan-200 dark:border-cyan-500/40 flex items-center gap-3">
                    <Loader2 className="w-5 h-5 text-cyan-600 dark:text-cyan-400 animate-spin shrink-0" />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-cyan-900 dark:text-cyan-200">
                        {lang === 'bn'
                          ? 'GitHub রিপোজিটরি ক্লোন ও ফাইল ডাউনলোড হচ্ছে...'
                          : 'Cloning GitHub repository & auditing files...'}
                      </p>
                      <p className="text-[11px] text-cyan-700 dark:text-cyan-400 truncate">
                        {lang === 'bn'
                          ? 'সব ফাইল (CSS, JS, ইমেজ, Python/Node ব্যাকএন্ড) পড়া হচ্ছে। অনুগ্রহ করে অপেক্ষা করুন...'
                          : 'Fetching assets, templates, and backend entrypoints. Please wait...'}
                      </p>
                    </div>
                  </div>
                )}

                <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={onCancel}
                    className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white text-xs font-medium"
                  >
                    {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                  </button>

                  <button
                    type="button"
                    disabled={isCloning}
                    onClick={handleFetchAndAudit}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-md transition disabled:opacity-60"
                  >
                    {isCloning && <Loader2 className="w-4 h-4 animate-spin" />}
                    <span>
                      {isCloning
                        ? lang === 'bn'
                          ? 'রিপোজিটরি ফেচ হচ্ছে...'
                          : 'Fetching repository...'
                        : lang === 'bn'
                        ? 'রিপোজিটরি ফেচ ও অডিট করুন'
                        : 'Fetch & Audit Repository'}
                    </span>
                    {!isCloning && <ArrowRight className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="space-y-4">
              {/* Top Settings & Launch CTA Card */}
              <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-2 flex-wrap">
                    <FileCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                      {lang === 'bn' ? 'গিটহাব রিপোজিটরি অডিট সম্পন্ন' : 'GitHub Repository Audit Ready'}
                    </span>
                    {importedPayload.runtimeType && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-500/30 text-indigo-700 dark:text-indigo-300 text-[10px] font-mono font-bold uppercase">
                        <Cpu className="w-3 h-3" />
                        {importedPayload.runtimeType}
                      </span>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setImportedPayload(null);
                      setShowFileList(false);
                    }}
                    className="inline-flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 font-medium"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>{lang === 'bn' ? 'অন্য রিপোজিটরি বাছুন' : 'Change Repository'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'bn' ? 'প্রজেক্টের নাম' : 'Project Name'}
                    </label>
                    <input
                      type="text"
                      value={projectName}
                      onChange={(e) => setProjectName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'bn' ? 'কাস্টম স্লাগ লিংক' : 'Custom URL Slug'}
                    </label>
                    <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2 text-sm">
                      <span className="text-slate-500 dark:text-slate-400 font-mono text-xs">/site/</span>
                      <input
                        type="text"
                        value={customSlug}
                        onChange={(e) => setCustomSlug(e.target.value)}
                        className="w-full bg-transparent text-cyan-700 dark:text-cyan-400 focus:outline-none font-mono text-sm ml-1"
                      />
                    </div>
                    {user.subdomain && (
                      <div className="mt-1 text-[11px] font-mono text-emerald-700 dark:text-emerald-400 space-y-0.5 truncate">
                        <div className="flex items-center gap-1 truncate font-bold">
                          <Globe className="w-3 h-3 shrink-0" />
                          <span className="truncate">
                            https://{user.subdomain}.{storage.getConfig().primaryDomain || 'nighthostcloud.dpdns.org'}/{slugify(customSlug || projectName || 'github-project')}
                          </span>
                        </div>
                        <div className="pl-4 text-[10px] opacity-80 truncate">
                          /u/{user.subdomain}/{slugify(customSlug || projectName || 'github-project')}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {trimSummary && (
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-500/40 text-xs text-emerald-800 dark:text-emerald-200 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    <span className="font-semibold">{trimSummary}</span>
                  </div>
                )}

                {footprint?.needsOptimization && (
                  <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-500/40 text-xs text-amber-900 dark:text-amber-200 space-y-2.5">
                    <div className="font-bold flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                      <span>
                        {lang === 'bn'
                          ? `প্রজেক্ট প্ল্যান সতর্কতা (~${footprint.estimatedRuntimeMb} MB+ সম্ভাব্য ব্যবহার)`
                          : `Plan Resource Advisory (~${footprint.estimatedRuntimeMb} MB+ Estimated Runtime)`}
                      </span>
                    </div>
                    <p className="text-[11px] leading-relaxed opacity-95">
                      {lang === 'bn' ? footprint.reasonBn : footprint.reasonEn}{' '}
                      {lang === 'bn'
                        ? 'চাইলে অপ্রয়োজনীয় ম্যাপ/টেস্ট/বড় ফাইল বাদ দিয়ে মেইন রানেবল কোর ছোট করে চালু করতে পারবেন।'
                        : 'You can safely strip non-essential files and launch only the core runnable files.'}
                    </p>
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          const trimmedPayload = applyRunnableTrim();
                          if (trimmedPayload) handleLaunchAfterAudit(trimmedPayload);
                        }}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-[11px] font-bold shadow-sm transition"
                      >
                        <Minimize2 className="w-3.5 h-3.5" />
                        <span>
                          {lang === 'bn'
                            ? 'হ্যাঁ, ছোট করে চালু করুন (Trim & Run Core)'
                            : 'Trim & Launch Core'}
                        </span>
                      </button>
                      <button
                        type="button"
                        onClick={() => applyRunnableTrim()}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-500/40 text-amber-800 dark:text-amber-200 text-[11px] font-semibold hover:bg-amber-100/60 dark:hover:bg-amber-900/30 transition"
                      >
                        <span>{lang === 'bn' ? 'শুধু ছোট করে প্রিভিউ দেখুন' : 'Trim & Preview Only'}</span>
                      </button>
                    </div>
                  </div>
                )}

                <div className="pt-2 flex flex-wrap items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={onCancel}
                    className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white text-xs font-medium"
                  >
                    {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleLaunchAfterAudit()}
                    className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white text-xs font-bold shadow-md transition flex-1 sm:flex-initial"
                  >
                    <span>{lang === 'bn' ? 'লাইভ ওয়েবসাইট চালু করুন' : 'Launch Live Website'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Metrics + Collapsible File Preview */}
              <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3.5">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono">
                      {lang === 'bn' ? 'মোট ফাইল' : 'Total Files'}
                    </span>
                    <p className="text-base font-bold text-slate-900 dark:text-white font-mono">
                      {importedPayload.totalFiles}
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono">
                      {lang === 'bn' ? 'ব্রাঞ্চ' : 'Branch'}
                    </span>
                    <p className="text-sm font-bold text-cyan-600 dark:text-cyan-400 font-mono truncate mt-1">
                      {importedPayload.branch}
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono">
                      {lang === 'bn' ? 'আকার' : 'Size'}
                    </span>
                    <p className="text-base font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                      {formatStorageFromKb(importedPayload.totalSizeKb)}
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono">
                      {lang === 'bn' ? 'এন্ট্রি পেজ' : 'Entry Point'}
                    </span>
                    <p className="text-xs font-semibold text-indigo-600 dark:text-indigo-300 font-mono truncate mt-1">
                      {importedPayload.rootFile}
                    </p>
                  </div>
                </div>

                {importedPayload.warnings && importedPayload.warnings.length > 0 && (
                  <div className="p-3 rounded-xl bg-cyan-50 dark:bg-cyan-950/40 border border-cyan-200 dark:border-cyan-800/40 text-xs text-cyan-800 dark:text-cyan-300 space-y-1">
                    {importedPayload.warnings.map((w, idx) => (
                      <p key={idx}>💡 {w}</p>
                    ))}
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                    {lang === 'bn' ? 'রিপোজিটরি ফাইলসমূহ:' : 'Repository Files:'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowFileList(!showFileList)}
                    aria-expanded={showFileList}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 transition"
                  >
                    <span>
                      {lang === 'bn'
                        ? `ফাইল তালিকা দেখুন (${importedPayload.totalFiles})`
                        : `View Files (${importedPayload.totalFiles})`}
                    </span>
                    {showFileList ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>
                </div>

                {showFileList && (
                  <div className="max-h-48 overflow-y-auto rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-2.5 space-y-1 font-mono text-xs">
                    {Object.values(importedPayload.files)
                      .slice(0, 40)
                      .map((f, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between px-2 py-1 rounded hover:bg-slate-100 dark:hover:bg-slate-900 text-slate-700 dark:text-slate-300"
                        >
                          <span className="flex items-center gap-2 truncate">
                            {isPathHidden(f.path) ? (
                              <Lock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                            ) : (
                              <FileCode className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400 flex-shrink-0" />
                            )}
                            <span className="truncate">{f.path}</span>
                          </span>
                          <span className="text-[10px] text-slate-500 dark:text-slate-400">
                            {(f.size / 1024).toFixed(1)} KB
                          </span>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
