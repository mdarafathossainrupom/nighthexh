import React, { useState, useEffect, useRef } from 'react';
import { User, SubAdmin, HostedSite, PlatformConfig, AuditLogEntry, ServerStorageStats, SiteFile, UserPopupMessage, AdminTab, AdminActivityReport } from '../types';
import { storage, RenderEnvPayload } from '../services/storage';
import {
  formatStorageFromMb,
  formatStorageFromKb,
  getRoleDisplayLabel,
  sanitizeExternalLinkUrl,
} from '../services/format';
import { resizeImageFileToDataUrl } from '../services/avatar';
import { SiteViewerModal } from './SiteViewerModal';
import {
  Shield,
  ShieldCheck,
  Users,
  Clock,
  Trash2,
  CheckCircle2,
  Search,
  Layers,
  ExternalLink,
  ArrowLeft,
  ArrowRight,
  UserPlus,
  Send,
  Settings,
  Save,
  Edit3,
  History,
  Megaphone,
  PauseCircle,
  PlayCircle,
  AlertTriangle,
  HardDrive,
  Eye,
  EyeOff,
  UserCog,
  Download,
  Camera,
  Loader2,
  X,
  FolderOpen,
  FileCode2,
  ChevronDown,
  ChevronUp,
  Server,
  Copy,
  Check,
  MessageSquare,
  BellRing,
  Database,
  Plus,
  RefreshCw,
  Info,
  FileSpreadsheet,
  BarChart3,
  UploadCloud,
  CheckCheck,
  FileJson,
  HelpCircle,
  Link2,
  Lock,
  Cloud,
  Globe,
} from 'lucide-react';

interface AdminPanelProps {
  currentUser: User;
  onNavigateHome: () => void;
  lang: 'bn' | 'en';
  externalProfileTrigger?: number;
  activeTab?: AdminTab;
  onChangeTab?: (tab: AdminTab) => void;
}

type StatusFilter = 'all' | 'pending' | 'approved' | 'suspended' | 'expired';

export const AdminPanel: React.FC<AdminPanelProps> = ({
  currentUser,
  onNavigateHome: _onNavigateHome,
  lang,
  externalProfileTrigger = 0,
  activeTab: externalTab,
  onChangeTab,
}) => {
  const isSuperAdmin = currentUser.role === 'admin';
  const [users, setUsers] = useState<User[]>([]);
  const [subAdmins, setSubAdmins] = useState<SubAdmin[]>([]);
  const [adminReports, setAdminReports] = useState<AdminActivityReport[]>([]);
  const [allSites, setAllSites] = useState<HostedSite[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [config, setConfig] = useState<PlatformConfig>(storage.getConfig());
  const [serverStorage, setServerStorage] = useState<ServerStorageStats>(() =>
    storage.getServerStorageStats()
  );
  const [internalTab, setInternalTab] = useState<AdminTab>(() => {
    const saved = storage.getSavedAdminTab();
    if (!isSuperAdmin && (saved === 'subadmins' || saved === 'settings')) return 'overview';
    return saved;
  });

  const activeTab: AdminTab = (() => {
    const requested = externalTab ?? internalTab;
    if (!isSuperAdmin && (requested === 'subadmins' || requested === 'settings')) return 'overview';
    return requested;
  })();

  const [userSearch, setUserSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [siteSearch, setSiteSearch] = useState('');

  const [previewSite, setPreviewSite] = useState<HostedSite | null>(null);

  // User Deep Inspector State
  const [inspectedUser, setInspectedUser] = useState<User | null>(null);
  const [expandedSiteId, setExpandedSiteId] = useState<string | null>(null);
  const [inspectedFile, setInspectedFile] = useState<{ siteId: string; file: SiteFile } | null>(null);

  const [approvingUser, setApprovingUser] = useState<User | null>(null);
  const [selectedDurationHours, setSelectedDurationHours] = useState<number>(1);
  const [customHoursInput, setCustomHoursInput] = useState<string>('');
  const [customQuotaMb, setCustomQuotaMb] = useState<number>(100);

  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editUserName, setEditUserName] = useState('');
  const [editUserEmail, setEditUserEmail] = useState('');
  const [editUserPassword, setEditUserPassword] = useState('');
  const [editUserQuota, setEditUserQuota] = useState(100);

  const [confirmAction, setConfirmAction] = useState<{
    type: 'user' | 'subadmin' | 'site';
    id: string;
    title: string;
    description: string;
  } | null>(null);

  // Busy spinner states
  const [busyActionId, setBusyActionId] = useState<string | null>(null);
  const [creatingSubAdmin, setCreatingSubAdmin] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);

  // Add SubAdmin state
  const [newSubUsername, setNewSubUsername] = useState('');
  const [newSubDisplayName, setNewSubDisplayName] = useState('');
  const [newSubEmail, setNewSubEmail] = useState('');
  const [newSubTelegram, setNewSubTelegram] = useState('');
  const [newSubPassword, setNewSubPassword] = useState('');
  const [showNewSubPass, setShowNewSubPass] = useState(false);
  const [showEditUserPass, setShowEditUserPass] = useState(false);
  const [subMsg, setSubMsg] = useState<{ text: string; error?: boolean } | null>(null);

  // Admin Self-Profile Modal State
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [profileUsername, setProfileUsername] = useState(currentUser.username);
  const [profileFullName, setProfileFullName] = useState(currentUser.fullName || '');
  const [profileEmail, setProfileEmail] = useState(currentUser.email || '');
  const [profilePassword, setProfilePassword] = useState('');
  const [showProfilePass, setShowProfilePass] = useState(false);
  const [profileAvatarDraft, setProfileAvatarDraft] = useState<string | null | undefined>(undefined);
  const [profileAvatarKb, setProfileAvatarKb] = useState<number>(currentUser.avatarSizeKb || 0);
  const [profileMsg, setProfileMsg] = useState<{ text: string; error?: boolean } | null>(null);
  const [savingProfile, setSavingProfile] = useState(false);
  const adminAvatarInputRef = useRef<HTMLInputElement>(null);

  // Settings state
  const [editBrandName, setEditBrandName] = useState(config.brandName);
  const [editAdminName, setEditAdminName] = useState(config.masterAdminName);
  const [editAdminTg, setEditAdminTg] = useState(config.masterAdminTelegram);
  const [editAdminTgHandle, setEditAdminTgHandle] = useState(config.masterAdminTelegramHandle);
  const [editSecretSlug, setEditSecretSlug] = useState(config.secretAdminSlug);
  const [editDefaultQuota, setEditDefaultQuota] = useState(config.defaultStorageMb);
  const [editHeroSubtitle, setEditHeroSubtitle] = useState(config.heroSubtitle || '');
  const [editFooterNote, setEditFooterNote] = useState(config.footerNote || '');
  const [editAllowRegistration, setEditAllowRegistration] = useState(config.allowRegistration !== false);
  const [editPrimaryDomain, setEditPrimaryDomain] = useState(config.primaryDomain || 'nighthostcloud.dpdns.org');
  const [editBroadcast, setEditBroadcast] = useState(config.broadcastMessage || '');
  const [settingsSaved, setSettingsSaved] = useState(false);
  const settingsDirtyRef = useRef(false);

  // Cloudflare Worker Wildcard Setup Modal state
  const [showCfWorkerModal, setShowCfWorkerModal] = useState(false);
  const [loadingCfWorker, setLoadingCfWorker] = useState(false);
  const [cfWorkerData, setCfWorkerData] = useState<{
    primaryDomain: string;
    workerScript: string;
    routes: string[];
  } | null>(null);
  const [copiedCfWorker, setCopiedCfWorker] = useState(false);

  // Backblaze B2 Storage Pool state (10 GB Free)
  const [b2Label, setB2Label] = useState('');
  const [b2KeyId, setB2KeyId] = useState('');
  const [b2AppKey, setB2AppKey] = useState('');
  const [b2Bucket, setB2Bucket] = useState('nighthost-vault-01');
  const [b2QuotaMb, setB2QuotaMb] = useState(10240);
  const [addingB2, setAddingB2] = useState(false);
  const [b2FormMsg, setB2FormMsg] = useState<{ text: string; error?: boolean } | null>(null);
  const [verifyingB2Id, setVerifyingB2Id] = useState<string | null>(null);
  const [removingB2Id, setRemovingB2Id] = useState<string | null>(null);
  const [syncingAllB2, setSyncingAllB2] = useState(false);

  // Multi-Supabase Storage Pool state
  const [supaLabel, setSupaLabel] = useState('');
  const [supaUrl, setSupaUrl] = useState('');
  const [supaKey, setSupaKey] = useState('');
  const [supaBucket, setSupaBucket] = useState('nighthost-sites');
  const [supaQuotaMb, setSupaQuotaMb] = useState(1024);
  const [addingSupa, setAddingSupa] = useState(false);
  const [supaFormMsg, setSupaFormMsg] = useState<{ text: string; error?: boolean } | null>(null);
  const [verifyingNodeId, setVerifyingNodeId] = useState<string | null>(null);
  const [removingNodeId, setRemovingNodeId] = useState<string | null>(null);
  const [showRenderGuide, setShowRenderGuide] = useState(false);
  const [copiedEnvGuide, setCopiedEnvGuide] = useState(false);
  const [showSupaHelpModal, setShowSupaHelpModal] = useState(false);
  const [renderEnvModalData, setRenderEnvModalData] = useState<RenderEnvPayload | null>(null);
  const [copiedRenderKey, setCopiedRenderKey] = useState<string | null>(null);
  const [recheckingSupa, setRecheckingSupa] = useState(false);
  const [syncingAllSupa, setSyncingAllSupa] = useState(false);

  // Advanced Admin controls state
  const [showServerDetailsModal, setShowServerDetailsModal] = useState(false);
  const [approvingAllPending, setApprovingAllPending] = useState(false);
  const [showAdminHelpModal, setShowAdminHelpModal] = useState(false);
  const [showLinkHelpModal, setShowLinkHelpModal] = useState(false);
  const [showSecurityEnvHelpModal, setShowSecurityEnvHelpModal] = useState(false);

  const [actionNotice, setActionNotice] = useState<string | null>(null);
  const [popupMessages, setPopupMessages] = useState<UserPopupMessage[]>([]);
  const [msgModalOpen, setMsgModalOpen] = useState(false);
  const [msgTargetId, setMsgTargetId] = useState<string>('all');
  const [msgTitle, setMsgTitle] = useState('');
  const [msgBody, setMsgBody] = useState('');
  const [msgLinkUrl, setMsgLinkUrl] = useState('');
  const [msgLinkText, setMsgLinkText] = useState('');
  const [msgLinkMarked, setMsgLinkMarked] = useState<boolean>(true);
  const [msgFormError, setMsgFormError] = useState<string | null>(null);
  const [sendingMsg, setSendingMsg] = useState(false);
  const [copiedInspectorCode, setCopiedInspectorCode] = useState(false);

  const showNotice = (msg: string) => {
    setActionNotice(msg);
    setTimeout(() => setActionNotice(null), 3500);
  };

  const selectTab = (tab: AdminTab) => {
    const next = !isSuperAdmin && (tab === 'subadmins' || tab === 'settings') ? 'overview' : tab;
    setInternalTab(next);
    storage.setSavedAdminTab(next);
    if (onChangeTab) {
      onChangeTab(next);
    }
  };

  useEffect(() => {
    if (externalProfileTrigger > 0) {
      openSelfProfileModal();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [externalProfileTrigger]);

  useEffect(() => {
    const refreshData = () => {
      const latestUsers = storage.getUsers();
      setUsers(latestUsers);
      setSubAdmins(storage.getSubAdmins());
      setAdminReports(storage.getAdminActivityReports());
      setAllSites(storage.getSites());
      setAuditLogs(storage.getAuditLogs());
      setPopupMessages(storage.getPopupMessages());
      setServerStorage(storage.getServerStorageStats());
      setInspectedUser((prev) =>
        prev ? latestUsers.find((u) => u.id === prev.id) || null : null
      );
      const latestCfg = storage.getConfig();
      setConfig(latestCfg);
      if (!settingsDirtyRef.current) {
        setEditBrandName(latestCfg.brandName);
        setEditAdminName(latestCfg.masterAdminName);
        setEditAdminTg(latestCfg.masterAdminTelegram);
        setEditAdminTgHandle(latestCfg.masterAdminTelegramHandle);
        setEditSecretSlug(latestCfg.secretAdminSlug);
        setEditDefaultQuota(latestCfg.defaultStorageMb);
        setEditHeroSubtitle(latestCfg.heroSubtitle || '');
        setEditFooterNote(latestCfg.footerNote || '');
        setEditAllowRegistration(latestCfg.allowRegistration !== false);
        setEditPrimaryDomain(latestCfg.primaryDomain || 'nighthostcloud.dpdns.org');
        setEditBroadcast(latestCfg.broadcastMessage || '');
      }
    };

    refreshData();
    storage.syncFromServer();
    return storage.subscribe(refreshData);
  }, []);

  const openApprovalModal = (u: User) => {
    setApprovingUser(u);
    setSelectedDurationHours(24);
    setCustomHoursInput('');
    setCustomQuotaMb(u.storageLimitMb || config.defaultStorageMb || 100);
  };

  const handleQuickApprove = (user: User, hours: number, labelBn: string, labelEn: string) => {
    const label = lang === 'bn' ? labelBn : labelEn;
    storage.approveUser(user.id, hours, label);
    showNotice(
      lang === 'bn'
        ? `ইউজার '${user.username}' কে ${label} মেয়াদে অনুমোদন দেওয়া হয়েছে!`
        : `Approved '${user.username}' for ${label}!`
    );
  };

  const getApprovalLabel = (hours: number): string => {
    if (hours === -1) return lang === 'bn' ? 'স্থায়ী (Permanent)' : 'Permanent';
    if (hours === 0.5) return lang === 'bn' ? '৩০ মিনিট (30 Min)' : '30 Minutes';
    if (hours === 1) return lang === 'bn' ? '১ ঘন্টা (1 Hour)' : '1 Hour';
    if (hours === 6) return lang === 'bn' ? '৬ ঘন্টা (6 Hours)' : '6 Hours';
    if (hours === 24) return lang === 'bn' ? '২৪ ঘন্টা (1 Day)' : '24 Hours (1 Day)';
    if (hours === 168) return lang === 'bn' ? '৭ দিন (7 Days)' : '7 Days';
    if (hours === 720) return lang === 'bn' ? '৩০ দিন (30 Days)' : '30 Days';
    return lang === 'bn' ? `${hours} ঘন্টা` : `${hours} Hours`;
  };

  const handleApproveWithDuration = () => {
    if (!approvingUser || !canApproveUsers) return;
    const parsedCustom = customHoursInput.trim() ? Number(customHoursInput) : NaN;
    const effectiveHours = !Number.isNaN(parsedCustom) && parsedCustom > 0 ? parsedCustom : selectedDurationHours;
    const label = getApprovalLabel(effectiveHours);
    const effectiveQuota = canSetQuota ? customQuotaMb : approvingUser.storageLimitMb;

    storage.approveUser(approvingUser.id, effectiveHours, label, effectiveQuota);

    showNotice(
      lang === 'bn'
        ? `ইউজার '${approvingUser.username}' কে ${label} এবং ${formatStorageFromMb(effectiveQuota)} কোটার জন্য অনুমোদন দেওয়া হয়েছে!`
        : `Approved '${approvingUser.username}' for ${label} with ${formatStorageFromMb(effectiveQuota)} quota!`
    );
    setApprovingUser(null);
  };

  const openEditUserModal = (u: User) => {
    setEditingUser(u);
    setEditUserName(u.fullName);
    setEditUserEmail(u.email);
    setEditUserPassword('');
    setShowEditUserPass(false);
    setEditUserQuota(u.storageLimitMb);
  };

  const openSelfProfileModal = () => {
    const active = storage.getCurrentUser() || currentUser;
    setProfileUsername(active.username);
    setProfileFullName(active.fullName || '');
    setProfileEmail(active.email || '');
    setProfilePassword('');
    setShowProfilePass(false);
    setProfileAvatarDraft(undefined);
    setProfileAvatarKb(active.avatarSizeKb || 0);
    setProfileMsg(null);
    setProfileModalOpen(true);
  };

  const handleAdminAvatarSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setProfileMsg(null);
    try {
      const { dataUrl, sizeKb } = await resizeImageFileToDataUrl(file, 360, 0.82);
      setProfileAvatarDraft(dataUrl);
      setProfileAvatarKb(sizeKb);
    } catch {
      setProfileMsg({
        text: lang === 'bn' ? 'ছবিটি প্রসেস করা যায়নি।' : 'Failed to process image.',
        error: true,
      });
    }
  };

  const handleSaveSelfProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileMsg(null);
    if (!profileUsername.trim() || profileUsername.trim().length < 3) {
      setProfileMsg({
        text: lang === 'bn' ? 'ইউজারনেম কমপক্ষে ৩ অক্ষরের হতে হবে।' : 'Username must be at least 3 characters.',
        error: true,
      });
      return;
    }
    if (profilePassword.trim() && profilePassword.trim().length < 4) {
      setProfileMsg({
        text: lang === 'bn' ? 'নতুন পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।' : 'Password must be at least 4 characters.',
        error: true,
      });
      return;
    }

    setSavingProfile(true);
    const res = await storage.updateAdminProfileAsync(currentUser.id, {
      username: profileUsername.trim(),
      fullName: profileFullName.trim(),
      email: profileEmail.trim(),
      password: profilePassword.trim() ? profilePassword.trim() : undefined,
      avatarDataUrl: profileAvatarDraft,
    });
    setSavingProfile(false);

    if (res.success) {
      setProfileModalOpen(false);
      showNotice(
        lang === 'bn'
          ? 'আপনার অ্যাডমিন প্রোফাইল ও পাসওয়ার্ড সফলভাবে আপডেট হয়েছে!'
          : 'Your admin profile & credentials have been updated!'
      );
    } else {
      setProfileMsg({
        text: res.message || (lang === 'bn' ? 'প্রোফাইল আপডেট ব্যর্থ হয়েছে।' : 'Failed to update profile.'),
        error: true,
      });
    }
  };

  const handleSaveUserEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    storage.updateUser(editingUser.id, {
      fullName: editUserName,
      email: editUserEmail,
      password: editUserPassword || undefined,
      storageLimitMb: editUserQuota,
    });
    showNotice(
      lang === 'bn'
        ? `ইউজার '${editingUser.username}' এর তথ্য আপডেট করা হয়েছে।`
        : `Updated user '${editingUser.username}'.`
    );
    setEditingUser(null);
  };

  const handleSuspendUser = (userId: string, username: string) => {
    storage.suspendUser(userId);
    showNotice(
      lang === 'bn'
        ? `ইউজার '${username}' সাময়িক সাসপেন্ড করা হয়েছে।`
        : `Suspended user '${username}'.`
    );
  };

  const handleUnsuspendUser = async (userId: string, username: string) => {
    setBusyActionId(`unsuspend_${userId}`);
    try {
      const ok = await storage.unsuspendUser(userId);
      if (ok) {
        showNotice(
          lang === 'bn'
            ? `ইউজার '${username}' আনসাসপেন্ড ও পুনরায় সক্রিয় করা হয়েছে!`
            : `Unsuspended and restored user '${username}'!`
        );
      }
    } finally {
      setBusyActionId(null);
    }
  };

  const openQuickMessageModal = (targetUserId: string) => {
    setMsgTargetId(targetUserId);
    setMsgTitle('');
    setMsgBody('');
    setMsgLinkUrl('');
    setMsgLinkText('');
    setMsgLinkMarked(true);
    setMsgFormError(null);
    setMsgModalOpen(true);
  };

  const handleSendPopupMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgTitle.trim() || !msgBody.trim()) return;
    setMsgFormError(null);
    setSendingMsg(true);
    try {
      const res = await storage.sendPopupMessageAsync(
        msgTargetId || 'all',
        msgTitle.trim(),
        msgBody.trim(),
        currentUser.username,
        {
          linkUrl: msgLinkUrl.trim() || undefined,
          linkText: msgLinkText.trim() || undefined,
          linkMarked: msgLinkMarked,
        }
      );
      if (res.success) {
        setMsgTitle('');
        setMsgBody('');
        setMsgLinkUrl('');
        setMsgLinkText('');
        setMsgLinkMarked(true);
        setMsgFormError(null);
        setMsgModalOpen(false);
        showNotice(
          lang === 'bn'
            ? 'পপআপ বার্তা সফলভাবে পাঠানো হয়েছে!'
            : 'Popup message sent successfully!'
        );
      } else {
        setMsgFormError(
          res.error || (lang === 'bn' ? 'বার্তা পাঠানো যায়নি।' : 'Failed to send popup notice.')
        );
      }
    } finally {
      setSendingMsg(false);
    }
  };

  const executeConfirmDelete = () => {
    if (!confirmAction) return;
    if (confirmAction.type === 'user') {
      storage.deleteUser(confirmAction.id);
      showNotice(
        lang === 'bn'
          ? 'অ্যাকাউন্ট সম্পূর্ণ মুছে ফেলা হয়েছে এবং ইউজারনেমটি খালি করা হয়েছে!'
          : 'Account permanently deleted and username freed.'
      );
    } else if (confirmAction.type === 'subadmin') {
      storage.removeSubAdmin(confirmAction.id);
      showNotice(
        lang === 'bn'
          ? 'অ্যাডমিন সম্পূর্ণভাবে মুছে ফেলা হয়েছে!'
          : 'Admin permanently removed.'
      );
    } else if (confirmAction.type === 'site') {
      storage.deleteSite(confirmAction.id);
      showNotice(lang === 'bn' ? 'সাইটটি মুছে ফেলা হয়েছে।' : 'Website deleted.');
    }
    setConfirmAction(null);
  };

  const handleCreateSubAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubMsg(null);
    if (!newSubUsername.trim() || !newSubEmail.trim() || !newSubTelegram.trim() || newSubPassword.trim().length < 4) {
      setSubMsg({
        text:
          lang === 'bn'
            ? 'ইউজারনেম, ইমেইল, টেলিগ্রাম লিঙ্ক এবং কমপক্ষে ৪ অক্ষরের পাসওয়ার্ড দিন।'
            : 'Please provide username, email, Telegram handle, and a password (min 4 chars).',
        error: true,
      });
      return;
    }

    setCreatingSubAdmin(true);
    const res = await storage.addSubAdminAsync(
      newSubUsername,
      newSubDisplayName || (lang === 'bn' ? `অ্যাডমিন (${newSubUsername})` : `Admin (${newSubUsername})`),
      newSubEmail,
      newSubTelegram,
      newSubPassword.trim()
    );
    setCreatingSubAdmin(false);

    if (res.success) {
      setSubMsg({ text: res.message });
      setNewSubUsername('');
      setNewSubDisplayName('');
      setNewSubEmail('');
      setNewSubTelegram('');
      setNewSubPassword('');
      showNotice(lang === 'bn' ? 'নতুন অ্যাডমিন সফলভাবে যুক্ত হয়েছে!' : 'Admin added successfully!');
    } else {
      setSubMsg({ text: res.message, error: true });
    }
  };

  const handleSavePlatformSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      const cleanSlug = editSecretSlug.trim().toLowerCase().replace(/[^a-z0-9-_]/g, '') || 'admin';
      storage.updateConfig({
        brandName: editBrandName.trim() || 'NIGHTHOST',
        masterAdminName: editAdminName.trim() || 'NIGHT HEX',
        masterAdminTelegram: editAdminTg.trim() || 'https://t.me/NightHex_X',
        masterAdminTelegramHandle: editAdminTgHandle.trim() || '@NightHex_X',
        secretAdminSlug: cleanSlug,
        defaultStorageMb: Math.max(10, Number(editDefaultQuota) || 100),
        primaryDomain: editPrimaryDomain.trim() || 'nighthostcloud.dpdns.org',
        heroSubtitle: editHeroSubtitle.trim(),
        footerNote: editFooterNote.trim(),
        allowRegistration: editAllowRegistration,
        broadcastMessage: editBroadcast.trim(),
      });
      settingsDirtyRef.current = false;
      setSettingsSaved(true);
      showNotice(
        lang === 'bn'
          ? 'প্ল্যাটফর্ম সেটিংস ও ঘোষণা সফলভাবে সংরক্ষণ ও লাইভ সিঙ্ক করা হয়েছে!'
          : 'Platform settings saved and synced live across the site!'
      );
      setTimeout(() => setSettingsSaved(false), 2500);
    } finally {
      setSavingSettings(false);
    }
  };

  const handleOpenCfWorkerModal = async () => {
    setShowCfWorkerModal(true);
    setLoadingCfWorker(true);
    const res = await storage.fetchCloudflareWorkerTemplateAsync();
    setLoadingCfWorker(false);
    if (res.success && res.workerCode) {
      setCfWorkerData({
        primaryDomain: res.primaryDomain || editPrimaryDomain || 'nighthostcloud.dpdns.org',
        workerScript: res.workerCode,
        routes: res.routes || [
          `${editPrimaryDomain || 'nighthostcloud.dpdns.org'}/*`,
          `*.${editPrimaryDomain || 'nighthostcloud.dpdns.org'}/*`,
        ],
      });
    } else {
      showNotice(res.message || (lang === 'bn' ? 'Cloudflare Worker টেমপ্লেট লোড করা যায়নি।' : 'Failed to load Cloudflare Worker template.'));
    }
  };

  const handleAddB2Node = async (e: React.FormEvent) => {
    e.preventDefault();
    setB2FormMsg(null);
    if (!b2KeyId.trim() || !b2AppKey.trim() || !b2Bucket.trim()) {
      setB2FormMsg({
        text: lang === 'bn' ? 'Backblaze B2 Key ID, Application Key ও Bucket Name দিন।' : 'Enter B2 Key ID, Application Key, and Bucket Name.',
        error: true,
      });
      return;
    }
    setAddingB2(true);
    const res = await storage.addB2NodeAsync({
      label: b2Label.trim() || `Backblaze B2 #${(serverStorage.b2Nodes?.length || 0) + 1}`,
      keyId: b2KeyId.trim(),
      applicationKey: b2AppKey.trim(),
      bucketName: b2Bucket.trim(),
      quotaMb: Math.max(100, Number(b2QuotaMb) || 10240),
    });
    setAddingB2(false);
    if (res.success) {
      setB2Label('');
      setB2KeyId('');
      setB2AppKey('');
      setB2Bucket('nighthost-vault-01');
      setB2QuotaMb(10240);
      setB2FormMsg({
        text: res.message || (lang === 'bn' ? 'Backblaze B2 স্টোরেজ পুল যুক্ত ও যাচাই হয়েছে!' : 'Backblaze B2 bucket connected!'),
      });
      if (res.renderEnv) {
        setRenderEnvModalData(res.renderEnv);
      }
    } else {
      setB2FormMsg({ text: res.message || (lang === 'bn' ? 'B2 সংযুক্ত করা যায়নি।' : 'B2 connection failed.'), error: true });
    }
  };

  const handleVerifyB2Node = async (nodeId: string) => {
    setVerifyingB2Id(nodeId);
    const res = await storage.verifyB2NodeAsync(nodeId);
    setVerifyingB2Id(null);
    showNotice(res.message || (res.success ? 'B2 Verified!' : 'B2 Verification failed'));
    if (res.success && res.renderEnv) {
      setRenderEnvModalData(res.renderEnv);
    }
  };

  const handleRemoveB2Node = async (nodeId: string) => {
    setRemovingB2Id(nodeId);
    const res = await storage.removeB2NodeAsync(nodeId);
    setRemovingB2Id(null);
    if (res.message) showNotice(res.message);
  };

  const handleSyncAllToB2 = async () => {
    setSyncingAllB2(true);
    const res = await storage.syncAllSitesToB2Async();
    setSyncingAllB2(false);
    showNotice(
      res.message ||
        (res.success
          ? lang === 'bn'
            ? 'সব সাইট Backblaze B2-তে ব্যাকআপ হয়েছে!'
            : 'All sites synced to Backblaze B2!'
          : lang === 'bn'
          ? 'B2 সিঙ্ক করা যায়নি।'
          : 'B2 sync failed.')
    );
  };

  const renderEnvSnippet = `SUPABASE_URL_1=https://your-project-1.supabase.co
SUPABASE_SERVICE_ROLE_KEY_1=eyJhbGci...
SUPABASE_BUCKET_1=nighthost-sites
SUPABASE_STORAGE_MB_1=1024

SUPABASE_URL_2=https://your-project-2.supabase.co
SUPABASE_SERVICE_ROLE_KEY_2=eyJhbGci...
SUPABASE_BUCKET_2=nighthost-sites-2
SUPABASE_STORAGE_MB_2=1024

# অথবা একটি JSON অ্যারে:
# SUPABASE_POOL_JSON=[{"label":"Supa-1","url":"https://...","serviceKey":"...","bucket":"nighthost-sites","quotaMb":1024}]`;

  const handleCopyEnvGuide = () => {
    navigator.clipboard?.writeText(renderEnvSnippet);
    setCopiedEnvGuide(true);
    setTimeout(() => setCopiedEnvGuide(false), 2000);
  };

  const copyTextWithKey = (keyId: string, text: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedRenderKey(keyId);
    setTimeout(() => setCopiedRenderKey(null), 1800);
  };

  const handleAddSupabaseNode = async (e: React.FormEvent) => {
    e.preventDefault();
    setSupaFormMsg(null);
    if (!supaUrl.trim() || !supaKey.trim()) {
      setSupaFormMsg({
        text: lang === 'bn' ? 'Supabase Project URL এবং Service Role Key দিন।' : 'Enter Supabase URL and Service Role Key.',
        error: true,
      });
      return;
    }
    setAddingSupa(true);
    const res = await storage.addSupabaseNodeAsync({
      label: supaLabel.trim() || `Supabase #${(serverStorage.supabaseNodes?.length || 0) + 1}`,
      url: supaUrl.trim(),
      serviceKey: supaKey.trim(),
      bucket: supaBucket.trim() || 'nighthost-sites',
      quotaMb: Math.max(100, Number(supaQuotaMb) || 1024),
    });
    setAddingSupa(false);
    if (res.success) {
      setSupaLabel('');
      setSupaUrl('');
      setSupaKey('');
      setSupaBucket('nighthost-sites');
      setSupaQuotaMb(1024);
      setSupaFormMsg({
        text: res.message || (lang === 'bn' ? 'Supabase পুল যুক্ত ও ভেরিফাই হয়েছে!' : 'Supabase storage node connected!'),
      });
      if (res.renderEnv) {
        setRenderEnvModalData(res.renderEnv);
      }
    } else {
      setSupaFormMsg({ text: res.message || (lang === 'bn' ? 'সংযুক্ত করা যায়নি।' : 'Connection failed.'), error: true });
    }
  };

  const handleVerifySupabaseNode = async (nodeId: string) => {
    setVerifyingNodeId(nodeId);
    const res = await storage.verifySupabaseNodeAsync(nodeId);
    setVerifyingNodeId(null);
    showNotice(res.message || (res.success ? 'Verified!' : 'Verification failed'));
    if (res.success && res.renderEnv) {
      setRenderEnvModalData(res.renderEnv);
    }
  };

  const handleOpenRenderEnvModal = async () => {
    const res = await storage.fetchSupabaseRenderEnvAsync();
    if (res.success && res.renderEnv) {
      setRenderEnvModalData(res.renderEnv);
    } else {
      showNotice(lang === 'bn' ? 'Render Env তথ্য লোড করা যায়নি।' : 'Failed to load Render Env variables.');
    }
  };

  const handleRecheckAllSupabase = async () => {
    setRecheckingSupa(true);
    const res = await storage.recheckAllSupabaseNodesAsync();
    setRecheckingSupa(false);
    if (res.renderEnv) {
      setRenderEnvModalData(res.renderEnv);
    }
    showNotice(
      res.message ||
        (res.success
          ? lang === 'bn'
            ? 'সব Supabase নড পুনরায় যাচাই ও সিঙ্ক সম্পন্ন হয়েছে!'
            : 'All Supabase nodes re-verified!'
          : lang === 'bn'
          ? 'পুনরায় যাচাই করা যায়নি।'
          : 'Re-check failed.')
    );
  };

  const handleSyncAllToSupabase = async () => {
    setSyncingAllSupa(true);
    const res = await storage.syncAllSitesToSupabaseAsync();
    setSyncingAllSupa(false);
    showNotice(
      res.message ||
        (res.success
          ? lang === 'bn'
            ? 'সব সাইট Supabase বাকেটে ব্যাকআপ করা হয়েছে!'
            : 'All sites synced to Supabase!'
          : lang === 'bn'
          ? 'সিঙ্ক করা যায়নি।'
          : 'Sync failed.')
    );
  };

  const handleRemoveSupabaseNode = async (nodeId: string) => {
    setRemovingNodeId(nodeId);
    const res = await storage.removeSupabaseNodeAsync(nodeId);
    setRemovingNodeId(null);
    if (res.message) showNotice(res.message);
  };

  const handleApproveAllPending = async () => {
    if (!canApproveUsers || pendingCount === 0) return;
    setApprovingAllPending(true);
    const defaultQuota = config.defaultStorageMb || 100;
    const res = await storage.approveAllPendingUsersAsync(
      24,
      lang === 'bn' ? '২৪ ঘন্টা (1 Day)' : '24 Hours (1 Day)',
      defaultQuota
    );
    setApprovingAllPending(false);
    showNotice(
      res.message ||
        (lang === 'bn'
          ? `${res.approvedCount ?? pendingCount} জন পেন্ডিং ইউজারকে ২৪ ঘন্টার জন্য অনুমোদন দেওয়া হয়েছে!`
          : `Approved ${res.approvedCount ?? pendingCount} pending users for 24 Hours!`)
    );
  };

  const handleExportUsersCsv = () => {
    const csvCell = (val: unknown) => `"${String(val ?? '').replace(/"/g, '""')}"`;
    const header = ['Username', 'Full Name', 'Email', 'Role', 'Status', 'Quota (MB)', 'Used (MB)', 'Sites', 'Expires At', 'Created At'];
    const rows = managedUsers.map((u) => {
      const userSites = allSites.filter((s) => s.userId === u.id).length;
      return [
        u.username,
        u.fullName || '',
        u.email,
        u.role,
        u.status,
        u.storageLimitMb,
        u.storageUsedMb,
        userSites,
        u.expiresAt || 'Permanent',
        u.createdAt,
      ]
        .map(csvCell)
        .join(',');
    });
    const csv = [header.map(csvCell).join(','), ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nighthost-users-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showNotice(lang === 'bn' ? 'ইউজার তালিকা CSV হিসেবে ডাউনলোড হয়েছে।' : 'Exported users CSV.');
  };

  const handleExportAuditLogsJson = () => {
    const blob = new Blob([JSON.stringify(auditLogs, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nighthost-audit-logs-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showNotice(lang === 'bn' ? 'অডিট লগ JSON হিসেবে ডাউনলোড হয়েছে।' : 'Exported audit logs JSON.');
  };

  const managedUsers = users.filter((u) => u.role !== 'admin');

  const filteredUsers = managedUsers.filter((u) => {
    const matchesQuery =
      u.username.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.fullName.toLowerCase().includes(userSearch.toLowerCase());
    if (!matchesQuery) return false;
    if (statusFilter === 'all') return true;
    const isExpired = u.status === 'approved' && storage.getRemainingApprovalTime(u, lang).isExpired;
    if (statusFilter === 'expired') return isExpired;
    if (statusFilter === 'approved') return u.status === 'approved' && !isExpired;
    return u.status === statusFilter;
  });

  const filteredSites = allSites.filter(
    (s) =>
      s.name.toLowerCase().includes(siteSearch.toLowerCase()) ||
      s.slug.toLowerCase().includes(siteSearch.toLowerCase()) ||
      s.username.toLowerCase().includes(siteSearch.toLowerCase())
  );

  const pendingCount = managedUsers.filter((u) => u.status === 'pending').length;

  const mySubAdminRecord = !isSuperAdmin
    ? subAdmins.find(
        (s) =>
          s.id === currentUser.id ||
          s.username.toLowerCase() === currentUser.username.toLowerCase()
      )
    : undefined;
  const canApproveUsers =
    isSuperAdmin || Boolean(mySubAdminRecord?.active && mySubAdminRecord?.canApproveUsers);
  const canSetQuota =
    isSuperAdmin || Boolean(mySubAdminRecord?.active && mySubAdminRecord?.canSetQuota);
  const canSendMessages =
    isSuperAdmin ||
    Boolean(mySubAdminRecord?.active && mySubAdminRecord?.canSendMessages !== false);
  const canDownloadSource =
    isSuperAdmin || Boolean(mySubAdminRecord?.active && mySubAdminRecord?.canDownloadSource);
  const canManageAllSites =
    isSuperAdmin || Boolean(mySubAdminRecord?.active && mySubAdminRecord?.canManageAllSites);

  const activeAdminUser = users.find((u) => u.id === currentUser.id) || currentUser;
  const poolCap = Math.max(1, serverStorage.configuredPoolMb);
  const allocatedPoolPercent = Math.min(100, Math.round((serverStorage.allocatedMb / poolCap) * 100));
  const usedSitesPoolPct = Math.min(100, (serverStorage.usedBySitesMb / poolCap) * 100);
  const usedAvatarsPoolPct = Math.min(100 - usedSitesPoolPct, (serverStorage.usedByAvatarsMb / poolCap) * 100);
  const reservedPoolPct = Math.min(
    Math.max(0, 100 - usedSitesPoolPct - usedAvatarsPoolPct),
    (Math.max(0, serverStorage.allocatedMb - serverStorage.totalUsedMb) / poolCap) * 100
  );

  const pendingUsersPreview = managedUsers.filter((u) => u.status === 'pending').slice(0, 3);

  const tabMeta: Record<Exclude<AdminTab, 'overview'>, { bn: string; en: string; descBn: string; descEn: string }> = {
    users: {
      bn: 'ইউজার ও অনুমোদন',
      en: 'Users & Approvals',
      descBn: 'ইউজারের মেয়াদ অনুমোদন, স্টোরেজ কোটা নির্ধারণ এবং ইনস্পেক্ট করুন।',
      descEn: 'Approve accounts, set time limits, adjust quotas, and inspect users.',
    },
    subadmins: {
      bn: 'অ্যাডমিন ও টেলিগ্রাম',
      en: 'Admins & Telegram',
      descBn: 'প্ল্যাটফর্ম অ্যাডমিন যুক্ত করুন এবং পারমিশন ও টেলিগ্রাম সাপোর্ট নিয়ন্ত্রণ করুন।',
      descEn: 'Manage Admins, permissions, and support Telegram links.',
    },
    sites: {
      bn: 'সকল হোস্টকৃত সাইট',
      en: 'Global Hosted Sites',
      descBn: 'সার্ভারে হোস্টকৃত সব ইউজারের প্রজেক্ট দেখুন, পজ বা ডাউনলোড করুন।',
      descEn: 'Inspect, toggle, or download all hosted websites across the server.',
    },
    messages: {
      bn: 'পপআপ মেসেজ',
      en: 'Popup Messages',
      descBn: 'একজন বা সকল ইউজারকে ওয়ান-টাইম নোটিশ ও ঘোষণা পাঠান।',
      descEn: 'Send one-time popup announcements to individual users or everyone.',
    },
    logs: {
      bn: 'অডিট লগ',
      en: 'Audit Logs',
      descBn: 'প্ল্যাটফর্মের সাম্প্রতিক অ্যাডমিন অ্যাকশন ও ডিপ্লয়মেন্ট হিস্ট্রি দেখুন।',
      descEn: 'Review recent administrative actions and system activity history.',
    },
    settings: {
      bn: 'প্ল্যাটফর্ম সেটিংস ও পুল',
      en: 'Platform Settings & Pool',
      descBn: 'মোট সার্ভার স্টোরেজ পুল, ব্র্যান্ড নাম, স্লাগ ও ঘোষণা কাস্টমাইজ করুন।',
      descEn: 'Configure server pool presets, owner details, secret URL, and banners.',
    },
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-5 sm:py-6 space-y-5">
      {/* Sub-page Header with Back Button when viewing a dedicated section */}
      {activeTab !== 'overview' && (
        <div className="p-4 sm:p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-panel-enter">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => selectTab('overview')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-xs font-bold border border-slate-200 dark:border-slate-700 transition shrink-0"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{lang === 'bn' ? 'ওভারভিউতে ফিরুন' : 'Back to Overview'}</span>
            </button>

            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white truncate">
                {lang === 'bn' ? tabMeta[activeTab].bn : tabMeta[activeTab].en}
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {lang === 'bn' ? tabMeta[activeTab].descBn : tabMeta[activeTab].descEn}
              </p>
            </div>
          </div>
        </div>
      )}

      {actionNotice && (
        <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/80 border border-emerald-200 dark:border-emerald-500/40 text-emerald-800 dark:text-emerald-300 text-xs font-medium flex items-center gap-2 shadow-sm">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* Overview Page */}
      {activeTab === 'overview' && (
        <div className="space-y-5">
          {/* Role Banner & Location-style Segmented Server Pool Bar */}
          <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 shadow-sm dark:shadow-xl space-y-5">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div className="flex items-center gap-3.5 min-w-0">
                {activeAdminUser.avatarDataUrl ? (
                  <img
                    src={activeAdminUser.avatarDataUrl}
                    alt={activeAdminUser.username}
                    referrerPolicy="no-referrer"
                    className={`w-12 h-12 rounded-2xl object-cover border shadow-sm shrink-0 ${
                      isSuperAdmin
                        ? 'border-rose-200 dark:border-rose-500/40'
                        : 'border-amber-200 dark:border-amber-500/40'
                    }`}
                  />
                ) : (
                  <div
                    className={`w-12 h-12 rounded-2xl border flex items-center justify-center shadow-sm shrink-0 ${
                      isSuperAdmin
                        ? 'bg-rose-50 dark:bg-rose-950/80 border-rose-200 dark:border-rose-500/40 text-rose-600 dark:text-rose-400'
                        : 'bg-amber-50 dark:bg-amber-950/80 border-amber-200 dark:border-amber-500/40 text-amber-600 dark:text-amber-400'
                    }`}
                  >
                    <Shield className="w-6 h-6" />
                  </div>
                )}
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase border ${
                        isSuperAdmin
                          ? 'bg-rose-50 dark:bg-rose-950 border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300'
                          : 'bg-amber-50 dark:bg-amber-950 border-amber-200 dark:border-amber-500/40 text-amber-700 dark:text-amber-300'
                      }`}
                    >
                      {isSuperAdmin
                        ? `${config.masterAdminName} (${lang === 'bn' ? 'মালিক • আনলিমিটেড' : 'OWNER • UNLIMITED'})`
                        : lang === 'bn'
                        ? 'অ্যাডমিন মডারেটর'
                        : 'ADMIN MODERATOR'}
                    </span>
                    <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                      | {config.brandName} Console
                    </span>
                  </div>
                  <h1 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white mt-0.5 truncate">
                    {isSuperAdmin
                      ? lang === 'bn'
                        ? 'মালিক কন্ট্রোল ওভারভিউ'
                        : 'Owner Console Overview'
                      : lang === 'bn'
                      ? 'অ্যাডমিন কন্ট্রোল ওভারভিউ'
                      : 'Admin Console Overview'}
                  </h1>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={openSelfProfileModal}
                  className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition ${
                    isSuperAdmin
                      ? 'bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 dark:hover:bg-rose-900 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-500/30'
                      : 'bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 dark:hover:bg-amber-900 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-500/30'
                  }`}
                >
                  <UserCog className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? 'প্রোফাইল' : 'Profile'}</span>
                </button>
              </div>
            </div>

            {/* Real Server Storage Pool Bar (Connected Supabase Pool or Local 1 GB App Pool) */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/80 border border-slate-200/80 dark:border-slate-800 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex flex-wrap items-center gap-2 min-w-0">
                  <Server className="w-4 h-4 text-cyan-600 dark:text-cyan-400 shrink-0" />
                  <span className="font-bold text-slate-800 dark:text-slate-100">
                    {lang === 'bn' ? 'রিয়েল সার্ভার স্টোরেজ পুল' : 'Real Server Storage Pool'}
                  </span>
                  <span
                    className={`text-[11px] font-mono font-semibold ${
                      serverStorage.storageSource === 'supabase-pool'
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {serverStorage.storageSource === 'supabase-pool'
                      ? `· Supabase Pool (${serverStorage.supabaseConnectedCount ?? serverStorage.supabaseNodesCount ?? 1} Connected · ${formatStorageFromMb(serverStorage.configuredPoolMb)})`
                      : `· Local Pool (${formatStorageFromMb(serverStorage.configuredPoolMb)} · 0 Supabase Connected)`}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2 font-mono tabular-nums">
                  <span className="text-cyan-700 dark:text-cyan-300 font-bold">
                    {formatStorageFromMb(serverStorage.allocatedMb)} / {formatStorageFromMb(serverStorage.configuredPoolMb)} ({allocatedPoolPercent}%)
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowServerDetailsModal(true)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-sans font-semibold transition whitespace-nowrap"
                  >
                    <BarChart3 className="w-3.5 h-3.5 text-indigo-500" />
                    <span>{lang === 'bn' ? 'বিস্তারিত' : 'Inspect Details'}</span>
                  </button>
                  {isSuperAdmin && (
                    <>
                      <button
                        type="button"
                        onClick={() => selectTab('settings')}
                        className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 hover:bg-cyan-50 dark:hover:bg-cyan-950/60 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-sans font-semibold transition whitespace-nowrap"
                      >
                        {lang === 'bn' ? 'স্টোরেজ পুল' : 'Storage Pool'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowSecurityEnvHelpModal(true)}
                        aria-label={lang === 'bn' ? 'সিকিউরিটি ও Render Env তথ্য' : 'Security & Render Env Guide'}
                        className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-cyan-50 dark:bg-cyan-950/60 hover:bg-cyan-100 dark:hover:bg-cyan-900 border border-cyan-200 dark:border-cyan-500/40 text-cyan-700 dark:text-cyan-300 text-[11px] font-sans font-bold transition whitespace-nowrap"
                      >
                        <Info className="w-3.5 h-3.5" />
                        <span>Env</span>
                      </button>
                    </>
                  )}
                </div>
              </div>

              <div className="w-full h-3 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden flex">
                {usedSitesPoolPct > 0 && (
                  <div
                    className="h-full bg-cyan-500 transition-all duration-500"
                    style={{ width: `${Math.max(0.5, usedSitesPoolPct)}%` }}
                    title={`Sites: ${formatStorageFromMb(serverStorage.usedBySitesMb)}`}
                  />
                )}
                {usedAvatarsPoolPct > 0 && (
                  <div
                    className="h-full bg-indigo-500 transition-all duration-500"
                    style={{ width: `${Math.max(0.5, usedAvatarsPoolPct)}%` }}
                    title={`Photos: ${formatStorageFromMb(serverStorage.usedByAvatarsMb)}`}
                  />
                )}
                {reservedPoolPct > 0 && (
                  <div
                    className="h-full bg-amber-400/80 dark:bg-amber-500/70 transition-all duration-500"
                    style={{ width: `${Math.max(0.5, reservedPoolPct)}%` }}
                    title={`Reserved Approved Quotas: ${formatStorageFromMb(Math.max(0, serverStorage.allocatedMb - serverStorage.totalUsedMb))}`}
                  />
                )}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono tabular-nums text-slate-600 dark:text-slate-400">
                <div className="flex flex-wrap items-center gap-3.5">
                  <span className="inline-flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-sm bg-cyan-500" />
                    {lang === 'bn' ? 'সাইট:' : 'Sites:'}{' '}
                    <strong className="text-slate-900 dark:text-slate-100">{formatStorageFromMb(serverStorage.usedBySitesMb)}</strong>
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-sm bg-indigo-500" />
                    {lang === 'bn' ? 'ছবি:' : 'Photos:'}{' '}
                    <strong className="text-slate-900 dark:text-slate-100">{formatStorageFromMb(serverStorage.usedByAvatarsMb)}</strong>
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-sm bg-amber-400" />
                    {lang === 'bn' ? 'অ্যাপ্রুভড বরাদ্দ:' : 'Approved Allocated:'}{' '}
                    <strong className="text-slate-900 dark:text-slate-100">{formatStorageFromMb(serverStorage.allocatedMb)}</strong>
                  </span>
                  {(serverStorage.pendingUsersCount ?? pendingCount) > 0 && (
                    <span className="text-amber-600 dark:text-amber-400 font-sans">
                      {lang === 'bn'
                        ? `· ${serverStorage.pendingUsersCount ?? pendingCount} পেন্ডিং (0 KB বরাদ্দ)`
                        : `· ${serverStorage.pendingUsersCount ?? pendingCount} pending (0 KB allocated)`}
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  {serverStorage.diskFreeMb !== null && (
                    <span className="text-slate-500 dark:text-slate-400">
                      {lang === 'bn' ? 'হোস্ট ডিস্ক:' : 'Host Disk:'} {formatStorageFromMb(serverStorage.diskFreeMb)} free
                    </span>
                  )}
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                    {lang === 'bn' ? 'ফ্রি পুল:' : 'Free Pool:'} {formatStorageFromMb(serverStorage.remainingAllocatableMb)} (~{serverStorage.estimatedRemainingUsers}{' '}
                    {lang === 'bn' ? 'জন' : 'users'})
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Clickable Summary Metrics Row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <button
              type="button"
              onClick={() => {
                selectTab('users');
                setStatusFilter('all');
              }}
              className="text-left p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 hover:border-cyan-400 dark:hover:border-cyan-500/50 shadow-sm transition group cursor-pointer"
            >
              <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono">
                {lang === 'bn' ? 'মোট ইউজার' : 'Total Users'}
              </span>
              <p className="text-xl font-bold text-slate-900 dark:text-white font-mono mt-0.5 group-hover:text-cyan-600 dark:group-hover:text-cyan-400 transition">
                {managedUsers.length}
              </p>
              <span className="text-[10px] text-cyan-600 dark:text-cyan-400">
                {managedUsers.filter((u) => u.status === 'approved').length}{' '}
                {lang === 'bn' ? 'অনুমোদিত' : 'Approved'} | {pendingCount}{' '}
                {lang === 'bn' ? 'পেন্ডিং' : 'Pending'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => selectTab('sites')}
              className="text-left p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 hover:border-emerald-400 dark:hover:border-emerald-500/50 shadow-sm transition group cursor-pointer"
            >
              <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono">
                {lang === 'bn' ? 'মোট ওয়েবসাইট' : 'Hosted Sites'}
              </span>
              <p className="text-xl font-bold text-slate-900 dark:text-white font-mono mt-0.5 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition">
                {allSites.length}
              </p>
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400">
                {allSites.filter((s) => s.status === 'online').length}{' '}
                {lang === 'bn' ? 'লাইভ অনলাইন' : 'Online Live'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => selectTab('sites')}
              className="text-left p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500/50 shadow-sm transition group cursor-pointer"
            >
              <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono">
                {lang === 'bn' ? 'প্রকৃত স্টোরেজ ব্যবহার' : 'Actual Storage Used'}
              </span>
              <p className="text-xl font-bold text-slate-900 dark:text-white font-mono mt-0.5 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition">
                {formatStorageFromMb(serverStorage.totalUsedMb)}
              </p>
              <span className="text-[10px] text-indigo-600 dark:text-indigo-400">
                {formatStorageFromMb(serverStorage.usedBySitesMb)} {lang === 'bn' ? 'সাইট' : 'sites'} + {formatStorageFromMb(serverStorage.usedByAvatarsMb)}{' '}
                {lang === 'bn' ? 'ছবি' : 'photos'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (isSuperAdmin) selectTab('subadmins');
              }}
              className={`text-left p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 shadow-sm transition group ${
                isSuperAdmin
                  ? 'hover:border-amber-400 dark:hover:border-amber-500/50 cursor-pointer'
                  : 'cursor-default'
              }`}
            >
              <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono">
                {lang === 'bn' ? 'সক্রিয় অ্যাডমিন' : 'Active Admins'}
              </span>
              <p className="text-xl font-bold text-slate-900 dark:text-white font-mono mt-0.5 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition">
                {subAdmins.length}
              </p>
              <span className="text-[10px] text-amber-600 dark:text-amber-400">
                {lang === 'bn' ? 'টেলিগ্রাম সাপোর্ট' : 'Telegram Support'}
              </span>
            </button>
          </div>

          {/* Pending Approvals Concise Card */}
          {pendingUsersPreview.length > 0 && (
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-500/30 shadow-sm space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-500" />
                  <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                    {lang === 'bn'
                      ? `নতুন অনুমোদনের অনুরোধ (${pendingCount})`
                      : `Pending Approval Requests (${pendingCount})`}
                  </h2>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setStatusFilter('pending');
                    selectTab('users');
                  }}
                  className="inline-flex items-center gap-1 text-xs font-bold text-cyan-600 dark:text-cyan-400 hover:underline"
                >
                  <span>{lang === 'bn' ? 'সকল পেন্ডিং দেখুন' : 'View All Pending'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {pendingUsersPreview.map((u) => (
                  <div
                    key={u.id}
                    className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2.5"
                  >
                    <div className="flex items-center justify-between gap-2 min-w-0">
                      <div className="min-w-0">
                        <div className="font-bold text-xs text-slate-900 dark:text-white truncate">
                          @{u.username}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {u.email}
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 text-[10px] font-bold shrink-0">
                        {lang === 'bn' ? 'পেন্ডিং' : 'Pending'}
                      </span>
                    </div>
                    {canApproveUsers && (
                      <div className="flex flex-wrap gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleQuickApprove(u, 1, '১ ঘন্টা (1 Hour)', '1 Hour')}
                          className="px-2 py-1 rounded-lg bg-cyan-50 dark:bg-cyan-950/70 border border-cyan-200 dark:border-cyan-500/30 text-cyan-700 dark:text-cyan-300 text-[11px] font-bold"
                        >
                          +1h
                        </button>
                        <button
                          type="button"
                          onClick={() => handleQuickApprove(u, 24, '২৪ ঘন্টা (1 Day)', '24 Hours')}
                          className="px-2 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/70 border border-indigo-200 dark:border-indigo-500/30 text-indigo-700 dark:text-indigo-300 text-[11px] font-bold"
                        >
                          +24h
                        </button>
                        <button
                          type="button"
                          onClick={() => openApprovalModal(u)}
                          className="flex-1 px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold text-center"
                        >
                          {lang === 'bn' ? 'মেয়াদ / কোটা' : 'Quota & Time'}
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick Sub-Page Cards (Open Separate Views) */}
          <div className="space-y-3">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 font-mono">
              {lang === 'bn' ? 'কনসোল মেনু (আলাদা পেজ ওপেন করুন)' : 'Console Sections (Open Dedicated Pages)'}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => selectTab('users')}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-rose-400 dark:hover:border-rose-500/50 text-left flex items-center justify-between gap-3 transition shadow-sm group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/80 border border-rose-200 dark:border-rose-500/30 flex items-center justify-center text-rose-600 dark:text-rose-400 shrink-0">
                    <Users className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                      <span>{lang === 'bn' ? 'ইউজার ও অনুমোদন' : 'User Approvals & Quotas'}</span>
                      {pendingCount > 0 && (
                        <span className="px-1.5 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-bold">
                          {pendingCount}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {lang === 'bn' ? 'সকল ইউজার তালিকা ও ইনস্পেক্টর' : 'Manage accounts, quotas & inspector'}
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-rose-500 shrink-0" />
              </button>

              {isSuperAdmin && (
                <button
                  type="button"
                  onClick={() => selectTab('subadmins')}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-400 dark:hover:border-amber-500/50 text-left flex items-center justify-between gap-3 transition shadow-sm group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/80 border border-amber-200 dark:border-amber-500/30 flex items-center justify-center text-amber-600 dark:text-amber-400 shrink-0">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="font-bold text-sm text-slate-900 dark:text-white">
                        {lang === 'bn' ? 'অ্যাডমিন ও টেলিগ্রাম' : 'Admins & Telegram'}
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {lang === 'bn' ? 'অ্যাডমিন যুক্ত ও পারমিশন কন্ট্রোল' : 'Add admins & manage permissions'}
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-amber-500 shrink-0" />
                </button>
              )}

              <button
                type="button"
                onClick={() => selectTab('sites')}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-400 dark:hover:border-emerald-500/50 text-left flex items-center justify-between gap-3 transition shadow-sm group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/80 border border-emerald-200 dark:border-emerald-500/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0">
                    <Layers className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-sm text-slate-900 dark:text-white">
                      {lang === 'bn' ? 'সকল হোস্টকৃত সাইট' : 'Global Hosted Sites'}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {lang === 'bn' ? `${allSites.length}টি সাইট প্রিভিউ ও .zip` : `${allSites.length} sites live & ZIP download`}
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-500 shrink-0" />
              </button>

              {canSendMessages && (
                <button
                  type="button"
                  onClick={() => selectTab('messages')}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-cyan-400 dark:hover:border-cyan-500/50 text-left flex items-center justify-between gap-3 transition shadow-sm group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-cyan-50 dark:bg-cyan-950/80 border border-cyan-200 dark:border-cyan-500/30 flex items-center justify-center text-cyan-600 dark:text-cyan-400 shrink-0">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="font-bold text-sm text-slate-900 dark:text-white">
                        {lang === 'bn' ? 'পপআপ মেসেজ' : 'Popup Messages'}
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {lang === 'bn' ? 'ইউজারদের পপআপ নোটিশ পাঠান' : 'Send broadcast or direct popups'}
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-cyan-500 shrink-0" />
                </button>
              )}

              <button
                type="button"
                onClick={() => selectTab('logs')}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500/50 text-left flex items-center justify-between gap-3 transition shadow-sm group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/80 border border-indigo-200 dark:border-indigo-500/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400 shrink-0">
                    <History className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-sm text-slate-900 dark:text-white">
                      {lang === 'bn' ? 'অডিট লগ' : 'Audit Logs'}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {lang === 'bn' ? `${auditLogs.length}টি সাম্প্রতিক লগ` : `${auditLogs.length} system log entries`}
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-500 shrink-0" />
              </button>

              {isSuperAdmin && (
                <button
                  type="button"
                  onClick={() => selectTab('settings')}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-purple-400 dark:hover:border-purple-500/50 text-left flex items-center justify-between gap-3 transition shadow-sm group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/80 border border-purple-200 dark:border-purple-500/30 flex items-center justify-center text-purple-600 dark:text-purple-400 shrink-0">
                      <Settings className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="font-bold text-sm text-slate-900 dark:text-white">
                        {lang === 'bn' ? 'প্ল্যাটফর্ম সেটিংস ও পুল' : 'Platform Settings & Pool'}
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {lang === 'bn' ? 'সার্ভার পুল, মালিক নাম ও ঘোষণা' : 'Server pool presets, branding & slug'}
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-purple-500 shrink-0" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tab 1: User Management — Clean Unified Responsive Cards */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-3">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full lg:w-auto">
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder={lang === 'bn' ? 'ইউজারনেম বা ইমেইল দিয়ে খুঁজুন...' : 'Search by username or email...'}
                  className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-semibold">
                {(
                  [
                    { id: 'all', bn: 'সব', en: 'All' },
                    { id: 'pending', bn: 'পেন্ডিং', en: 'Pending' },
                    { id: 'approved', bn: 'অনুমোদিত', en: 'Approved' },
                    { id: 'suspended', bn: 'সাসপেন্ড', en: 'Suspended' },
                    { id: 'expired', bn: 'মেয়াদোত্তীর্ণ', en: 'Expired' },
                  ] as { id: StatusFilter; bn: string; en: string }[]
                ).map((f) => (
                  <button
                    type="button"
                    key={f.id}
                    onClick={() => setStatusFilter(f.id)}
                    className={`px-3 py-1.5 rounded-lg border transition whitespace-nowrap ${
                      statusFilter === f.id
                        ? 'bg-rose-600 border-rose-600 text-white shadow-sm'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-400'
                    }`}
                  >
                    {lang === 'bn' ? f.bn : f.en}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto justify-end">
              {canApproveUsers && pendingCount > 0 && (
                <button
                  type="button"
                  disabled={approvingAllPending}
                  onClick={handleApproveAllPending}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-sm transition whitespace-nowrap disabled:opacity-60"
                >
                  {approvingAllPending ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <CheckCheck className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {lang === 'bn'
                      ? `সব পেন্ডিং অনুমোদন করুন (${pendingCount})`
                      : `Approve All Pending (${pendingCount})`}
                  </span>
                </button>
              )}

              {managedUsers.length > 0 && (
                <button
                  type="button"
                  onClick={handleExportUsersCsv}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold transition whitespace-nowrap"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                  <span>{lang === 'bn' ? 'CSV ডাউনলোড' : 'Export CSV'}</span>
                </button>
              )}
            </div>
          </div>

          {filteredUsers.length === 0 ? (
            <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-800 text-center text-xs text-slate-500 dark:text-slate-400">
              {lang === 'bn' ? 'কোনো ইউজার পাওয়া যায়নি।' : 'No matching users found.'}
            </div>
          ) : (
            <div className="space-y-3">
              {filteredUsers.map((u) => {
                const remaining = storage.getRemainingApprovalTime(u, lang);
                const userSitesCount = allSites.filter((s) => s.userId === u.id).length;
                const quotaPct = Math.min(100, Math.round((u.storageUsedMb / Math.max(1, u.storageLimitMb)) * 100));
                const isActiveApproved = u.status === 'approved' && !remaining.isExpired;
                const isPending = u.status === 'pending';

                const cardBorderClass = isActiveApproved
                  ? 'border-emerald-300/90 dark:border-emerald-500/40'
                  : isPending
                  ? 'border-amber-300/90 dark:border-amber-500/45'
                  : 'border-rose-300/90 dark:border-rose-500/40';

                const statusTextColor = isActiveApproved
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : isPending
                  ? 'text-amber-600 dark:text-amber-400'
                  : 'text-rose-600 dark:text-rose-400';

                const statusLabel = isActiveApproved
                  ? lang === 'bn'
                    ? 'অনুমোদিত'
                    : 'Approved'
                  : isPending
                  ? lang === 'bn'
                    ? 'অনুমোদন পেন্ডিং'
                    : 'Pending Approval'
                  : u.status === 'approved' && remaining.isExpired
                  ? lang === 'bn'
                    ? 'মেয়াদোত্তীর্ণ'
                    : 'Expired'
                  : lang === 'bn'
                  ? 'সাসপেন্ড'
                  : 'Suspended';

                return (
                  <div
                    key={u.id}
                    className={`p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border ${cardBorderClass} shadow-sm transition hover:shadow-md`}
                  >
                    <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
                      {/* Identity Block */}
                      <div className="flex items-center gap-3.5 min-w-0 xl:w-[32%]">
                        <button
                          type="button"
                          onClick={() => {
                            setInspectedUser(u);
                            setExpandedSiteId(null);
                            setInspectedFile(null);
                          }}
                          className="flex items-center gap-3.5 min-w-0 text-left group w-full"
                        >
                          {u.avatarDataUrl ? (
                            <img
                              src={u.avatarDataUrl}
                              alt={u.username}
                              referrerPolicy="no-referrer"
                              className="w-11 h-11 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                            />
                          ) : (
                            <div
                              className={`w-11 h-11 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 ${
                                u.role === 'subadmin'
                                  ? 'bg-amber-50 dark:bg-amber-950/70 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-500/30'
                                  : 'bg-cyan-50 dark:bg-cyan-950/70 text-cyan-700 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-500/30'
                              }`}
                            >
                              {u.username.charAt(0).toUpperCase()}
                            </div>
                          )}
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                              <span className="font-bold text-sm text-slate-900 dark:text-white group-hover:text-cyan-600 dark:group-hover:text-cyan-400 truncate">
                                @{u.username}
                              </span>
                              <span className="text-[10px] font-mono uppercase font-bold text-slate-500 dark:text-slate-400">
                                · {getRoleDisplayLabel(u.role, lang)}
                              </span>
                              <span className={`text-[10px] font-mono uppercase font-bold ${statusTextColor}`}>
                                · {statusLabel}
                              </span>
                            </div>
                            <div className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                              {u.fullName || 'User'} · {u.email}
                            </div>
                            <div className="text-[11px] text-slate-400 dark:text-slate-500 font-mono tabular-nums mt-0.5">
                              {lang === 'bn' ? `সাইট: ${userSitesCount}টি` : `Sites: ${userSitesCount}`} ·{' '}
                              {new Date(u.createdAt).toLocaleDateString()}
                            </div>
                          </div>
                        </button>
                      </div>

                      {/* Validity & Storage Telemetry Block */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 xl:w-[34%] p-3 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200/80 dark:border-slate-800/80 text-xs">
                        <div className="min-w-0 space-y-1">
                          <div className="text-[10px] text-slate-400 uppercase font-mono">
                            {lang === 'bn' ? 'অ্যাক্সেস ও মেয়াদ' : 'Access & Validity'}
                          </div>
                          <div className="flex items-center gap-1.5 font-mono font-semibold text-slate-700 dark:text-slate-200 tabular-nums">
                            <Clock className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400 shrink-0" />
                            <span className="truncate">
                              {isPending
                                ? lang === 'bn'
                                  ? 'অনুমোদনের অপেক্ষায়'
                                  : 'Awaiting Approval'
                                : u.status === 'suspended'
                                ? lang === 'bn'
                                  ? 'অ্যাক্সেস স্থগিত'
                                  : 'Access Suspended'
                                : remaining.label}
                            </span>
                          </div>
                          {isPending && (
                            <div className="text-[10px] text-amber-600 dark:text-amber-400 font-mono">
                              {lang === 'bn' ? 'পুল রিজার্ভ: 0 KB' : 'Pool Reserved: 0 KB'}
                            </div>
                          )}
                        </div>

                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-[10px] text-slate-400 uppercase font-mono tabular-nums">
                            <span>{lang === 'bn' ? 'স্টোরেজ কোটা' : 'Storage Quota'}</span>
                            <span className="text-cyan-600 dark:text-cyan-400 font-bold">{quotaPct}%</span>
                          </div>
                          <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-cyan-500 to-indigo-500 rounded-full"
                              style={{ width: `${quotaPct}%` }}
                            />
                          </div>
                          <div className="text-[11px] font-mono tabular-nums text-slate-600 dark:text-slate-300">
                            <strong className="text-cyan-700 dark:text-cyan-400">{formatStorageFromMb(u.storageUsedMb)}</strong> /{' '}
                            {isPending
                              ? `${formatStorageFromMb(u.storageLimitMb)} (default)`
                              : formatStorageFromMb(u.storageLimitMb)}
                          </div>
                        </div>
                      </div>

                      {/* Horizontal Action Controls */}
                      <div className="flex flex-wrap items-center xl:justify-end gap-1.5 shrink-0">
                        {canApproveUsers && u.role !== 'admin' && (
                          <>
                            <button
                              type="button"
                              onClick={() => handleQuickApprove(u, 1, '১ ঘন্টা (1 Hour)', '1 Hour')}
                              className="px-2.5 py-1.5 rounded-lg bg-cyan-50 dark:bg-cyan-950/60 hover:bg-cyan-100 dark:hover:bg-cyan-900 border border-cyan-200 dark:border-cyan-500/30 text-cyan-700 dark:text-cyan-300 text-xs font-bold whitespace-nowrap shrink-0"
                            >
                              +1h
                            </button>
                            <button
                              type="button"
                              onClick={() => handleQuickApprove(u, 24, '২৪ ঘন্টা (1 Day)', '24 Hours')}
                              className="px-2.5 py-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900 border border-indigo-200 dark:border-indigo-500/30 text-indigo-700 dark:text-indigo-300 text-xs font-bold whitespace-nowrap shrink-0"
                            >
                              +24h
                            </button>
                            <button
                              type="button"
                              onClick={() => openApprovalModal(u)}
                              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold whitespace-nowrap shrink-0 shadow-sm"
                            >
                              {lang === 'bn' ? 'মেয়াদ ও কোটা' : 'Quota & Time'}
                            </button>
                          </>
                        )}

                        <button
                          type="button"
                          onClick={() => {
                            setInspectedUser(u);
                            setExpandedSiteId(null);
                            setInspectedFile(null);
                          }}
                          aria-label={`Inspect user ${u.username}`}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-cyan-50 dark:hover:bg-cyan-950/60 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold whitespace-nowrap shrink-0 transition"
                          title={lang === 'bn' ? 'ইনস্পেক্ট করুন' : 'Inspect User'}
                        >
                          <Eye className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                          <span>{lang === 'bn' ? 'ইনস্পেক্ট' : 'Inspect'}</span>
                        </button>

                        {canSendMessages && (
                          <button
                            type="button"
                            onClick={() => openQuickMessageModal(u.id)}
                            aria-label={`Message user ${u.username}`}
                            className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900 border border-indigo-200 dark:border-indigo-500/30 text-indigo-700 dark:text-indigo-300 transition shrink-0"
                            title={lang === 'bn' ? 'পপআপ মেসেজ পাঠান' : 'Send Popup Notice'}
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => openEditUserModal(u)}
                          aria-label={`Edit user ${u.username}`}
                          className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition shrink-0"
                          title={lang === 'bn' ? 'এডিট করুন' : 'Edit User'}
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>

                        {canApproveUsers && u.status === 'approved' && u.role !== 'admin' && (
                          <button
                            type="button"
                            onClick={() => handleSuspendUser(u.id, u.username)}
                            className="px-2.5 py-1.5 rounded-lg bg-amber-50 dark:bg-slate-800 hover:bg-amber-100 dark:hover:bg-slate-700 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-slate-700 text-xs font-semibold whitespace-nowrap shrink-0"
                          >
                            {lang === 'bn' ? 'সাসপেন্ড' : 'Suspend'}
                          </button>
                        )}

                        {canApproveUsers && u.status === 'suspended' && u.role !== 'admin' && (
                          <button
                            type="button"
                            disabled={busyActionId === `unsuspend_${u.id}`}
                            onClick={() => handleUnsuspendUser(u.id, u.username)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold whitespace-nowrap shrink-0 disabled:opacity-60"
                          >
                            {busyActionId === `unsuspend_${u.id}` && (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            )}
                            <span>{lang === 'bn' ? 'আনসাসপেন্ড' : 'Unsuspend'}</span>
                          </button>
                        )}

                        {isSuperAdmin && u.role !== 'admin' && (
                          <button
                            type="button"
                            onClick={() =>
                              setConfirmAction({
                                type: 'user',
                                id: u.id,
                                title:
                                  lang === 'bn'
                                    ? `ইউজার '@${u.username}' ডিলিট করুন`
                                    : `Delete User '@${u.username}'`,
                                description:
                                  lang === 'bn'
                                    ? `ইউজার '${u.username}' এবং তার সব হোস্টকৃত সাইট সম্পূর্ণভাবে মুছে যাবে ও ইউজারনেমটি খালি হয়ে যাবে।`
                                    : `User '${u.username}' and all of their hosted sites will be permanently deleted.`,
                              })
                            }
                            aria-label={`Delete user ${u.username}`}
                            className="p-2 rounded-lg bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 dark:hover:bg-rose-900 border border-rose-200 dark:border-rose-500/40 text-rose-600 dark:text-rose-300 transition shrink-0"
                            title={lang === 'bn' ? 'সম্পূর্ণ অ্যাকাউন্ট ডিলিট করুন' : 'Delete Account'}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Admin Management */}
      {activeTab === 'subadmins' && isSuperAdmin && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-rose-500" />
                <span>
                  {lang === 'bn'
                    ? 'নতুন অ্যাডমিন যোগ করুন (টেলিগ্রাম সংযোগ সহ)'
                    : 'Add New Admin (with Telegram Contact)'}
                </span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAdminHelpModal(true)}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 dark:hover:bg-amber-900 border border-amber-200 dark:border-amber-500/40 text-amber-700 dark:text-amber-300 text-[11px] font-bold transition whitespace-nowrap"
              >
                <Info className="w-3.5 h-3.5" />
                <span>{lang === 'bn' ? 'অ্যাডমিন নিয়ম ও পারমিশন গাইড' : 'Admin RBAC Guide'}</span>
              </button>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {lang === 'bn'
                ? 'অ্যাডমিন যোগ করলে ইউজারদের পেন্ডিং স্ক্রিনে তাদের টেলিগ্রাম লিঙ্ক দেখাবে। অ্যাডমিনদের জন্য শেয়ার্ড ইউজার পুল থেকে কোনো কোটা কাটা হয় না।'
                : 'Active Admins appear in the pending approval Telegram contact list for users. Admin accounts do not reserve quota from the User Storage Pool.'}
            </p>

            {subMsg && (
              <div
                className={`p-3 rounded-xl text-xs border ${
                  subMsg.error
                    ? 'bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-500'
                    : 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-500'
                }`}
              >
                {subMsg.text}
              </div>
            )}

            <form onSubmit={handleCreateSubAdmin} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
              <input
                type="text"
                value={newSubUsername}
                onChange={(e) => setNewSubUsername(e.target.value)}
                placeholder={lang === 'bn' ? 'ইউজারনেম (e.g. riad)' : 'Username (e.g. riad)'}
                className="px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none"
                required
              />
              <input
                type="text"
                value={newSubDisplayName}
                onChange={(e) => setNewSubDisplayName(e.target.value)}
                placeholder={lang === 'bn' ? 'ডিসপ্লে নাম' : 'Display Name'}
                className="px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none"
              />
              <input
                type="email"
                value={newSubEmail}
                onChange={(e) => setNewSubEmail(e.target.value)}
                placeholder={lang === 'bn' ? 'ইমেইল' : 'Email'}
                className="px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none"
                required
              />
              <input
                type="text"
                value={newSubTelegram}
                onChange={(e) => setNewSubTelegram(e.target.value)}
                placeholder={lang === 'bn' ? 'টেলিগ্রাম (@username)' : 'Telegram (@username)'}
                className="px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none font-mono"
                required
              />
              <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2">
                <input
                  type={showNewSubPass ? 'text' : 'password'}
                  value={newSubPassword}
                  onChange={(e) => setNewSubPassword(e.target.value)}
                  placeholder={lang === 'bn' ? 'পাসওয়ার্ড (কমপক্ষে ৪ অক্ষর)' : 'Password (min 4 chars)'}
                  minLength={4}
                  required
                  className="w-full bg-transparent text-xs text-slate-900 dark:text-white focus:outline-none font-mono min-w-0"
                />
                <button
                  type="button"
                  onClick={() => setShowNewSubPass(!showNewSubPass)}
                  aria-label={showNewSubPass ? (lang === 'bn' ? 'পাসওয়ার্ড লুকান' : 'Hide password') : (lang === 'bn' ? 'পাসওয়ার্ড দেখুন' : 'Show password')}
                  className="ml-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition shrink-0"
                >
                  {showNewSubPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
              <button
                type="submit"
                disabled={creatingSubAdmin}
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-sm transition disabled:opacity-60"
              >
                {creatingSubAdmin && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>{lang === 'bn' ? 'অ্যাডমিন যুক্ত করুন' : 'Add Admin'}</span>
              </button>
            </form>
          </div>

          {subAdmins.length === 0 ? (
            <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-800 text-center text-xs text-slate-500 dark:text-slate-400">
              {lang === 'bn'
                ? `বর্তমানে কোনো অ্যাডমিন যুক্ত নেই। পেন্ডিং ইউজাররা শুধুমাত্র মালিক (${config.masterAdminName}) এর টেলিগ্রাম দেখতে পাবেন।`
                : `No Admins added yet. Pending users will only see the Owner (${config.masterAdminName}) Telegram contact.`}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {subAdmins.map((sub) => (
                <div
                  key={sub.id}
                  className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                        {sub.displayName || sub.username}
                      </h4>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">@{sub.username}</span>
                    </div>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded font-mono border ${
                        sub.active
                          ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-500/30'
                          : 'bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-400 border-rose-200 dark:border-rose-500/30'
                      }`}
                    >
                      {sub.active ? 'ACTIVE' : 'DISABLED'}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 dark:text-slate-400">
                        {lang === 'bn' ? 'টেলিগ্রাম:' : 'Telegram:'}
                      </span>
                      <a
                        href={sub.telegramUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-cyan-600 dark:text-cyan-400 hover:underline flex items-center gap-1 font-mono font-bold"
                      >
                        <Send className="w-3 h-3" />
                        <span>{sub.telegramUsername}</span>
                      </a>
                    </div>

                    <label className="flex items-center justify-between text-[11px] text-slate-600 dark:text-slate-300 cursor-pointer">
                      <span>{lang === 'bn' ? 'ইউজার অনুমোদন পারমিশন:' : 'Approve Users Permission:'}</span>
                      <input
                        type="checkbox"
                        checked={sub.canApproveUsers}
                        onChange={(e) =>
                          storage.updateSubAdminPermissions(sub.id, { canApproveUsers: e.target.checked })
                        }
                        className="rounded text-cyan-600"
                      />
                    </label>

                    <label className="flex items-center justify-between text-[11px] text-slate-600 dark:text-slate-300 cursor-pointer">
                      <span>{lang === 'bn' ? 'কোটা নির্ধারণ পারমিশন:' : 'Set Quota Permission:'}</span>
                      <input
                        type="checkbox"
                        checked={sub.canSetQuota}
                        onChange={(e) =>
                          storage.updateSubAdminPermissions(sub.id, { canSetQuota: e.target.checked })
                        }
                        className="rounded text-cyan-600"
                      />
                    </label>

                    <label className="flex items-center justify-between text-[11px] text-slate-600 dark:text-slate-300 cursor-pointer">
                      <span>{lang === 'bn' ? 'পপআপ মেসেজ পারমিশন:' : 'Popup Message Permission:'}</span>
                      <input
                        type="checkbox"
                        checked={sub.canSendMessages !== false}
                        onChange={(e) =>
                          storage.updateSubAdminPermissions(sub.id, { canSendMessages: e.target.checked })
                        }
                        className="rounded text-cyan-600"
                      />
                    </label>

                    <label className="flex items-center justify-between text-[11px] text-slate-600 dark:text-slate-300 cursor-pointer">
                      <span>{lang === 'bn' ? 'সোর্স (.zip) ডাউনলোড:' : 'Download Source (.zip):'}</span>
                      <input
                        type="checkbox"
                        checked={Boolean(sub.canDownloadSource)}
                        onChange={(e) =>
                          storage.updateSubAdminPermissions(sub.id, { canDownloadSource: e.target.checked })
                        }
                        className="rounded text-cyan-600"
                      />
                    </label>

                    <label className="flex items-center justify-between text-[11px] text-slate-600 dark:text-slate-300 cursor-pointer">
                      <span>{lang === 'bn' ? 'সব ইউজারের সাইট নিয়ন্ত্রণ:' : 'Manage All User Sites:'}</span>
                      <input
                        type="checkbox"
                        checked={Boolean(sub.canManageAllSites)}
                        onChange={(e) =>
                          storage.updateSubAdminPermissions(sub.id, { canManageAllSites: e.target.checked })
                        }
                        className="rounded text-cyan-600"
                      />
                    </label>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => storage.toggleSubAdminStatus(sub.id)}
                      className="flex-1 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs text-slate-700 dark:text-slate-300 font-medium"
                    >
                      {sub.active
                        ? lang === 'bn'
                          ? 'অ্যাক্সেস বন্ধ করুন'
                          : 'Disable Access'
                        : lang === 'bn'
                        ? 'অ্যাক্সেস চালু করুন'
                        : 'Enable Access'}
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setConfirmAction({
                          type: 'subadmin',
                          id: sub.id,
                          title:
                            lang === 'bn'
                              ? `অ্যাডমিন '@${sub.username}' মুছে ফেলুন`
                              : `Remove Admin '@${sub.username}'`,
                          description:
                            lang === 'bn'
                              ? `অ্যাডমিন '${sub.username}' কে সম্পূর্ণভাবে রিমুভ করা হবে এবং ইউজারদের টেলিগ্রাম সাপোর্ট তালিকা থেকেও সরে যাবে।`
                              : `Admin '${sub.username}' will be permanently deleted and removed from support contacts.`,
                        })
                      }
                      aria-label={`Remove subadmin ${sub.username}`}
                      className="p-1.5 rounded-lg border border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 hover:bg-rose-100"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Admin Activity Reports (Owner Governance Telemetry) */}
          {adminReports.length > 0 && (
            <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-indigo-500" />
                    <span>
                      {lang === 'bn'
                        ? `অ্যাডমিন অ্যাক্টিভিটি রিপোর্ট (${adminReports.length})`
                        : `Admin Activity Reports (${adminReports.length})`}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {lang === 'bn'
                      ? 'কোন অ্যাডমিন কয়জন ইউজার অনুমোদন দিয়েছেন, কতটি মেসেজ পাঠিয়েছেন ও কী কী কাজ করেছেন তার লাইভ হিসাব।'
                      : 'Live tracking of users approved, messages sent, and total actions performed by each Admin.'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {adminReports.map((rep) => (
                  <div
                    key={rep.adminId}
                    className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3 text-xs"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <div className="font-bold text-slate-900 dark:text-white truncate">
                          {rep.displayName || rep.username}
                        </div>
                        <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                          @{rep.username}
                        </div>
                      </div>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                          rep.active
                            ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-200 dark:border-emerald-500/30 text-emerald-700 dark:text-emerald-400'
                            : 'bg-rose-50 dark:bg-rose-950 border-rose-200 dark:border-rose-500/30 text-rose-700 dark:text-rose-400'
                        }`}
                      >
                        {rep.active ? 'ACTIVE' : 'DISABLED'}
                      </span>
                    </div>

                    <div className="grid grid-cols-4 gap-2 text-center font-mono tabular-nums">
                      <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                        <div className="text-[10px] text-slate-400">{lang === 'bn' ? 'অ্যাপ্রুভ' : 'Approved'}</div>
                        <div className="font-bold text-emerald-600 dark:text-emerald-400 text-sm">{rep.approvedUsersCount}</div>
                      </div>
                      <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                        <div className="text-[10px] text-slate-400">{lang === 'bn' ? 'অ্যাকশন' : 'Actions'}</div>
                        <div className="font-bold text-cyan-600 dark:text-cyan-400 text-sm">{rep.actionsCount}</div>
                      </div>
                      <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                        <div className="text-[10px] text-slate-400">{lang === 'bn' ? 'মেসেজ' : 'Msgs'}</div>
                        <div className="font-bold text-indigo-600 dark:text-indigo-400 text-sm">{rep.messagesSentCount}</div>
                      </div>
                      <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                        <div className="text-[10px] text-slate-400">{lang === 'bn' ? 'সাইট' : 'Sites'}</div>
                        <div className="font-bold text-slate-800 dark:text-slate-200 text-sm">{rep.sitesCount}</div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                      <div className="truncate">
                        {rep.approvedUsernames.length > 0 ? (
                          <span>
                            {lang === 'bn' ? 'অনুমোদিত:' : 'Approved:'}{' '}
                            <span className="font-mono text-slate-700 dark:text-slate-200">
                              {rep.approvedUsernames.slice(0, 4).map((u) => `@${u}`).join(', ')}
                              {rep.approvedUsernames.length > 4 ? ` +${rep.approvedUsernames.length - 4}` : ''}
                            </span>
                          </span>
                        ) : (
                          <span>{lang === 'bn' ? 'এখনো কাউকে অনুমোদন দেননি' : 'No users approved yet'}</span>
                        )}
                      </div>
                      <span className="font-mono text-[10px] shrink-0">
                        {rep.lastActionAt
                          ? `${lang === 'bn' ? 'শেষ কাজ:' : 'Last:'} ${new Date(rep.lastActionAt).toLocaleDateString()}`
                          : lang === 'bn'
                          ? 'কোনো কাজ নেই'
                          : 'No activity'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Global Sites */}
      {activeTab === 'sites' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={siteSearch}
                onChange={(e) => setSiteSearch(e.target.value)}
                placeholder={lang === 'bn' ? 'সাইট, স্লাগ বা ইউজার খুঁজুন...' : 'Search site, slug, or owner...'}
                className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none"
              />
            </div>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {lang === 'bn' ? `মোট ${filteredSites.length}টি সাইট` : `${filteredSites.length} Total Sites`}
            </span>
          </div>

          {filteredSites.length === 0 ? (
            <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-800 text-center text-xs text-slate-500 dark:text-slate-400">
              {lang === 'bn' ? 'এখনও কোনো ওয়েবসাইট হোস্ট করা হয়নি।' : 'No websites hosted yet.'}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredSites.map((site) => {
                const ownerSub = site.ownerSubdomain || users.find((u) => u.id === site.userId)?.subdomain;
                const siteLivePath = ownerSub ? `/u/${ownerSub}/${site.slug}` : `/site/${site.slug}`;
                const allowDownload = canDownloadSource || site.userId === currentUser.id;
                const allowSiteControl = canManageAllSites || site.userId === currentUser.id;

                return (
                  <div
                    key={site.id}
                    className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 flex flex-col justify-between shadow-sm"
                  >
                    <div>
                      <div className="flex items-center justify-between text-[11px] mb-1">
                        <span className="font-mono text-cyan-700 dark:text-cyan-400">@{site.username}</span>
                        <span
                          className={`font-mono font-semibold ${
                            site.status === 'online'
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-amber-600 dark:text-amber-400'
                          }`}
                        >
                          ● {(site.status || 'online').toUpperCase()}
                        </span>
                      </div>
                      <h3 className="font-bold text-slate-900 dark:text-white text-sm">{site.name}</h3>
                      <a
                        href={siteLivePath}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-cyan-600 dark:text-cyan-400 hover:underline font-mono break-all"
                      >
                        {siteLivePath}
                      </a>
                    </div>

                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-2.5">
                        <button
                          type="button"
                          onClick={() => setPreviewSite(site)}
                          className="text-cyan-600 dark:text-cyan-400 hover:underline flex items-center gap-1 font-medium"
                        >
                          <span>{lang === 'bn' ? 'ইনস্পেক্ট করুন' : 'Inspect'}</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </button>

                        {allowDownload && (
                          <a
                            href={`/api/admin/sites/${encodeURIComponent(site.id)}/download.zip`}
                            download
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-semibold border border-slate-200 dark:border-slate-700 transition"
                            title={lang === 'bn' ? 'সম্পূর্ণ সাইট ZIP ডাউনলোড' : 'Download Site ZIP'}
                          >
                            <Download className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                            <span>.zip</span>
                          </a>
                        )}
                      </div>

                      {allowSiteControl && (
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            disabled={busyActionId === `toggle_${site.id}`}
                            onClick={() => {
                              setBusyActionId(`toggle_${site.id}`);
                              try {
                                storage.toggleSiteStatus(site.id);
                                showNotice(
                                  lang === 'bn'
                                    ? `সাইট '${site.name}' স্ট্যাটাস পরিবর্তন হয়েছে।`
                                    : `Updated status for '${site.name}'.`
                                );
                              } finally {
                                setBusyActionId(null);
                              }
                            }}
                            className="p-1 text-slate-500 hover:text-amber-500 disabled:opacity-50"
                            title={
                              site.status === 'online'
                                ? lang === 'bn'
                                  ? 'পজ করুন'
                                  : 'Pause Site'
                                : lang === 'bn'
                                ? 'অনলাইন করুন'
                                : 'Resume Site'
                            }
                          >
                            {busyActionId === `toggle_${site.id}` ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : site.status === 'online' ? (
                              <PauseCircle className="w-4 h-4" />
                            ) : (
                              <PlayCircle className="w-4 h-4" />
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setConfirmAction({
                                type: 'site',
                                id: site.id,
                                title:
                                  lang === 'bn'
                                    ? `সাইট '${site.name}' মুছে ফেলুন`
                                    : `Delete Site '${site.name}'`,
                                description:
                                  lang === 'bn'
                                    ? `অ্যাডমিন হিসেবে ${siteLivePath} সাইটটি স্থায়ীভাবে মুছে ফেলা হবে।`
                                    : `Site ${siteLivePath} will be permanently deleted.`,
                              })
                            }
                            aria-label={`Delete site ${site.name}`}
                            className="p-1 text-slate-500 hover:text-rose-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Tab 3.5: Popup Messages (One-Time User Notifications) */}
      {activeTab === 'messages' && canSendMessages && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 space-y-4 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <BellRing className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                <span>{lang === 'bn' ? 'নতুন পপআপ মেসেজ পাঠান' : 'Send One-Time Popup Notice'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowLinkHelpModal(true)}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-50 dark:bg-cyan-950/70 hover:bg-cyan-100 dark:hover:bg-cyan-900 border border-cyan-200 dark:border-cyan-500/40 text-cyan-700 dark:text-cyan-300 text-[11px] font-bold transition"
              >
                <Info className="w-3.5 h-3.5" />
                <span>{lang === 'bn' ? 'Marked / Unmarked লিংক কী?' : 'Link Styles?'}</span>
              </button>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {lang === 'bn'
                ? 'এই মেসেজ ইউজারের স্ক্রিনের মাঝখানে পপআপ হিসেবে দেখাবে। চাইলে সাথে ক্লিকেবল লিংকও (Marked বাটন বা Unmarked টেক্সট লিংক) যোগ করতে পারবেন।'
                : 'Appears centered on the target user screen. Optionally attach a Marked button link or an Unmarked inline hyperlink.'}
            </p>

            {msgFormError && (
              <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300 text-xs">
                {msgFormError}
              </div>
            )}

            <form onSubmit={handleSendPopupMessage} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'প্রাপক নির্বাচন করুন' : 'Select Target Recipient'}
                </label>
                <select
                  value={msgTargetId}
                  onChange={(e) => setMsgTargetId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500"
                >
                  <option value="all">
                    {lang === 'bn' ? 'সকল ইউজার (Broadcast All Users)' : 'All Users (Broadcast)'}
                  </option>
                  {managedUsers.map((u) => (
                    <option key={u.id} value={u.id}>
                      @{u.username} ({u.fullName || u.email})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'শিরোনাম (Title)' : 'Title'}
                </label>
                <input
                  type="text"
                  value={msgTitle}
                  onChange={(e) => setMsgTitle(e.target.value)}
                  placeholder={lang === 'bn' ? 'যেমন: সার্ভার মেইনটেন্যান্স নোটিশ' : 'e.g. Important Account Notice'}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'বার্তা (Message Body)' : 'Message Body'}
                </label>
                <textarea
                  rows={3}
                  value={msgBody}
                  onChange={(e) => setMsgBody(e.target.value)}
                  placeholder={
                    lang === 'bn'
                      ? 'আপনার বিস্তারিত বার্তা লিখুন...'
                      : 'Write the popup notice message...'
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500 resize-none"
                  required
                />
              </div>

              {/* Optional Marked / Unmarked Link */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                    <Link2 className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                    <span>{lang === 'bn' ? 'লিংক সংযুক্ত করুন (ঐচ্ছিক)' : 'Attach Link (Optional)'}</span>
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <input
                    type="text"
                    value={msgLinkUrl}
                    onChange={(e) => setMsgLinkUrl(e.target.value)}
                    placeholder="https://t.me/NightHex_X"
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white font-mono text-[11px] focus:outline-none focus:border-cyan-500"
                  />
                  <input
                    type="text"
                    value={msgLinkText}
                    onChange={(e) => setMsgLinkText(e.target.value)}
                    placeholder={lang === 'bn' ? 'লিংকের লেখা (যেমন: চ্যানেল জয়েন)' : 'Button / Link label (optional)'}
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white text-[11px] focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2 pt-0.5">
                  <button
                    type="button"
                    onClick={() => setMsgLinkMarked(true)}
                    className={`px-3 py-2 rounded-xl border text-[11px] font-bold transition text-left ${
                      msgLinkMarked
                        ? 'bg-cyan-50 dark:bg-cyan-950/70 border-cyan-500 text-cyan-700 dark:text-cyan-300'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {lang === 'bn' ? 'Marked (হাইলাইট বাটন)' : 'Marked (CTA Button)'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setMsgLinkMarked(false)}
                    className={`px-3 py-2 rounded-xl border text-[11px] font-bold transition text-left ${
                      !msgLinkMarked
                        ? 'bg-indigo-50 dark:bg-indigo-950/70 border-indigo-500 text-indigo-700 dark:text-indigo-300'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {lang === 'bn' ? 'Unmarked (টেক্সট লিংক)' : 'Unmarked (Text Link)'}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={sendingMsg}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-sm transition disabled:opacity-60"
              >
                {sendingMsg ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                <span>{lang === 'bn' ? 'পপআপ মেসেজ পাঠান' : 'Send Popup Message'}</span>
              </button>
            </form>
          </div>

          <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 space-y-4 shadow-sm">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center justify-between">
              <span className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-indigo-500" />
                <span>{lang === 'bn' ? `প্রেরিত পপআপসমূহ (${popupMessages.length})` : `Sent Popups (${popupMessages.length})`}</span>
              </span>
            </h3>

            {popupMessages.length === 0 ? (
              <div className="p-8 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-dashed border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500 dark:text-slate-400">
                {lang === 'bn' ? 'এখনও কোনো পপআপ মেসেজ পাঠানো হয়নি।' : 'No popup notices sent yet.'}
              </div>
            ) : (
              <div className="space-y-2.5 max-h-96 overflow-y-auto">
                {popupMessages.map((pm) => {
                  const targetUserObj = pm.targetUserId === 'all' ? null : users.find((u) => u.id === pm.targetUserId);
                  const safeUrl = pm.linkUrl ? sanitizeExternalLinkUrl(pm.linkUrl) : '';
                  return (
                    <div
                      key={pm.id}
                      className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1.5 text-xs"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-1.5 mb-1">
                            <span className="inline-block px-2 py-0.5 rounded bg-cyan-50 dark:bg-cyan-950 border border-cyan-200 dark:border-cyan-500/30 text-[10px] font-mono font-bold text-cyan-700 dark:text-cyan-300">
                              {pm.targetUserId === 'all'
                                ? lang === 'bn'
                                  ? 'সকল ইউজার'
                                  : 'ALL USERS'
                                : `@${targetUserObj?.username || pm.targetUserId}`}
                            </span>
                            {safeUrl && (
                              <span
                                className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                                  pm.linkMarked !== false
                                    ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-200 dark:border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
                                    : 'bg-indigo-50 dark:bg-indigo-950 border-indigo-200 dark:border-indigo-500/30 text-indigo-700 dark:text-indigo-300'
                                }`}
                              >
                                {pm.linkMarked !== false ? 'Marked CTA' : 'Unmarked Link'}
                              </span>
                            )}
                          </div>
                          <h4 className="font-bold text-slate-900 dark:text-white truncate">{pm.title}</h4>
                        </div>
                        <button
                          type="button"
                          aria-label={`Delete popup message ${pm.title}`}
                          onClick={() => storage.deletePopupMessageAsync(pm.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition shrink-0"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 whitespace-pre-wrap break-words">
                        {pm.message}
                      </p>
                      {safeUrl && (
                        <a
                          href={safeUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-[11px] font-semibold text-cyan-600 dark:text-cyan-400 hover:underline break-all"
                        >
                          <ExternalLink className="w-3 h-3 shrink-0" />
                          <span>{pm.linkText || safeUrl}</span>
                        </a>
                      )}
                      <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono pt-1">
                        <span>by @{pm.senderUsername}</span>
                        <span>
                          {lang === 'bn' ? 'দেখেছেন:' : 'Dismissed:'} {(pm.dismissedByUserIds || []).length}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 4: Audit Logs */}
      {activeTab === 'logs' && (
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <History className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
              <span>
                {lang === 'bn'
                  ? `অ্যাক্টিভিটি ও অডিট লগ (${auditLogs.length})`
                  : `Activity & Audit Logs (${auditLogs.length})`}
              </span>
            </h3>
            <div className="flex items-center gap-2">
              {auditLogs.length > 0 && (
                <button
                  type="button"
                  onClick={handleExportAuditLogsJson}
                  className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 transition"
                >
                  <FileJson className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                  <span>{lang === 'bn' ? 'JSON ডাউনলোড' : 'Export JSON'}</span>
                </button>
              )}
              {isSuperAdmin && auditLogs.length > 0 && (
                <button
                  type="button"
                  onClick={() => storage.clearAuditLogs()}
                  className="px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs text-slate-600 dark:text-slate-300 hover:text-rose-600"
                >
                  {lang === 'bn' ? 'লগ পরিষ্কার করুন' : 'Clear Logs'}
                </button>
              )}
            </div>
          </div>

          {auditLogs.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-slate-400 py-6 text-center">
              {lang === 'bn' ? 'কোনো অডিট লগ নেই।' : 'No audit logs recorded.'}
            </p>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto overflow-x-hidden font-mono text-xs">
              {auditLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 min-w-0"
                >
                  <div className="flex items-start sm:items-center gap-2 flex-wrap min-w-0">
                    <span className="px-2 py-0.5 rounded bg-cyan-50 dark:bg-cyan-950 text-cyan-700 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-500/30 text-[10px] font-bold shrink-0">
                      {log.action}
                    </span>
                    <span className="font-bold text-slate-900 dark:text-white break-all">{log.target}</span>
                    <span className="text-slate-600 dark:text-slate-400 font-sans text-xs break-words min-w-0">— {log.details}</span>
                  </div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-400 flex-shrink-0">
                    by @{log.actor} • {new Date(log.timestamp).toLocaleTimeString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 5: Platform & Broadcast Settings */}
      {activeTab === 'settings' && isSuperAdmin && (
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Settings className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                <span>
                  {lang === 'bn'
                    ? 'প্ল্যাটফর্ম কাস্টমাইজেশন, গোপন লিংক ও ব্রডকাস্ট'
                    : 'Platform Customization, Secret URL & Broadcast'}
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {lang === 'bn'
                  ? 'এখানে পরিবর্তন করলে সাথে সাথেই পুরো ওয়েবসাইটে লাইভ আপডেট হবে।'
                  : 'Changes saved here propagate instantly across all open client tabs in real time.'}
              </p>
            </div>
            {settingsSaved && (
              <span className="px-3 py-1 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-500/40 text-xs font-bold">
                {lang === 'bn' ? '✓ সংরক্ষিত!' : '✓ Saved!'}
              </span>
            )}
          </div>

          <form onSubmit={handleSavePlatformSettings} className="space-y-4 max-w-2xl">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'ওয়েবসাইটের নাম (Brand Name)' : 'Platform Brand Name'}
                </label>
                <input
                  type="text"
                  value={editBrandName}
                  onChange={(e) => {
                    settingsDirtyRef.current = true;
                    setEditBrandName(e.target.value);
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500 font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'মালিকের প্রদর্শিত নাম (Owner Name)' : 'Owner Display Name'}
                </label>
                <input
                  type="text"
                  value={editAdminName}
                  onChange={(e) => {
                    settingsDirtyRef.current = true;
                    setEditAdminName(e.target.value);
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'টেলিগ্রাম ইউজারনেম হ্যান্ডেল' : 'Telegram Handle'}
                </label>
                <input
                  type="text"
                  value={editAdminTgHandle}
                  onChange={(e) => {
                    settingsDirtyRef.current = true;
                    setEditAdminTgHandle(e.target.value);
                  }}
                  placeholder="@NightHex_X"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'টেলিগ্রাম ফুল লিঙ্ক' : 'Full Telegram URL'}
                </label>
                <input
                  type="text"
                  value={editAdminTg}
                  onChange={(e) => {
                    settingsDirtyRef.current = true;
                    setEditAdminTg(e.target.value);
                  }}
                  placeholder="https://t.me/NightHex_X"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn'
                    ? `গোপন অ্যাডমিন প্যানেল স্লাগ (/${editSecretSlug || 'admin'})`
                    : `Secret Admin Path (/${editSecretSlug || 'admin'})`}
                </label>
                <input
                  type="text"
                  value={editSecretSlug}
                  onChange={(e) => {
                    settingsDirtyRef.current = true;
                    setEditSecretSlug(e.target.value);
                  }}
                  placeholder="admin"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-cyan-700 dark:text-cyan-400 focus:outline-none font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'নতুন ইউজারের ডিফল্ট স্টোরেজ কোটা (MB)' : 'Default User Storage Quota (MB)'}
                </label>
                <input
                  type="number"
                  min="10"
                  max="5000"
                  value={editDefaultQuota}
                  onChange={(e) => {
                    settingsDirtyRef.current = true;
                    setEditDefaultQuota(Number(e.target.value));
                  }}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none font-mono"
                />
              </div>
            </div>

            {/* Wildcard Domain & Cloudflare Worker Setup */}
            <div className="p-4 rounded-2xl bg-cyan-50/60 dark:bg-cyan-950/30 border border-cyan-200 dark:border-cyan-500/30 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                    <Globe className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                    <span>{lang === 'bn' ? 'প্রাইমারি ওয়াইল্ডকার্ড ডোমেইন (Wildcard Domain)' : 'Primary Wildcard Domain'}</span>
                  </label>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    {lang === 'bn'
                      ? 'প্রতিটি ইউজারের সাইট <username>.yourdomain.com লিংকে চালানোর জন্য।'
                      : 'Routes each user automatically to <username>.yourdomain.com.'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleOpenCfWorkerModal}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold shadow-sm transition whitespace-nowrap"
                >
                  <Cloud className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? '☁️ Cloudflare Worker ও Wildcard সেটআপ' : '☁️ Cloudflare Worker & Wildcard Setup'}</span>
                </button>
              </div>
              <input
                type="text"
                value={editPrimaryDomain}
                onChange={(e) => {
                  settingsDirtyRef.current = true;
                  setEditPrimaryDomain(e.target.value);
                }}
                placeholder="nighthostcloud.dpdns.org"
                className="w-full px-3.5 py-2 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-cyan-700 dark:text-cyan-400 focus:outline-none focus:border-cyan-500 font-mono font-bold"
              />
            </div>

            <div className="pt-1">
              <label className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 cursor-pointer">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  {lang === 'bn' ? 'নতুন ইউজার রেজিস্ট্রেশন চালু রাখুন' : 'Allow New User Registrations'}
                </span>
                <input
                  type="checkbox"
                  checked={editAllowRegistration}
                  onChange={(e) => {
                    settingsDirtyRef.current = true;
                    setEditAllowRegistration(e.target.checked);
                  }}
                  className="rounded text-cyan-600"
                />
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'হিরো সাব-টাইটেল (ঐচ্ছিক)' : 'Landing Hero Subtitle (Optional)'}
                </label>
                <input
                  type="text"
                  value={editHeroSubtitle}
                  onChange={(e) => {
                    settingsDirtyRef.current = true;
                    setEditHeroSubtitle(e.target.value);
                  }}
                  placeholder={lang === 'bn' ? 'হোমপেজের কাস্টম বর্ণনা...' : 'Custom homepage subtitle...'}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'ফুটার কপিরাইট নোট (ঐচ্ছিক)' : 'Footer Extra Note (Optional)'}
                </label>
                <input
                  type="text"
                  value={editFooterNote}
                  onChange={(e) => {
                    settingsDirtyRef.current = true;
                    setEditFooterNote(e.target.value);
                  }}
                  placeholder={lang === 'bn' ? 'যেমন: High-Speed Cloud Infrastructure' : 'e.g. Cloud Hosting Platform'}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Megaphone className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                <span>
                  {lang === 'bn'
                    ? 'সিস্টেম ঘোষণা ব্যানার (User Dashboard-এ দেখাবে)'
                    : 'Live Broadcast Banner (Shown on User Dashboard)'}
                </span>
              </label>
              <input
                type="text"
                value={editBroadcast}
                onChange={(e) => {
                  settingsDirtyRef.current = true;
                  setEditBroadcast(e.target.value);
                }}
                placeholder={
                  lang === 'bn'
                    ? 'যেমন: আজ রাত ১২টায় সার্ভার আপডেট চলবে...'
                    : 'e.g. Scheduled server upgrade tonight at 12 AM...'
                }
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={savingSettings}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md transition disabled:opacity-60"
              >
                {savingSettings ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Save className="w-4 h-4" />
                )}
                <span>{lang === 'bn' ? 'পরিবর্তন সংরক্ষণ করুন' : 'Save & Broadcast Live'}</span>
              </button>
            </div>
          </form>

          {/* REAL MULTI-SUPABASE STORAGE POOL & SERVER DISK TELEMETRY */}
          <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white flex flex-wrap items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>
                    {lang === 'bn'
                      ? 'রিয়েল স্টোরেজ পুল ও মাল্টি-Supabase অ্যাকাউন্ট ম্যানেজার'
                      : 'Real Storage Pool & Multi-Supabase Bucket Manager'}
                  </span>
                  <span className="text-xs font-mono text-emerald-600 dark:text-emerald-400 tabular-nums">
                    · {serverStorage.supabaseConnectedCount ?? 0} / {serverStorage.supabaseNodesCount ?? 0}{' '}
                    {lang === 'bn' ? 'সংযুক্ত' : 'Connected'}
                  </span>
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {lang === 'bn'
                    ? 'এক বা একাধিক ফ্রি Supabase Storage (প্রতিটি 1024 MB ফ্রি) যুক্ত করলে মোট সার্ভার স্টোরেজ স্বয়ংক্রিয়ভাবে একসাথে যোগ হবে এবং প্রতিটি ডিপ্লয়কৃত সাইট ব্যাকআপ হবে।'
                    : 'Connect multiple free Supabase Storage accounts (1024 MB each) to pool real cloud bucket capacity and automatically sync deployed sites.'}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  disabled={syncingAllSupa || (serverStorage.supabaseConnectedCount ?? 0) === 0}
                  onClick={handleSyncAllToSupabase}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition disabled:opacity-50 whitespace-nowrap"
                >
                  {syncingAllSupa ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <UploadCloud className="w-3.5 h-3.5" />
                  )}
                  <span>{lang === 'bn' ? 'সব সাইট সিঙ্ক' : 'Sync All Sites'}</span>
                </button>

                <button
                  type="button"
                  disabled={recheckingSupa || (serverStorage.supabaseNodesCount ?? 0) === 0}
                  onClick={handleRecheckAllSupabase}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition disabled:opacity-50 whitespace-nowrap"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${recheckingSupa ? 'animate-spin' : ''}`} />
                  <span>{lang === 'bn' ? 'অ্যাপ্লাই ও রি-চেক' : 'Apply & Re-Verify'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleOpenRenderEnvModal}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold transition whitespace-nowrap"
                >
                  <Server className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                  <span>{lang === 'bn' ? 'Render Env গাইড' : 'Render Env Vars'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowSecurityEnvHelpModal(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300 text-xs font-bold transition whitespace-nowrap"
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? 'সিকিউরিটি Env (i)' : 'Security Env (i)'}</span>
                </button>
              </div>
            </div>

            {/* Real Live Storage Telemetry Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs tabular-nums">
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                <div className="text-[11px] text-slate-500 dark:text-slate-400 font-semibold">
                  {lang === 'bn' ? 'সক্রিয় স্টোরেজ সোর্স ও সংখ্যা' : 'Active Cloud Pool Nodes'}
                </div>
                <div className="text-sm font-extrabold text-cyan-700 dark:text-cyan-400 mt-0.5 font-mono">
                  {serverStorage.storageSource === 'hybrid-cloud-pool'
                    ? `Hybrid Pool (${serverStorage.b2ConnectedCount ?? 0} B2 + ${serverStorage.supabaseConnectedCount ?? 0} Supa)`
                    : serverStorage.storageSource === 'b2-pool'
                    ? `Backblaze B2 (${serverStorage.b2ConnectedCount ?? 1} Connected)`
                    : serverStorage.storageSource === 'supabase-pool'
                    ? `Supabase Pool (${serverStorage.supabaseConnectedCount ?? serverStorage.supabaseNodesCount ?? 1} Connected)`
                    : `Local Disk (0 Cloud Connected)`}
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                <div className="text-[11px] text-slate-500 dark:text-slate-400 font-semibold">
                  {lang === 'bn' ? 'কার্যকরী পুল ক্যাপাসিটি' : 'Effective Pool Capacity'}
                </div>
                <div className="text-sm font-extrabold text-emerald-700 dark:text-emerald-400 mt-0.5 font-mono">
                  {formatStorageFromMb(serverStorage.configuredPoolMb)}
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                <div className="text-[11px] text-slate-500 dark:text-slate-400 font-semibold">
                  {lang === 'bn' ? 'ব্যবহৃত স্টোরেজ ও হোস্ট ডিস্ক' : 'App Usage & Host Disk'}
                </div>
                <div className="text-sm font-extrabold text-slate-800 dark:text-slate-200 mt-0.5 font-mono">
                  {formatStorageFromMb(serverStorage.totalUsedMb)} used
                  {serverStorage.diskFreeMb !== null && (
                    <span className="text-[11px] font-normal text-slate-500 dark:text-slate-400">
                      {' '}
                      · Disk: {formatStorageFromMb(serverStorage.diskFreeMb)} free
                    </span>
                  )}
                </div>
              </div>
            </div>

            {showRenderGuide && (
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-bold text-cyan-400">
                    {lang === 'bn'
                      ? 'Render Dashboard → Environment Variables-এ যোগ করুন:'
                      : 'Add in Render Dashboard → Environment Variables:'}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyEnvGuide}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold"
                  >
                    {copiedEnvGuide ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedEnvGuide ? (lang === 'bn' ? 'কপি হয়েছে' : 'Copied') : (lang === 'bn' ? 'কপি' : 'Copy')}</span>
                  </button>
                </div>
                <pre className="p-3 rounded-xl bg-slate-900 text-[11px] font-mono text-emerald-300 overflow-x-auto leading-relaxed">
                  {renderEnvSnippet}
                </pre>
              </div>
            )}

            {/* Connected Supabase Nodes List */}
            {(serverStorage.supabaseNodes || []).length > 0 && (
              <div className="space-y-2.5">
                {(serverStorage.supabaseNodes || []).map((node) => {
                  const usedMb = Number(node.usedMb) || 0;
                  const quotaMb = Math.max(1, Number(node.quotaMb) || 1024);
                  const nodePct = Math.min(100, Math.round((usedMb / quotaMb) * 100));
                  const borderTone =
                    node.status === 'connected'
                      ? 'border-emerald-300/80 dark:border-emerald-500/35'
                      : node.status === 'error'
                      ? 'border-rose-300/80 dark:border-rose-500/40'
                      : 'border-amber-300/80 dark:border-amber-500/35';

                  return (
                    <div
                      key={node.id}
                      className={`p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border ${borderTone} flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs`}
                    >
                      <div className="min-w-0 flex-1 space-y-1.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-bold text-slate-900 dark:text-white">{node.label}</span>
                          <span
                            className={`text-[10px] font-mono font-bold uppercase ${
                              node.status === 'connected'
                                ? 'text-emerald-600 dark:text-emerald-400'
                                : node.status === 'error'
                                ? 'text-rose-600 dark:text-rose-400'
                                : 'text-amber-600 dark:text-amber-400'
                            }`}
                          >
                            · {node.status.toUpperCase()}
                          </span>
                          <span className="text-[10px] font-mono uppercase text-slate-500 dark:text-slate-400">
                            · {node.source}
                          </span>
                          <span className="font-mono text-[11px] font-bold text-cyan-700 dark:text-cyan-300 tabular-nums">
                            · {formatStorageFromMb(usedMb)} / {formatStorageFromMb(quotaMb)} ({nodePct}%)
                          </span>
                        </div>
                        <div className="w-full max-w-md h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-emerald-500 transition-all"
                            style={{ width: `${usedMb > 0 ? Math.max(0.5, nodePct) : 0}%` }}
                          />
                        </div>
                        <div className="font-mono text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {node.url} · Bucket: <strong>{node.bucketName}</strong> · Key: {node.serviceRoleKeyMasked}
                        </div>
                        {node.errorMessage && (
                          <div className="text-[11px] text-rose-600 dark:text-rose-400">{node.errorMessage}</div>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          disabled={verifyingNodeId === node.id}
                          onClick={() => handleVerifySupabaseNode(node.id)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-cyan-500 text-slate-700 dark:text-slate-200 text-xs font-semibold transition whitespace-nowrap"
                        >
                          <RefreshCw className={`w-3.5 h-3.5 ${verifyingNodeId === node.id ? 'animate-spin' : ''}`} />
                          <span>{lang === 'bn' ? 'যাচাই ও Env' : 'Verify & Env'}</span>
                        </button>

                        {node.source === 'manual' && (
                          <button
                            type="button"
                            disabled={removingNodeId === node.id}
                            onClick={() => handleRemoveSupabaseNode(node.id)}
                            aria-label={`Remove Supabase node ${node.label}`}
                            className="p-2 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-500/30 text-rose-600 dark:text-rose-400 hover:bg-rose-100 transition"
                            title={lang === 'bn' ? 'রিমুভ করুন' : 'Remove Node'}
                          >
                            {removingNodeId === node.id ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Trash2 className="w-3.5 h-3.5" />
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Add New Supabase Storage Bucket Form */}
            <form
              onSubmit={handleAddSupabaseNode}
              className="p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 space-y-3.5"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-100">
                  <Plus className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>
                    {lang === 'bn' ? 'নতুন Supabase স্টোরেজ অ্যাকাউন্ট যুক্ত করুন' : 'Connect New Supabase Storage Bucket'}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => setShowSupaHelpModal(true)}
                  aria-label={lang === 'bn' ? 'কোথায় পাবেন গাইড দেখুন' : 'Where to find Supabase credentials'}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-50 dark:bg-cyan-950/70 hover:bg-cyan-100 dark:hover:bg-cyan-900 border border-cyan-200 dark:border-cyan-500/40 text-cyan-700 dark:text-cyan-300 text-[11px] font-bold transition whitespace-nowrap"
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? 'কোনটা কোথায় পাবেন?' : 'Where to find?'}</span>
                </button>
              </div>

              {supaFormMsg && (
                <div
                  className={`p-2.5 rounded-xl text-xs border ${
                    supaFormMsg.error
                      ? 'bg-rose-50 dark:bg-rose-950/50 border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300'
                      : 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-500/40 text-emerald-700 dark:text-emerald-300'
                  }`}
                >
                  {supaFormMsg.text}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'bn' ? 'অ্যাকাউন্টের নাম (Label)' : 'Account Label'}
                  </label>
                  <input
                    type="text"
                    value={supaLabel}
                    onChange={(e) => setSupaLabel(e.target.value)}
                    placeholder={lang === 'bn' ? 'যেমন: Supa Bucket #1' : 'e.g. Supa Bucket #1'}
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Project URL <span className="text-[10px] text-slate-400">(Data API)</span>
                  </label>
                  <input
                    type="url"
                    value={supaUrl}
                    onChange={(e) => setSupaUrl(e.target.value)}
                    placeholder="https://xxxx.supabase.co"
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    service_role / Secret Key
                  </label>
                  <input
                    type="password"
                    value={supaKey}
                    onChange={(e) => setSupaKey(e.target.value)}
                    placeholder="eyJhbGci... বা sb_secret_..."
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'bn' ? 'Bucket নাম ও সাইজ (MB)' : 'Bucket Name & Size (MB)'}
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={supaBucket}
                      onChange={(e) => setSupaBucket(e.target.value)}
                      placeholder="nighthost-sites"
                      className="flex-1 min-w-0 px-2.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white font-mono"
                    />
                    <input
                      type="number"
                      min="100"
                      value={supaQuotaMb}
                      onChange={(e) => setSupaQuotaMb(Number(e.target.value))}
                      placeholder="1024"
                      className="w-20 px-2.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white font-mono tabular-nums"
                    />
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  {lang === 'bn'
                    ? 'কানেক্ট করলে স্বয়ংক্রিয়ভাবে Render Environment Variables পপআপ দেখাবে।'
                    : 'Connecting automatically generates exact Render Environment Variables.'}
                </span>
                <button
                  type="submit"
                  disabled={addingSupa}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition disabled:opacity-60 whitespace-nowrap"
                >
                  {addingSupa ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                  <span>{lang === 'bn' ? 'সংযুক্ত ও যাচাই করুন' : 'Connect & Verify Bucket'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* BACKBLAZE B2 CLOUD STORAGE POOL (10 GB FREE FOREVER) */}
          <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white flex flex-wrap items-center gap-2">
                  <Cloud className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                  <span>
                    {lang === 'bn'
                      ? 'Backblaze B2 ক্লাউড স্টোরেজ পুল (প্রতি অ্যাকাউন্টে 10 GB ফ্রি)'
                      : 'Backblaze B2 Cloud Pool (10 GB Free Forever)'}
                  </span>
                  <span className="text-xs font-mono text-rose-600 dark:text-rose-400 tabular-nums">
                    · {serverStorage.b2ConnectedCount ?? 0} / {serverStorage.b2NodesCount ?? 0}{' '}
                    {lang === 'bn' ? 'সংযুক্ত' : 'Connected'}
                  </span>
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {lang === 'bn'
                    ? 'কার্ড ছাড়াই Backblaze B2-তে 10 GB ফ্রি বাকেট যুক্ত করলে Supabase-এর সাথে মিলে মোট ক্লাউড স্টোরেজ (যেমন: 10 GB + 1 GB) একত্রে পুল হবে।'
                    : 'Add cardless Backblaze B2 buckets (10 GB free each) to automatically combine capacity with your Supabase pool.'}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  disabled={syncingAllB2 || (serverStorage.b2ConnectedCount ?? 0) === 0}
                  onClick={handleSyncAllToB2}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition disabled:opacity-50 whitespace-nowrap"
                >
                  {syncingAllB2 ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <UploadCloud className="w-3.5 h-3.5" />}
                  <span>{lang === 'bn' ? 'সব সাইট B2-তে সিঙ্ক' : 'Sync All to B2'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleOpenRenderEnvModal}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold transition whitespace-nowrap"
                >
                  <Server className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                  <span>{lang === 'bn' ? 'Render Env গাইড' : 'Combined Render Env'}</span>
                </button>
              </div>
            </div>

            {(serverStorage.b2Nodes || []).length > 0 && (
              <div className="space-y-2.5">
                {(serverStorage.b2Nodes || []).map((node) => {
                  const usedMb = Number(node.usedMb) || 0;
                  const quotaMb = Math.max(1, Number(node.quotaMb) || 10240);
                  const nodePct = Math.min(100, Math.round((usedMb / quotaMb) * 100));
                  return (
                    <div
                      key={node.id}
                      className={`p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border ${
                        node.status === 'connected'
                          ? 'border-rose-300/80 dark:border-rose-500/35'
                          : 'border-amber-300/80 dark:border-amber-500/35'
                      } flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs`}
                    >
                      <div className="min-w-0 flex-1 space-y-1.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-bold text-slate-900 dark:text-white">{node.label}</span>
                          <span
                            className={`text-[10px] font-mono font-bold uppercase ${
                              node.status === 'connected'
                                ? 'text-emerald-600 dark:text-emerald-400'
                                : 'text-rose-600 dark:text-rose-400'
                            }`}
                          >
                            · {node.status.toUpperCase()}
                          </span>
                          <span className="text-[10px] font-mono uppercase text-slate-500 dark:text-slate-400">
                            · {node.source}
                          </span>
                          <span className="font-mono text-[11px] font-bold text-rose-700 dark:text-rose-300 tabular-nums">
                            · {formatStorageFromMb(usedMb)} / {formatStorageFromMb(quotaMb)} ({nodePct}%)
                          </span>
                        </div>
                        <div className="font-mono text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          Bucket: <strong>{node.bucketName}</strong> · KeyID: {node.keyId}
                        </div>
                        {node.errorMessage && (
                          <div className="text-[11px] text-rose-600 dark:text-rose-400">{node.errorMessage}</div>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          disabled={verifyingB2Id === node.id}
                          onClick={() => handleVerifyB2Node(node.id)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-rose-500 text-slate-700 dark:text-slate-200 text-xs font-semibold transition whitespace-nowrap"
                        >
                          <RefreshCw className={`w-3.5 h-3.5 ${verifyingB2Id === node.id ? 'animate-spin' : ''}`} />
                          <span>{lang === 'bn' ? 'যাচাই ও Env' : 'Verify & Env'}</span>
                        </button>
                        {node.source === 'manual' && (
                          <button
                            type="button"
                            disabled={removingB2Id === node.id}
                            onClick={() => handleRemoveB2Node(node.id)}
                            aria-label={`Remove B2 node ${node.label}`}
                            className="p-2 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-500/30 text-rose-600 dark:text-rose-400 hover:bg-rose-100 transition"
                          >
                            {removingB2Id === node.id ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Trash2 className="w-3.5 h-3.5" />
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <form
              onSubmit={handleAddB2Node}
              className="p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 space-y-3.5"
            >
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-100">
                <Plus className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                <span>
                  {lang === 'bn' ? 'নতুন Backblaze B2 বাকেট যুক্ত করুন (10 GB Free)' : 'Connect Backblaze B2 Bucket (10 GB Free)'}
                </span>
              </div>

              {b2FormMsg && (
                <div
                  className={`p-2.5 rounded-xl text-xs border ${
                    b2FormMsg.error
                      ? 'bg-rose-50 dark:bg-rose-950/50 border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300'
                      : 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-500/40 text-emerald-700 dark:text-emerald-300'
                  }`}
                >
                  {b2FormMsg.text}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'bn' ? 'নাম (Label)' : 'Label'}
                  </label>
                  <input
                    type="text"
                    value={b2Label}
                    onChange={(e) => setB2Label(e.target.value)}
                    placeholder="B2 Vault 10GB"
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    keyID (App Key ID)
                  </label>
                  <input
                    type="text"
                    value={b2KeyId}
                    onChange={(e) => setB2KeyId(e.target.value)}
                    placeholder="005xxxxxxxxxxxx00000001"
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    applicationKey
                  </label>
                  <input
                    type="password"
                    value={b2AppKey}
                    onChange={(e) => setB2AppKey(e.target.value)}
                    placeholder="K005..."
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'bn' ? 'Bucket ও Quota (MB)' : 'Bucket & Quota (MB)'}
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={b2Bucket}
                      onChange={(e) => setB2Bucket(e.target.value)}
                      placeholder="nighthost-vault-01"
                      className="flex-1 min-w-0 px-2.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white font-mono"
                    />
                    <input
                      type="number"
                      min="100"
                      value={b2QuotaMb}
                      onChange={(e) => setB2QuotaMb(Number(e.target.value))}
                      placeholder="10240"
                      className="w-20 px-2.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white font-mono tabular-nums"
                    />
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  {lang === 'bn'
                    ? 'Backblaze → App Keys → Add a New Application Key থেকে keyID ও applicationKey পাবেন।'
                    : 'Find keyID & applicationKey under Backblaze Dashboard → App Keys.'}
                </span>
                <button
                  type="submit"
                  disabled={addingB2}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition disabled:opacity-60 whitespace-nowrap"
                >
                  {addingB2 ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                  <span>{lang === 'bn' ? 'B2 সংযুক্ত ও যাচাই' : 'Connect & Verify B2'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Upgraded Approval Duration & Quota Modal */}
      {approvingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-lg p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 max-h-[92vh] overflow-y-auto">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Clock className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
                  <span>{lang === 'bn' ? 'ইউজার মেয়াদ ও কোটা অনুমোদন' : 'Approve Validity & Storage Quota'}</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  {lang === 'bn'
                    ? `ইউজার '@${approvingUser.username}' (${approvingUser.email}) এর অ্যাক্সেস সেট করুন`
                    : `Configure access duration and storage quota for '@${approvingUser.username}'`}
                </p>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-cyan-50 dark:bg-cyan-950/70 border border-cyan-200 dark:border-cyan-500/30 text-[10px] font-mono font-bold text-cyan-700 dark:text-cyan-300">
                @{approvingUser.username}
              </span>
            </div>

            <div className="space-y-2.5">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                {lang === 'bn' ? 'অনুমোদনের মেয়াদ নির্বাচন করুন:' : 'Select Access Duration:'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                {[
                  { hours: 0.5, bn: '৩০ মিনিট', en: '30 Minutes' },
                  { hours: 1, bn: '১ ঘন্টা', en: '1 Hour' },
                  { hours: 6, bn: '৬ ঘন্টা', en: '6 Hours' },
                  { hours: 24, bn: '২৪ ঘন্টা (১ দিন)', en: '24 Hours (1d)' },
                  { hours: 168, bn: '৭ দিন (1 Week)', en: '7 Days' },
                  { hours: 720, bn: '৩০ দিন (1 Month)', en: '30 Days' },
                  { hours: -1, bn: 'স্থায়ী (Unlimited)', en: 'Permanent' },
                ].map((d) => {
                  const isSelected = !customHoursInput.trim() && selectedDurationHours === d.hours;
                  return (
                    <button
                      key={d.hours}
                      type="button"
                      onClick={() => {
                        setSelectedDurationHours(d.hours);
                        setCustomHoursInput('');
                      }}
                      className={`p-2.5 rounded-xl border text-left transition ${
                        isSelected
                          ? 'bg-cyan-50 dark:bg-cyan-950/80 border-cyan-500 text-cyan-700 dark:text-cyan-300 font-bold shadow-sm'
                          : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      {lang === 'bn' ? d.bn : d.en}
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="number"
                  min="1"
                  max="8760"
                  value={customHoursInput}
                  onChange={(e) => setCustomHoursInput(e.target.value)}
                  placeholder={lang === 'bn' ? 'অথবা কাস্টম ঘন্টা লিখুন (যেমন: 48)' : 'Or enter custom hours (e.g. 48)'}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:border-cyan-500"
                />
                <span className="text-xs text-slate-500 dark:text-slate-400 font-mono shrink-0">
                  {lang === 'bn' ? 'ঘন্টা' : 'hrs'}
                </span>
              </div>
            </div>

            <div className="space-y-2.5">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center justify-between gap-1.5">
                <span className="flex items-center gap-1.5">
                  <HardDrive className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                  <span>{lang === 'bn' ? 'স্টোরেজ লিমিট (Storage Quota):' : 'Storage Quota:'}</span>
                </span>
                {!canSetQuota && (
                  <span className="text-[10px] text-amber-600 dark:text-amber-400 font-normal">
                    {lang === 'bn' ? 'কোটা পরিবর্তনের অনুমতি বন্ধ' : 'Quota edit locked'}
                  </span>
                )}
              </label>
              <div className="flex flex-wrap gap-1.5">
                {[50, 100, 250, 500, 1024, 5120].map((mb) => (
                  <button
                    key={mb}
                    type="button"
                    disabled={!canSetQuota}
                    onClick={() => setCustomQuotaMb(mb)}
                    className={`px-2.5 py-1 rounded-lg border text-[11px] font-mono font-bold transition disabled:opacity-50 ${
                      customQuotaMb === mb
                        ? 'bg-indigo-600 border-indigo-600 text-white'
                        : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-400'
                    }`}
                  >
                    {mb >= 1024 ? `${mb / 1024} GB` : `${mb} MB`}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="10"
                  max="10000"
                  disabled={!canSetQuota}
                  value={customQuotaMb}
                  onChange={(e) => setCustomQuotaMb(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm text-cyan-700 dark:text-cyan-400 font-mono font-bold disabled:opacity-50"
                />
                <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">MB</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setApprovingUser(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 text-xs font-medium"
              >
                {lang === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleApproveWithDuration}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white text-xs font-bold shadow-md transition"
              >
                {lang === 'bn' ? 'অনুমোদন নিশ্চিত করুন' : 'Confirm Approval'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-sm">
          <form
            onSubmit={handleSaveUserEdit}
            className="w-full max-w-md p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4"
          >
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Edit3 className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
              <span>
                {lang === 'bn'
                  ? `ইউজার প্রোফাইল ও পাসওয়ার্ড এডিট (@${editingUser.username})`
                  : `Edit Profile & Password (@${editingUser.username})`}
              </span>
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'পুরো নাম' : 'Full Name'}
                </label>
                <input
                  type="text"
                  value={editUserName}
                  onChange={(e) => setEditUserName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'ইমেইল' : 'Email'}
                </label>
                <input
                  type="email"
                  value={editUserEmail}
                  onChange={(e) => setEditUserEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn'
                    ? 'নতুন পাসওয়ার্ড (খালি রাখলে আগেরটি থাকবে)'
                    : 'New Password (leave blank to keep current)'}
                </label>
                <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2">
                  <input
                    type={showEditUserPass ? 'text' : 'password'}
                    value={editUserPassword}
                    onChange={(e) => setEditUserPassword(e.target.value)}
                    placeholder={lang === 'bn' ? 'নতুন পাসওয়ার্ড লিখুন...' : 'Enter new password...'}
                    className="w-full bg-transparent text-slate-900 dark:text-white font-mono focus:outline-none min-w-0"
                  />
                  <button
                    type="button"
                    onClick={() => setShowEditUserPass(!showEditUserPass)}
                    aria-label={showEditUserPass ? (lang === 'bn' ? 'পাসওয়ার্ড লুকান' : 'Hide password') : (lang === 'bn' ? 'পাসওয়ার্ড দেখুন' : 'Show password')}
                    className="ml-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition shrink-0"
                  >
                    {showEditUserPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'স্টোরেজ লিমিট (MB)' : 'Storage Limit (MB)'}
                </label>
                <input
                  type="number"
                  min="10"
                  max="10000"
                  disabled={!canSetQuota}
                  value={editUserQuota}
                  onChange={(e) => setEditUserQuota(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-cyan-700 dark:text-cyan-400 font-mono font-bold disabled:opacity-50"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="px-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 text-xs"
              >
                {lang === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold"
              >
                {lang === 'bn' ? 'আপডেট সংরক্ষণ' : 'Save Changes'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Confirmation Modal */}
      {confirmAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-sm p-6 rounded-2xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-500/40 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-rose-500" />
              <span>{confirmAction.title}</span>
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {confirmAction.description}
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmAction(null)}
                className="px-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 text-xs"
              >
                {lang === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={executeConfirmDelete}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
              >
                {lang === 'bn' ? 'হ্যাঁ, মুছে ফেলুন' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Self-Profile Update Modal */}
      {profileModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-sm">
          <form
            onSubmit={handleSaveSelfProfile}
            className="w-full max-w-md p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto"
          >
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <UserCog
                className={`w-4 h-4 ${
                  isSuperAdmin ? 'text-rose-600 dark:text-rose-400' : 'text-amber-600 dark:text-amber-400'
                }`}
              />
              <span>
                {lang === 'bn'
                  ? 'আমার অ্যাডমিন প্রোফাইল ও ছবি'
                  : 'Update My Admin Profile & Photo'}
              </span>
            </h3>

            {profileMsg && (
              <div
                className={`p-3 rounded-xl text-xs border ${
                  profileMsg.error
                    ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-500/40'
                    : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-500/40'
                }`}
              >
                {profileMsg.text}
              </div>
            )}

            {/* Admin Avatar Upload Preview */}
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center gap-3.5">
              {(() => {
                const effectiveAvatar =
                  profileAvatarDraft === undefined ? activeAdminUser.avatarDataUrl : profileAvatarDraft;
                return effectiveAvatar ? (
                  <img
                    src={effectiveAvatar}
                    alt={activeAdminUser.username}
                    referrerPolicy="no-referrer"
                    className={`w-14 h-14 rounded-2xl object-cover border shrink-0 ${
                      isSuperAdmin
                        ? 'border-rose-200 dark:border-rose-500/40'
                        : 'border-amber-200 dark:border-amber-500/40'
                    }`}
                  />
                ) : (
                  <div
                    className={`w-14 h-14 rounded-2xl border flex items-center justify-center font-bold text-xl shrink-0 ${
                      isSuperAdmin
                        ? 'bg-rose-100 dark:bg-rose-950 border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300'
                        : 'bg-amber-100 dark:bg-amber-950 border-amber-200 dark:border-amber-500/40 text-amber-700 dark:text-amber-300'
                    }`}
                  >
                    {activeAdminUser.username.charAt(0).toUpperCase()}
                  </div>
                );
              })()}

              <div className="flex-1 min-w-0 space-y-2">
                <div className="text-[11px] text-slate-600 dark:text-slate-300">
                  {lang === 'bn'
                    ? `প্রোফাইল ছবি (${profileAvatarDraft === null ? 0 : profileAvatarKb} KB)`
                    : `Profile Photo (${profileAvatarDraft === null ? 0 : profileAvatarKb} KB)`}
                </div>
                <input
                  ref={adminAvatarInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleAdminAvatarSelected}
                  className="hidden"
                />
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => adminAvatarInputRef.current?.click()}
                    className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-white text-[11px] font-semibold ${
                      isSuperAdmin
                        ? 'bg-rose-600 hover:bg-rose-500'
                        : 'bg-amber-600 hover:bg-amber-500'
                    }`}
                  >
                    <Camera className="w-3 h-3" />
                    <span>
                      {profileAvatarDraft
                        ? lang === 'bn'
                          ? 'অন্য ছবি বাছুন'
                          : 'Change Photo'
                        : lang === 'bn'
                        ? 'ছবি বাছুন'
                        : 'Upload Photo'}
                    </span>
                  </button>
                  {(profileAvatarDraft || (profileAvatarDraft === undefined && activeAdminUser.avatarDataUrl)) && (
                    <button
                      type="button"
                      onClick={() => {
                        setProfileAvatarDraft(null);
                        setProfileAvatarKb(0);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-semibold"
                    >
                      {lang === 'bn' ? 'মুছুন' : 'Remove'}
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'ইউজারনেম' : 'Username'}
                </label>
                <input
                  type="text"
                  value={profileUsername}
                  onChange={(e) => setProfileUsername(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white font-mono"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'পুরো নাম' : 'Full Name'}
                </label>
                <input
                  type="text"
                  value={profileFullName}
                  onChange={(e) => setProfileFullName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'ইমেইল' : 'Email'}
                </label>
                <input
                  type="email"
                  value={profileEmail}
                  onChange={(e) => setProfileEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn'
                    ? 'নতুন পাসওয়ার্ড (খালি রাখলে আগেরটি থাকবে)'
                    : 'New Password (leave blank to keep current)'}
                </label>
                <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2">
                  <input
                    type={showProfilePass ? 'text' : 'password'}
                    value={profilePassword}
                    onChange={(e) => setProfilePassword(e.target.value)}
                    placeholder={lang === 'bn' ? 'নতুন পাসওয়ার্ড লিখুন...' : 'Enter new password...'}
                    className="w-full bg-transparent text-slate-900 dark:text-white font-mono focus:outline-none min-w-0"
                  />
                  <button
                    type="button"
                    onClick={() => setShowProfilePass(!showProfilePass)}
                    aria-label={showProfilePass ? (lang === 'bn' ? 'পাসওয়ার্ড লুকান' : 'Hide password') : (lang === 'bn' ? 'পাসওয়ার্ড দেখুন' : 'Show password')}
                    className="ml-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition shrink-0"
                  >
                    {showProfilePass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setProfileModalOpen(false)}
                className="px-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 text-xs"
              >
                {lang === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="submit"
                disabled={savingProfile}
                className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-white text-xs font-bold disabled:opacity-60 ${
                  isSuperAdmin
                    ? 'bg-rose-600 hover:bg-rose-500'
                    : 'bg-amber-600 hover:bg-amber-500'
                }`}
              >
                {savingProfile && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>{lang === 'bn' ? 'প্রোফাইল সংরক্ষণ করুন' : 'Save Profile'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Deep User Inspector Modal */}
      {inspectedUser && (() => {
        const userSites = allSites.filter((s) => s.userId === inspectedUser.id);
        const sitesSizeKb = userSites.reduce((acc, s) => acc + (Number(s.totalSizeKb) || 0), 0);
        const avatarSizeKb = Number(inspectedUser.avatarSizeKb) || 0;
        const validity = storage.getRemainingApprovalTime(inspectedUser, lang);

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/75 dark:bg-slate-950/90 backdrop-blur-sm">
            <div className="w-full max-w-4xl max-h-[92vh] rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden">
              {/* Modal Header */}
              <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50 dark:bg-slate-950/60">
                <div className="flex items-center gap-3 min-w-0">
                  {inspectedUser.avatarDataUrl ? (
                    <img
                      src={inspectedUser.avatarDataUrl}
                      alt={inspectedUser.username}
                      referrerPolicy="no-referrer"
                      className="w-12 h-12 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-2xl bg-cyan-100 dark:bg-cyan-950 border border-cyan-200 dark:border-cyan-500/30 flex items-center justify-center font-bold text-lg text-cyan-700 dark:text-cyan-300 shrink-0">
                      {inspectedUser.username.charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-base font-bold text-slate-900 dark:text-white truncate">
                        {inspectedUser.fullName || inspectedUser.username}
                      </h3>
                      <span className="text-xs font-mono text-cyan-600 dark:text-cyan-400">
                        @{inspectedUser.username}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold">
                        {getRoleDisplayLabel(inspectedUser.role, lang)}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {inspectedUser.email} • {lang === 'bn' ? 'মেয়াদ:' : 'Validity:'} {validity.label}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  aria-label="Close inspector"
                  onClick={() => {
                    setInspectedUser(null);
                    setInspectedFile(null);
                  }}
                  className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono block">
                      {lang === 'bn' ? 'মোট কোটা ব্যবহার' : 'Total Used / Limit'}
                    </span>
                    <strong className="font-mono text-cyan-600 dark:text-cyan-400">
                      {formatStorageFromMb(inspectedUser.storageUsedMb)} / {formatStorageFromMb(inspectedUser.storageLimitMb)}
                    </strong>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono block">
                      {lang === 'bn' ? 'হোস্টকৃত সাইট' : 'Sites Storage'}
                    </span>
                    <strong className="font-mono text-slate-900 dark:text-white">
                      {userSites.length} ({formatStorageFromKb(sitesSizeKb)})
                    </strong>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono block">
                      {lang === 'bn' ? 'প্রোফাইল ছবি' : 'Avatar Photo'}
                    </span>
                    <strong className="font-mono text-indigo-600 dark:text-indigo-400">
                      {avatarSizeKb > 0
                        ? formatStorageFromKb(avatarSizeKb)
                        : lang === 'bn'
                        ? 'নেই'
                        : 'None'}
                    </strong>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono block">
                      {lang === 'bn' ? 'যোগদান' : 'Joined'}
                    </span>
                    <strong className="font-mono text-slate-700 dark:text-slate-300">
                      {new Date(inspectedUser.createdAt).toLocaleDateString()}
                    </strong>
                  </div>
                </div>

                {/* User Hosted Sites */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 font-mono">
                    {lang === 'bn'
                      ? `হোস্টকৃত প্রজেক্ট ও ফাইল (${userSites.length})`
                      : `Hosted Projects & Files (${userSites.length})`}
                  </h4>

                  {userSites.length === 0 ? (
                    <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-dashed border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500">
                      {lang === 'bn' ? 'এই ইউজারের কোনো হোস্টকৃত সাইট নেই।' : 'This user has no hosted sites.'}
                    </div>
                  ) : (
                    userSites.map((site) => {
                      const isExpanded = expandedSiteId === site.id;
                      const siteFiles = Object.values(site.files || {});
                      return (
                        <div
                          key={site.id}
                          className="rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 space-y-3"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-bold text-sm text-slate-900 dark:text-white">
                                  {site.name}
                                </span>
                                <span className="px-2 py-0.5 rounded bg-cyan-50 dark:bg-cyan-950 border border-cyan-200 dark:border-cyan-500/30 text-[10px] font-mono text-cyan-700 dark:text-cyan-300 uppercase">
                                  {site.runtimeType || 'static'} • {site.totalFiles} files ({formatStorageFromKb(site.totalSizeKb)})
                                </span>
                              </div>
                              <a
                                href={
                                  (site.ownerSubdomain || inspectedUser.subdomain)
                                    ? `/u/${site.ownerSubdomain || inspectedUser.subdomain}/${site.slug}`
                                    : `/site/${site.slug}`
                                }
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-xs font-mono text-cyan-600 dark:text-cyan-400 hover:underline break-all"
                              >
                                {(site.ownerSubdomain || inspectedUser.subdomain)
                                  ? `/u/${site.ownerSubdomain || inspectedUser.subdomain}/${site.slug}`
                                  : `/site/${site.slug}`}
                              </a>
                            </div>

                            <div className="flex flex-wrap items-center gap-2">
                              <button
                                type="button"
                                onClick={() => setPreviewSite(site)}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                                <span>{lang === 'bn' ? 'লাইভ প্রিভিউ' : 'Live View'}</span>
                              </button>

                              {(canDownloadSource || site.userId === currentUser.id) && (
                                <a
                                  href={`/api/admin/sites/${encodeURIComponent(site.id)}/download.zip`}
                                  download
                                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
                                >
                                  <Download className="w-3.5 h-3.5" />
                                  <span>{lang === 'bn' ? 'ZIP ডাউনলোড' : 'Download .zip'}</span>
                                </a>
                              )}

                              <button
                                type="button"
                                onClick={() => setExpandedSiteId(isExpanded ? null : site.id)}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold"
                              >
                                <FolderOpen className="w-3.5 h-3.5 text-indigo-500" />
                                <span>{lang === 'bn' ? 'ফাইল ব্রাউজ' : 'Files'}</span>
                                {isExpanded ? (
                                  <ChevronUp className="w-3.5 h-3.5" />
                                ) : (
                                  <ChevronDown className="w-3.5 h-3.5" />
                                )}
                              </button>
                            </div>
                          </div>

                          {isExpanded && (
                            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2 max-h-60 overflow-y-auto font-mono text-xs">
                              {siteFiles.map((f) => (
                                <div
                                  key={f.path}
                                  className="flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"
                                >
                                  <span className="flex items-center gap-2 truncate text-slate-700 dark:text-slate-200">
                                    <FileCode2 className="w-3.5 h-3.5 text-cyan-500 shrink-0" />
                                    <span className="truncate">{f.path}</span>
                                    <span className="text-[10px] text-slate-400">
                                      ({formatStorageFromKb((f.size || 0) / 1024)})
                                    </span>
                                  </span>

                                  <div className="flex items-center gap-1.5 shrink-0 font-sans">
                                    {(canDownloadSource || site.userId === currentUser.id) ? (
                                      <>
                                        {!f.isBinary && (
                                          <button
                                            type="button"
                                            onClick={() => setInspectedFile({ siteId: site.id, file: f })}
                                            className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-[11px] font-semibold text-slate-700 dark:text-slate-200"
                                          >
                                            {lang === 'bn' ? 'দেখুন' : 'View'}
                                          </button>
                                        )}
                                        <a
                                          href={`/api/admin/sites/${encodeURIComponent(site.id)}/file?path=${encodeURIComponent(f.path)}&raw=1`}
                                          download
                                          aria-label={`Download ${f.path}`}
                                          className="px-2 py-0.5 rounded bg-cyan-50 dark:bg-cyan-950/60 border border-cyan-200 dark:border-cyan-500/30 text-[11px] font-semibold text-cyan-700 dark:text-cyan-300"
                                        >
                                          <Download className="w-3 h-3 inline" />
                                        </a>
                                      </>
                                    ) : (
                                      <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                                        {lang === 'bn' ? 'সংরক্ষিত' : 'Locked'}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>

                {inspectedFile && (
                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between gap-2 text-xs font-mono">
                      <span className="text-cyan-300 font-bold truncate">{inspectedFile.file.path}</span>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard?.writeText(inspectedFile.file.content || '');
                            setCopiedInspectorCode(true);
                            setTimeout(() => setCopiedInspectorCode(false), 1800);
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-sans font-semibold transition"
                        >
                          {copiedInspectorCode ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3 text-cyan-400" />
                          )}
                          <span>{copiedInspectorCode ? (lang === 'bn' ? 'কপি হয়েছে' : 'Copied') : (lang === 'bn' ? 'কোড কপি' : 'Copy Code')}</span>
                        </button>
                        <button
                          type="button"
                          aria-label="Close code inspector"
                          onClick={() => setInspectedFile(null)}
                          className="text-slate-400 hover:text-white"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    <pre className="text-[11px] text-slate-200 font-mono max-h-56 overflow-auto whitespace-pre-wrap break-all">
                      {inspectedFile.file.content.slice(0, 12000)}
                    </pre>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })()}

      {/* Quick Targeted Popup Message Modal */}
      {msgModalOpen && (
        <div className="fixed inset-0 z-50 min-h-[100dvh] flex items-center justify-center p-4 bg-slate-900/65 dark:bg-slate-950/85 backdrop-blur-md">
          <form
            onSubmit={handleSendPopupMessage}
            className="w-full max-w-md max-h-[92vh] overflow-y-auto p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <BellRing className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                <span>{lang === 'bn' ? 'পপআপ মেসেজ পাঠান' : 'Send Popup Notice'}</span>
              </h3>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setShowLinkHelpModal(true)}
                  aria-label="Link style help"
                  className="p-1.5 rounded-lg bg-cyan-50 dark:bg-cyan-950/70 text-cyan-600 dark:text-cyan-400 hover:bg-cyan-100"
                >
                  <Info className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  aria-label="Close message modal"
                  onClick={() => setMsgModalOpen(false)}
                  className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {msgFormError && (
              <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300 text-xs">
                {msgFormError}
              </div>
            )}

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'প্রাপক' : 'Target User'}
                </label>
                <select
                  value={msgTargetId}
                  onChange={(e) => setMsgTargetId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="all">
                    {lang === 'bn' ? 'সকল ইউজার (Broadcast All)' : 'All Users (Broadcast)'}
                  </option>
                  {managedUsers.map((u) => (
                    <option key={u.id} value={u.id}>
                      @{u.username} ({u.fullName || u.email})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'শিরোনাম' : 'Title'}
                </label>
                <input
                  type="text"
                  value={msgTitle}
                  onChange={(e) => setMsgTitle(e.target.value)}
                  placeholder={lang === 'bn' ? 'মেসেজের শিরোনাম লিখুন...' : 'Notice title...'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'বার্তা' : 'Message'}
                </label>
                <textarea
                  rows={3}
                  value={msgBody}
                  onChange={(e) => setMsgBody(e.target.value)}
                  placeholder={lang === 'bn' ? 'ইউজারের জন্য বার্তা লিখুন...' : 'Write message...'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white resize-none"
                  required
                />
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Link2 className="w-3.5 h-3.5 text-cyan-500" />
                  <span>{lang === 'bn' ? 'লিংক যোগ করুন (ঐচ্ছিক)' : 'Attach Link (Optional)'}</span>
                </div>
                <input
                  type="text"
                  value={msgLinkUrl}
                  onChange={(e) => setMsgLinkUrl(e.target.value)}
                  placeholder="https://t.me/NightHex_X"
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white font-mono text-[11px]"
                />
                <input
                  type="text"
                  value={msgLinkText}
                  onChange={(e) => setMsgLinkText(e.target.value)}
                  placeholder={lang === 'bn' ? 'লিংকের লেখা (যেমন: ভিজিট করুন)' : 'Link label (optional)'}
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white text-[11px]"
                />
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setMsgLinkMarked(true)}
                    className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-bold ${
                      msgLinkMarked
                        ? 'bg-cyan-50 dark:bg-cyan-950/70 border-cyan-500 text-cyan-700 dark:text-cyan-300'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-500'
                    }`}
                  >
                    {lang === 'bn' ? 'Marked (বাটন)' : 'Marked (Button)'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setMsgLinkMarked(false)}
                    className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-bold ${
                      !msgLinkMarked
                        ? 'bg-indigo-50 dark:bg-indigo-950/70 border-indigo-500 text-indigo-700 dark:text-indigo-300'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-500'
                    }`}
                  >
                    {lang === 'bn' ? 'Unmarked (লিংক)' : 'Unmarked (Link)'}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setMsgModalOpen(false)}
                className="px-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 text-xs"
              >
                {lang === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="submit"
                disabled={sendingMsg}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold disabled:opacity-60"
              >
                {sendingMsg ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                <span>{lang === 'bn' ? 'পাঠিয়ে দিন' : 'Send Now'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Detailed Server & Storage Pool Inspector Modal */}
      {showServerDetailsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 dark:bg-slate-950/85 backdrop-blur-sm">
          <div className="w-full max-w-3xl max-h-[90vh] rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50 dark:bg-slate-950/60">
              <div className="flex items-center gap-2.5">
                <BarChart3 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                    {lang === 'bn' ? 'বিস্তারিত সার্ভার ও স্টোরেজ পুল বিশ্লেষণ' : 'Detailed Server & Pool Analytics'}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {lang === 'bn'
                      ? 'অ্যাপ্রুভড বরাদ্দ, পেন্ডিং (0 KB) হিসাব, রানটাইম বিতরণ ও Supabase পুল বিস্তারিত'
                      : 'Approved allocations, pending exclusion (0 KB), runtime distribution & Supabase nodes'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                aria-label="Close server details"
                onClick={() => setShowServerDetailsModal(false)}
                className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-xs tabular-nums">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono block">
                    {lang === 'bn' ? 'মোট পুল' : 'Pool Capacity'}
                  </span>
                  <strong className="text-sm font-mono text-emerald-600 dark:text-emerald-400">
                    {formatStorageFromMb(serverStorage.configuredPoolMb)}
                  </strong>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono block">
                    {lang === 'bn' ? 'অ্যাপ্রুভড বরাদ্দ' : 'Approved Allocated'}
                  </span>
                  <strong className="text-sm font-mono text-cyan-600 dark:text-cyan-400">
                    {formatStorageFromMb(serverStorage.allocatedMb)}
                  </strong>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono block">
                    {lang === 'bn' ? 'প্রকৃত ব্যবহার' : 'Actual Used'}
                  </span>
                  <strong className="text-sm font-mono text-indigo-600 dark:text-indigo-400">
                    {formatStorageFromMb(serverStorage.totalUsedMb)}
                  </strong>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono block">
                    {lang === 'bn' ? 'অবশিষ্ট ফ্রি পুল' : 'Remaining Free Pool'}
                  </span>
                  <strong className="text-sm font-mono text-slate-900 dark:text-white">
                    {formatStorageFromMb(serverStorage.remainingAllocatableMb)}
                  </strong>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2.5">
                  <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-cyan-500" />
                    <span>{lang === 'bn' ? 'ইউজার স্ট্যাটাস ব্রেকডাউন' : 'Account Status Breakdown'}</span>
                  </h4>
                  <div className="space-y-1.5 font-mono text-[11px]">
                    <div className="flex items-baseline justify-between gap-3">
                      <span className="text-emerald-600 dark:text-emerald-400">
                        {lang === 'bn' ? 'অ্যাপ্রুভড (কোটা সক্রিয়):' : 'Approved (Active Quotas):'}
                      </span>
                      <strong className="text-slate-900 dark:text-white text-right shrink-0">
                        {serverStorage.approvedUsersCount ?? managedUsers.filter((u) => u.status === 'approved').length}
                      </strong>
                    </div>
                    <div className="flex items-baseline justify-between gap-3">
                      <span className="text-amber-600 dark:text-amber-400">
                        {lang === 'bn' ? 'পেন্ডিং (0 KB বরাদ্দ):' : 'Pending (0 KB Reserved):'}
                      </span>
                      <strong className="text-slate-900 dark:text-white text-right shrink-0">
                        {serverStorage.pendingUsersCount ?? pendingCount}
                      </strong>
                    </div>
                    <div className="flex items-baseline justify-between gap-3">
                      <span className="text-rose-600 dark:text-rose-400">
                        {lang === 'bn' ? 'সাসপেন্ড (শুধু ব্যবহৃত বাইট):' : 'Suspended (Actual Bytes Only):'}
                      </span>
                      <strong className="text-slate-900 dark:text-white text-right shrink-0">
                        {serverStorage.suspendedUsersCount ?? managedUsers.filter((u) => u.status === 'suspended').length}
                      </strong>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2.5">
                  <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-indigo-500" />
                    <span>{lang === 'bn' ? 'সাইট রানটাইম ও ডিস্ক তথ্য' : 'Site Runtimes & Host Disk'}</span>
                  </h4>
                  <div className="space-y-1.5 font-mono text-[11px]">
                    <div className="flex items-baseline justify-between gap-3">
                      <span className="text-slate-500 dark:text-slate-400">Static / HTML:</span>
                      <strong className="text-slate-900 dark:text-white text-right shrink-0">
                        {allSites.filter((s) => !s.runtimeType || s.runtimeType === 'static').length}
                      </strong>
                    </div>
                    <div className="flex items-baseline justify-between gap-3">
                      <span className="text-slate-500 dark:text-slate-400">PHP / Node.js / Python:</span>
                      <strong className="text-slate-900 dark:text-white text-right shrink-0">
                        {allSites.filter((s) => s.runtimeType === 'php').length} PHP ·{' '}
                        {allSites.filter((s) => s.runtimeType === 'node').length} Node ·{' '}
                        {allSites.filter((s) => s.runtimeType === 'python').length} Python
                      </strong>
                    </div>
                    <div className="flex items-baseline justify-between gap-3">
                      <span className="text-slate-500 dark:text-slate-400">
                        {lang === 'bn' ? 'হোস্ট সার্ভার ডিস্ক:' : 'Host Server Disk:'}
                      </span>
                      <strong className="text-slate-900 dark:text-white text-right shrink-0">
                        {serverStorage.diskTotalMb !== null
                          ? `${formatStorageFromMb(serverStorage.diskFreeMb || 0)} free / ${formatStorageFromMb(serverStorage.diskTotalMb)}`
                          : 'N/A'}
                      </strong>
                    </div>
                  </div>
                </div>
              </div>

              {allSites.length > 0 && (
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
                  <h4 className="font-bold text-slate-900 dark:text-white">
                    {lang === 'bn' ? 'শীর্ষ স্টোরেজ ব্যবহৃত প্রজেক্টসমূহ' : 'Top Storage Consuming Sites'}
                  </h4>
                  <div className="space-y-1.5 max-h-44 overflow-y-auto">
                    {[...allSites]
                      .sort((a, b) => (b.totalSizeKb || 0) - (a.totalSizeKb || 0))
                      .slice(0, 6)
                      .map((site) => (
                        <div
                          key={site.id}
                          className="flex items-center justify-between px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[11px]"
                        >
                          <div className="min-w-0 truncate">
                            <span className="font-bold text-slate-900 dark:text-white">{site.name}</span>{' '}
                            <span className="font-mono text-slate-500">(@{site.username} · /site/{site.slug})</span>
                          </div>
                          <span className="font-mono font-bold text-cyan-600 dark:text-cyan-400 shrink-0 ml-2">
                            {formatStorageFromKb(site.totalSizeKb || 0)}
                          </span>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Supabase Info Help Modal (i) */}
      {showSupaHelpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 dark:bg-slate-950/85 backdrop-blur-sm">
          <div className="w-full max-w-xl max-h-[90vh] rounded-3xl bg-white dark:bg-slate-900 border border-cyan-200 dark:border-cyan-500/40 shadow-2xl flex flex-col overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50 dark:bg-slate-950/60">
              <div className="flex items-center gap-2.5">
                <HelpCircle className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
                <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                  {lang === 'bn'
                    ? 'Supabase তথ্য কোন জায়গায় ও কোন নামে পাবেন?'
                    : 'Where to Find Each Supabase Field'}
                </h3>
              </div>
              <button
                type="button"
                aria-label="Close Supabase help"
                onClick={() => setShowSupaHelpModal(false)}
                className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 sm:p-6 overflow-y-auto space-y-3 text-xs leading-relaxed">
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1">
                <div className="font-bold text-cyan-700 dark:text-cyan-300 font-mono">
                  1. Project URL (https://xxxx.supabase.co)
                </div>
                <p className="text-slate-600 dark:text-slate-300">
                  {lang === 'bn'
                    ? 'Supabase Dashboard-এ আপনার প্রজেক্টে ঢুকে বাম মেনু থেকে Project Settings (⚙️) → Data API (অথবা API Settings)-এ যান। উপরে "Project URL" নামের বক্স থেকে লিঙ্কটি কপি করুন।'
                    : 'Open your Supabase project → Left sidebar Project Settings (⚙️) → Data API → copy the "Project URL" (looks like https://xyzcompany.supabase.co).'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1">
                <div className="font-bold text-emerald-700 dark:text-emerald-300 font-mono">
                  2. service_role / Secret Key
                </div>
                <p className="text-slate-600 dark:text-slate-300">
                  {lang === 'bn'
                    ? 'Project Settings (⚙️) → API Keys-এ গিয়ে "Secret keys" বা Legacy "service_role" (eyJhbGci... বা sb_secret_...) এর পাশের Reveal/Copy বাটনে চাপুন। (anon/publishable key দিবেন না)।'
                    : 'Go to Project Settings (⚙️) → API Keys → reveal & copy the "Secret key" (sb_secret_...) or legacy "service_role" secret key. Do not use the public anon key.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1">
                <div className="font-bold text-indigo-700 dark:text-indigo-300 font-mono">
                  {lang === 'bn' ? '3. Bucket Name (যেমন: nighthost-sites)' : '3. Bucket Name (e.g. nighthost-sites)'}
                </div>
                <p className="text-slate-600 dark:text-slate-300">
                  {lang === 'bn'
                    ? 'বাম মেনুর Storage-এ একটি Bucket তৈরি থাকলে তার নাম দিন (যেমন nighthost-sites), অথবা না থাকলেও সমস্যা নেই — কানেক্ট করার সময় সিস্টেম স্বয়ংক্রিয়ভাবে Bucket তৈরি করে নিবে।'
                    : 'Enter an existing Storage bucket name (e.g. nighthost-sites), or leave the default — NIGHTHOST will automatically create the bucket if needed.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1">
                <div className="font-bold text-amber-700 dark:text-amber-300 font-mono">
                  4. Quota (MB) — Free Plan: 1024 MB (1 GB)
                </div>
                <p className="text-slate-600 dark:text-slate-300">
                  {lang === 'bn'
                    ? 'প্রতিটি ফ্রি Supabase অ্যাকাউন্টে ১ GB (1024 MB) স্টোরেজ থাকে। একাধিক ফ্রি অ্যাকাউন্ট (যেমন ২টি বা ৫টি) যুক্ত করলে সেগুলোর স্টোরেজ যোগ হয়ে ২ GB / ৫ GB হয়ে যাবে।'
                    : 'Each Free Supabase account gives 1 GB (1024 MB) Storage. Connecting multiple free accounts pools their capacity together automatically.'}
                </p>
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setShowSupaHelpModal(false)}
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold"
              >
                {lang === 'bn' ? 'বুঝেছি' : 'Got It'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Render Environment Variables Popup Modal (Shown after Connect / Verify or on button click) */}
      {renderEnvModalData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/75 dark:bg-slate-950/90 backdrop-blur-sm">
          <div className="w-full max-w-2xl max-h-[92vh] rounded-3xl bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-500/40 shadow-2xl flex flex-col overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50 dark:bg-slate-950/70">
              <div className="flex items-center gap-2.5 min-w-0">
                <Server className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <div className="min-w-0">
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white truncate">
                    {lang === 'bn'
                      ? 'Render-এ এই Environment Variables যুক্ত করুন'
                      : 'Add These Environment Variables in Render'}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    {lang === 'bn'
                      ? 'Render → Dashboard → Your Web Service → Environment → Add & Save Changes'
                      : 'Render Dashboard → Your Web Service → Environment → Save Changes'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                aria-label="Close Render Env Modal"
                onClick={() => setRenderEnvModalData(null)}
                className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs">
              {renderEnvModalData.pairs.length === 0 ? (
                <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-dashed border-slate-300 dark:border-slate-800 text-center text-slate-500 dark:text-slate-400">
                  {lang === 'bn'
                    ? 'এখনো কোনো Supabase অ্যাকাউন্ট যুক্ত করা হয়নি। নিচের ফর্ম থেকে প্রথমে একটি অ্যাকাউন্ট যুক্ত করুন।'
                    : 'No Supabase storage accounts connected yet. Connect an account first.'}
                </div>
              ) : (
                <>
                  <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-500/30 text-emerald-800 dark:text-emerald-200 space-y-1">
                    <div className="font-bold">
                      {lang === 'bn'
                        ? 'ধাপ ১: Render Dashboard → Environment-এ নিচের কী-ভ্যালুগুলো যোগ করে Save Changes চাপুন।'
                        : 'Step 1: Add the numbered variables below in Render → Environment and click Save Changes.'}
                    </div>
                    <div className="text-[11px]">
                      {lang === 'bn'
                        ? 'ধাপ ২: Render রিস্টার্ট হয়ে গেলে নিচের "অ্যাপ্লাই ও রি-চেক করুন" বাটনে ক্লিক করে সব বাকেট স্থায়ীভাবে ভেরিফাই করুন।'
                        : 'Step 2: Once Render finishes deploying, click "Apply & Re-Check Nodes" below to verify persistence.'}
                    </div>
                  </div>

                  {/* Individual Key-Value Pairs */}
                  <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                    {renderEnvModalData.pairs.map((pair) => (
                      <div
                        key={pair.key}
                        className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 font-mono text-[11px]"
                      >
                        <div className="min-w-0 truncate">
                          <span className="font-bold text-cyan-700 dark:text-cyan-400">{pair.key}</span>
                          <span className="text-slate-400">=</span>
                          <span className="text-slate-700 dark:text-slate-200">{pair.value}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => copyTextWithKey(pair.key, pair.value)}
                          className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-[10px] font-sans font-bold text-slate-700 dark:text-slate-200 shrink-0"
                        >
                          {copiedRenderKey === pair.key ? (
                            <Check className="w-3 h-3 text-emerald-500" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                          <span>{copiedRenderKey === pair.key ? (lang === 'bn' ? 'কপি' : 'Copied') : 'Copy'}</span>
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Full .env block */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-700 dark:text-slate-200">
                        {lang === 'bn' ? 'একসাথে সম্পূর্ণ .env / Bulk Add ব্লক:' : 'Complete .env / Bulk Paste Block:'}
                      </span>
                      <button
                        type="button"
                        onClick={() => copyTextWithKey('__dotenv__', renderEnvModalData.dotenvText)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-bold"
                      >
                        {copiedRenderKey === '__dotenv__' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedRenderKey === '__dotenv__' ? (lang === 'bn' ? 'কপি হয়েছে' : 'Copied!') : (lang === 'bn' ? 'সব কপি করুন' : 'Copy All')}</span>
                      </button>
                    </div>
                    <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-emerald-300 overflow-x-auto max-h-40">
                      {renderEnvModalData.dotenvText}
                    </pre>
                  </div>

                  {/* Single SUPABASE_POOL_JSON alternative */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-700 dark:text-slate-200 font-mono text-[11px]">
                        SUPABASE_POOL_JSON {lang === 'bn' ? '(এক লাইনে অপশনাল)' : '(Single Key Alternative)'}
                      </span>
                      <button
                        type="button"
                        onClick={() => copyTextWithKey('__pooljson__', renderEnvModalData.poolJson)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-semibold"
                      >
                        {copiedRenderKey === '__pooljson__' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedRenderKey === '__pooljson__' ? (lang === 'bn' ? 'কপি' : 'Copied') : 'Copy JSON'}</span>
                      </button>
                    </div>
                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 font-mono text-[11px] text-slate-600 dark:text-slate-300 break-all max-h-24 overflow-y-auto">
                      {renderEnvModalData.poolJson}
                    </div>
                  </div>
                </>
              )}
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-end gap-2 bg-slate-50 dark:bg-slate-950/50">
              <button
                type="button"
                onClick={() => setRenderEnvModalData(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 text-xs font-semibold"
              >
                {lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
              </button>
              <button
                type="button"
                disabled={recheckingSupa}
                onClick={handleRecheckAllSupabase}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-sm transition disabled:opacity-60"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${recheckingSupa ? 'animate-spin' : ''}`} />
                <span>{lang === 'bn' ? 'অ্যাপ্লাই ও রি-চেক করুন' : 'Apply & Re-Check Nodes'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin RBAC Governance Help Modal (i) */}
      {showAdminHelpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 dark:bg-slate-950/85 backdrop-blur-sm">
          <div className="w-full max-w-lg max-h-[90vh] rounded-3xl bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-500/40 shadow-2xl flex flex-col overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50 dark:bg-slate-950/60">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                  {lang === 'bn' ? 'অ্যাডমিন পারমিশন ও স্টোরেজ নিয়ম' : 'Admin Permissions & Pool Governance'}
                </h3>
              </div>
              <button
                type="button"
                aria-label="Close admin guide"
                onClick={() => setShowAdminHelpModal(false)}
                className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 sm:p-6 overflow-y-auto space-y-3 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1">
                <div className="font-bold text-slate-900 dark:text-white">
                  {lang === 'bn' ? '১. মালিক বনাম অ্যাডমিন ক্ষমতা' : '1. Owner vs Admin Access'}
                </div>
                <p>
                  {lang === 'bn'
                    ? 'মালিক (Owner) সর্বময় ক্ষমতার অধিকারী। অ্যাডমিনরা (Admin) শুধুমাত্র অনুমোদিত পারমিশন অনুযায়ী ইউজার অনুমোদন, কোটা সেট, মেসেজ পাঠানো, এবং চাইলে .zip ডাউনলোড বা সাইট নিয়ন্ত্রণ করতে পারবেন — কিন্তু অ্যাডমিনরা মালিকের সেটিংস, Supabase কী বা অন্যান্য অ্যাডমিন ডিলিট করতে পারবেন না।'
                    : 'Only the Owner controls platform settings, Supabase secrets, and Admin accounts. Admins only access features explicitly enabled on their card.'}
                </p>
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1">
                <div className="font-bold text-slate-900 dark:text-white">
                  {lang === 'bn' ? '২. শেয়ার্ড সার্ভার পুল (0 KB রুল)' : '2. Shared Server Pool (0 KB Rule)'}
                </div>
                <p>
                  {lang === 'bn'
                    ? 'পেন্ডিং ইউজার (অনুমোদনের আগে) ও অ্যাডমিন অ্যাকাউন্ট সার্ভারের ইউজার পুল থেকে কোনো স্টোরেজ রিজার্ভ করে না। কেবল অনুমোদিত ইউজারদের কোটা ও প্রকৃত আপলোড করা ফাইল পুল থেকে হিসাব হয়।'
                    : 'Pending users and Admin accounts consume 0 KB of pooled quota until approved normal users or uploaded files use real disk/bucket space.'}
                </p>
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1">
                <div className="font-bold text-slate-900 dark:text-white">
                  {lang === 'bn' ? '৩. লাইভ অ্যাডমিন রিপোর্ট' : '3. Live Activity Tracking'}
                </div>
                <p>
                  {lang === 'bn'
                    ? 'নিচের রিপোর্ট কার্ড থেকে প্রতিটি অ্যাডমিন কয়জন ইউজার অ্যাপ্রুভ করেছেন ও কতগুলো কাজ করেছেন তা মালিক সরাসরি দেখতে পারবেন।'
                    : 'The Activity Reports section tracks approved users, popup messages, and total actions per Admin.'}
                </p>
              </div>
            </div>
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setShowAdminHelpModal(false)}
                className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold"
              >
                {lang === 'bn' ? 'বুঝেছি' : 'Got It'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Marked vs Unmarked Link Help Modal (i) */}
      {showLinkHelpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 dark:bg-slate-950/85 backdrop-blur-sm">
          <div className="w-full max-w-md max-h-[90vh] rounded-3xl bg-white dark:bg-slate-900 border border-cyan-200 dark:border-cyan-500/40 shadow-2xl flex flex-col overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50 dark:bg-slate-950/60">
              <div className="flex items-center gap-2.5">
                <Link2 className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
                <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                  {lang === 'bn' ? 'Marked বনাম Unmarked লিংক' : 'Marked vs Unmarked Link'}
                </h3>
              </div>
              <button
                type="button"
                aria-label="Close link help"
                onClick={() => setShowLinkHelpModal(false)}
                className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 sm:p-6 overflow-y-auto space-y-3 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
              <div className="p-3.5 rounded-2xl bg-cyan-50/70 dark:bg-cyan-950/40 border border-cyan-200 dark:border-cyan-500/30 space-y-1">
                <div className="font-bold text-cyan-700 dark:text-cyan-300">
                  {lang === 'bn' ? 'Marked (হাইলাইটেড CTA বাটন)' : 'Marked (Highlighted CTA Button)'}
                </div>
                <p>
                  {lang === 'bn'
                    ? 'ইউজারের পপআপ স্ক্রিনে লিংকটি একটি আকর্ষণীয় উজ্জ্বল রঙের বড় বাটন আকারে দেখাবে। টেলিগ্রাম চ্যানেল বা জরুরি অফারের জন্য সেরা।'
                    : 'Renders the link as a prominent gradient action button inside the popup modal.'}
                </p>
              </div>
              <div className="p-3.5 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-500/30 space-y-1">
                <div className="font-bold text-indigo-700 dark:text-indigo-300">
                  {lang === 'bn' ? 'Unmarked (পরিষ্কার ইনলাইন টেক্সট লিংক)' : 'Unmarked (Clean Inline Hyperlink)'}
                </div>
                <p>
                  {lang === 'bn'
                    ? 'বাটনের বদলে সাধারণ পরিষ্কার আন্ডারলাইন টেক্সট লিংক হিসেবে বার্তার নিচে দেখাবে। ক্লিক করলেই লিংকটি নিরাপদ নতুন ট্যাবে খুলবে (শুধু https:// / http:// লিংক গ্রহণযোগ্য)।'
                    : 'Renders the link as a subtle underlined text link beneath the message body. Only safe http(s):// links are allowed.'}
                </p>
              </div>
            </div>
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setShowLinkHelpModal(false)}
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold"
              >
                {lang === 'bn' ? 'বুঝেছি' : 'Got It'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Render Security & Auth Environment Help Modal (i) */}
      {showSecurityEnvHelpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 dark:bg-slate-950/85 backdrop-blur-sm">
          <div className="w-full max-w-xl max-h-[90vh] rounded-3xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-500/40 shadow-2xl flex flex-col overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50 dark:bg-slate-950/60">
              <div className="flex items-center gap-2.5">
                <Lock className="w-5 h-5 text-rose-600 dark:text-rose-400" />
                <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                  {lang === 'bn'
                    ? 'সিকিউরিটি, মালিক অ্যাকাউন্ট ও Render Env গাইড'
                    : 'Platform Security & Render Environment Guide'}
                </h3>
              </div>
              <button
                type="button"
                aria-label="Close security guide"
                onClick={() => setShowSecurityEnvHelpModal(false)}
                className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 sm:p-6 overflow-y-auto space-y-3 text-xs leading-relaxed">
              <p className="text-slate-600 dark:text-slate-300">
                {lang === 'bn'
                  ? 'ডাটাবেজ ডাম্প, অ্যাডমিন হাইজ্যাক ও ব্রুট-ফোর্স অ্যাটাক প্রতিরোধে সার্ভারে scrypt পাসওয়ার্ড হ্যাশিং, স্বাক্ষরিত HttpOnly কুকি, /data ব্লকিং এবং কড়া RBAC চালু আছে। Render Dashboard → Environment-এ নিচের ভেরিয়েবলগুলো অবশ্যই সেট করুন:'
                  : 'To harden production deployments on Render against database dumps, session hijacking, and default-password attacks, configure these Environment Variables:'}
              </p>
              <pre className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-emerald-300 overflow-x-auto leading-relaxed">
{`NIGHTHOST_OWNER_USERNAME=your_secret_owner
NIGHTHOST_OWNER_PASSWORD=use_a_strong_unique_password
NIGHTHOST_OWNER_EMAIL=owner@yourdomain.com
NIGHTHOST_SESSION_SECRET=64_char_random_hex_secret
NIGHTHOST_PRIMARY_DOMAIN=yourdomain.com`}
              </pre>
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-600 dark:text-slate-300 space-y-1">
                <div className="font-bold text-slate-900 dark:text-white">
                  {lang === 'bn' ? 'কেন এগুলো জরুরি?' : 'What Each Variable Protects:'}
                </div>
                <p>• <code className="font-mono text-cyan-600 dark:text-cyan-400">NIGHTHOST_OWNER_*</code>: {lang === 'bn' ? 'ডিফল্ট admin পাসওয়ার্ড পরিবর্তন করে সার্ভার বুটেই আপনার গোপন মালিক লগইন সেট করে।' : 'Replaces default owner credentials securely at boot.'}</p>
                <p>• <code className="font-mono text-cyan-600 dark:text-cyan-400">NIGHTHOST_SESSION_SECRET</code>: {lang === 'bn' ? 'রিস্টার্টের পরেও HttpOnly সেশন কুকি নিরাপদ ও যাচাইযোগ্য রাখে।' : 'Signs HttpOnly session cookies across server restarts.'}</p>
                <p>• <code className="font-mono text-cyan-600 dark:text-cyan-400">NIGHTHOST_PRIMARY_DOMAIN</code>: {lang === 'bn' ? 'ইউজারের পার্সোনাল সাবডোমেইন (<sub >.yourdomain.com) দেখাতে সাহায্য করে।' : 'Enables custom subdomain previews (<sub >.yourdomain.com) alongside /u/<sub >/<slug>.'}</p>
              </div>
            </div>
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setShowSecurityEnvHelpModal(false)}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
              >
                {lang === 'bn' ? 'বুঝেছি' : 'Got It'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cloudflare Worker & Wildcard Domain Setup Modal */}
      {showCfWorkerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/75 dark:bg-slate-950/90 backdrop-blur-sm">
          <div className="w-full max-w-2xl max-h-[92vh] rounded-3xl bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-500/40 shadow-2xl flex flex-col overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50 dark:bg-slate-950/70">
              <div className="flex items-center gap-2.5 min-w-0">
                <Cloud className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
                <div className="min-w-0">
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white truncate">
                    {lang === 'bn'
                      ? 'Cloudflare Worker দিয়ে *.nighthostcloud.dpdns.org Wildcard সেটআপ'
                      : 'Cloudflare Worker Wildcard Subdomain Setup'}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    {lang === 'bn'
                      ? 'ইউজাররা স্বয়ংক্রিয়ভাবে username.nighthostcloud.dpdns.org সাবডোমেইন পাবে'
                      : 'Routes *.yourdomain.com traffic directly to your Render app'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                aria-label="Close Cloudflare Worker modal"
                onClick={() => setShowCfWorkerModal(false)}
                className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs">
              {loadingCfWorker ? (
                <div className="p-8 text-center text-slate-500 flex items-center justify-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{lang === 'bn' ? 'Worker স্ক্রিপ্ট তৈরি হচ্ছে...' : 'Loading Worker script...'}</span>
                </div>
              ) : (
                <>
                  <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-500/30 text-amber-900 dark:text-amber-200 space-y-1.5 leading-relaxed">
                    <div className="font-bold">
                      {lang === 'bn' ? 'Cloudflare-এ ৩টি সহজ ধাপ:' : '3 Easy Steps in Cloudflare:'}
                    </div>
                    <p>1. {lang === 'bn' ? 'DNS → Records-এ গিয়ে A অথবা CNAME রেকর্ড * (Proxied Orange Cloud ON) যোগ করুন।' : 'In DNS → Records, add CNAME for * pointing to your Render hostname (Proxied ON).'}</p>
                    <p>2. {lang === 'bn' ? 'Workers & Pages → Create Worker-এ নিচের কোড পেস্ট করে ORIGIN_HOST-এ আপনার Render ডোমেইন দিন ও Deploy চাপুন।' : 'Create a Cloudflare Worker, paste the script below, set ORIGIN_HOST to your Render hostname, and Deploy.'}</p>
                    <p>3. {lang === 'bn' ? 'Worker → Settings → Triggers → Routes-এ এই ২টি রুট যোগ করুন:' : 'Add these 2 Worker Routes:'}</p>
                    <div className="flex flex-wrap gap-1.5 font-mono text-[11px] pt-1">
                      {(cfWorkerData?.routes || []).map((rt) => (
                        <span key={rt} className="px-2 py-0.5 rounded bg-white/80 dark:bg-slate-900 border border-amber-300 dark:border-amber-500/40 text-amber-800 dark:text-amber-300 font-bold">
                          {rt}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-700 dark:text-slate-200">
                        cloudflare-worker.js
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          if (!cfWorkerData?.workerScript) return;
                          navigator.clipboard?.writeText(cfWorkerData.workerScript);
                          setCopiedCfWorker(true);
                          setTimeout(() => setCopiedCfWorker(false), 2000);
                        }}
                        className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-bold"
                      >
                        {copiedCfWorker ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedCfWorker ? (lang === 'bn' ? 'কপি হয়েছে' : 'Copied!') : (lang === 'bn' ? 'Worker কোড কপি' : 'Copy Worker Code')}</span>
                      </button>
                    </div>
                    <pre className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-emerald-300 overflow-x-auto max-h-72 leading-relaxed">
                      {cfWorkerData?.workerScript || ''}
                    </pre>
                  </div>
                </>
              )}
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setShowCfWorkerModal(false)}
                className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold"
              >
                {lang === 'bn' ? 'বন্ধ করুন' : 'Done'}
              </button>
            </div>
          </div>
        </div>
      )}

      {previewSite && (
        <SiteViewerModal site={previewSite} onClose={() => setPreviewSite(null)} lang={lang} />
      )}
    </div>
  );
};
