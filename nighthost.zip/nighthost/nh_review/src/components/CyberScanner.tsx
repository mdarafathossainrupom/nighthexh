import React, { useEffect, useState, useRef } from 'react';
import { Cpu, Terminal, Radio, Loader2 } from 'lucide-react';

interface CyberScannerProps {
  mode: 'startup' | 'deploy' | 'scan';
  title?: string;
  subtitle?: string;
  progress?: number; // 0 to 100
  currentStepMessage?: string;
  checksum?: string;
  filesCount?: number;
  hiddenCount?: number;
  isBusy?: boolean;
  busyMessage?: string;
  onComplete?: () => void;
}

export const CyberScanner: React.FC<CyberScannerProps> = ({
  mode,
  title = 'NIGHTHOST NEURAL SCANNER',
  subtitle = 'Verifying sandbox environment & security tokens...',
  progress: externalProgress,
  currentStepMessage,
  checksum = '0x8f3b29c1',
  filesCount = 0,
  hiddenCount = 0,
  isBusy = false,
  busyMessage,
  onComplete,
}) => {
  const [internalProgress, setInternalProgress] = useState(0);
  const [stepIndex, setStepIndex] = useState(0);
  const completedRef = useRef(false);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  const steps = [
    'Initializing quantum cloud container sandbox...',
    'Inspecting root file hierarchy & hidden config vaults (.env, .htaccess)...',
    'Analyzing entry points (index.html / app.py / server.js) & scripts...',
    'Performing deep AST vulnerability audit & integrity hash...',
    'Synchronizing micro-routes with NIGHTHOST Edge Gateway...',
    'Finalizing deployment & booting isolated runtime...',
  ];

  useEffect(() => {
    if (externalProgress !== undefined) {
      setInternalProgress(externalProgress);
      return;
    }

    completedRef.current = false;
    const interval = setInterval(() => {
      setInternalProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          if (!completedRef.current && onCompleteRef.current) {
            completedRef.current = true;
            setTimeout(() => onCompleteRef.current?.(), 150);
          }
          return 100;
        }
        const next = prev + Math.floor(Math.random() * 18) + 14;
        const bounded = Math.min(100, next);
        setStepIndex(Math.min(steps.length - 1, Math.floor((bounded / 100) * steps.length)));
        return bounded;
      });
    }, 95);

    return () => clearInterval(interval);
  }, [externalProgress, steps.length]);

  const activeMessage =
    currentStepMessage || (isBusy && busyMessage) || steps[stepIndex];
  const displayProgress =
    externalProgress !== undefined
      ? Math.max(0, Math.min(100, Math.round(externalProgress)))
      : isBusy && internalProgress >= 99
      ? 99
      : internalProgress;

  return (
    <div className={`relative flex flex-col items-center justify-center p-6 sm:p-8 overflow-hidden rounded-2xl border border-cyan-500/20 bg-slate-950/90 backdrop-blur-xl shadow-2xl shadow-cyan-950/40 ${mode === 'startup' ? 'min-h-[380px] w-full max-w-lg mx-auto' : 'w-full'}`}>
      
      {/* Background Cyber Grid */}
      <div className="absolute inset-0 cyber-grid-dense opacity-40 pointer-events-none" />

      {/* Laser Scanning Line */}
      <div className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_#22d3ee] animate-laser-scan pointer-events-none" />

      {/* Dual Holographic Radar Reticle */}
      <div className="relative w-40 h-40 sm:w-44 sm:h-44 mb-6 flex items-center justify-center">
        {/* Outer Ring */}
        <div className="absolute inset-0 rounded-full border border-dashed border-cyan-500/40 animate-pulse-ring" />
        
        {/* Rotating Radar Ring */}
        <div className="absolute inset-2 rounded-full border-2 border-t-cyan-400 border-r-transparent border-b-indigo-500 border-l-transparent animate-radar-sweep shadow-[0_0_20px_rgba(34,211,238,0.25)]" />

        {/* Counter-rotating Inner Ring */}
        <div className="absolute inset-6 rounded-full border border-t-transparent border-r-emerald-400 border-b-transparent border-l-emerald-500/30 animate-[radar-sweep_4s_linear_infinite_reverse]" />

        {/* Center Target & Pulse Dot */}
        <div className="relative z-10 w-20 h-20 rounded-full bg-slate-900/90 border border-cyan-400/50 flex flex-col items-center justify-center shadow-inner">
          {isBusy ? (
            <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
          ) : (
            <Cpu className="w-8 h-8 text-cyan-400 animate-pulse" />
          )}
          <span className="text-[10px] font-mono tabular-nums font-bold text-cyan-300 mt-1">
            {displayProgress}%
          </span>
        </div>

        {/* Reticle Crosshairs */}
        <div className="absolute inset-x-0 h-px bg-cyan-500/20" />
        <div className="absolute inset-y-0 w-px bg-cyan-500/20" />
      </div>

      {/* Scanner Header */}
      <div className="text-center z-10 mb-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-semibold tracking-wider uppercase mb-2 shadow-[0_0_10px_rgba(6,182,212,0.15)]">
          <Radio className="w-3.5 h-3.5 animate-pulse text-cyan-400" />
          {title}
        </div>
        <p className="text-sm text-slate-400 font-medium">{subtitle}</p>
      </div>

      {/* Live Step Log Box */}
      <div className="w-full bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 z-10 font-mono text-xs text-slate-300 shadow-inner">
        <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800 pb-2 mb-2">
          <div className="flex items-center gap-1.5 text-cyan-400">
            <Terminal className="w-3.5 h-3.5" />
            <span>TELEMETRY FEED</span>
          </div>
          <span className="text-slate-400 font-mono">HASH: {checksum}</span>
        </div>

        <div className="flex items-start gap-2 text-cyan-200">
          <div className="w-2 h-2 rounded-full bg-cyan-400 mt-1 animate-ping flex-shrink-0" />
          <span className="leading-relaxed font-sans text-xs text-cyan-100 break-words">{activeMessage}</span>
        </div>

        {filesCount > 0 && (
          <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
            <span>মোট ফাইল: <strong className="text-white">{filesCount}</strong></span>
            {hiddenCount > 0 && (
              <span className="text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-500/30">
                🔒 {hiddenCount}টি হিডেন/কনফিগ ফাইল সুরক্ষিত
              </span>
            )}
          </div>
        )}
      </div>

      {/* Progress Bar */}
      <div className="w-full mt-4 z-10">
        <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
          <div
            className="h-full bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-400 transition-all duration-300 ease-out shadow-[0_0_10px_#06b6d4]"
            style={{ width: `${displayProgress}%` }}
          />
        </div>
        <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono mt-1.5">
          <span>STATUS: {isBusy ? 'DEPLOYING_TO_CLOUD' : 'SCANNING_ACTIVE'}</span>
          <span className="text-cyan-400 font-semibold tabular-nums">{displayProgress}% READY</span>
        </div>
      </div>
    </div>
  );
};
