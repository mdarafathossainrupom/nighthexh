import React, { useState, useEffect, useCallback } from 'react';
import { HostedSite, SiteHealthReport } from '../types';
import { storage } from '../services/storage';
import { buildSubdomainUrls, formatStorageFromKb } from '../services/format';
import { diagnoseRuntimeError } from '../services/siteEngine';
import {
  X,
  ExternalLink,
  RotateCw,
  Smartphone,
  Tablet,
  Monitor,
  Copy,
  Check,
  FileText,
  Terminal,
  Lock,
  Edit3,
  Cpu,
  RefreshCw,
  Wrench,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Download,
  Save,
  Loader2,
  Globe,
  Sparkles,
  Undo2,
} from 'lucide-react';

interface SiteViewerModalProps {
  site: HostedSite;
  onClose: () => void;
  onSlugUpdated?: (newSlug: string) => void;
  lang: 'bn' | 'en';
}

type DeviceMode = 'desktop' | 'tablet' | 'mobile';

export const SiteViewerModal: React.FC<SiteViewerModalProps> = ({
  site,
  onClose,
  onSlugUpdated,
  lang,
}) => {
  const [liveSite, setLiveSite] = useState<HostedSite>(site);
  const [device, setDevice] = useState<DeviceMode>('desktop');
  const [copied, setCopied] = useState(false);
  const [isEditingSlug, setIsEditingSlug] = useState(false);
  const [slugInput, setSlugInput] = useState(site.slug);
  const [slugError, setSlugError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'preview' | 'files' | 'logs'>('preview');
  const [refreshKey, setRefreshKey] = useState(0);
  const [runtimeInfo, setRuntimeInfo] = useState<{
    hasBackend: boolean;
    runtime: string;
    backendEntry: string | null;
    state?: {
      status: string;
      port: number;
      logs: string[];
      errorMessage?: string;
    };
  } | null>(null);
  const [isRestartingRuntime, setIsRestartingRuntime] = useState(false);
  const [healthReport, setHealthReport] = useState<SiteHealthReport | null>(null);
  const [checkingHealth, setCheckingHealth] = useState(false);
  const [copiedError, setCopiedError] = useState(false);
  const [selectedFilePath, setSelectedFilePath] = useState<string | null>(null);
  const [copiedFileCode, setCopiedFileCode] = useState(false);

  // Live code editor state
  const [isEditingFile, setIsEditingFile] = useState(false);
  const [fileDraftContent, setFileDraftContent] = useState('');
  const [savingFile, setSavingFile] = useState(false);
  const [loadingFile, setLoadingFile] = useState(false);
  const [fetchedFiles, setFetchedFiles] = useState<HostedSite['files']>({});
  const [fileSaveMsg, setFileSaveMsg] = useState<{ text: string; error?: boolean } | null>(null);
  const [healingSite, setHealingSite] = useState(false);
  const [undoingHeal, setUndoingHeal] = useState(false);
  const [healMsg, setHealMsg] = useState<{ text: string; error?: boolean } | null>(null);
  const [copiedWildcard, setCopiedWildcard] = useState(false);

  useEffect(() => {
    setLiveSite(site);
    setSlugInput(site.slug);
    setFetchedFiles({});
  }, [site]);

  useEffect(() => {
    return storage.subscribe(() => {
      const updated = storage.getSites().find((s) => s.id === site.id);
      if (updated) {
        setLiveSite(updated);
      }
    });
  }, [site.id]);

  const fetchRuntimeStatus = useCallback(async () => {
    try {
      const res = await fetch(`/api/sites/${liveSite.id}/runtime`);
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setRuntimeInfo(data);
        }
      }
    } catch {
      // ignore network fetch errors
    }
  }, [liveSite.id]);

  const fetchHealthReport = useCallback(async () => {
    setCheckingHealth(true);
    try {
      const res = await fetch(`/api/sites/${liveSite.id}/health`, { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setHealthReport(data as SiteHealthReport);
        }
      }
    } catch {
      // ignore health probe error
    } finally {
      setCheckingHealth(false);
    }
  }, [liveSite.id]);

  useEffect(() => {
    fetchHealthReport();
  }, [fetchHealthReport]);

  useEffect(() => {
    if (activeTab !== 'logs') return;
    fetchRuntimeStatus();
    const timer = setInterval(fetchRuntimeStatus, 3000);
    return () => clearInterval(timer);
  }, [activeTab, fetchRuntimeStatus]);

  const handleRestartRuntime = async () => {
    setIsRestartingRuntime(true);
    try {
      const res = await fetch(`/api/sites/${liveSite.id}/runtime/restart`, { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setRuntimeInfo(data);
          setRefreshKey((k) => k + 1);
          fetchHealthReport();
        }
      }
    } finally {
      setIsRestartingRuntime(false);
    }
  };

  const handleTriggerAutoHeal = async () => {
    setHealingSite(true);
    setHealMsg(null);
    try {
      const res = await storage.triggerAutoHealAsync(liveSite.id);
      if (res.success && res.site) {
        setLiveSite(res.site);
        setRefreshKey((k) => k + 1);
        fetchHealthReport();
        fetchRuntimeStatus();
        setHealMsg({
          text:
            res.message ||
            (lang === 'bn'
              ? 'অটো-হিল সম্পন্ন হয়েছে এবং প্রজেক্ট আপডেট হয়েছে।'
              : 'Auto-Heal finished and project updated.'),
        });
      } else {
        setHealMsg({
          text: res.message || (lang === 'bn' ? 'অটো-হিল ব্যর্থ হয়েছে।' : 'Auto-Heal failed.'),
          error: true,
        });
      }
    } finally {
      setHealingSite(false);
    }
  };

  const handleUndoAutoHeal = async () => {
    setUndoingHeal(true);
    setHealMsg(null);
    try {
      const res = await storage.undoAutoHealAsync(liveSite.id);
      if (res.success && res.site) {
        setLiveSite(res.site);
        setRefreshKey((k) => k + 1);
        fetchHealthReport();
        fetchRuntimeStatus();
        setHealMsg({
          text:
            res.message ||
            (lang === 'bn'
              ? 'পূর্বের সংরক্ষিত কোডে সফলভাবে ফিরিয়ে আনা হয়েছে!'
              : 'Successfully restored previous code snapshot!'),
        });
      } else {
        setHealMsg({
          text: res.message || (lang === 'bn' ? 'পূর্বের কোডে ফেরানো যায়নি।' : 'Undo failed.'),
          error: true,
        });
      }
    } finally {
      setUndoingHeal(false);
    }
  };

  const handleCopyErrorLogs = () => {
    const rawLogs = [
      healthReport?.detailBn || '',
      runtimeInfo?.state?.errorMessage || '',
      ...(runtimeInfo?.state?.logs || []),
      healthReport?.errorText || '',
    ]
      .filter(Boolean)
      .join('\n');
    if (!rawLogs) return;
    navigator.clipboard?.writeText(rawLogs);
    setCopiedError(true);
    setTimeout(() => setCopiedError(false), 2000);
  };

  const handleCopyFileCode = (content: string) => {
    navigator.clipboard?.writeText(content);
    setCopiedFileCode(true);
    setTimeout(() => setCopiedFileCode(false), 2000);
  };

  const handleStartEditFile = (content: string) => {
    setFileDraftContent(content);
    setIsEditingFile(true);
    setFileSaveMsg(null);
  };

  const handleSaveFileEdit = async () => {
    if (!selectedFilePath) return;
    setSavingFile(true);
    setFileSaveMsg(null);
    const res = await storage.updateSiteFileAsync(liveSite.id, selectedFilePath, fileDraftContent);
    setSavingFile(false);

    if (res.success && res.site) {
      setLiveSite(res.site);
      setIsEditingFile(false);
      setRefreshKey((k) => k + 1);
      setFileSaveMsg({
        text:
          lang === 'bn'
            ? 'ফাইল সেভ এবং লাইভ প্রিভিউ আপডেট হয়েছে!'
            : 'File saved and live deployment updated!',
      });
      fetchHealthReport();
    } else {
      setFileSaveMsg({
        text:
          res.message ||
          (lang === 'bn' ? 'ফাইল সেভ করা যায়নি।' : 'Failed to save file changes.'),
        error: true,
      });
    }
  };

  const currentUser = storage.getCurrentUser();
  const subRecord =
    currentUser?.role === 'subadmin'
      ? storage
          .getSubAdmins()
          .find(s => s.id === currentUser.id || s.username.toLowerCase() === currentUser.username.toLowerCase())
      : undefined;
  const canDownloadZip = Boolean(
    currentUser &&
      (currentUser.role === 'admin' ||
        currentUser.id === liveSite.userId ||
        (currentUser.role === 'subadmin' && subRecord?.canDownloadSource === true))
  );
  const ownerSubdomain =
    liveSite.ownerSubdomain ||
    storage.getUsers().find(u => u.id === liveSite.userId)?.subdomain;

  const baseOrigin = window.location.origin;
  const primaryMountPath = ownerSubdomain
    ? `/u/${ownerSubdomain}/${liveSite.slug}`
    : liveSite.customDomain
    ? `/d/${liveSite.customDomain}`
    : `/site/${liveSite.slug}`;
  const subdomainUrls = ownerSubdomain
    ? buildSubdomainUrls(ownerSubdomain, liveSite.slug, storage.getConfig().primaryDomain)
    : null;
  const fullSiteUrl = subdomainUrls?.wildcardSiteUrl || `${baseOrigin}${primaryMountPath}`;
  const previewSrc = `${primaryMountPath}?_preview=${refreshKey}`;

  const copyUrl = () => {
    navigator.clipboard.writeText(fullSiteUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const copyWildcardDirect = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedWildcard(true);
    setTimeout(() => setCopiedWildcard(false), 2000);
  };

  const handleSaveSlug = async () => {
    setSlugError(null);
    const res = await storage.updateSiteSlugAsync(liveSite.id, slugInput);
    if (!res.success) {
      setSlugError(res.message);
      return;
    }
    setIsEditingSlug(false);
    setRefreshKey((k) => k + 1);
    if (onSlugUpdated) onSlugUpdated(slugInput);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/70 dark:bg-slate-950/85 backdrop-blur-md animate-soft-fade">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-6xl h-[92vh] flex flex-col rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden z-10 animate-modal-pop">
        {/* Top Control Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-3 sm:px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                aria-label="Close preview"
                onClick={onClose}
                className="w-3 h-3 rounded-full bg-rose-500 hover:bg-rose-600 transition"
                title={lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
              />
              <div className="w-3 h-3 rounded-full bg-amber-500/80" />
              <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
            </div>

            <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800 min-w-0">
              <span className="font-semibold text-xs text-slate-900 dark:text-white truncate max-w-[140px] sm:max-w-[200px]">
                {liveSite.name}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/30 shrink-0">
                {(liveSite.status || 'online').toUpperCase()}
              </span>
            </div>
          </div>

          {/* URL Bar */}
          <div className="flex-1 min-w-[200px] max-w-xl flex items-center gap-2">
            <div className="w-full flex items-center justify-between px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs">
              <div className="flex items-center gap-1.5 overflow-hidden font-mono">
                <Lock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                {!isEditingSlug && (
                  <>
                    <span className="text-slate-400 truncate hidden md:inline">
                      {baseOrigin}
                      {ownerSubdomain ? `/u/${ownerSubdomain}/` : liveSite.customDomain ? '/d/' : '/site/'}
                    </span>
                    <span className="text-slate-400 md:hidden">
                      {ownerSubdomain ? `/u/${ownerSubdomain}/` : liveSite.customDomain ? '/d/' : '/site/'}
                    </span>
                  </>
                )}

                {isEditingSlug ? (
                  <div className="flex flex-wrap items-center gap-1">
                    <input
                      type="text"
                      value={slugInput}
                      onChange={(e) => setSlugInput(e.target.value)}
                      placeholder="slug"
                      className="bg-slate-50 dark:bg-slate-950 border border-cyan-500 rounded px-1.5 py-0.5 text-cyan-700 dark:text-cyan-300 font-mono text-xs w-32 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleSaveSlug}
                      className="px-2 py-0.5 bg-cyan-600 text-white rounded text-[10px] font-bold"
                    >
                      {lang === 'bn' ? 'সেভ' : 'Save'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsEditingSlug(false)}
                      className="text-slate-400 text-[10px]"
                    >
                      {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                    </button>
                  </div>
                ) : (
                  <span className="text-cyan-700 dark:text-cyan-400 font-semibold truncate">
                    {ownerSubdomain ? liveSite.slug : liveSite.customDomain || liveSite.slug}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1 shrink-0">
                {!isEditingSlug && (
                  <button
                    type="button"
                    aria-label="Edit slug"
                    onClick={() => setIsEditingSlug(true)}
                    className="p-1 text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 rounded transition"
                    title={lang === 'bn' ? 'কাস্টম লিংক পরিবর্তন করুন' : 'Edit Custom Slug'}
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                )}
                <button
                  type="button"
                  aria-label="Copy site URL"
                  onClick={copyUrl}
                  className="p-1 text-slate-400 hover:text-slate-900 dark:hover:text-white rounded transition"
                  title={lang === 'bn' ? 'লিংক কপি করুন' : 'Copy Link'}
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-1.5 shrink-0">
            <div className="hidden sm:flex items-center bg-white dark:bg-slate-900 rounded-lg p-0.5 border border-slate-200 dark:border-slate-800">
              <button
                type="button"
                aria-label="Desktop view"
                onClick={() => setDevice('desktop')}
                className={`p-1.5 rounded ${device === 'desktop' ? 'bg-slate-200 dark:bg-slate-800 text-cyan-600 dark:text-cyan-400' : 'text-slate-500 dark:text-slate-400'}`}
              >
                <Monitor className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                aria-label="Tablet view"
                onClick={() => setDevice('tablet')}
                className={`p-1.5 rounded ${device === 'tablet' ? 'bg-slate-200 dark:bg-slate-800 text-cyan-600 dark:text-cyan-400' : 'text-slate-500 dark:text-slate-400'}`}
              >
                <Tablet className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                aria-label="Mobile view"
                onClick={() => setDevice('mobile')}
                className={`p-1.5 rounded ${device === 'mobile' ? 'bg-slate-200 dark:bg-slate-800 text-cyan-600 dark:text-cyan-400' : 'text-slate-500 dark:text-slate-400'}`}
              >
                <Smartphone className="w-3.5 h-3.5" />
              </button>
            </div>

            {canDownloadZip && (
              <a
                href={`/api/sites/${encodeURIComponent(liveSite.id)}/download.zip`}
                download
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-200/80 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-xs font-semibold transition"
                title={lang === 'bn' ? 'প্রজেক্ট .zip ডাউনলোড' : 'Download Project .zip'}
              >
                <Download className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span className="hidden md:inline">.zip</span>
              </a>
            )}

            <a
              href={primaryMountPath}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition"
              title={lang === 'bn' ? 'স্বতন্ত্র ট্যাবে ওপেন করুন' : 'Open in New Tab'}
            >
              <span className="hidden sm:inline">{lang === 'bn' ? 'লাইভ ট্যাব' : 'Live Tab'}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            <button
              type="button"
              aria-label="Refresh preview"
              onClick={() => setRefreshKey((k) => k + 1)}
              className="p-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            >
              <RotateCw className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              aria-label="Close modal"
              onClick={onClose}
              className="p-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:text-rose-500"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {slugError && (
          <div className="px-4 py-1.5 bg-rose-50 dark:bg-rose-950/60 border-b border-rose-200 dark:border-rose-500/30 text-rose-700 dark:text-rose-300 text-xs text-center">
            {slugError}
          </div>
        )}

        {/* Sub Tabs & AI Auto-Heal Controls */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-1.5 bg-slate-100/70 dark:bg-slate-950/50 border-b border-slate-200 dark:border-slate-800 text-xs">
          <div className="flex items-center gap-2 overflow-x-auto">
            <button
              type="button"
              onClick={() => setActiveTab('preview')}
              className={`px-3 py-1 rounded-md transition font-medium whitespace-nowrap ${
                activeTab === 'preview'
                  ? 'bg-cyan-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {lang === 'bn' ? '🌐 লাইভ প্রিভিউ' : '🌐 Live Preview'}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('files')}
              className={`px-3 py-1 rounded-md transition font-medium whitespace-nowrap ${
                activeTab === 'files'
                  ? 'bg-cyan-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {lang === 'bn' ? `📁 ফাইল (${liveSite.totalFiles})` : `📁 Files (${liveSite.totalFiles})`}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('logs')}
              className={`px-3 py-1 rounded-md transition font-medium whitespace-nowrap ${
                activeTab === 'logs'
                  ? 'bg-cyan-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {lang === 'bn' ? '📜 ডিপ্লয় লগ' : '📜 Deploy Logs'}
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={healingSite || undoingHeal}
              onClick={handleTriggerAutoHeal}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold transition shadow-sm disabled:opacity-60 whitespace-nowrap"
              title={lang === 'bn' ? 'কোডের এরর স্বয়ংক্রিয়ভাবে ঠিক করুন' : 'Auto-heal code errors with AI'}
            >
              {healingSite ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
              <span>{lang === 'bn' ? '✨ অটো-হিল' : '✨ Auto-Heal'}</span>
            </button>

            {liveSite.preHealBackup && (
              <button
                type="button"
                disabled={undoingHeal || healingSite}
                onClick={handleUndoAutoHeal}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-[11px] font-bold transition shadow-sm disabled:opacity-60 whitespace-nowrap"
                title={lang === 'bn' ? 'অটো-হিলের আগের কোডে ফিরে যান' : 'Undo AI fix and restore previous code'}
              >
                {undoingHeal ? <Loader2 className="w-3 h-3 animate-spin" /> : <Undo2 className="w-3 h-3" />}
                <span>{lang === 'bn' ? '↩ পূর্বের কোডে ফিরুন' : '↩ Undo Fix'}</span>
              </button>
            )}

            <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono hidden lg:flex items-center gap-3 pl-1">
              {subdomainUrls && subdomainUrls.wildcardSiteUrl && (
                <button
                  type="button"
                  onClick={() => copyWildcardDirect(subdomainUrls.wildcardSiteUrl!)}
                  className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 hover:underline truncate max-w-[230px]"
                  title={subdomainUrls.wildcardSiteUrl}
                >
                  <Globe className="w-3 h-3 shrink-0" />
                  <span className="truncate">{subdomainUrls.wildcardSiteUrl.replace(/^https?:\/\//, '')}</span>
                  {copiedWildcard && <Check className="w-3 h-3 shrink-0" />}
                </button>
              )}
              <span>{formatStorageFromKb(liveSite.totalSizeKb)}</span>
              <span className="tabular-nums">
                {lang === 'bn' ? 'ভিজিট:' : 'Visits:'}{' '}
                <strong className="text-slate-900 dark:text-white">{liveSite.visitsCount}</strong>
              </span>
            </div>
          </div>
        </div>

        {healMsg && (
          <div
            className={`px-4 py-2 text-xs border-b flex items-center justify-between gap-2 ${
              healMsg.error
                ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-500/30 text-rose-700 dark:text-rose-300'
                : 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
            }`}
          >
            <span className="font-medium">{healMsg.text}</span>
            <button
              type="button"
              onClick={() => setHealMsg(null)}
              className="text-[11px] opacity-70 hover:opacity-100"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Body */}
        <div className="flex-1 bg-slate-200/70 dark:bg-slate-950/90 overflow-hidden flex items-center justify-center p-2 sm:p-4">
          {activeTab === 'preview' && (
            <div
              className={`h-full bg-white rounded-xl shadow-2xl overflow-hidden transition-all duration-300 border border-slate-300 dark:border-slate-800 ${
                device === 'mobile' ? 'w-[375px] max-w-full' : device === 'tablet' ? 'w-[768px] max-w-full' : 'w-full'
              }`}
            >
              <iframe
                key={previewSrc}
                title={liveSite.name}
                src={previewSrc}
                className="w-full h-full border-0 bg-white"
              />
            </div>
          )}

          {activeTab === 'files' && (() => {
            const rawTargetFile = selectedFilePath
              ? liveSite.files[selectedFilePath] || fetchedFiles[selectedFilePath]
              : null;
            const inspectedFile = selectedFilePath
              ? (rawTargetFile && (!rawTargetFile.content && fetchedFiles[selectedFilePath]?.content)
                  ? fetchedFiles[selectedFilePath]
                  : rawTargetFile) ||
                (selectedFilePath === '.env' && isEditingFile
                  ? {
                      path: '.env',
                      content: fileDraftContent,
                      size: fileDraftContent.length,
                      isHidden: true,
                      isBinary: false,
                      type: 'config',
                    }
                  : null)
              : null;
            return (
              <div className="w-full h-full rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 overflow-y-auto space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
                  <div>
                    <span className="font-semibold text-sm text-slate-900 dark:text-white">
                      {lang === 'bn'
                        ? 'হোস্টকৃত ফাইলের তালিকা (ক্লিক করে কোড দেখুন বা লাইভ এডিট করুন)'
                        : 'Hosted Project Files (Click to Inspect & Live Edit)'}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={async () => {
                        setSelectedFilePath('.env');
                        setIsEditingFile(true);
                        setFileSaveMsg(null);
                        const existingEnv = fetchedFiles['.env']?.content || liveSite.files['.env']?.content;
                        if (existingEnv !== undefined && (existingEnv !== '' || (liveSite.files['.env']?.size || 0) === 0)) {
                          setFileDraftContent(existingEnv);
                          return;
                        }
                        if (liveSite.files['.env']) {
                          setLoadingFile(true);
                          const res = await storage.fetchSiteFileContentAsync(liveSite.id, '.env');
                          setLoadingFile(false);
                          if (res.success && res.file) {
                            setFetchedFiles(prev => ({ ...prev, ['.env']: res.file! }));
                            setFileDraftContent(res.file.content || '');
                            return;
                          }
                        }
                        setFileDraftContent('# Runtime Environment Variables\nPORT=3000\n');
                      }}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold transition shadow-sm"
                    >
                      <Lock className="w-3 h-3" />
                      <span>{lang === 'bn' ? '.env এডিট' : 'Edit .env'}</span>
                    </button>
                    {(liveSite.repairedFilesCount || 0) > 0 && (
                      <span className="text-xs text-sky-700 dark:text-sky-300 bg-sky-50 dark:bg-sky-950/60 border border-sky-200 dark:border-sky-500/30 px-2.5 py-0.5 rounded-full inline-flex items-center gap-1">
                        <Wrench className="w-3 h-3" />
                        {lang === 'bn'
                          ? `${liveSite.repairedFilesCount}টি অটো-ফিক্সড`
                          : `${liveSite.repairedFilesCount} Auto-Fixed`}
                      </span>
                    )}
                    {liveSite.hiddenFilesCount > 0 && (
                      <span className="text-xs text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-500/30 px-2.5 py-0.5 rounded-full">
                        {lang === 'bn'
                          ? `🔒 ${liveSite.hiddenFilesCount}টি হিডেন ফাইল সংরক্ষিত`
                          : `🔒 ${liveSite.hiddenFilesCount} Hidden Files Preserved`}
                      </span>
                    )}
                  </div>
                </div>

                {fileSaveMsg && (
                  <div
                    className={`p-2.5 rounded-xl text-xs border flex items-center gap-2 ${
                      fileSaveMsg.error
                        ? 'bg-rose-50 dark:bg-rose-950/50 border-rose-200 dark:border-rose-500/30 text-rose-700 dark:text-rose-300'
                        : 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
                    }`}
                  >
                    {fileSaveMsg.error ? (
                      <AlertTriangle className="w-4 h-4 shrink-0" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                    )}
                    <span>{fileSaveMsg.text}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 font-mono text-xs">
                  {Object.values(liveSite.files).map((f, i) => {
                    const isSelected = selectedFilePath === f.path;
                    return (
                      <button
                        type="button"
                        key={i}
                        onClick={async () => {
                          if (isSelected) {
                            setSelectedFilePath(null);
                            setIsEditingFile(false);
                            setFileSaveMsg(null);
                            return;
                          }
                          setSelectedFilePath(f.path);
                          setIsEditingFile(false);
                          setFileSaveMsg(null);
                          if (!f.isBinary && !f.content && !fetchedFiles[f.path] && (f.size || 0) > 0) {
                            setLoadingFile(true);
                            const res = await storage.fetchSiteFileContentAsync(liveSite.id, f.path);
                            setLoadingFile(false);
                            if (res.success && res.file) {
                              setFetchedFiles(prev => ({ ...prev, [f.path]: res.file! }));
                            }
                          }
                        }}
                        className={`p-3 rounded-xl border flex items-center justify-between text-left transition ${
                          isSelected
                            ? 'bg-cyan-50 dark:bg-cyan-950/40 border-cyan-500'
                            : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 hover:border-cyan-400'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          {f.isHidden ? (
                            <Lock className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                          ) : (
                            <FileText className="w-4 h-4 text-cyan-600 dark:text-cyan-400 flex-shrink-0" />
                          )}
                          <span className={f.isHidden ? 'text-emerald-700 dark:text-emerald-300 font-semibold truncate' : 'text-slate-700 dark:text-slate-200 truncate'}>
                            {f.path}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 shrink-0 ml-2">
                          {formatStorageFromKb((f.size || 0) / 1024)}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {inspectedFile && (
                  <div className="rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden bg-slate-950">
                    <div className="px-3.5 py-2 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
                      <span className="font-mono text-cyan-300 font-semibold truncate">{inspectedFile.path}</span>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {!inspectedFile.isBinary && !isEditingFile && (
                          <button
                            type="button"
                            onClick={() => handleStartEditFile(inspectedFile.content || '')}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-[11px] font-bold transition"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>{lang === 'bn' ? 'কোড এডিট' : 'Edit Code'}</span>
                          </button>
                        )}
                        {!inspectedFile.isBinary && isEditingFile && (
                          <>
                            <button
                              type="button"
                              onClick={() => {
                                setIsEditingFile(false);
                                setFileSaveMsg(null);
                              }}
                              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-semibold"
                            >
                              {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                            </button>
                            <button
                              type="button"
                              disabled={savingFile}
                              onClick={handleSaveFileEdit}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold transition disabled:opacity-60"
                            >
                              {savingFile ? (
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              ) : (
                                <Save className="w-3.5 h-3.5" />
                              )}
                              <span>{lang === 'bn' ? 'সেভ ও ডিপ্লয়' : 'Save & Redeploy'}</span>
                            </button>
                          </>
                        )}
                        {!inspectedFile.isBinary && !isEditingFile && (
                          <button
                            type="button"
                            onClick={() => handleCopyFileCode(inspectedFile.content || '')}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-bold transition"
                          >
                            {copiedFileCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                            <span>{copiedFileCode ? (lang === 'bn' ? 'কপি হয়েছে' : 'Copied') : (lang === 'bn' ? 'কোড কপি' : 'Copy Code')}</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedFilePath(null);
                            setIsEditingFile(false);
                          }}
                          className="p-1 text-slate-400 hover:text-white"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    {loadingFile ? (
                      <div className="p-4 text-xs text-cyan-300 flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin shrink-0" />
                        <span>{lang === 'bn' ? 'ফাইল লোড হচ্ছে...' : 'Loading file content...'}</span>
                      </div>
                    ) : inspectedFile.isBinary ? (
                      <div className="p-4 text-xs text-slate-400 font-sans">
                        {lang === 'bn' ? 'এটি একটি বাইনারি/মিডিয়া ফাইল।' : 'Binary or media file.'}
                      </div>
                    ) : isEditingFile ? (
                      <textarea
                        value={fileDraftContent}
                        onChange={(e) => setFileDraftContent(e.target.value)}
                        rows={12}
                        spellCheck={false}
                        className="w-full p-3.5 text-xs font-mono bg-slate-950 text-slate-100 focus:outline-none resize-y min-h-[240px]"
                      />
                    ) : (
                      <pre className="p-3.5 text-[11px] font-mono text-slate-200 overflow-auto max-h-64 whitespace-pre-wrap break-words">
                        {inspectedFile.content}
                      </pre>
                    )}
                  </div>
                )}
              </div>
            );
          })()}

          {activeTab === 'logs' && (
            <div className="w-full h-full rounded-xl bg-slate-950 border border-slate-800 p-4 font-mono text-xs overflow-y-auto overflow-x-hidden text-slate-300 space-y-4">
              {/* Live Health Check Diagnostic Banner */}
              <div
                className={`p-3.5 rounded-xl border font-sans space-y-2 ${
                  healthReport?.overall === 'healthy'
                    ? 'bg-emerald-950/50 border-emerald-500/40 text-emerald-200'
                    : healthReport?.overall === 'partial'
                    ? 'bg-amber-950/50 border-amber-500/40 text-amber-200'
                    : healthReport?.overall === 'down'
                    ? 'bg-rose-950/50 border-rose-500/40 text-rose-200'
                    : 'bg-slate-900 border-slate-800 text-slate-300'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 font-bold text-xs">
                    {healthReport?.overall === 'healthy' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : healthReport ? (
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    ) : (
                      <Activity className="w-4 h-4 text-cyan-400 shrink-0" />
                    )}
                    <span>
                      {healthReport
                        ? lang === 'bn'
                          ? healthReport.summaryBn
                          : healthReport.summaryEn
                        : lang === 'bn'
                        ? 'ওয়েবসাইট হেলথ যাচাই করা হচ্ছে...'
                        : 'Checking site frontend & backend health...'}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {(healthReport?.errorText || runtimeInfo?.state?.errorMessage || runtimeInfo?.state?.status === 'error') && (
                      <button
                        type="button"
                        onClick={handleCopyErrorLogs}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold transition"
                      >
                        {copiedError ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedError ? (lang === 'bn' ? 'কপি হয়েছে' : 'Copied') : (lang === 'bn' ? 'এরর কপি' : 'Copy Error')}</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={fetchHealthReport}
                      disabled={checkingHealth}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold transition"
                    >
                      <RefreshCw className={`w-3 h-3 ${checkingHealth ? 'animate-spin' : ''}`} />
                      <span>{lang === 'bn' ? 'চেক' : 'Check'}</span>
                    </button>
                  </div>
                </div>

                {healthReport && (
                  <div className="flex flex-wrap items-center gap-2 text-[11px]">
                    <span className={`px-2 py-0.5 rounded-full font-semibold ${healthReport.frontendOk ? 'bg-emerald-900/60 text-emerald-300' : 'bg-rose-900/60 text-rose-300'}`}>
                      {lang === 'bn' ? `ফ্রন্টএন্ড: ${healthReport.frontendOk ? 'সচল' : 'বন্ধ'}` : `Frontend: ${healthReport.frontendOk ? 'OK' : 'Down'}`}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full font-semibold ${healthReport.backendOk ? 'bg-emerald-900/60 text-emerald-300' : 'bg-rose-900/60 text-rose-300'}`}>
                      {lang === 'bn' ? `ব্যাকএন্ড / API: ${healthReport.backendOk ? 'সচল' : 'কাজ করছে না'}` : `Backend / API: ${healthReport.backendOk ? 'OK' : 'Failing'}`}
                    </span>
                    {(healthReport.detailBn || healthReport.detailEn) && (
                      <span className="opacity-90 break-words">
                        • {lang === 'bn' ? healthReport.detailBn : healthReport.detailEn}
                      </span>
                    )}
                  </div>
                )}
              </div>

              {runtimeInfo && (runtimeInfo.hasBackend || liveSite.runtimeType === 'node' || liveSite.runtimeType === 'python') && (
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Cpu className="w-4 h-4 text-cyan-400" />
                      <span className="text-cyan-300 font-bold uppercase">
                        {runtimeInfo.runtime} BACKEND RUNTIME
                      </span>
                      {runtimeInfo.backendEntry && (
                        <span className="text-[11px] text-slate-400">({runtimeInfo.backendEntry})</span>
                      )}
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          runtimeInfo.state?.status === 'running'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                            : runtimeInfo.state?.status === 'error'
                            ? 'bg-rose-950 text-rose-400 border border-rose-500/40'
                            : 'bg-amber-950 text-amber-300 border border-amber-500/40'
                        }`}
                      >
                        {runtimeInfo.state?.status || 'idle'}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={handleCopyErrorLogs}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold transition"
                      >
                        {copiedError ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedError ? (lang === 'bn' ? 'কপি হয়েছে' : 'Copied') : (lang === 'bn' ? 'লগ কপি' : 'Copy Log')}</span>
                      </button>
                      <button
                        type="button"
                        disabled={isRestartingRuntime}
                        onClick={handleRestartRuntime}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-bold transition disabled:opacity-60"
                      >
                        <RefreshCw className={`w-3 h-3 ${isRestartingRuntime ? 'animate-spin' : ''}`} />
                        <span>
                          {isRestartingRuntime
                            ? lang === 'bn'
                              ? 'রিস্টার্ট হচ্ছে...'
                              : 'Restarting...'
                            : lang === 'bn'
                            ? 'ব্যাকএন্ড রিস্টার্ট'
                            : 'Restart Runtime'}
                        </span>
                      </button>
                    </div>
                  </div>

                  {runtimeInfo.state?.errorMessage && (
                    <div className="text-rose-400 text-[11px] break-words">
                      Error: {runtimeInfo.state.errorMessage}
                    </div>
                  )}

                  {(runtimeInfo.state?.status === 'error' || runtimeInfo.state?.errorMessage) && (() => {
                    const diag = diagnoseRuntimeError(
                      runtimeInfo.state?.logs || [runtimeInfo.state?.errorMessage || ''],
                      (runtimeInfo.runtime as 'node' | 'python' | 'php' | 'static') || 'node',
                      runtimeInfo.backendEntry || null
                    );
                    const steps = lang === 'bn' ? diag.stepsBn : diag.stepsEn;
                    return (
                      <div className="p-3 rounded-xl bg-sky-950/60 border border-sky-500/40 space-y-1.5 text-[11px] font-sans">
                        <div className="flex items-center gap-1.5 text-sky-300 font-bold">
                          <Wrench className="w-3.5 h-3.5 shrink-0" />
                          <span>
                            {lang === 'bn'
                              ? `প্রজেক্ট সমাধান নির্দেশিকা: ${diag.titleBn}`
                              : `Project Self-Fix Guide: ${diag.titleEn}`}
                          </span>
                        </div>
                        <p className="text-slate-200 leading-relaxed">
                          {lang === 'bn' ? diag.causeBn : diag.causeEn}
                        </p>
                        <ul className="list-disc pl-4 space-y-0.5 text-sky-100/90">
                          {steps.map((step, i) => (
                            <li key={i}>{step}</li>
                          ))}
                        </ul>
                      </div>
                    );
                  })()}

                  <div className="space-y-1 max-h-44 overflow-y-auto overflow-x-hidden text-[11px]">
                    {runtimeInfo.state?.logs && runtimeInfo.state.logs.length > 0 ? (
                      runtimeInfo.state.logs.map((line, idx) => (
                        <div key={idx} className="text-slate-300 break-all sm:break-words">
                          {line}
                        </div>
                      ))
                    ) : (
                      <div className="text-slate-500">
                        {lang === 'bn'
                          ? 'এখনো কোনো রানটাইম আউটপুট আসেনি — প্রিভিউ লোড করলে চালু হবে।'
                          : 'Runtime idle — open Live Preview to trigger auto-boot or click Restart Runtime.'}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Auto-Fix AI & Rule Engine Reports */}
              {liveSite.autoFixReports && liveSite.autoFixReports.length > 0 && (
                <div className="p-3.5 rounded-xl bg-indigo-950/50 border border-indigo-500/40 space-y-2.5 font-sans">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2 text-indigo-300 font-bold text-xs">
                      <Sparkles className="w-4 h-4 text-indigo-400 shrink-0" />
                      <span>
                        {lang === 'bn'
                          ? `অটো-হিল রিপোর্ট (${liveSite.autoFixReports.length}টি পরিবর্তন)`
                          : `Auto-Heal Fix Report (${liveSite.autoFixReports.length} Patches)`}
                      </span>
                    </div>
                    {liveSite.preHealBackup && (
                      <button
                        type="button"
                        disabled={undoingHeal}
                        onClick={handleUndoAutoHeal}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-[11px] font-bold transition disabled:opacity-60"
                      >
                        <Undo2 className="w-3 h-3" />
                        <span>{lang === 'bn' ? '↩ পূর্বের কোডে ফিরুন' : '↩ Undo Fix'}</span>
                      </button>
                    )}
                  </div>
                  <div className="space-y-2">
                    {liveSite.autoFixReports.map((rep, idx) => (
                      <div
                        key={rep.id || idx}
                        className="p-2.5 rounded-lg bg-slate-900/90 border border-indigo-500/20 text-[11px] space-y-1"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-mono font-bold text-cyan-300">{rep.filePath}</span>
                          <span className="px-2 py-0.5 rounded bg-indigo-900/60 text-indigo-200 font-mono text-[10px] uppercase">
                            {rep.engine}
                          </span>
                        </div>
                        <div className="text-amber-300">
                          {lang === 'bn' ? 'সমস্যা:' : 'Issue:'} {rep.issueBn}
                        </div>
                        <div className="text-emerald-300">
                          {lang === 'bn' ? 'সমাধান:' : 'Fix:'} {rep.fixAppliedBn}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <div className="text-cyan-400 pb-2 border-b border-slate-800 flex items-center gap-2">
                  <Terminal className="w-4 h-4" />
                  <span>REALTIME DEPLOYMENT LOGS</span>
                </div>
                {liveSite.deploymentLogs.map((log, i) => (
                  <div key={i} className="flex flex-wrap sm:flex-nowrap items-start gap-1.5 sm:gap-2 min-w-0">
                    <span className="text-slate-400 shrink-0">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                    <span
                      className={`shrink-0 ${
                        log.level === 'error'
                          ? 'text-rose-400 font-bold'
                          : log.level === 'warn'
                          ? 'text-amber-400'
                          : log.level === 'success'
                          ? 'text-emerald-400 font-bold'
                          : 'text-cyan-300'
                      }`}
                    >
                      {log.level.toUpperCase()}:
                    </span>
                    <span className="text-slate-200 break-all sm:break-words min-w-0">{log.message}</span>
                  </div>
                ))}
                <div className="pt-2 text-emerald-400 flex flex-wrap items-center gap-3 min-w-0">
                  <span className="inline-flex items-center gap-1.5 break-all">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                    <span>Endpoint: /site/{liveSite.slug}</span>
                  </span>
                  {ownerSubdomain && (
                    <span className="inline-flex items-center gap-1 text-cyan-300 break-all">
                      <Globe className="w-3 h-3 shrink-0" />
                      <span>Subdomain: /u/{ownerSubdomain}/{liveSite.slug}</span>
                    </span>
                  )}
                  {subdomainUrls && subdomainUrls.wildcardSiteUrl && (
                    <a
                      href={subdomainUrls.wildcardSiteUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-emerald-300 hover:underline break-all"
                    >
                      <Globe className="w-3 h-3 shrink-0" />
                      <span>Live Domain: {subdomainUrls.wildcardSiteUrl}</span>
                    </a>
                  )}
                  {!ownerSubdomain && liveSite.customDomain && (
                    <span className="inline-flex items-center gap-1 text-cyan-300 break-all">
                      <Globe className="w-3 h-3 shrink-0" />
                      <span>Domain: /d/{liveSite.customDomain}</span>
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

