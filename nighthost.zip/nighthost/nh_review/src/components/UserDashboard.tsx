import React, { useState, useEffect, useRef } from 'react';
import { User, HostedSite, UserPageView } from '../types';
import { storage } from '../services/storage';
import { resizeImageFileToDataUrl } from '../services/avatar';
import { buildSubdomainUrls, formatStorageFromMb, formatStorageFromKb, getRoleDisplayLabel, normalizeUserSubdomain } from '../services/format';
import { FolderDeployer } from './FolderDeployer';
import { SingleFileDeployer } from './SingleFileDeployer';
import { GithubDeployer } from './GithubDeployer';
import { SiteViewerModal } from './SiteViewerModal';
import {
  Globe,
  FolderUp,
  FileCode2,
  FolderGit2,
  ExternalLink,
  MoreVertical,
  Trash2,
  Edit3,
  PauseCircle,
  PlayCircle,
  Copy,
  Check,
  HardDrive,
  Activity,
  Clock,
  Layers,
  Lock,
  Calendar,
  Megaphone,
  Eye,
  EyeOff,
  Shield,
  UserCog,
  Camera,
  Loader2,
  ArrowLeft,
  Search,
  Download,
  Terminal,
  Send,
  ShieldCheck,
  Link2,
  Wrench,
  Bell,
  Sparkles,
} from 'lucide-react';

interface UserDashboardProps {
  user: User;
  lang: 'bn' | 'en';
  activePage?: UserPageView;
  onChangePage?: (page: UserPageView) => void;
  onOpenAdminPanel?: () => void;
  externalProfileTrigger?: number;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  user,
  lang,
  activePage = 'overview',
  onChangePage,
  onOpenAdminPanel,
  externalProfileTrigger = 0,
}) => {
  const [sites, setSites] = useState<HostedSite[]>([]);
  const [selectedSiteForPreview, setSelectedSiteForPreview] = useState<HostedSite | null>(null);
  const [activeMenuSiteId, setActiveMenuSiteId] = useState<string | null>(null);
  const [copiedSlugId, setCopiedSlugId] = useState<string | null>(null);
  const [confirmDeleteSite, setConfirmDeleteSite] = useState<HostedSite | null>(null);

  const [siteSearch, setSiteSearch] = useState('');
  const [runtimeFilter, setRuntimeFilter] = useState<'all' | 'static' | 'php' | 'node' | 'python'>('all');

  const [editingSite, setEditingSite] = useState<HostedSite | null>(null);
  const [newSlugInput, setNewSlugInput] = useState('');
  const [slugError, setSlugError] = useState<string | null>(null);
  const [savingSlug, setSavingSlug] = useState(false);
  const [deletingSite, setDeletingSite] = useState(false);
  const [togglingSiteId, setTogglingSiteId] = useState<string | null>(null);

  // Profile & Photo Form State
  const [profileFullName, setProfileFullName] = useState(user.fullName || '');
  const [profileEmail, setProfileEmail] = useState(user.email || '');
  const [profilePassword, setProfilePassword] = useState('');
  const [showProfilePass, setShowProfilePass] = useState(false);
  const [profileAvatarDraft, setProfileAvatarDraft] = useState<string | null | undefined>(undefined);
  const [profileAvatarKb, setProfileAvatarKb] = useState<number>(user.avatarSizeKb || 0);
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileMsg, setProfileMsg] = useState<{ text: string; error?: boolean } | null>(null);
  const [profileSubdomain, setProfileSubdomain] = useState(user.subdomain || '');
  const [profileSubStatus, setProfileSubStatus] = useState<{
    checking: boolean;
    available?: boolean;
    message?: string;
  }>({ checking: false });
  const [savingSubdomain, setSavingSubdomain] = useState(false);
  const [subdomainFeedback, setSubdomainFeedback] = useState<{ text: string; error?: boolean } | null>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  const [validity, setValidity] = useState(storage.getRemainingApprovalTime(user, lang));
  const [broadcastMessage, setBroadcastMessage] = useState(storage.getConfig().broadcastMessage || '');
  const config = storage.getConfig();

  const menuContainerRef = useRef<HTMLDivElement>(null);

  const navigatePage = (page: UserPageView) => {
    if (onChangePage) {
      onChangePage(page);
    } else {
      storage.setSavedUserPage(page);
    }
  };

  useEffect(() => {
    const update = () => {
      setSites(storage.getSites(user.id));
      setValidity(storage.getRemainingApprovalTime(user, lang));
      setBroadcastMessage(storage.getConfig().broadcastMessage || '');
    };
    update();
    const interval = setInterval(update, 1000);
    const unsub = storage.subscribe(update);
    return () => {
      clearInterval(interval);
      unsub();
    };
  }, [user, lang]);

  useEffect(() => {
    setProfileFullName(user.fullName || '');
    setProfileEmail(user.email || '');
    setProfilePassword('');
    setShowProfilePass(false);
    setProfileAvatarDraft(undefined);
    setProfileAvatarKb(user.avatarSizeKb || 0);
    setProfileMsg(null);
    setProfileSubdomain(user.subdomain || '');
    setSubdomainFeedback(null);
  }, [user.id, user.fullName, user.email, user.avatarSizeKb, user.subdomain, activePage]);

  useEffect(() => {
    if (activePage !== 'profile') return;
    const candidate = normalizeUserSubdomain(profileSubdomain);
    if (!candidate || candidate === (user.subdomain || '')) {
      setProfileSubStatus({ checking: false });
      return;
    }
    let cancelled = false;
    setProfileSubStatus({ checking: true });
    const t = window.setTimeout(async () => {
      const res = await storage.checkSubdomainAvailabilityAsync(candidate);
      if (!cancelled) {
        setProfileSubStatus({
          checking: false,
          available: res.available,
          message: res.message,
        });
      }
    }, 260);
    return () => {
      cancelled = true;
      window.clearTimeout(t);
    };
  }, [activePage, profileSubdomain, user.subdomain]);

  const handleSaveProfileSubdomain = async () => {
    setSubdomainFeedback(null);
    setSavingSubdomain(true);
    try {
      const res = await storage.saveUserSubdomainAsync(profileSubdomain);
      setSubdomainFeedback({ text: res.message, error: !res.success });
    } finally {
      setSavingSubdomain(false);
    }
  };

  useEffect(() => {
    if (externalProfileTrigger > 0) {
      navigatePage('profile');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [externalProfileTrigger]);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (menuContainerRef.current && !menuContainerRef.current.contains(e.target as Node)) {
        setActiveMenuSiteId(null);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const getPrimarySitePath = (site: HostedSite) => {
    const ownerSub = site.ownerSubdomain || (site.userId === user.id ? user.subdomain : undefined);
    if (ownerSub) return `/u/${ownerSub}/${site.slug}`;
    if (site.customDomain) return `/d/${site.customDomain}`;
    return `/site/${site.slug}`;
  };

  const handleCopyLink = (site: HostedSite, targetPathOrUrl?: string) => {
    const raw = targetPathOrUrl || getPrimarySitePath(site);
    const url = /^https?:\/\//i.test(raw) ? raw : `${window.location.origin}${raw}`;
    navigator.clipboard.writeText(url);
    setCopiedSlugId(site.id);
    setTimeout(() => setCopiedSlugId(null), 2000);
  };

  const handleToggleStatus = async (siteId: string) => {
    setTogglingSiteId(siteId);
    try {
      storage.toggleSiteStatus(siteId);
    } finally {
      setTogglingSiteId(null);
      setActiveMenuSiteId(null);
    }
  };

  const handleConfirmDeleteSite = async () => {
    if (!confirmDeleteSite) return;
    setDeletingSite(true);
    try {
      storage.deleteSite(confirmDeleteSite.id);
      setConfirmDeleteSite(null);
      setActiveMenuSiteId(null);
    } finally {
      setDeletingSite(false);
    }
  };

  const openSlugModal = (site: HostedSite) => {
    setEditingSite(site);
    setNewSlugInput(site.slug);
    setSlugError(null);
    setActiveMenuSiteId(null);
  };

  const handleSaveCustomSlug = async () => {
    if (!editingSite) return;
    setSavingSlug(true);
    setSlugError(null);
    try {
      const res = await storage.updateSiteSlugAsync(editingSite.id, newSlugInput);
      if (!res.success) {
        setSlugError(res.message);
        return;
      }
      setEditingSite(null);
    } finally {
      setSavingSlug(false);
    }
  };

  const handleAvatarFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setProfileMsg(null);
    try {
      const { dataUrl, sizeKb } = await resizeImageFileToDataUrl(file, 360, 0.82);
      setProfileAvatarDraft(dataUrl);
      setProfileAvatarKb(sizeKb);
    } catch {
      setProfileMsg({
        text: lang === 'bn' ? 'ছবিটি প্রসেস করা যায়নি।' : 'Failed to process image.',
        error: true,
      });
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileMsg(null);
    if (profilePassword.trim() && profilePassword.trim().length < 4) {
      setProfileMsg({
        text: lang === 'bn' ? 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।' : 'Password must be at least 4 characters.',
        error: true,
      });
      return;
    }

    setSavingProfile(true);
    const res = await storage.updateProfileAsync(user.id, {
      fullName: profileFullName.trim(),
      email: profileEmail.trim(),
      password: profilePassword.trim() ? profilePassword.trim() : undefined,
      avatarDataUrl: profileAvatarDraft,
    });
    setSavingProfile(false);

    if (res.success) {
      setProfilePassword('');
      setProfileMsg({
        text: lang === 'bn' ? 'প্রোফাইল ও ছবি সফলভাবে সেভ হয়েছে।' : 'Profile & photo updated successfully.',
        error: false,
      });
    } else {
      setProfileMsg({
        text: res.message || (lang === 'bn' ? 'প্রোফাইল আপডেট ব্যর্থ হয়েছে।' : 'Failed to update profile.'),
        error: true,
      });
    }
  };

  const handleDeploySuccess = (site: HostedSite) => {
    navigatePage('sites');
    setSelectedSiteForPreview(site);
  };

  const storageLimit = user.storageLimitMb || 100;
  const sitesSizeKb = sites.reduce((acc, s) => acc + (Number(s.totalSizeKb) || 0), 0);
  const avatarSizeKb = Number(user.avatarSizeKb) || 0;
  const exactKbUsed = sitesSizeKb + avatarSizeKb;
  const storageUsed = exactKbUsed > 0 ? exactKbUsed / 1024 : 0;
  const storageFree = Math.max(0, storageLimit - storageUsed);
  const rawStoragePercent = storageLimit > 0 ? (exactKbUsed / (storageLimit * 1024)) * 100 : 0;
  const storagePercentText =
    exactKbUsed === 0
      ? '0'
      : rawStoragePercent > 0 && rawStoragePercent < 1
      ? '<1'
      : String(Math.min(100, Math.round(rawStoragePercent)));
  const poolDenomMb =
    user.role === 'admin'
      ? Math.max(100, storage.getServerStorageStats().configuredPoolMb || 1024)
      : storageLimit;
  const sitesBarPct = sitesSizeKb > 0 ? Math.min(100, (sitesSizeKb / (poolDenomMb * 1024)) * 100) : 0;
  const avatarBarPct =
    avatarSizeKb > 0 ? Math.min(100 - sitesBarPct, (avatarSizeKb / (poolDenomMb * 1024)) * 100) : 0;
  const inboxNoticeCount = storage.getPopupMessagesForUser(user.id).length;
  const unreadInboxCount = storage.getUnreadPopupMessagesForUser(user.id).length;
  const totalVisits = sites.reduce((acc, s) => acc + s.visitsCount, 0);
  const totalBandwidth = sites.reduce((acc, s) => acc + s.bandwidthMb, 0);

  const filteredSites = sites.filter((s) => {
    const q = siteSearch.trim().toLowerCase();
    const matchQuery =
      !q ||
      s.name.toLowerCase().includes(q) ||
      s.slug.toLowerCase().includes(q) ||
      (s.description || '').toLowerCase().includes(q);
    const rt = s.runtimeType || 'static';
    const matchRuntime = runtimeFilter === 'all' || rt === runtimeFilter;
    return matchQuery && matchRuntime;
  });

  const renderBackBanner = (title: string, subtitle?: string) => (
    <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={() => navigatePage('overview')}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-xs font-bold transition shrink-0"
        >
          <ArrowLeft className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
          <span>{lang === 'bn' ? 'ড্যাশবোর্ডে ফিরুন' : 'Back to Dashboard'}</span>
        </button>
        <div className="min-w-0">
          <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white truncate">{title}</h2>
          {subtitle && (
            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">{subtitle}</p>
          )}
        </div>
      </div>
    </div>
  );

  const renderSiteCard = (site: HostedSite) => (
    <div
      key={site.id}
      className="rounded-2xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 hover:border-cyan-500/50 p-4 sm:p-5 flex flex-col justify-between transition group shadow-sm"
    >
      <div>
        <div className="flex items-center justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-2 min-w-0">
            <span
              className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase ${
                site.type === 'folder'
                  ? 'bg-cyan-50 dark:bg-cyan-950/80 border border-cyan-200 dark:border-cyan-500/30 text-cyan-700 dark:text-cyan-300'
                  : site.type === 'single-file'
                  ? 'bg-indigo-50 dark:bg-indigo-950/80 border border-indigo-200 dark:border-indigo-500/30 text-indigo-700 dark:text-indigo-300'
                  : 'bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              {site.type === 'folder'
                ? lang === 'bn'
                  ? '📁 ফোল্ডার'
                  : '📁 FOLDER'
                : site.type === 'single-file'
                ? lang === 'bn'
                  ? '⚡ সিঙ্গেল ফাইল'
                  : '⚡ SINGLE FILE'
                : '🐙 GITHUB'}
            </span>

            <span
              className={`inline-flex items-center gap-1 text-[10px] font-semibold ${
                site.status === 'online'
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-amber-600 dark:text-amber-400'
              }`}
            >
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  site.status === 'online' ? 'bg-emerald-500' : 'bg-amber-500'
                }`}
              />
              {(site.status || 'online').toUpperCase()}
            </span>
          </div>

          <div className="relative">
            <button
              type="button"
              aria-label={`Manage ${site.name}`}
              onClick={(e) => {
                e.stopPropagation();
                setActiveMenuSiteId(activeMenuSiteId === site.id ? null : site.id);
              }}
              className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 transition"
              title={lang === 'bn' ? 'ম্যানেজ অপশন' : 'Manage Site'}
            >
              <MoreVertical className="w-4 h-4" />
            </button>

            {activeMenuSiteId === site.id && (
              <div className="absolute right-0 mt-1 w-48 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-1.5 shadow-2xl z-30 text-xs divide-y divide-slate-100 dark:divide-slate-800/60">
                <div className="py-1">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedSiteForPreview(site);
                      setActiveMenuSiteId(null);
                    }}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900 transition"
                  >
                    <Eye className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                    <span>{lang === 'bn' ? 'প্রিভিউ, ফাইল ও এডিট' : 'Inspect, Edit & Preview'}</span>
                  </button>

                  <a
                    href={`/api/sites/${encodeURIComponent(site.id)}/download.zip`}
                    onClick={() => setActiveMenuSiteId(null)}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900 transition"
                  >
                    <Download className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span>{lang === 'bn' ? 'ZIP ডাউনলোড' : 'Download ZIP'}</span>
                  </a>

                  <button
                    type="button"
                    onClick={() => openSlugModal(site)}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900 transition"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                    <span>{lang === 'bn' ? 'কাস্টম লিংক পরিবর্তন' : 'Edit Slug'}</span>
                  </button>

                  <button
                    type="button"
                    disabled={togglingSiteId === site.id}
                    onClick={() => handleToggleStatus(site.id)}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900 transition disabled:opacity-50"
                  >
                    {togglingSiteId === site.id ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-cyan-500" />
                    ) : site.status === 'online' ? (
                      <PauseCircle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                    ) : (
                      <PlayCircle className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    )}
                    <span>
                      {site.status === 'online'
                        ? lang === 'bn'
                          ? 'পজ রাখুন'
                          : 'Pause Site'
                        : lang === 'bn'
                        ? 'অনলাইন করুন'
                        : 'Resume Site'}
                    </span>
                  </button>
                </div>

                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setConfirmDeleteSite(site);
                      setActiveMenuSiteId(null);
                    }}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{lang === 'bn' ? 'মুছে ফেলুন' : 'Delete'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate">{site.name}</h3>
        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">
          {site.description || 'Hosted application'}
        </p>

        <div className="mt-3 space-y-1.5">
          {(() => {
            const ownerSub = site.ownerSubdomain || (site.userId === user.id ? user.subdomain : undefined);
            if (!ownerSub) return null;
            const wild = buildSubdomainUrls(ownerSub, site.slug, config.primaryDomain);
            return (
              <>
                {wild.wildcardSiteUrl && (
                  <div className="p-2 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-500/30 flex items-center justify-between gap-2 text-xs font-mono">
                    <a
                      href={wild.wildcardSiteUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-emerald-700 dark:text-emerald-300 hover:underline truncate text-[11px] font-bold min-w-0"
                      title={wild.wildcardSiteUrl}
                    >
                      <Globe className="w-3 h-3 shrink-0" />
                      <span className="truncate">{wild.wildcardSiteUrl.replace(/^https?:\/\//, '')}</span>
                    </a>
                    <button
                      type="button"
                      aria-label={`Copy wildcard domain link for ${site.name}`}
                      onClick={() => handleCopyLink(site, wild.wildcardSiteUrl!)}
                      className="p-1 text-emerald-600 dark:text-emerald-400 hover:text-emerald-800 dark:hover:text-emerald-200 transition shrink-0"
                      title={lang === 'bn' ? 'লাইভ সাবডোমেইন লিংক কপি করুন' : 'Copy Live Subdomain URL'}
                    >
                      {copiedSlugId === site.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-500" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                )}

                <div className="p-2 rounded-xl bg-cyan-50/50 dark:bg-cyan-950/20 border border-cyan-200/70 dark:border-cyan-500/20 flex items-center justify-between gap-2 text-xs font-mono">
                  <a
                    href={wild.pathUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-cyan-700 dark:text-cyan-300 hover:underline truncate text-[11px] font-semibold min-w-0"
                  >
                    <span className="truncate">{wild.pathUrl}</span>
                  </a>
                  <button
                    type="button"
                    aria-label={`Copy mount path for ${site.name}`}
                    onClick={() => handleCopyLink(site, wild.pathUrl)}
                    className="p-1 text-cyan-600 dark:text-cyan-400 hover:text-cyan-800 dark:hover:text-cyan-200 transition shrink-0"
                    title={lang === 'bn' ? 'সাবপাথ কপি করুন' : 'Copy Mount Path'}
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </>
            );
          })()}

          {!site.ownerSubdomain && !(site.userId === user.id && user.subdomain) && site.customDomain && (
            <div className="p-2 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-500/30 flex items-center justify-between gap-2 text-xs font-mono">
              <a
                href={`/d/${site.customDomain}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-emerald-700 dark:text-emerald-300 hover:underline truncate text-[11px] font-bold min-w-0"
              >
                <Globe className="w-3 h-3 shrink-0" />
                <span className="truncate">/d/{site.customDomain}</span>
              </a>
              <button
                type="button"
                aria-label={`Copy legacy domain for ${site.name}`}
                onClick={() => handleCopyLink(site, `/d/${site.customDomain}`)}
                className="p-1 text-emerald-600 dark:text-emerald-400 hover:text-emerald-800 dark:hover:text-emerald-200 transition shrink-0"
                title={lang === 'bn' ? 'ডোমেইন লিংক কপি করুন' : 'Copy Domain Link'}
              >
                {copiedSlugId === site.id ? (
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          )}

          <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800/80 flex items-center justify-between gap-2 text-xs font-mono">
            <a
              href={`/site/${site.slug}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-cyan-700 dark:text-cyan-400 hover:underline truncate text-[11px]"
            >
              /site/{site.slug}
            </a>
            <button
              type="button"
              aria-label={`Copy link for ${site.name}`}
              onClick={() => handleCopyLink(site, `/site/${site.slug}`)}
              className="p-1 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition shrink-0"
              title={lang === 'bn' ? 'স্লাগ লিংক কপি করুন' : 'Copy Slug Link'}
            >
              {copiedSlugId === site.id ? (
                <Check className="w-3.5 h-3.5 text-emerald-500" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
            </button>
          </div>
        </div>

        <div className="mt-2.5 flex flex-wrap items-center gap-2 text-[10px] text-slate-500 dark:text-slate-400 font-mono">
          <span className="tabular-nums">
            {site.totalFiles} Files · {formatStorageFromKb(site.totalSizeKb)}
          </span>
          {site.runtimeType && (
            <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 uppercase">
              {site.runtimeType}
            </span>
          )}
          {(site.repairedFilesCount || 0) > 0 && (
            <span className="bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 px-1.5 py-0.5 rounded border border-sky-200 dark:border-sky-500/30 flex items-center gap-1">
              <Wrench className="w-2.5 h-2.5" />
              {site.repairedFilesCount} {lang === 'bn' ? 'অটো-ফিক্সড' : 'Fixed'}
            </span>
          )}
          {(site.autoFixReports?.length || 0) > 0 && (
            <span className="bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 px-1.5 py-0.5 rounded border border-indigo-200 dark:border-indigo-500/30 flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" />
              {lang === 'bn' ? 'AI হিলড' : 'AI Healed'}
            </span>
          )}
          {site.hiddenFilesCount > 0 && (
            <span className="bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 px-1.5 py-0.5 rounded border border-emerald-200 dark:border-emerald-500/30 flex items-center gap-1">
              <Lock className="w-2.5 h-2.5" />
              {site.hiddenFilesCount}
            </span>
          )}
        </div>
      </div>

      <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-2">
        <span className="text-[10px] text-slate-500 dark:text-slate-400 tabular-nums">
          {lang === 'bn' ? 'ভিজিট:' : 'Visits:'}{' '}
          <strong className="text-slate-900 dark:text-white font-mono">{site.visitsCount}</strong>
        </span>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setSelectedSiteForPreview(site)}
            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 transition"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'ইন্সপেক্ট' : 'Inspect'}</span>
          </button>

          <a
            href={getPrimarySitePath(site)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition shadow-sm"
          >
            <span>{lang === 'bn' ? 'লাইভ' : 'Open'}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </div>
  );

  const guideSections = [
    {
      icon: FolderUp,
      color: 'text-cyan-600 dark:text-cyan-400 bg-cyan-50 dark:bg-cyan-950/60 border-cyan-200 dark:border-cyan-500/30',
      titleBn: '১. ফোল্ডার হোস্টিং (Full Folder Hosting)',
      titleEn: '1. Full Folder Hosting',
      bodyBn:
        'আপনার সম্পূর্ণ ওয়েব প্রজেক্ট ফোল্ডার ড্র্যাগ-ড্রপ বা সিলেক্ট করুন। HTML, CSS, JS, PHP, Python (Flask/FastAPI), Node.js অ্যাপ এবং .env / .htaccess সহ সকল হিডেন ও মিডিয়া ফাইল স্বয়ংক্রিয়ভাবে রান ও হোস্ট হয়।',
      bodyEn:
        'Select or drag-and-drop an entire project folder. Supports HTML, CSS, JS, PHP, Python (Flask/FastAPI), Node.js backends, media assets, plus .env and .htaccess hidden configs.',
    },
    {
      icon: FileCode2,
      color: 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-500/30',
      titleBn: '২. সিঙ্গেল ফাইল হোস্টিং (PHP 8.3 / HTML / JS / CSS)',
      titleEn: '2. Single-File Hosting (PHP / HTML / JS / CSS)',
      bodyBn:
        'কোনো ফোল্ডার বা জিপ ছাড়াই একটি মাত্র index.php বা index.html ফাইল আপলোড বা পেস্ট করে লাইভ করুন। PHP ফর্ম সাবমিশন (POST/GET), সেশন, ফাইল স্টোরেজ ও API রিকোয়েস্ট রিয়েল-টাইমে কাজ করে।',
      bodyEn:
        'Deploy a single index.php or index.html script instantly. Full server-side PHP execution supports POST/GET forms, sessions, local file persistence, and external API calls.',
    },
    {
      icon: FolderGit2,
      color: 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-500/30',
      titleBn: '৩. GitHub রিপোজিটরি সিঙ্ক (Public & Private PAT)',
      titleEn: '3. GitHub Repository Sync (Public & Private)',
      bodyBn:
        'পাবলিক রিপোর URL দিন অথবা প্রাইভেট রিপোর জন্য GitHub Personal Access Token (PAT) যুক্ত করে ব্রাঞ্চ সিঙ্ক করুন। রিপোর ফাইল অটো-অডিট হয়ে আপনার কাস্টম স্লাগে চালু হবে।',
      bodyEn:
        'Paste any public GitHub repo URL, or attach a Personal Access Token (PAT) for private repositories. Files and backend entry points are audited and launched automatically.',
    },
    {
      icon: Link2,
      color: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-500/30',
      titleBn: '৪. নিজস্ব লাইভ সাবডোমেইন (<নাম>.nighthostcloud.dpdns.org) ও স্লাগ',
      titleEn: '4. Live Personal Subdomain (<name>.nighthostcloud.dpdns.org) & Slug',
      bodyBn:
        'আপনার অ্যাকাউন্টের ইউনিক সাবডোমেইনের অধীনে <name>.nighthostcloud.dpdns.org/<slug>, /u/<name>/<slug> এবং সরাসরি /site/<slug> — তিনটি লিংকেই আপনার সব ওয়েবসাইট লাইভ হয়।',
      bodyEn:
        'Your personal account subdomain automatically resolves on <name>.nighthostcloud.dpdns.org/<slug>, /u/<name>/<slug>, and direct /site/<slug> endpoints.',
    },
    {
      icon: Terminal,
      color: 'text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/60 border-purple-200 dark:border-purple-500/30',
      titleBn: '৫. ✨ AI অটো-হিল, ১-ক্লিক Undo, লাইভ কোড ও .env এডিটর',
      titleEn: '5. ✨ AI Auto-Heal, 1-Click Undo, Live Code & .env Editor',
      bodyBn:
        'ডিপ্লয়ের সময় বা রানটাইম ক্র্যাশ করলে সিস্টেম পোর্ট/হোস্ট/JSON এরর স্বয়ংক্রিয়ভাবে ঠিক করে এবং বাংলা রিপোর্ট দেয়। চাইলে ইন্সপেক্টর থেকে "✨ অটো-হিল" বা ১ ক্লিকে "↩ পূর্বের কোডে ফিরুন" ব্যবহার করে আগের কোডে ফিরে যেতে পারবেন।',
      bodyEn:
        'Automatically repairs port/host/JSON issues and provides Bengali explanations, plus manual "✨ Auto-Heal", 1-click Undo snapshot restore, live code/.env editor, and .zip backup.',
    },
    {
      icon: ShieldCheck,
      color: 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-500/30',
      titleBn: '৬. অ্যাকাউন্ট অনুমোদন, স্টোরেজ কোটা ও সাপোর্ট',
      titleEn: '6. Account Approval, Quotas & Support',
      bodyBn:
        'নতুন অ্যাকাউন্ট খোলার পর মালিক বা অ্যাডমিনের অনুমোদন ও স্টোরেজ কোটা সক্রিয় হলেই হোস্টিং চালু হয়। মেয়াদ বা কোটা বাড়াতে নিচের টেলিগ্রামে যোগাযোগ করুন।',
      bodyEn:
        'Once approved by the Owner or an Admin with validity and storage quota, you can deploy and manage apps continuously. Contact Telegram support anytime below.',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 space-y-6" ref={menuContainerRef}>
      {broadcastMessage && activePage === 'overview' && (
        <div className="p-3.5 rounded-2xl bg-cyan-50 dark:bg-cyan-950/50 border border-cyan-200 dark:border-cyan-500/30 text-cyan-800 dark:text-cyan-200 text-xs flex items-center gap-2.5 shadow-sm">
          <Megaphone className="w-4 h-4 text-cyan-600 dark:text-cyan-400 flex-shrink-0" />
          <span className="font-medium">{broadcastMessage}</span>
        </div>
      )}

      {/* DEDICATED DEPLOY PAGES */}
      {activePage === 'deploy-folder' && (
        <div className="space-y-4">
          {renderBackBanner(
            lang === 'bn' ? 'ফোল্ডার হোস্টিং (Folder Deploy)' : 'Full Folder Deployment',
            lang === 'bn' ? 'আপনার প্রজেক্ট ফোল্ডার সিলেক্ট করে হোস্ট করুন' : 'Select or drop a full project directory'
          )}
          <FolderDeployer
            user={user}
            onDeploySuccess={handleDeploySuccess}
            onCancel={() => navigatePage('overview')}
            lang={lang}
          />
        </div>
      )}

      {activePage === 'deploy-single' && (
        <div className="space-y-4">
          {renderBackBanner(
            lang === 'bn' ? 'সিঙ্গেল ফাইল রানার (PHP / HTML)' : 'Single-File Runner (PHP / HTML)',
            lang === 'bn' ? 'একটি কোড ফাইল দিয়ে সরাসরি লাইভ সাইট তৈরি করুন' : 'Upload or paste a single PHP/HTML/JS/CSS file'
          )}
          <SingleFileDeployer
            user={user}
            onDeploySuccess={handleDeploySuccess}
            onCancel={() => navigatePage('overview')}
            lang={lang}
          />
        </div>
      )}

      {activePage === 'deploy-github' && (
        <div className="space-y-4">
          {renderBackBanner(
            lang === 'bn' ? 'গিটহাব রিপোজিটরি সিঙ্ক' : 'GitHub Repository Sync',
            lang === 'bn' ? 'পাবলিক বা প্রাইভেট রিপো থেকে ডিপ্লয় করুন' : 'Import public or private repos cleanly'
          )}
          <GithubDeployer
            user={user}
            onDeploySuccess={handleDeploySuccess}
            onCancel={() => navigatePage('overview')}
            lang={lang}
          />
        </div>
      )}

      {/* DEDICATED HOSTED SITES PAGE */}
      {activePage === 'sites' && (
        <div className="space-y-4">
          {renderBackBanner(
            lang === 'bn' ? `আমার ওয়েবসাইটসমূহ (${sites.length})` : `My Hosted Sites (${sites.length})`,
            lang === 'bn'
              ? 'লাইভ লিংক ওপেন করুন, কোড এডিট করুন অথবা ZIP ডাউনলোড করুন'
              : 'Manage live URLs, inspect & edit code, or download ZIP archives'
          )}

          <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={siteSearch}
                onChange={(e) => setSiteSearch(e.target.value)}
                placeholder={lang === 'bn' ? 'সাইটের নাম বা /site/slug দিয়ে খুঁজুন...' : 'Search by site name or slug...'}
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              {(['all', 'static', 'php', 'node', 'python'] as const).map((rt) => (
                <button
                  key={rt}
                  type="button"
                  onClick={() => setRuntimeFilter(rt)}
                  className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold uppercase transition ${
                    runtimeFilter === rt
                      ? 'bg-cyan-600 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {rt === 'all' ? (lang === 'bn' ? 'সব' : 'All') : rt}
                </button>
              ))}
            </div>
          </div>

          {filteredSites.length === 0 ? (
            <div className="p-8 sm:p-10 rounded-3xl bg-white dark:bg-slate-900/50 border border-dashed border-slate-300 dark:border-slate-800 text-center space-y-3">
              <Globe className="w-8 h-8 text-cyan-600 dark:text-cyan-400 mx-auto" />
              <p className="text-sm font-bold text-slate-900 dark:text-white">
                {sites.length === 0
                  ? lang === 'bn'
                    ? 'কোনো ওয়েবসাইট এখনও হোস্ট করা হয়নি'
                    : 'No Websites Deployed Yet'
                  : lang === 'bn'
                  ? 'ফিল্টারের সাথে কোনো ওয়েবসাইট মেলেনি'
                  : 'No websites match your search or filter'}
              </p>
              <div className="flex flex-wrap justify-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => navigatePage('deploy-folder')}
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold"
                >
                  {lang === 'bn' ? 'নতুন ফোল্ডার ডিপ্লয়' : 'Deploy Folder'}
                </button>
                <button
                  type="button"
                  onClick={() => navigatePage('deploy-single')}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold"
                >
                  {lang === 'bn' ? 'সিঙ্গেল ফাইল' : 'Single File'}
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredSites.map(renderSiteCard)}
            </div>
          )}
        </div>
      )}

      {/* DEDICATED PROFILE & PHOTO PAGE */}
      {activePage === 'profile' && (
        <div className="space-y-4">
          {renderBackBanner(
            lang === 'bn' ? 'আমার প্রোফাইল ও ছবি' : 'Profile & Photo Settings',
            lang === 'bn' ? 'ব্যক্তিগত তথ্য, ছবি ও পাসওয়ার্ড পরিবর্তন করুন' : 'Update display name, avatar photo, email, or password'
          )}

          <form
            onSubmit={handleSaveProfile}
            className="max-w-xl mx-auto p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4"
          >
            {profileMsg && (
              <div
                className={`p-3 rounded-xl text-xs border ${
                  profileMsg.error
                    ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-500/40'
                    : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-500/40'
                }`}
              >
                {profileMsg.text}
              </div>
            )}

            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center gap-3.5">
              {(() => {
                const effectiveAvatar =
                  profileAvatarDraft === undefined ? user.avatarDataUrl : profileAvatarDraft;
                return effectiveAvatar ? (
                  <img
                    src={effectiveAvatar}
                    alt={user.username}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center text-white text-2xl font-bold shrink-0">
                    {user.username.charAt(0).toUpperCase()}
                  </div>
                );
              })()}

              <div className="flex-1 min-w-0 space-y-2">
                <div className="text-[11px] text-slate-600 dark:text-slate-300">
                  {lang === 'bn'
                    ? `ছবির সাইজ: ${formatStorageFromKb(profileAvatarDraft === null ? 0 : profileAvatarKb)}`
                    : `Photo Size: ${formatStorageFromKb(profileAvatarDraft === null ? 0 : profileAvatarKb)}`}
                  {user.role !== 'admin' && (
                    <span className="block text-[10px] text-slate-500 dark:text-slate-400">
                      {lang === 'bn'
                        ? 'আপনার স্টোরেজ কোটা থেকে হিসাব হবে'
                        : 'Counted toward your storage quota'}
                    </span>
                  )}
                </div>

                <input
                  ref={avatarInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarFileSelected}
                  className="hidden"
                />

                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => avatarInputRef.current?.click()}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-semibold"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>
                      {profileAvatarDraft
                        ? lang === 'bn'
                          ? 'অন্য ছবি বাছুন'
                          : 'Change Photo'
                        : lang === 'bn'
                        ? 'ছবি বাছুন'
                        : 'Upload Photo'}
                    </span>
                  </button>

                  {(profileAvatarDraft || (profileAvatarDraft === undefined && user.avatarDataUrl)) && (
                    <button
                      type="button"
                      onClick={() => {
                        setProfileAvatarDraft(null);
                        setProfileAvatarKb(0);
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-500/30 text-rose-600 dark:text-rose-300 text-[11px] font-semibold"
                    >
                      {lang === 'bn' ? 'ছবি মুছুন' : 'Remove'}
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'পুরো নাম' : 'Full Name'}
                </label>
                <input
                  type="text"
                  value={profileFullName}
                  onChange={(e) => setProfileFullName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'ইমেইল' : 'Email'}
                </label>
                <input
                  type="email"
                  value={profileEmail}
                  onChange={(e) => setProfileEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn'
                    ? 'নতুন পাসওয়ার্ড (খালি রাখলে আগেরটি থাকবে)'
                    : 'New Password (leave blank to keep current)'}
                </label>
                <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2">
                  <input
                    type={showProfilePass ? 'text' : 'password'}
                    value={profilePassword}
                    onChange={(e) => setProfilePassword(e.target.value)}
                    placeholder={lang === 'bn' ? 'নতুন পাসওয়ার্ড লিখুন...' : 'Enter new password...'}
                    className="w-full bg-transparent text-slate-900 dark:text-white font-mono focus:outline-none min-w-0"
                  />
                  <button
                    type="button"
                    onClick={() => setShowProfilePass(!showProfilePass)}
                    aria-label={showProfilePass ? (lang === 'bn' ? 'পাসওয়ার্ড লুকান' : 'Hide password') : (lang === 'bn' ? 'পাসওয়ার্ড দেখুন' : 'Show password')}
                    className="ml-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition shrink-0"
                  >
                    {showProfilePass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => navigatePage('overview')}
                className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 text-xs font-semibold"
              >
                {lang === 'bn' ? 'ফিরুন' : 'Back'}
              </button>
              <button
                type="submit"
                disabled={savingProfile}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold disabled:opacity-60"
              >
                {savingProfile && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>{lang === 'bn' ? 'প্রোফাইল সংরক্ষণ করুন' : 'Save Profile'}</span>
              </button>
            </div>
          </form>

          {/* Personal Subdomain Management Card */}
          <div className="max-w-xl mx-auto p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Globe className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>{lang === 'bn' ? 'ব্যক্তিগত সাবডোমেইন (/u/<নাম>/...)' : 'Personal Subdomain (/u/<name>/...)'}</span>
              </h3>
              {user.subdomain && (
                <span className="text-[11px] font-mono font-bold text-emerald-700 dark:text-emerald-400">
                  /u/{user.subdomain}/
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {lang === 'bn'
                ? 'আপনার সব সাইট স্বয়ংক্রিয়ভাবে /u/<সাবডোমেইন>/<স্লাগ> লিংকে পাওয়া যাবে।'
                : 'All of your deployed apps resolve cleanly under /u/<subdomain>/<slug>.'}
            </p>
            {subdomainFeedback && (
              <div
                className={`p-3 rounded-xl text-xs border ${
                  subdomainFeedback.error
                    ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-500/40'
                    : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-500/40'
                }`}
              >
                {subdomainFeedback.text}
              </div>
            )}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <div className="flex-1 flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2">
                <span className="text-xs font-mono text-slate-500 dark:text-slate-400">/u/</span>
                <input
                  type="text"
                  value={profileSubdomain}
                  onChange={(e) => setProfileSubdomain(e.target.value.toLowerCase())}
                  placeholder={normalizeUserSubdomain(user.username || 'my-brand')}
                  className="w-full bg-transparent text-xs font-mono font-bold text-cyan-700 dark:text-cyan-400 focus:outline-none ml-1 min-w-0"
                />
              </div>
              <button
                type="button"
                disabled={
                  savingSubdomain ||
                  profileSubStatus.checking ||
                  profileSubStatus.available === false ||
                  normalizeUserSubdomain(profileSubdomain).length < 3 ||
                  normalizeUserSubdomain(profileSubdomain) === (user.subdomain || '')
                }
                onClick={handleSaveProfileSubdomain}
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold disabled:opacity-60 whitespace-nowrap"
              >
                {savingSubdomain && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>{lang === 'bn' ? 'সাবডোমেইন সেভ' : 'Save Subdomain'}</span>
              </button>
            </div>
            {profileSubStatus.checking ? (
              <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                <Loader2 className="w-3 h-3 animate-spin" />
                <span>{lang === 'bn' ? 'যাচাই হচ্ছে...' : 'Checking availability...'}</span>
              </div>
            ) : profileSubStatus.message ? (
              <div
                className={`text-[11px] font-semibold ${
                  profileSubStatus.available
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                {profileSubStatus.message}
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* DEDICATED USER GUIDE PAGE */}
      {activePage === 'guide' && (
        <div className="space-y-4">
          {renderBackBanner(
            lang === 'bn' ? `${config.brandName} ব্যবহার নির্দেশিকা` : `${config.brandName} User Guide`,
            lang === 'bn' ? 'হোস্টিং প্ল্যাটফর্মের প্রতিটি ফিচারের সহজ গাইড' : 'Complete guide to deploying and managing apps'
          )}

          <div className="max-w-3xl mx-auto space-y-3">
            {guideSections.map((sec, idx) => {
              const Icon = sec.icon;
              return (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-start gap-3"
                >
                  <div className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 ${sec.color}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 space-y-1">
                    <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                      {lang === 'bn' ? sec.titleBn : sec.titleEn}
                    </h3>
                    <p className="text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      {lang === 'bn' ? sec.bodyBn : sec.bodyEn}
                    </p>
                  </div>
                </div>
              );
            })}

            <div className="p-4 rounded-2xl bg-cyan-50/70 dark:bg-cyan-950/30 border border-cyan-200/70 dark:border-cyan-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs text-cyan-900 dark:text-cyan-200">
                <Terminal className="w-4 h-4 text-cyan-600 dark:text-cyan-400 shrink-0" />
                <span>
                  {lang === 'bn'
                    ? 'সহায়তা বা অ্যাকাউন্ট অনুমোদনের জন্য টেলিগ্রামে যোগাযোগ করুন:'
                    : 'Need support or approval? Reach out on Telegram:'}
                </span>
              </div>
              <a
                href={config.masterAdminTelegram}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{config.masterAdminName}</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* CLEAN DASHBOARD OVERVIEW PAGE */}
      {activePage === 'overview' && (
        <>
          <div className="rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 p-4 sm:p-6 shadow-sm dark:shadow-xl transition-colors space-y-5">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
              <div className="flex items-start sm:items-center gap-3.5 min-w-0">
                <button
                  type="button"
                  onClick={() => navigatePage('profile')}
                  aria-label={lang === 'bn' ? 'প্রোফাইল ছবি পরিবর্তন করুন' : 'Change profile photo'}
                  className="relative group shrink-0 rounded-2xl focus:outline-none"
                  title={lang === 'bn' ? 'প্রোফাইল ও ছবি আপডেট' : 'Edit Profile & Photo'}
                >
                  {user.avatarDataUrl ? (
                    <img
                      src={user.avatarDataUrl}
                      alt={user.username}
                      referrerPolicy="no-referrer"
                      className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shadow-md"
                    />
                  ) : (
                    <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center text-white text-xl font-bold shadow-md">
                      {user.username.charAt(0).toUpperCase()}
                    </div>
                  )}
                  <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-cyan-600 dark:text-cyan-400 shadow">
                    <Camera className="w-3 h-3" />
                  </span>
                </button>

                <div className="space-y-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight truncate">
                      {user.fullName || user.username}
                    </h1>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-50 dark:bg-cyan-950/80 border border-cyan-200 dark:border-cyan-500/30 text-cyan-700 dark:text-cyan-300 font-bold">
                      @{user.username}
                    </span>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                        user.role === 'admin'
                          ? 'bg-rose-50 dark:bg-rose-950/80 border-rose-200 dark:border-rose-500/30 text-rose-700 dark:text-rose-300'
                          : user.role === 'subadmin'
                          ? 'bg-amber-50 dark:bg-amber-950/80 border-amber-200 dark:border-amber-500/30 text-amber-700 dark:text-amber-300'
                          : 'bg-cyan-50 dark:bg-cyan-950/80 border-cyan-200 dark:border-cyan-500/30 text-cyan-700 dark:text-cyan-300'
                      }`}
                    >
                      {getRoleDisplayLabel(user.role, lang)}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {user.email} ·{' '}
                    {user.role === 'admin' ? (
                      <strong className="text-rose-600 dark:text-rose-400">
                        {lang === 'bn' ? 'মালিক (আনলিমিটেড অ্যাক্সেস)' : 'Platform Owner (Unlimited)'}
                      </strong>
                    ) : (
                      <>
                        {lang === 'bn' ? 'ক্লাউড ভল্ট:' : 'Vault Quota:'}{' '}
                        <strong className="text-cyan-600 dark:text-cyan-400 font-mono tabular-nums">
                          {formatStorageFromMb(storageLimit)}
                        </strong>
                      </>
                    )}
                    {user.subdomain && (
                      <>
                        {' · '}
                        <span className="font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                          /u/{user.subdomain}/
                        </span>
                      </>
                    )}
                  </p>

                  {user.role === 'admin' ? (
                    <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg text-xs font-bold border bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300">
                        <Shield className="w-3.5 h-3.5" />
                        <span>
                          {lang === 'bn'
                            ? 'সর্বোচ্চ ও আনলিমিটেড মালিকানা অ্যাক্সেস'
                            : 'Unrestricted Owner Root Access'}
                        </span>
                      </span>
                    </div>
                  ) : (
                    <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                      <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400" />
                        <span>{lang === 'bn' ? 'মেয়াদ বাকি:' : 'Remaining:'}</span>
                      </span>
                      <span
                        className={`px-2.5 py-0.5 rounded-lg text-xs font-mono font-bold border ${
                          validity.isExpired
                            ? 'bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border-rose-300 dark:border-rose-500'
                            : user.expiresAt
                            ? 'bg-amber-50 dark:bg-amber-950/80 border-amber-200 dark:border-amber-500/40 text-amber-700 dark:text-amber-300'
                            : 'bg-emerald-50 dark:bg-emerald-950/80 border-emerald-200 dark:border-emerald-500/40 text-emerald-700 dark:text-emerald-300'
                        }`}
                      >
                        {validity.label}
                      </span>
                      {user.expiresAt && (
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                          ({validity.formattedCountdown})
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => navigatePage('deploy-folder')}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-sm transition whitespace-nowrap"
                >
                  <FolderUp className="w-4 h-4 shrink-0" />
                  <span>{lang === 'bn' ? 'ফোল্ডার' : 'Folder'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => navigatePage('deploy-single')}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-sm transition whitespace-nowrap"
                >
                  <FileCode2 className="w-4 h-4 shrink-0" />
                  <span>{lang === 'bn' ? 'সিঙ্গেল ফাইল' : 'Single File'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => navigatePage('deploy-github')}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition whitespace-nowrap"
                >
                  <FolderGit2 className="w-4 h-4 text-cyan-600 dark:text-cyan-400 shrink-0" />
                  <span>GitHub</span>
                </button>

                <button
                  type="button"
                  onClick={() => window.dispatchEvent(new CustomEvent('nighthost:open-inbox'))}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition whitespace-nowrap"
                >
                  <Bell className="w-4 h-4 text-cyan-600 dark:text-cyan-400 shrink-0" />
                  <span>{lang === 'bn' ? 'ইনবক্স' : 'Inbox'}</span>
                  {inboxNoticeCount > 0 && (
                    <span
                      className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono font-bold leading-none ${
                        unreadInboxCount > 0
                          ? 'bg-rose-600 text-white'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      {unreadInboxCount > 0 ? unreadInboxCount : inboxNoticeCount}
                    </span>
                  )}
                </button>

                {onOpenAdminPanel && (user.role === 'admin' || user.role === 'subadmin') && (
                  <button
                    type="button"
                    onClick={onOpenAdminPanel}
                    className={`inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl text-white text-xs font-bold shadow-sm transition whitespace-nowrap ${
                      user.role === 'admin'
                        ? 'bg-rose-600 hover:bg-rose-500'
                        : 'bg-amber-600 hover:bg-amber-500'
                    }`}
                  >
                    <Shield className="w-4 h-4 shrink-0" />
                    <span>{lang === 'bn' ? 'ম্যানেজমেন্ট কনসোল' : 'Management Console'}</span>
                  </button>
                )}
              </div>
            </div>

            {/* LOCATION-STYLE SEGMENTED STORAGE BAR */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/75 border border-slate-200 dark:border-slate-800 space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2 font-bold text-slate-800 dark:text-slate-100">
                  <HardDrive className="w-4 h-4 text-cyan-600 dark:text-cyan-400 shrink-0" />
                  <span>{lang === 'bn' ? 'স্টোরেজ লোকেশন ও ব্যবহার' : 'Storage Location & Allocation'}</span>
                </div>
                <div className="font-mono text-xs tabular-nums">
                  <span className="font-bold text-cyan-700 dark:text-cyan-400">{formatStorageFromKb(exactKbUsed)}</span>
                  <span className="text-slate-400 mx-1">/</span>
                  <span className="font-semibold text-slate-700 dark:text-slate-200">
                    {user.role === 'admin' ? (lang === 'bn' ? 'আনলিমিটেড' : 'Unlimited') : formatStorageFromMb(storageLimit)}
                  </span>
                  {user.role !== 'admin' && (
                    <span className="ml-2 text-slate-500 dark:text-slate-400">({storagePercentText}%)</span>
                  )}
                </div>
              </div>

              <div className="w-full h-3 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden flex">
                {sitesBarPct > 0 && (
                  <div
                    className="h-full bg-cyan-500 transition-all duration-500"
                    style={{
                      width: `${sitesBarPct}%`,
                    }}
                    title={lang === 'bn' ? `ওয়েবসাইট: ${formatStorageFromKb(sitesSizeKb)}` : `Sites: ${formatStorageFromKb(sitesSizeKb)}`}
                  />
                )}
                {avatarBarPct > 0 && (
                  <div
                    className="h-full bg-indigo-500 transition-all duration-500"
                    style={{
                      width: `${avatarBarPct}%`,
                    }}
                    title={lang === 'bn' ? `প্রোফাইল ছবি: ${formatStorageFromKb(avatarSizeKb)}` : `Photo: ${formatStorageFromKb(avatarSizeKb)}`}
                  />
                )}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-600 dark:text-slate-300 font-mono tabular-nums">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="inline-flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-sm bg-cyan-500 inline-block" />
                    {lang === 'bn' ? 'ওয়েবসাইট:' : 'Sites:'} <strong>{formatStorageFromKb(sitesSizeKb)}</strong>
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-sm bg-indigo-500 inline-block" />
                    {lang === 'bn' ? 'প্রোফাইল ছবি:' : 'Photo:'} <strong>{formatStorageFromKb(avatarSizeKb)}</strong>
                  </span>
                </div>
                {user.role !== 'admin' && (
                  <span className="inline-flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400 font-semibold">
                    <span className="w-2.5 h-2.5 rounded-sm bg-slate-300 dark:bg-slate-700 inline-block" />
                    {lang === 'bn' ? 'ফ্রি আছে:' : 'Free:'} <strong>{formatStorageFromMb(storageFree)}</strong>
                  </span>
                )}
              </div>
            </div>

            <div className="pt-1 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <button
                type="button"
                onClick={() => navigatePage('sites')}
                className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 hover:border-cyan-400 text-left text-slate-600 dark:text-slate-400 transition"
              >
                <Globe className="w-4 h-4 text-cyan-600 dark:text-cyan-400 shrink-0" />
                <span>
                  {lang === 'bn' ? 'লাইভ সাইট:' : 'Live Sites:'}{' '}
                  <strong className="text-slate-900 dark:text-white font-mono">{sites.length}</strong>
                </span>
              </button>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400">
                <Activity className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span>
                  {lang === 'bn' ? 'মোট ভিজিট:' : 'Visits:'}{' '}
                  <strong className="text-slate-900 dark:text-white font-mono">{totalVisits}</strong>
                </span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400">
                <HardDrive className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
                <span>
                  {lang === 'bn' ? 'ব্যান্ডউইথ:' : 'Bandwidth:'}{' '}
                  <strong className="text-slate-900 dark:text-white font-mono">{formatStorageFromMb(totalBandwidth)}</strong>
                </span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400">
                <Calendar className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                <span>
                  {lang === 'bn' ? 'যোগদান:' : 'Joined:'}{' '}
                  <strong className="text-slate-900 dark:text-white font-mono">
                    {new Date(user.createdAt).toLocaleDateString()}
                  </strong>
                </span>
              </div>
            </div>
          </div>

          {/* COMPACT RECENT HOSTED SITES PREVIEW */}
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Layers className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                  <span>{lang === 'bn' ? 'সাম্প্রতিক ওয়েবসাইটসমূহ' : 'Recent Hosted Applications'}</span>
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {lang === 'bn'
                    ? 'উপরের ৩-লাইন মেনু থেকে সব সাইট, ডিপ্লয় টুল ও প্রোফাইল আলাদা পেজে খুলতে পারবেন'
                    : 'Use the 3-line menu to open full sites manager, deploy tools, or profile settings'}
                </p>
              </div>
              {sites.length > 0 && (
                <button
                  type="button"
                  onClick={() => navigatePage('sites')}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-cyan-600 hover:bg-slate-800 dark:hover:bg-cyan-500 text-white text-xs font-bold transition"
                >
                  <Globe className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? `সব ওয়েবসাইট দেখুন (${sites.length})` : `View All Sites (${sites.length})`}</span>
                </button>
              )}
            </div>

            {sites.length === 0 ? (
              <div className="p-8 sm:p-10 rounded-3xl bg-white dark:bg-slate-900/50 border border-dashed border-slate-300 dark:border-slate-800 text-center flex flex-col items-center justify-center">
                <div className="w-14 h-14 rounded-2xl bg-cyan-50 dark:bg-cyan-950/60 border border-cyan-200 dark:border-cyan-500/30 flex items-center justify-center text-cyan-600 dark:text-cyan-400 mb-3">
                  <Globe className="w-7 h-7" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  {lang === 'bn' ? 'কোনো ওয়েবসাইট এখনও হোস্ট করা হয়নি' : 'No Websites Deployed Yet'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mt-1 mb-4">
                  {lang === 'bn'
                    ? 'উপরের বাটন থেকে ফোল্ডার, সিঙ্গেল ফাইল অথবা GitHub ব্যবহার করে প্রথম সাইটটি চালু করুন।'
                    : 'Deploy your first project using folder, single file, or GitHub above.'}
                </p>
                <div className="flex flex-wrap justify-center gap-2">
                  <button
                    type="button"
                    onClick={() => navigatePage('deploy-folder')}
                    className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold"
                  >
                    {lang === 'bn' ? 'ফোল্ডার আপলোড' : 'Upload Folder'}
                  </button>
                  <button
                    type="button"
                    onClick={() => navigatePage('deploy-single')}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold"
                  >
                    {lang === 'bn' ? 'সিঙ্গেল ফাইল (PHP/HTML)' : 'Single File'}
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {sites.slice(0, 6).map(renderSiteCard)}
              </div>
            )}
          </div>
        </>
      )}

      {selectedSiteForPreview && (
        <SiteViewerModal
          site={selectedSiteForPreview}
          onClose={() => setSelectedSiteForPreview(null)}
          onSlugUpdated={(newSlug) => {
            setSelectedSiteForPreview({ ...selectedSiteForPreview, slug: newSlug });
          }}
          lang={lang}
        />
      )}

      {/* Custom Slug Editor Modal */}
      {editingSite && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-sm animate-soft-fade">
          <div className="w-full max-w-md p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 animate-modal-pop">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Edit3 className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
              <span>{lang === 'bn' ? 'সাইটের পাথ স্লাগ পরিবর্তন' : 'Edit Site Path Slug'}</span>
            </h3>

            <p className="text-xs text-slate-500 dark:text-slate-400">
              {lang === 'bn'
                ? 'আপনার সাইটের ইউনিক পাথ স্লাগ (/site/...) সেট করুন:'
                : 'Set a unique path slug (/site/...) for your project:'}
            </p>

            {slugError && (
              <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300 text-xs">
                {slugError}
              </div>
            )}

            <div className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'পাথ স্লাগ' : 'Path Slug'}
                </label>
                <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2 text-sm">
                  <span className="text-slate-500 dark:text-slate-400 font-mono text-xs">/site/</span>
                  <input
                    type="text"
                    value={newSlugInput}
                    onChange={(e) => setNewSlugInput(e.target.value)}
                    className="w-full bg-transparent text-cyan-700 dark:text-cyan-400 focus:outline-none font-mono text-sm ml-1"
                    autoFocus
                  />
                </div>
                {(editingSite.ownerSubdomain || user.subdomain) && (
                  <p className="mt-1.5 text-[11px] font-mono text-emerald-700 dark:text-emerald-400">
                    /u/{editingSite.ownerSubdomain || user.subdomain}/{newSlugInput || editingSite.slug}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingSite(null)}
                className="px-3.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 text-xs"
              >
                {lang === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                disabled={savingSlug}
                onClick={handleSaveCustomSlug}
                className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold disabled:opacity-60"
              >
                {savingSlug && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>{lang === 'bn' ? 'সংরক্ষণ করুন' : 'Save Changes'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Site Confirmation Modal */}
      {confirmDeleteSite && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-sm animate-soft-fade">
          <div className="w-full max-w-sm p-6 rounded-2xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-500/30 shadow-2xl space-y-4 animate-modal-pop">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Trash2 className="w-4 h-4 text-rose-600 dark:text-rose-400" />
              <span>{lang === 'bn' ? 'ওয়েবসাইট মুছে ফেলুন' : 'Delete Website'}</span>
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {lang === 'bn' ? (
                <>
                  আপনি কি নিশ্চিতভাবে <strong>{confirmDeleteSite.name}</strong> (/site/{confirmDeleteSite.slug}) মুছে ফেলতে চান?
                </>
              ) : (
                <>
                  Are you sure you want to permanently delete <strong>{confirmDeleteSite.name}</strong> (/site/{confirmDeleteSite.slug})?
                </>
              )}
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteSite(null)}
                className="px-3.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 text-xs"
              >
                {lang === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                disabled={deletingSite}
                onClick={handleConfirmDeleteSite}
                className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold disabled:opacity-60"
              >
                {deletingSite && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>{lang === 'bn' ? 'হ্যাঁ, মুছে ফেলুন' : 'Yes, Delete'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
