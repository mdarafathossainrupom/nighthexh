import React, { useState, useEffect } from 'react';
import { User, ThemeMode } from '../types';
import { storage } from '../services/storage';
import {
  Shield,
  Lock,
  ArrowRight,
  AlertTriangle,
  Terminal,
  ArrowLeft,
  Sun,
  Moon,
  Eye,
  EyeOff,
  Loader2,
  UserCheck,
  Mail,
  Sparkles,
} from 'lucide-react';

interface AdminLoginGatewayProps {
  onSuccess: (user: User) => void;
  onGoHome: () => void;
  lang: 'bn' | 'en';
  theme?: ThemeMode;
  onToggleTheme?: () => void;
}

export const AdminLoginGateway: React.FC<AdminLoginGatewayProps> = ({
  onSuccess,
  onGoHome,
  lang,
  theme = 'dark',
  onToggleTheme,
}) => {
  const [role, setRole] = useState<'admin' | 'subadmin'>('admin');
  const [needsOwnerSetup, setNeedsOwnerSetup] = useState<boolean>(() =>
    storage.getNeedsOwnerSetup()
  );
  const [checkingSetup, setCheckingSetup] = useState(true);

  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const config = storage.getConfig();

  useEffect(() => {
    let cancelled = false;
    storage.getOwnerSetupStatusAsync().then((status) => {
      if (!cancelled) {
        setNeedsOwnerSetup(status);
        setCheckingSetup(false);
      }
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const handleAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (needsOwnerSetup && role === 'admin') {
      if (username.trim().length < 3 || !email.trim().includes('@') || password.trim().length < 4) {
        setErrorMessage(
          lang === 'bn'
            ? 'কমপক্ষে ৩ অক্ষরের ইউজারনেম, সঠিক ইমেইল এবং কমপক্ষে ৪ অক্ষরের শক্তিশালী পাসওয়ার্ড দিন।'
            : 'Provide at least 3-char username, valid email, and at least 4-char password.'
        );
        return;
      }
      setSubmitting(true);
      const setupRes = await storage.setupInitialOwnerAsync({
        username: username.trim(),
        fullName: fullName.trim() || username.trim(),
        email: email.trim(),
        password: password.trim(),
      });
      setSubmitting(false);
      if (setupRes.success && setupRes.user) {
        onSuccess(setupRes.user);
        return;
      }
      setErrorMessage(
        setupRes.message ||
          (lang === 'bn' ? 'মালিক অ্যাকাউন্ট তৈরি করা যায়নি।' : 'Failed to initialize Owner.')
      );
      return;
    }

    setSubmitting(true);
    const res = await storage.adminLoginAsync(role, username, password);
    setSubmitting(false);

    if (res.success && res.user) {
      onSuccess(res.user);
      return;
    }

    setErrorMessage(
      res.message ||
        (lang === 'bn' ? 'অ্যাডমিন লগইন ব্যর্থ হয়েছে!' : 'Administrator authentication failed.')
    );
  };

  const isOwnerSetupMode = needsOwnerSetup && role === 'admin';

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-100/85 dark:bg-slate-950 text-slate-900 dark:text-slate-100 cyber-grid relative transition-colors overflow-x-hidden">
      <div
        className={`absolute w-[420px] h-[420px] rounded-full blur-3xl pointer-events-none ${
          role === 'admin'
            ? 'bg-rose-500/10 dark:bg-rose-950/20'
            : 'bg-amber-500/10 dark:bg-amber-950/20'
        }`}
      />

      {onToggleTheme && (
        <button
          type="button"
          onClick={onToggleTheme}
          aria-label="Toggle theme"
          className="absolute top-5 right-5 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-slate-700 dark:text-slate-300 z-20"
        >
          {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-600" />}
        </button>
      )}

      <div
        className={`relative w-full max-w-md rounded-3xl bg-white/95 dark:bg-slate-900/95 p-6 sm:p-8 shadow-2xl backdrop-blur-xl z-10 space-y-6 border ${
          role === 'admin'
            ? 'border-rose-200 dark:border-rose-500/30'
            : 'border-amber-200 dark:border-amber-500/30'
        }`}
      >
        <div className="text-center space-y-2">
          <div
            className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto shadow-md border ${
              role === 'admin'
                ? 'bg-rose-50 dark:bg-rose-950/80 border-rose-200 dark:border-rose-500/50 text-rose-600 dark:text-rose-400'
                : 'bg-amber-50 dark:bg-amber-950/80 border-amber-200 dark:border-amber-500/50 text-amber-600 dark:text-amber-400'
            }`}
          >
            {isOwnerSetupMode ? <Sparkles className="w-7 h-7" /> : <Shield className="w-7 h-7" />}
          </div>
          <div
            className={`inline-flex items-center gap-1.5 px-3 py-0.5 rounded-md text-[10px] font-mono font-bold tracking-wider uppercase border ${
              role === 'admin'
                ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300'
                : 'bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-500/40 text-amber-700 dark:text-amber-300'
            }`}
          >
            {isOwnerSetupMode ? 'FIRST-TIME OWNER SETUP' : 'RESTRICTED ADMIN GATEWAY'}
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {config.brandName}{' '}
            <span className={role === 'admin' ? 'text-rose-600 dark:text-rose-400' : 'text-amber-600 dark:text-amber-400'}>
              Core
            </span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isOwnerSetupMode
              ? lang === 'bn'
                ? 'প্ল্যাটফর্মের প্রথম মালিক (Owner) অ্যাকাউন্ট ও শক্তিশালী পাসওয়ার্ড সেট করুন'
                : 'Initialize the primary Platform Owner account and strong password'
              : lang === 'bn'
              ? 'শুধুমাত্র প্ল্যাটফর্ম মালিক ও অনুমোদিত অ্যাডমিনদের জন্য সংরক্ষিত'
              : 'Authorized Owner and Admin console access only'}
          </p>
        </div>

        {errorMessage && (
          <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/70 border border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0 text-rose-500" />
            <span>{errorMessage}</span>
          </div>
        )}

        <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-semibold">
          <button
            type="button"
            onClick={() => {
              setRole('admin');
              setErrorMessage(null);
            }}
            className={`py-2 rounded-lg transition whitespace-nowrap ${
              role === 'admin'
                ? 'bg-rose-600 text-white shadow'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {lang === 'bn' ? 'মালিক (Owner)' : 'Owner'}
          </button>

          <button
            type="button"
            onClick={() => {
              setRole('subadmin');
              setErrorMessage(null);
            }}
            className={`py-2 rounded-lg transition whitespace-nowrap ${
              role === 'subadmin'
                ? 'bg-amber-600 text-white shadow'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {lang === 'bn' ? 'অ্যাডমিন (Admin)' : 'Admin'}
          </button>
        </div>

        {checkingSetup ? (
          <div className="py-8 flex flex-col items-center justify-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <Loader2 className="w-5 h-5 animate-spin text-rose-500" />
            <span>{lang === 'bn' ? 'সিস্টেম স্ট্যাটাস যাচাই হচ্ছে...' : 'Checking gateway status...'}</span>
          </div>
        ) : needsOwnerSetup && role === 'subadmin' ? (
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-500/40 text-xs text-amber-800 dark:text-amber-200 space-y-2">
            <p className="font-bold">
              {lang === 'bn'
                ? 'প্রথমে প্ল্যাটফর্ম মালিক (Owner) সেটআপ সম্পন্ন করুন।'
                : 'Initialize the Platform Owner first.'}
            </p>
            <p className="text-[11px] opacity-90">
              {lang === 'bn'
                ? 'মালিক অ্যাকাউন্ট তৈরি করার পর কনসোল থেকে নতুন অ্যাডমিন যুক্ত করা যাবে।'
                : 'Once the Owner account is initialized, Admins can be created inside the console.'}
            </p>
            <button
              type="button"
              onClick={() => setRole('admin')}
              className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition"
            >
              {lang === 'bn' ? 'মালিক সেটআপে যান' : 'Switch to Owner Setup'}
            </button>
          </div>
        ) : (
          <form onSubmit={handleAdminSubmit} className="space-y-4">
            {isOwnerSetupMode && (
              <>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {lang === 'bn' ? 'মালিকের পূর্ণ নাম' : 'Owner Full Name'}
                  </label>
                  <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3.5 py-2.5">
                    <UserCheck className="w-4 h-4 text-slate-400 mr-2 flex-shrink-0" />
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder={lang === 'bn' ? 'যেমন: NIGHT HEX' : 'e.g. NIGHT HEX'}
                      className="w-full bg-transparent text-sm text-slate-900 dark:text-white focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {lang === 'bn' ? 'মালিকের ইমেইল' : 'Owner Email'}
                  </label>
                  <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3.5 py-2.5">
                    <Mail className="w-4 h-4 text-slate-400 mr-2 flex-shrink-0" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="owner@yourdomain.com"
                      className="w-full bg-transparent text-sm text-slate-900 dark:text-white focus:outline-none"
                      required
                    />
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {role === 'admin'
                  ? lang === 'bn'
                    ? 'মালিক ইউজারনেম'
                    : 'Owner Username'
                  : lang === 'bn'
                  ? 'অ্যাডমিন ইউজারনেম'
                  : 'Admin Username'}
              </label>
              <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3.5 py-2.5">
                <Terminal className="w-4 h-4 text-slate-400 mr-2 flex-shrink-0" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={role === 'admin' ? 'owner_handle' : 'admin_username'}
                  className="w-full bg-transparent text-sm text-slate-900 dark:text-white focus:outline-none font-mono"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {isOwnerSetupMode
                  ? lang === 'bn'
                    ? 'নতুন শক্তিশালী পাসওয়ার্ড (কমপক্ষে ৪ অক্ষর)'
                    : 'Create Strong Password (min 4 chars)'
                  : lang === 'bn'
                  ? 'সিক্রেট পাসওয়ার্ড'
                  : 'Secret Password'}
              </label>
              <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3.5 py-2.5">
                <Lock className="w-4 h-4 text-slate-400 mr-2 flex-shrink-0" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-transparent text-sm text-slate-900 dark:text-white focus:outline-none"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? (lang === 'bn' ? 'পাসওয়ার্ড লুকান' : 'Hide password') : (lang === 'bn' ? 'পাসওয়ার্ড দেখুন' : 'Show password')}
                  className="ml-2 p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition shrink-0"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className={`w-full py-3 rounded-xl text-white font-bold text-xs shadow-lg transition flex items-center justify-center gap-2 group disabled:opacity-75 whitespace-nowrap ${
                role === 'admin'
                  ? 'bg-gradient-to-r from-rose-600 via-rose-500 to-rose-700 hover:from-rose-500 hover:to-rose-600'
                  : 'bg-gradient-to-r from-amber-600 via-amber-500 to-orange-600 hover:from-amber-500 hover:to-orange-500'
              }`}
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{lang === 'bn' ? 'প্রক্রিয়া চলছে...' : 'Authenticating...'}</span>
                </>
              ) : (
                <>
                  <span>
                    {isOwnerSetupMode
                      ? lang === 'bn'
                        ? 'মালিক অ্যাকাউন্ট তৈরি ও প্রবেশ করুন'
                        : 'Create Owner & Enter Console'
                      : lang === 'bn'
                      ? 'অ্যাডমিন প্যানেলে প্রবেশ করুন'
                      : 'Authenticate & Enter Console'}
                  </span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </form>
        )}

        <div className="pt-2 border-t border-slate-200 dark:border-slate-800/80 text-center">
          <button
            type="button"
            onClick={onGoHome}
            className="inline-flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'ইউজার হোমপেজে ফিরে যান' : 'Return to Public Site'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
