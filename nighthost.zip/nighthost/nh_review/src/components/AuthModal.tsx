import React, { useState, useEffect } from 'react';
import { User, SubAdmin, PlatformConfig } from '../types';
import { storage } from '../services/storage';
import {
  X,
  User as UserIcon,
  Lock,
  CheckCircle,
  AlertTriangle,
  Send,
  MessageCircle,
  Clock,
  Eye,
  EyeOff,
  Loader2,
} from 'lucide-react';

interface AuthModalProps {
  initialMode?: 'login' | 'register';
  onClose: () => void;
  onSuccess: (user: User) => void;
  lang: 'bn' | 'en';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  initialMode = 'login',
  onClose,
  onSuccess,
  lang,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);

  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showLoginPass, setShowLoginPass] = useState(false);
  const [showRegPass, setShowRegPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const [pendingModalOpen, setPendingModalOpen] = useState(false);
  const [supportReason, setSupportReason] = useState<'PENDING' | 'EXPIRED' | 'SUSPENDED'>('PENDING');
  const [pendingWatchCreds, setPendingWatchCreds] = useState<{ username: string; password: string } | null>(null);
  const [approvalUnlockMsg, setApprovalUnlockMsg] = useState<string | null>(null);
  const [liveConfig, setLiveConfig] = useState<PlatformConfig>(storage.getConfig());
  const [liveSubAdmins, setLiveSubAdmins] = useState<SubAdmin[]>(storage.getActiveSubAdmins());

  const refreshSupportContacts = async () => {
    try {
      const res = await fetch('/api/public/contacts', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.config) setLiveConfig(data.config);
        if (Array.isArray(data.activeSubAdmins)) setLiveSubAdmins(data.activeSubAdmins);
      }
    } catch {
      setLiveConfig(storage.getConfig());
      setLiveSubAdmins(storage.getActiveSubAdmins());
    }
  };

  useEffect(() => {
    refreshSupportContacts();
    const prevDocOverflow = document.documentElement.style.overflow;
    const prevBodyOverflow = document.body.style.overflow;
    const prevBodyTouch = document.body.style.touchAction;
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';
    document.body.style.touchAction = 'none';
    return () => {
      document.documentElement.style.overflow = prevDocOverflow;
      document.body.style.overflow = prevBodyOverflow;
      document.body.style.touchAction = prevBodyTouch;
    };
  }, []);

  const handleUserLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessNotice(null);
    setSubmitting(true);

    const res = await storage.loginUserAsync(username, password);
    setSubmitting(false);

    if (res.success && res.user) {
      onSuccess(res.user);
      return;
    }

    if (res.code === 'PENDING' || res.code === 'EXPIRED' || res.code === 'SUSPENDED') {
      setSupportReason(res.code);
      if (res.code === 'PENDING' && username.trim()) {
        setPendingWatchCreds({ username: username.trim(), password });
      }
      if (res.config) setLiveConfig(res.config);
      if (res.activeSubAdmins) setLiveSubAdmins(res.activeSubAdmins);
      else await refreshSupportContacts();
      setPendingModalOpen(true);
      return;
    }

    setErrorMessage(
      res.message ||
        (lang === 'bn'
          ? 'লগইন করা সম্ভব হয়নি। ইউজারনেম ও পাসওয়ার্ড যাচাই করুন।'
          : 'Login failed. Please check credentials.')
    );
  };

  const handleUserRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessNotice(null);

    if (!username.trim() || !fullName.trim() || !email.trim() || !password.trim()) {
      setErrorMessage(lang === 'bn' ? 'অনুগ্রহ করে সকল তথ্য পূরণ করুন।' : 'Please fill all required fields.');
      return;
    }

    if (password.trim().length < 4) {
      setErrorMessage(
        lang === 'bn' ? 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।' : 'Password must be at least 4 characters.'
      );
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage(lang === 'bn' ? 'উভয় পাসওয়ার্ড হুবহু এক হতে হবে।' : 'Passwords do not match.');
      return;
    }

    setSubmitting(true);
    const res = await storage.registerUserAsync(username, fullName, email, password);
    setSubmitting(false);

    if (res.success) {
      if (res.config) setLiveConfig(res.config);
      if (res.activeSubAdmins) setLiveSubAdmins(res.activeSubAdmins);
      else await refreshSupportContacts();
      setPendingWatchCreds({ username: username.trim(), password });
      setSuccessNotice(
        lang === 'bn'
          ? 'রেজিস্ট্রেশন সফল হয়েছে! অ্যাকাউন্ট অনুমোদন পেতে টেলিগ্রামে যোগাযোগ করুন।'
          : 'Registration successful! Please contact support on Telegram for account approval.'
      );
      setSupportReason('PENDING');
      setPendingModalOpen(true);
      setUsername(username.trim());
      setFullName('');
      setEmail('');
      setPassword('');
      setConfirmPassword('');
    } else {
      setErrorMessage(res.message);
    }
  };

  useEffect(() => {
    if (!pendingModalOpen || supportReason !== 'PENDING' || !pendingWatchCreds?.username) return;
    let cancelled = false;

    const checkApproval = async () => {
      if (cancelled) return;
      try {
        const res = await fetch(
          `/api/auth/pending-status?username=${encodeURIComponent(pendingWatchCreds.username)}`,
          { cache: 'no-store' }
        );
        if (!res.ok || cancelled) return;
        const data = (await res.json()) as { success?: boolean; status?: string };
        if (cancelled) return;
        if (data?.status === 'approved') {
          setApprovalUnlockMsg(
            lang === 'bn'
              ? '🎉 অভিনন্দন! অ্যাডমিন আপনার অ্যাকাউন্ট অনুমোদন করেছেন — অটো লগইন হচ্ছে...'
              : '🎉 Approved! Signing you into your dashboard automatically...'
          );
          if (pendingWatchCreds.password) {
            const loginRes = await storage.loginUserAsync(
              pendingWatchCreds.username,
              pendingWatchCreds.password
            );
            if (!cancelled && loginRes.success && loginRes.user) {
              setPendingModalOpen(false);
              onSuccess(loginRes.user);
              return;
            }
          }
          if (!cancelled) {
            setPendingModalOpen(false);
            setMode('login');
            setUsername(pendingWatchCreds.username);
            setSuccessNotice(
              lang === 'bn'
                ? 'অ্যাকাউন্ট অনুমোদন সম্পন্ন হয়েছে! এখন লগইন করুন।'
                : 'Account approved! Please sign in now.'
            );
          }
        } else if (data?.status === 'suspended') {
          setSupportReason('SUSPENDED');
        }
      } catch {
        // retry on next tick
      }
    };

    checkApproval();
    const timer = setInterval(checkApproval, 2500);
    window.addEventListener('focus', checkApproval);
    return () => {
      cancelled = true;
      clearInterval(timer);
      window.removeEventListener('focus', checkApproval);
    };
  }, [pendingModalOpen, supportReason, pendingWatchCreds, lang, onSuccess]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/55 dark:bg-slate-950/75 backdrop-blur-md">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-2xl z-10 space-y-5 max-h-[92vh] overflow-y-auto">
        <button
          type="button"
          aria-label="Close modal"
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-cyan-50 dark:bg-cyan-950/80 border border-cyan-200 dark:border-cyan-500/30 text-cyan-700 dark:text-cyan-300 text-[10px] font-mono font-bold uppercase mb-2">
            {liveConfig.brandName} CLOUD ACCESS
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
            {mode === 'login'
              ? lang === 'bn'
                ? 'হোস্টিং অ্যাকাউন্টে প্রবেশ'
                : 'Sign In to Your Account'
              : lang === 'bn'
              ? 'নতুন হোস্টিং অ্যাকাউন্ট খুলুন'
              : 'Create Hosting Account'}
          </h2>
        </div>

        {/* Mode Switcher */}
        <div className="flex items-center justify-center gap-2 p-1 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setErrorMessage(null);
            }}
            className={`w-1/2 py-1.5 rounded-lg text-xs font-semibold transition ${
              mode === 'login'
                ? 'bg-cyan-600 text-white shadow'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {lang === 'bn' ? 'লগইন' : 'Login'}
          </button>

          <button
            type="button"
            onClick={() => {
              setMode('register');
              setErrorMessage(null);
            }}
            className={`w-1/2 py-1.5 rounded-lg text-xs font-semibold transition ${
              mode === 'register'
                ? 'bg-cyan-600 text-white shadow'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {lang === 'bn' ? 'রেজিস্ট্রেশন' : 'Register'}
          </button>
        </div>

        {errorMessage && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/70 border border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0 text-rose-500" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successNotice && (
          <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/70 border border-emerald-200 dark:border-emerald-500/40 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle className="w-4 h-4 flex-shrink-0 text-emerald-500" />
            <span>{successNotice}</span>
          </div>
        )}

        {mode === 'login' && (
          <form onSubmit={handleUserLogin} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {lang === 'bn' ? 'ইউজারনেম বা ইমেইল' : 'Username or Email'}
              </label>
              <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3.5 py-2">
                <UserIcon className="w-4 h-4 text-slate-400 mr-2 flex-shrink-0" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="username"
                  className="w-full bg-transparent text-sm text-slate-900 dark:text-white focus:outline-none"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {lang === 'bn' ? 'পাসওয়ার্ড' : 'Password'}
              </label>
              <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3.5 py-2">
                <Lock className="w-4 h-4 text-slate-400 mr-2 flex-shrink-0" />
                <input
                  type={showLoginPass ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-transparent text-sm text-slate-900 dark:text-white focus:outline-none"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowLoginPass(!showLoginPass)}
                  aria-label={showLoginPass ? (lang === 'bn' ? 'পাসওয়ার্ড লুকান' : 'Hide password') : (lang === 'bn' ? 'পাসওয়ার্ড দেখুন' : 'Show password')}
                  className="ml-2 p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition shrink-0"
                >
                  {showLoginPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 via-indigo-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold shadow-lg transition mt-2 disabled:opacity-75 flex items-center justify-center gap-2"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{lang === 'bn' ? 'প্রবেশ হচ্ছে...' : 'Signing In...'}</span>
                </>
              ) : (
                <span>{lang === 'bn' ? 'লগইন করুন' : 'Sign In'}</span>
              )}
            </button>
          </form>
        )}

        {mode === 'register' && liveConfig.allowRegistration === false && (
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-500/40 text-amber-800 dark:text-amber-200 text-xs text-center space-y-2">
            <p className="font-bold">
              {lang === 'bn'
                ? 'বর্তমানে নতুন অ্যাকাউন্ট তৈরি সাময়িকভাবে বন্ধ আছে'
                : 'New Account Registration is Temporarily Paused'}
            </p>
            <p className="text-[11px] opacity-90">
              {lang === 'bn'
                ? 'অনুগ্রহ করে বিদ্যমান অ্যাকাউন্ট দিয়ে লগইন করুন অথবা অ্যাডমিনের সাথে যোগাযোগ করুন।'
                : 'Please sign in with an existing account or contact support on Telegram.'}
            </p>
          </div>
        )}

        {mode === 'register' && liveConfig.allowRegistration !== false && (
          <form onSubmit={handleUserRegister} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {lang === 'bn' ? 'আপনার নাম' : 'Full Name'}
              </label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Your Full Name"
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {lang === 'bn' ? 'ইউজারনেম (অনন্য)' : 'Username'}
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="username"
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500 font-mono"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {lang === 'bn' ? 'ইমেইল অ্যাড্রেস' : 'Email Address'}
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'পাসওয়ার্ড' : 'Password'}
                </label>
                <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-2.5 py-2 focus-within:border-cyan-500">
                  <input
                    type={showRegPass ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-transparent text-xs text-slate-900 dark:text-white focus:outline-none min-w-0"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegPass(!showRegPass)}
                    aria-label={showRegPass ? (lang === 'bn' ? 'পাসওয়ার্ড লুকান' : 'Hide password') : (lang === 'bn' ? 'পাসওয়ার্ড দেখুন' : 'Show password')}
                    className="ml-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition shrink-0"
                  >
                    {showRegPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'bn' ? 'পুনরায় পাসওয়ার্ড' : 'Confirm'}
                </label>
                <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-2.5 py-2 focus-within:border-cyan-500">
                  <input
                    type={showConfirmPass ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-transparent text-xs text-slate-900 dark:text-white focus:outline-none min-w-0"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPass(!showConfirmPass)}
                    aria-label={showConfirmPass ? (lang === 'bn' ? 'নিশ্চিত পাসওয়ার্ড লুকান' : 'Hide confirm password') : (lang === 'bn' ? 'নিশ্চিত পাসওয়ার্ড দেখুন' : 'Show confirm password')}
                    className="ml-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition shrink-0"
                  >
                    {showConfirmPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg transition mt-2 disabled:opacity-75 flex items-center justify-center gap-2"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{lang === 'bn' ? 'তৈরি হচ্ছে...' : 'Creating Account...'}</span>
                </>
              ) : (
                <span>{lang === 'bn' ? 'অ্যাকাউন্ট তৈরি করুন' : 'Create Account'}</span>
              )}
            </button>
          </form>
        )}
      </div>

      {/* APPROVAL SUPPORT MODAL WITH LIVE TELEGRAM CONTACTS */}
      {pendingModalOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-md p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-cyan-200 dark:border-cyan-500/30 shadow-2xl text-center space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="w-12 h-12 rounded-2xl bg-cyan-50 dark:bg-cyan-950/80 border border-cyan-200 dark:border-cyan-500/40 flex items-center justify-center text-cyan-600 dark:text-cyan-400 mx-auto">
              <MessageCircle className="w-6 h-6" />
            </div>

            <div>
              <div
                className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md border text-[11px] font-semibold mb-1.5 ${
                  supportReason === 'SUSPENDED'
                    ? 'bg-rose-50 dark:bg-rose-950/70 border-rose-200 dark:border-rose-500/30 text-rose-700 dark:text-rose-300'
                    : 'bg-amber-50 dark:bg-amber-950/70 border-amber-200 dark:border-amber-500/30 text-amber-700 dark:text-amber-300'
                }`}
              >
                {supportReason === 'SUSPENDED' ? (
                  <AlertTriangle className="w-3 h-3" />
                ) : (
                  <Clock className="w-3 h-3" />
                )}
                <span>
                  {supportReason === 'SUSPENDED'
                    ? lang === 'bn'
                      ? 'অ্যাকাউন্ট স্থগিত (Suspended)'
                      : 'Account Suspended'
                    : supportReason === 'EXPIRED'
                    ? lang === 'bn'
                      ? 'হোস্টিং মেয়াদ শেষ (Expired)'
                      : 'Hosting Validity Expired'
                    : lang === 'bn'
                    ? 'লগইন অনুমোদন পেন্ডিং'
                    : 'Account Approval Pending'}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-snug">
                {supportReason === 'SUSPENDED'
                  ? lang === 'bn'
                    ? 'অ্যাকাউন্ট পুনরায় চালু করতে যোগাযোগ করুন'
                    : 'Contact Support to Restore Access'
                  : lang === 'bn'
                  ? 'অ্যাকাউন্ট সচল করার জন্য টেলিগ্রামে যোগাযোগ করুন'
                  : 'Contact Telegram Support for Activation'}
              </h3>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 max-w-sm mx-auto mt-1 leading-relaxed">
                {supportReason === 'SUSPENDED'
                  ? lang === 'bn'
                    ? 'আপনার অ্যাকাউন্ট ও ওয়েবসাইট বর্তমানে সাসপেন্ড রয়েছে। পুনরায় চালু করতে নিচের মালিক বা অ্যাডমিনের টেলিগ্রামে মেসেজ দিন।'
                    : 'Your account and hosted sites are currently paused. Message the Owner or an active Admin on Telegram to reinstate.'
                  : lang === 'bn'
                  ? 'সরাসরি নিচের মালিক অথবা সক্রিয় অ্যাডমিনের টেলিগ্রামে মেসেজ দিয়ে অনুমোদন গ্রহণ করুন। অনুমোদন হওয়া মাত্রই অটো-লগইন হয়ে যাবে।'
                  : 'Message the Owner or any active Admin below on Telegram to approve your account. This screen will unlock automatically once approved.'}
              </p>
              {approvalUnlockMsg && (
                <div className="mt-2.5 p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/70 border border-emerald-300 dark:border-emerald-500/40 text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center justify-center gap-2">
                  <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
                  <span>{approvalUnlockMsg}</span>
                </div>
              )}
            </div>

            <div className="space-y-2 text-left">
              <div className="p-2.5 px-3 rounded-xl bg-rose-50 dark:bg-rose-950/35 border border-rose-200 dark:border-rose-500/30 flex items-center justify-between gap-2.5">
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  {liveConfig.masterAdminAvatarDataUrl ? (
                    <img
                      src={liveConfig.masterAdminAvatarDataUrl}
                      alt={liveConfig.masterAdminName}
                      referrerPolicy="no-referrer"
                      className="w-9 h-9 rounded-lg object-cover border border-rose-300 dark:border-rose-500/40 shrink-0"
                    />
                  ) : (
                    <div className="w-9 h-9 rounded-lg bg-rose-100 dark:bg-rose-950 border border-rose-300 dark:border-rose-500/40 flex items-center justify-center text-rose-700 dark:text-rose-400 font-bold text-xs shrink-0">
                      {(liveConfig.masterAdminName || 'O').charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="font-bold text-slate-900 dark:text-white text-xs leading-snug break-words">
                      {liveConfig.masterAdminName}
                    </div>
                    <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-rose-100 dark:bg-rose-900/60 text-rose-700 dark:text-rose-300 font-mono font-semibold shrink-0">
                        {lang === 'bn' ? 'মালিক (Owner)' : 'Owner'}
                      </span>
                      <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono truncate">
                        {liveConfig.masterAdminTelegramHandle}
                      </span>
                    </div>
                  </div>
                </div>

                <a
                  href={liveConfig.masterAdminTelegram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold shadow-sm transition shrink-0 whitespace-nowrap"
                >
                  <Send className="w-3 h-3" />
                  <span>{lang === 'bn' ? 'টেলিগ্রাম' : 'Telegram'}</span>
                </a>
              </div>

              {liveSubAdmins.map((sub) => (
                <div
                  key={sub.id}
                  className="p-2.5 px-3 rounded-xl bg-cyan-50 dark:bg-cyan-950/30 border border-cyan-200 dark:border-cyan-500/25 flex items-center justify-between gap-2.5"
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    {sub.avatarDataUrl ? (
                      <img
                        src={sub.avatarDataUrl}
                        alt={sub.displayName || sub.username}
                        referrerPolicy="no-referrer"
                        className="w-9 h-9 rounded-lg object-cover border border-cyan-300 dark:border-cyan-500/30 shrink-0"
                      />
                    ) : (
                      <div className="w-9 h-9 rounded-lg bg-cyan-100 dark:bg-cyan-950 border border-cyan-300 dark:border-cyan-500/30 flex items-center justify-center text-cyan-700 dark:text-cyan-400 font-bold text-xs shrink-0">
                        {sub.username.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="font-bold text-slate-900 dark:text-white text-xs leading-snug break-words">
                        {sub.displayName || sub.username}
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-100 dark:bg-cyan-900/60 text-cyan-700 dark:text-cyan-300 font-mono font-semibold shrink-0">
                          {lang === 'bn' ? 'অ্যাডমিন (Admin)' : 'Admin'}
                        </span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono truncate">
                          {sub.telegramUsername}
                        </span>
                      </div>
                    </div>
                  </div>

                  <a
                    href={sub.telegramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-bold shadow-sm transition shrink-0 whitespace-nowrap"
                  >
                    <Send className="w-3 h-3" />
                    <span>{lang === 'bn' ? 'টেলিগ্রাম' : 'Telegram'}</span>
                  </a>
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setPendingModalOpen(false)}
              className="w-full py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold transition"
            >
              {lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
