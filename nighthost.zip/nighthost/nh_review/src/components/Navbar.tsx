import React, { useState, useEffect, useRef } from 'react';
import { User, ThemeMode, UserPageView, AdminTab } from '../types';
import { storage } from '../services/storage';
import { formatStorageFromKb, formatStorageFromMb, getRoleDisplayLabel, sanitizeExternalLinkUrl } from '../services/format';
import {
  HardDrive,
  Clock,
  ArrowLeft,
  Menu,
  LogOut,
  Globe,
  Sun,
  Moon,
  Shield,
  Info,
  UserCog,
  LayoutDashboard,
  FolderUp,
  FileCode2,
  FolderGit2,
  Users,
  UserPlus,
  BellRing,
  Activity,
  Settings,
  X,
  Link2,
  ExternalLink,
  Check,
} from 'lucide-react';

interface NavbarProps {
  user: User | null;
  currentView: string;
  userPage?: UserPageView;
  onSelectUserPage?: (page: UserPageView) => void;
  adminTab?: AdminTab;
  onSelectAdminTab?: (tab: AdminTab) => void;
  theme: ThemeMode;
  onToggleTheme: () => void;
  onNavigate: (view: string) => void;
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onOpenProfile?: () => void;
  lang: 'bn' | 'en';
  onToggleLang: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  currentView,
  userPage = 'overview',
  onSelectUserPage,
  adminTab = 'overview',
  onSelectAdminTab,
  theme,
  onToggleTheme,
  onNavigate,
  onOpenAuth,
  onOpenProfile,
  lang,
  onToggleLang,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [inboxOpen, setInboxOpen] = useState(false);
  const [timeInfo, setTimeInfo] = useState<{ seconds: number; isExpired: boolean; label: string }>({
    seconds: Infinity,
    isExpired: false,
    label: '',
  });

  const config = storage.getConfig();
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const openInboxListener = () => setInboxOpen(true);
    window.addEventListener('nighthost:open-inbox', openInboxListener);
    return () => window.removeEventListener('nighthost:open-inbox', openInboxListener);
  }, []);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (!user) return;
    const updateTimer = () => {
      setTimeInfo(storage.getRemainingApprovalTime(user, lang));
    };

    updateTimer();
    const timer = setInterval(updateTimer, 1000);
    return () => clearInterval(timer);
  }, [user, lang]);

  const handleLogout = async () => {
    setMenuOpen(false);
    await storage.logoutAsync();
    if (window.location.pathname !== '/') {
      window.history.pushState({}, '', '/');
    }
    onNavigate('dashboard');
  };

  const isAdminPanel = currentView === 'admin';
  const showBackButton =
    Boolean(user) &&
    ((isAdminPanel && adminTab !== 'overview') ||
      (!isAdminPanel && currentView === 'dashboard' && userPage !== 'overview') ||
      (currentView !== 'dashboard' && currentView !== 'admin'));

  const handleBack = () => {
    if (isAdminPanel) {
      onSelectAdminTab?.('overview');
    } else if (currentView === 'dashboard') {
      onSelectUserPage?.('overview');
    } else {
      onNavigate('dashboard');
    }
  };

  const storageLimit = user?.storageLimitMb || 100;
  const exactKbUsed = user
    ? storage.getSites(user.id).reduce((acc, s) => acc + (Number(s.totalSizeKb) || 0), 0) +
      (Number(user.avatarSizeKb) || 0)
    : 0;
  const storageUsedMb = exactKbUsed > 0 ? exactKbUsed / 1024 : 0;
  const rawPct = storageLimit > 0 ? (exactKbUsed / (storageLimit * 1024)) * 100 : 0;
  const storageBarWidth = exactKbUsed === 0 ? 0 : Math.min(100, rawPct);
  const storagePercentLabel =
    exactKbUsed === 0 ? '0' : rawPct > 0 && rawPct < 1 ? '<1' : String(Math.min(100, Math.round(rawPct)));

  const userNotifications = user ? storage.getPopupMessagesForUser(user.id) : [];
  const unreadNotifications = user ? storage.getUnreadPopupMessagesForUser(user.id) : [];

  const subAdminList = storage.getSubAdmins();
  const subRecord =
    user?.role === 'subadmin'
      ? subAdminList.find(s => s.id === user.id || s.username.toLowerCase() === user.username.toLowerCase())
      : undefined;
  const canSendMessages = user?.role === 'admin' || subRecord?.canSendMessages !== false;
  const roleLabel = user ? getRoleDisplayLabel(user.role, lang) : '';

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 dark:border-slate-800/80 bg-white/95 dark:bg-slate-950/90 backdrop-blur-md transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-2">
        {/* Left: Optional Sub-Page Back Button & Brand Logo */}
        <div className="flex items-center gap-2 min-w-0">
          {showBackButton && (
            <button
              type="button"
              onClick={handleBack}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white text-xs font-semibold transition border border-slate-200 dark:border-slate-800 shadow-sm shrink-0"
              title={lang === 'bn' ? 'ফিরে যান' : 'Back'}
            >
              <ArrowLeft className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
              <span className="hidden sm:inline">{lang === 'bn' ? 'ফিরে যান' : 'Back'}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              if (user && (user.role === 'admin' || user.role === 'subadmin') && isAdminPanel) {
                onSelectAdminTab?.('overview');
              } else {
                onSelectUserPage?.('overview');
                onNavigate('dashboard');
              }
            }}
            aria-label={config.brandName || 'NIGHTHOST'}
            className="flex items-center gap-2 cursor-pointer group select-none text-left min-w-0 focus:outline-none"
          >
            <img
              src="/nighthost-icon.png"
              alt="NIGHTHOST Icon"
              className="w-8 h-8 sm:w-9 sm:h-9 object-contain shrink-0 transition-transform duration-200 group-hover:scale-105"
            />
            <div className="min-w-0">
              {(!config.brandName || config.brandName.trim().toUpperCase() === 'NIGHTHOST') ? (
                <div className="flex items-center gap-1.5">
                  <img
                    src="/nighthost-wordmark.png"
                    alt="NIGHTHOST"
                    className="h-4 sm:h-5 w-auto object-contain drop-shadow-[0_1px_2px_rgba(15,23,42,0.75)] dark:drop-shadow-none"
                  />
                  <span className="hidden sm:inline-block text-[9px] font-mono px-1.5 py-0.5 rounded bg-cyan-50 dark:bg-cyan-950/70 border border-cyan-200 dark:border-cyan-500/30 text-cyan-700 dark:text-cyan-300 font-bold uppercase">
                    CLOUD
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-sm sm:text-base tracking-tight text-slate-900 dark:text-white truncate">
                    {config.brandName}
                  </span>
                  <span className="hidden sm:inline-block text-[9px] font-mono px-1.5 py-0.5 rounded bg-cyan-50 dark:bg-cyan-950/70 border border-cyan-200 dark:border-cyan-500/30 text-cyan-700 dark:text-cyan-300 font-bold uppercase">
                    CLOUD
                  </span>
                </div>
              )}
              <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium hidden md:block leading-tight">
                Web & Microservice Hosting
              </p>
            </div>
          </button>
        </div>

        {/* Center Metrics (Desktop Logged In) */}
        {user ? (
          user.role === 'admin' ? (
            <div className="hidden lg:flex items-center gap-2.5 shrink-0">
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300 text-xs font-bold">
                <Shield className="w-3.5 h-3.5 flex-shrink-0" />
                <span>
                  {lang === 'bn'
                    ? 'মালিক (Owner) • আনলিমিটেড রুট অ্যাক্সেস'
                    : 'Platform Owner • Unlimited Root Access'}
                </span>
              </div>
            </div>
          ) : (
            <div className="hidden lg:flex items-center gap-3 shrink-0">
              <div
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-medium ${
                  timeInfo.isExpired
                    ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300'
                    : user.expiresAt
                    ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-500/40 text-amber-700 dark:text-amber-300'
                    : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
                }`}
              >
                <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                <div className="flex flex-col">
                  <span className="text-[9px] uppercase tracking-wider text-slate-500 dark:text-slate-400 font-mono">
                    {lang === 'bn' ? 'অ্যাক্সেস মেয়াদ' : 'Validity'}
                  </span>
                  <span className="font-semibold text-xs leading-none">
                    {timeInfo.label || (lang === 'bn' ? 'স্থায়ী অ্যাক্টিভ' : 'Unlimited Access')}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 text-xs">
                <HardDrive className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400 flex-shrink-0" />
                <div className="flex flex-col w-40">
                  <div className="flex justify-between items-center text-[10px] text-slate-500 dark:text-slate-400 mb-0.5 tabular-nums">
                    <span className="font-mono">
                      {formatStorageFromKb(exactKbUsed)} / {formatStorageFromMb(storageLimit)}
                    </span>
                    <span className="font-mono text-cyan-600 dark:text-cyan-400 font-bold">{storagePercentLabel}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-300 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        rawPct > 85 ? 'bg-rose-500' : 'bg-gradient-to-r from-cyan-500 to-indigo-500'
                      }`}
                      style={{ width: `${storageBarWidth}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          )
        ) : null}

        {/* Right Actions — compact & guaranteed never to overflow 360px mobile */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {user && user.status === 'approved' && (
            <button
              type="button"
              onClick={() => setInboxOpen(true)}
              aria-label={lang === 'bn' ? 'নোটিফিকেশন ইনবক্স' : 'Notifications Inbox'}
              className="relative p-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:border-cyan-500 transition shrink-0"
              title={lang === 'bn' ? 'নোটিফিকেশন ও লিংকসমূহ' : 'Notifications & Links'}
            >
              <BellRing className={`w-4 h-4 ${unreadNotifications.length > 0 ? 'text-cyan-600 dark:text-cyan-400' : ''}`} />
              {unreadNotifications.length > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[16px] h-4 px-1 rounded-full bg-rose-600 text-white text-[9px] font-mono font-bold flex items-center justify-center shadow">
                  {unreadNotifications.length}
                </span>
              )}
            </button>
          )}

          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:border-cyan-500 transition shrink-0"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-indigo-600" />
            )}
          </button>

          <button
            type="button"
            onClick={onToggleLang}
            aria-label="Toggle language"
            className="px-2 py-1.5 text-[11px] sm:text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition font-mono font-bold shrink-0"
          >
            {lang === 'bn' ? 'EN' : 'বাংলা'}
          </button>

          {!user ? (
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() => onOpenAuth('login')}
                className="px-2.5 sm:px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] sm:text-xs font-semibold shadow-sm transition whitespace-nowrap"
              >
                {lang === 'bn' ? 'লগইন' : 'Login'}
              </button>
              {config.allowRegistration !== false && (
                <button
                  type="button"
                  onClick={() => onOpenAuth('register')}
                  className="px-2.5 sm:px-3.5 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-700 text-[11px] sm:text-xs font-medium transition whitespace-nowrap"
                >
                  {lang === 'bn' ? 'অ্যাকাউন্ট' : 'Register'}
                </button>
              )}
            </div>
          ) : (
            <div className="relative shrink-0" ref={menuRef}>
              <button
                type="button"
                aria-label="Navigation menu"
                aria-expanded={menuOpen}
                onClick={() => setMenuOpen(!menuOpen)}
                className="flex items-center gap-1.5 p-1 pr-2 rounded-xl bg-slate-100 dark:bg-slate-900 hover:bg-slate-200 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 transition text-left"
              >
                {user.avatarDataUrl ? (
                  <img
                    src={user.avatarDataUrl}
                    alt={user.username}
                    referrerPolicy="no-referrer"
                    className="w-7 h-7 rounded-lg object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                  />
                ) : (
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                      user.role === 'admin'
                        ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border border-rose-300 dark:border-rose-500/30'
                        : user.role === 'subadmin'
                        ? 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-500/30'
                        : 'bg-cyan-100 dark:bg-cyan-950 text-cyan-700 dark:text-cyan-300 border border-cyan-300 dark:border-cyan-500/30'
                    }`}
                  >
                    {user.username.charAt(0).toUpperCase()}
                  </div>
                )}
                <div className="hidden sm:block text-left">
                  <div className="text-xs font-medium text-slate-800 dark:text-slate-200 leading-tight max-w-[90px] truncate">
                    {user.username}
                  </div>
                  <div
                    className={`text-[10px] font-semibold ${
                      user.role === 'admin'
                        ? 'text-rose-600 dark:text-rose-400'
                        : user.role === 'subadmin'
                        ? 'text-amber-600 dark:text-amber-400'
                        : 'text-cyan-600 dark:text-cyan-400'
                    }`}
                  >
                    {roleLabel}
                  </div>
                </div>
                <Menu className="w-4 h-4 text-slate-500 dark:text-slate-400" />
              </button>

              {menuOpen && (
                <div className="absolute right-0 mt-2 w-68 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2 shadow-2xl z-50 divide-y divide-slate-100 dark:divide-slate-800/80 max-h-[82vh] overflow-y-auto">
                  <div className="p-3">
                    <div className="flex items-center gap-2.5">
                      {user.avatarDataUrl ? (
                        <img
                          src={user.avatarDataUrl}
                          alt={user.username}
                          referrerPolicy="no-referrer"
                          className="w-9 h-9 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                        />
                      ) : (
                        <div
                          className={`w-9 h-9 rounded-xl border flex items-center justify-center font-bold text-xs shrink-0 ${
                            user.role === 'admin'
                              ? 'bg-rose-50 dark:bg-rose-950 border-rose-200 dark:border-rose-500/30 text-rose-700 dark:text-rose-300'
                              : user.role === 'subadmin'
                              ? 'bg-amber-50 dark:bg-amber-950 border-amber-200 dark:border-amber-500/30 text-amber-700 dark:text-amber-300'
                              : 'bg-cyan-50 dark:bg-cyan-950 border-cyan-200 dark:border-cyan-500/30 text-cyan-700 dark:text-cyan-300'
                          }`}
                        >
                          {user.username.charAt(0).toUpperCase()}
                        </div>
                      )}
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{user.fullName || user.username}</p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {user.email}
                          {user.subdomain ? ` · /u/${user.subdomain}/` : ''}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 flex items-center gap-1.5">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold ${
                          user.role === 'admin'
                            ? 'bg-rose-50 dark:bg-rose-950 border border-rose-200 dark:border-rose-800/60 text-rose-700 dark:text-rose-300'
                            : user.role === 'subadmin'
                            ? 'bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800/60 text-amber-700 dark:text-amber-300'
                            : 'bg-cyan-50 dark:bg-cyan-950 border border-cyan-200 dark:border-cyan-800/60 text-cyan-700 dark:text-cyan-300'
                        }`}
                      >
                        {roleLabel}
                      </span>
                      <span className="text-[10px] text-slate-500 dark:text-slate-400">
                        {user.role === 'admin'
                          ? lang === 'bn'
                            ? 'প্ল্যাটফর্ম মালিক (আনলিমিটেড)'
                            : 'Platform Owner (Unlimited)'
                          : lang === 'en' && !user.expiresAt
                          ? 'Permanent'
                          : user.approvalDurationLabel || (lang === 'bn' ? 'সক্রিয়' : 'Active')}
                      </span>
                    </div>

                    {user.role !== 'admin' && (
                      <div className="mt-3 lg:hidden pt-2 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-600 dark:text-slate-300 space-y-1">
                        <div className="flex justify-between tabular-nums">
                          <span>{lang === 'bn' ? 'স্টোরেজ:' : 'Storage:'}</span>
                          <span className="font-mono text-cyan-600 dark:text-cyan-400">
                            {formatStorageFromKb(exactKbUsed)} / {formatStorageFromMb(storageLimit)} ({storagePercentLabel}%)
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>{lang === 'bn' ? 'মেয়াদ:' : 'Validity:'}</span>
                          <span className="text-amber-600 dark:text-amber-400 font-semibold">
                            {timeInfo.label || (lang === 'bn' ? 'স্থায়ী' : 'Unlimited')}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Role-aware dedicated sub-pages */}
                  {isAdminPanel && (user.role === 'admin' || user.role === 'subadmin') ? (
                    <div className="py-1.5 space-y-0.5">
                      <button
                        type="button"
                        onClick={() => {
                          onSelectAdminTab?.('overview');
                          setMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                          adminTab === 'overview'
                            ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <LayoutDashboard className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                        <span>{lang === 'bn' ? 'ওভারভিউ ড্যাশবোর্ড' : 'Overview Dashboard'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onSelectAdminTab?.('users');
                          setMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                          adminTab === 'users'
                            ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <Users className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                        <span>{lang === 'bn' ? 'সকল ইউজার' : 'Manage Users'}</span>
                      </button>

                      {user.role === 'admin' && (
                        <button
                          type="button"
                          onClick={() => {
                            onSelectAdminTab?.('subadmins');
                            setMenuOpen(false);
                          }}
                          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                            adminTab === 'subadmins'
                              ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                          }`}
                        >
                          <UserPlus className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                          <span>{lang === 'bn' ? 'অ্যাডমিন ও টেলিগ্রাম' : 'Admins & Telegram'}</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          onSelectAdminTab?.('sites');
                          setMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                          adminTab === 'sites'
                            ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <Globe className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                        <span>{lang === 'bn' ? 'গ্লোবাল ওয়েবসাইট' : 'Global Sites'}</span>
                      </button>

                      {canSendMessages && (
                        <button
                          type="button"
                          onClick={() => {
                            onSelectAdminTab?.('messages');
                            setMenuOpen(false);
                          }}
                          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                            adminTab === 'messages'
                              ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                          }`}
                        >
                          <BellRing className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                          <span>{lang === 'bn' ? 'পপআপ মেসেজ' : 'Popup Messages'}</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          onSelectAdminTab?.('logs');
                          setMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                          adminTab === 'logs'
                            ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <Activity className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                        <span>{lang === 'bn' ? 'অডিট লগ' : 'Audit Logs'}</span>
                      </button>

                      {user.role === 'admin' && (
                        <button
                          type="button"
                          onClick={() => {
                            onSelectAdminTab?.('settings');
                            setMenuOpen(false);
                          }}
                          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                            adminTab === 'settings'
                              ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                          }`}
                        >
                          <Settings className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                          <span>{lang === 'bn' ? 'প্ল্যাটফর্ম সেটিংস' : 'Platform Settings'}</span>
                        </button>
                      )}

                      {onOpenProfile && (
                        <button
                          type="button"
                          onClick={() => {
                            setMenuOpen(false);
                            onOpenProfile();
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                        >
                          <UserCog className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                          <span>{lang === 'bn' ? 'প্রোফাইল ও ছবি এডিট' : 'Profile & Photo Edit'}</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          onSelectUserPage?.('overview');
                          onNavigate('dashboard');
                          setMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition"
                      >
                        <Globe className="w-4 h-4" />
                        <span>{lang === 'bn' ? 'ইউজার ড্যাশবোর্ডে যান' : 'Switch to User View'}</span>
                      </button>
                    </div>
                  ) : (
                    <div className="py-1.5 space-y-0.5">
                      {(user.role === 'admin' || user.role === 'subadmin') && (
                        <button
                          type="button"
                          onClick={() => {
                            onSelectAdminTab?.('overview');
                            onNavigate('admin');
                            setMenuOpen(false);
                          }}
                          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition font-semibold ${
                            user.role === 'admin'
                              ? 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30'
                              : 'text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/30'
                          }`}
                        >
                          <Shield className="w-4 h-4" />
                          <span>{lang === 'bn' ? 'ম্যানেজমেন্ট কনসোলে যান' : 'Open Management Console'}</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          onSelectUserPage?.('overview');
                          setMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                          userPage === 'overview'
                            ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <LayoutDashboard className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                        <span>{lang === 'bn' ? 'ড্যাশবোর্ড ওভারভিউ' : 'Dashboard Overview'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onSelectUserPage?.('sites');
                          setMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                          userPage === 'sites'
                            ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <Globe className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                        <span>{lang === 'bn' ? 'আমার ওয়েবসাইটসমূহ' : 'My Hosted Sites'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onSelectUserPage?.('deploy-folder');
                          setMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                          userPage === 'deploy-folder'
                            ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <FolderUp className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                        <span>{lang === 'bn' ? 'ফোল্ডার ডিপ্লয়' : 'Deploy Folder'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onSelectUserPage?.('deploy-single');
                          setMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                          userPage === 'deploy-single'
                            ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <FileCode2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                        <span>{lang === 'bn' ? 'সিঙ্গেল ফাইল (PHP/HTML)' : 'Single File Runner'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onSelectUserPage?.('deploy-github');
                          setMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                          userPage === 'deploy-github'
                            ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <FolderGit2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                        <span>{lang === 'bn' ? 'গিটহাব সিঙ্ক' : 'GitHub Sync'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onSelectUserPage?.('profile');
                          setMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                          userPage === 'profile'
                            ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <UserCog className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                        <span>{lang === 'bn' ? 'প্রোফাইল ও ছবি এডিট' : 'Profile & Photo Edit'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onSelectUserPage?.('guide');
                          setMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition ${
                          userPage === 'guide'
                            ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 font-bold'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <Info className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                        <span>{lang === 'bn' ? 'ব্যবহার নির্দেশিকা / ইনফো' : 'User Guide / Info'}</span>
                      </button>
                    </div>
                  )}

                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={handleLogout}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>{lang === 'bn' ? 'লগআউট করুন' : 'Sign Out'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Persistent User Notification Inbox Modal (with Marked & Unmarked Links) */}
      {inboxOpen && user && (
        <div
          className="fixed inset-0 z-[70] min-h-[100dvh] flex items-center justify-center p-4 bg-slate-900/65 dark:bg-slate-950/85 backdrop-blur-md"
          role="dialog"
          aria-modal="true"
          aria-labelledby="inbox-modal-title"
        >
          <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[86dvh]">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50 dark:bg-slate-950/60">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-9 h-9 rounded-xl bg-cyan-50 dark:bg-cyan-950/70 border border-cyan-200 dark:border-cyan-500/30 flex items-center justify-center text-cyan-600 dark:text-cyan-400 shrink-0">
                  <BellRing className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h2 id="inbox-modal-title" className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white truncate">
                    {lang === 'bn' ? 'নোটিফিকেশন ও অ্যাডমিন ইনবক্স' : 'Notifications & Notice Inbox'}
                  </h2>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {lang === 'bn'
                      ? `মোট ${userNotifications.length}টি বিজ্ঞপ্তি • ${unreadNotifications.length}টি নতুন`
                      : `${userNotifications.length} notices • ${unreadNotifications.length} unread`}
                  </p>
                </div>
              </div>
              <button
                type="button"
                aria-label={lang === 'bn' ? 'ইনবক্স বন্ধ করুন' : 'Close notifications'}
                onClick={() => setInboxOpen(false)}
                className="p-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 sm:p-5 overflow-y-auto space-y-3">
              {userNotifications.length === 0 ? (
                <div className="p-8 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-dashed border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500 dark:text-slate-400">
                  {lang === 'bn'
                    ? 'আপনার জন্য এখনো কোনো অ্যাডমিন নোটিশ বা বার্তা আসেনি।'
                    : 'No admin notices or announcements yet.'}
                </div>
              ) : (
                userNotifications.map((msg) => {
                  const isDismissed = storage.isPopupMessageDismissedByUser(msg, user.id);
                  const safeUrl = msg.linkUrl ? sanitizeExternalLinkUrl(msg.linkUrl) : '';
                  return (
                    <div
                      key={msg.id}
                      className={`p-4 rounded-2xl border space-y-2.5 text-xs ${
                        !isDismissed
                          ? 'bg-cyan-50/50 dark:bg-cyan-950/30 border-cyan-300 dark:border-cyan-500/40'
                          : 'bg-slate-50 dark:bg-slate-950/75 border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-1.5 mb-0.5">
                            <span className="text-[10px] font-mono font-bold text-cyan-700 dark:text-cyan-400">
                              @{msg.senderUsername}
                            </span>
                            {!isDismissed && (
                              <span className="px-1.5 py-0.5 rounded bg-rose-50 dark:bg-rose-950 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-500/30 text-[9px] font-mono font-bold uppercase">
                                {lang === 'bn' ? 'নতুন' : 'NEW'}
                              </span>
                            )}
                          </div>
                          <h3 className="text-sm font-bold text-slate-900 dark:text-white break-words">
                            {msg.title}
                          </h3>
                        </div>
                        {!isDismissed && (
                          <button
                            type="button"
                            onClick={() => storage.dismissPopupMessageAsync(msg.id, user.id)}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-[10px] font-bold shrink-0 whitespace-nowrap"
                          >
                            <Check className="w-3 h-3" />
                            <span>{lang === 'bn' ? 'পঠিত' : 'Mark Read'}</span>
                          </button>
                        )}
                      </div>

                      <p className="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap break-words">
                        {msg.message}
                      </p>

                      {safeUrl && msg.linkMarked === false && (
                        <div>
                          <a
                            href={safeUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 font-medium text-cyan-700 dark:text-cyan-400 underline underline-offset-4 hover:opacity-80 break-all"
                          >
                            <Link2 className="w-3.5 h-3.5 shrink-0" />
                            <span>{msg.linkText || safeUrl}</span>
                            <ExternalLink className="w-3 h-3 shrink-0" />
                          </a>
                        </div>
                      )}

                      {safeUrl && msg.linkMarked !== false && (
                        <a
                          href={safeUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-full flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold shadow-sm transition"
                        >
                          <span className="inline-flex items-center gap-2 min-w-0 truncate">
                            <Link2 className="w-3.5 h-3.5 shrink-0" />
                            <span className="truncate">{msg.linkText || safeUrl}</span>
                          </span>
                          <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                        </a>
                      )}

                      <div className="text-[10px] text-slate-400 font-mono tabular-nums pt-0.5">
                        {new Date(msg.createdAt).toLocaleString()}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
