import React, { useMemo, useState, useRef } from 'react';
import { User, HostedSite, SiteFile } from '../types';
import {
  assessProjectCloudFootprint,
  auditFolderFiles,
  autoRepairSiteFiles,
  getFileType,
  getMimeType,
  isBinaryFile,
  isPathHidden,
  optimizeProjectToRunnableCore,
  slugify,
} from '../services/siteEngine';
import { storage } from '../services/storage';
import { formatStorageFromMb, formatStorageFromKb } from '../services/format';
import { CyberScanner } from './CyberScanner';
import {
  FolderUp,
  AlertCircle,
  FileCode,
  Lock,
  Sparkles,
  ArrowRight,
  FileCheck,
  Loader2,
  Cpu,
  ChevronDown,
  ChevronUp,
  Globe,
  Wrench,
  Minimize2,
  CheckCircle2,
} from 'lucide-react';

interface FolderDeployerProps {
  user: User;
  onDeploySuccess: (site: HostedSite) => void;
  onCancel: () => void;
  lang: 'bn' | 'en';
}

interface ParsedLocalFile {
  path: string;
  content: string;
  size: number;
  isBinary: boolean;
  mimeType: string;
}

export const FolderDeployer: React.FC<FolderDeployerProps> = ({
  user,
  onDeploySuccess,
  onCancel,
  lang,
}) => {
  const [projectName, setProjectName] = useState('');
  const [customSlug, setCustomSlug] = useState('');
  const [description, setDescription] = useState('');
  const [parsedFiles, setParsedFiles] = useState<ParsedLocalFile[]>([]);
  const [scanResult, setScanResult] = useState<ReturnType<typeof auditFolderFiles> | null>(null);
  const [repairPreviewNotes, setRepairPreviewNotes] = useState<string[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanStage, setScanStage] = useState('');
  const [isReadingFiles, setIsReadingFiles] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [showFileList, setShowFileList] = useState(false);
  const [deployError, setDeployError] = useState<string | null>(null);
  const [trimSummary, setTrimSummary] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const isOwner = user.role === 'admin';

  const footprint = useMemo(() => {
    if (parsedFiles.length === 0) return null;
    return assessProjectCloudFootprint(
      parsedFiles.map(f => ({
        path: f.path,
        content: f.isBinary ? '' : f.content,
        size: f.size,
        isBinary: f.isBinary,
      }))
    );
  }, [parsedFiles]);

  const handleFolderSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    await processFiles(Array.from(fileList));
  };

  const readEntryRecursive = async (
    entry: FileSystemEntry,
    basePath = ''
  ): Promise<{ file: File; path: string }[]> => {
    if (entry.isFile) {
      const fileEntry = entry as FileSystemFileEntry;
      return new Promise((resolve) => {
        fileEntry.file(
          (file) => resolve([{ file, path: basePath ? `${basePath}/${file.name}` : file.name }]),
          () => resolve([])
        );
      });
    }
    if (entry.isDirectory) {
      const dirEntry = entry as FileSystemDirectoryEntry;
      const reader = dirEntry.createReader();
      const entries = await new Promise<FileSystemEntry[]>((resolve) => {
        const all: FileSystemEntry[] = [];
        const readBatch = () => {
          reader.readEntries(
            (batch) => {
              if (batch.length === 0) resolve(all);
              else {
                all.push(...batch);
                readBatch();
              }
            },
            () => resolve(all)
          );
        };
        readBatch();
      });
      const nested = await Promise.all(
        entries.map((child) => readEntryRecursive(child, basePath ? `${basePath}/${entry.name}` : entry.name))
      );
      return nested.flat();
    }
    return [];
  };

  const readFilePayload = (file: File, binary: boolean): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      if (binary) {
        reader.onload = () => {
          const result = (reader.result as string) || '';
          const commaIdx = result.indexOf(',');
          resolve(commaIdx >= 0 ? result.slice(commaIdx + 1) : '');
        };
        reader.onerror = () => resolve('');
        reader.readAsDataURL(file);
      } else {
        reader.onload = () => resolve((reader.result as string) || '');
        reader.onerror = () => resolve('');
        reader.readAsText(file);
      }
    });
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    setDeployError(null);

    const items = e.dataTransfer.items;
    if (items && items.length > 0 && typeof items[0].webkitGetAsEntry === 'function') {
      setIsReadingFiles(true);
      try {
        const collected: { file: File; path: string }[] = [];
        let rootFolderName = '';
        for (let i = 0; i < items.length; i++) {
          const entry = items[i].webkitGetAsEntry();
          if (entry) {
            if (entry.isDirectory && !rootFolderName) {
              rootFolderName = entry.name;
            }
            const res = await readEntryRecursive(entry);
            collected.push(...res);
          }
        }
        if (collected.length > 0) {
          const processed: ParsedLocalFile[] = [];
          for (const item of collected) {
            const cleanPath = item.path.includes('/')
              ? item.path.substring(item.path.indexOf('/') + 1)
              : item.path;
            if (!cleanPath || cleanPath.startsWith('.git/') || cleanPath.includes('node_modules/')) continue;
            const binary = isBinaryFile(cleanPath);
            const content = await readFilePayload(item.file, binary);
            processed.push({
              path: cleanPath,
              content,
              size: item.file.size,
              isBinary: binary,
              mimeType: getMimeType(cleanPath),
            });
          }
          finalizeProcessedFiles(processed, rootFolderName);
          return;
        }
      } finally {
        setIsReadingFiles(false);
      }
    }

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      await processFiles(Array.from(e.dataTransfer.files));
    }
  };

  const processFiles = async (files: File[]) => {
    setDeployError(null);
    setIsReadingFiles(true);
    try {
      const processed: ParsedLocalFile[] = [];
      let detectedDirName = '';

      for (const file of files) {
        const relativePath = file.webkitRelativePath || file.name;
        if (!detectedDirName && relativePath.includes('/')) {
          detectedDirName = relativePath.split('/')[0];
        }

        const cleanPath = relativePath.includes('/')
          ? relativePath.substring(relativePath.indexOf('/') + 1)
          : relativePath;

        if (!cleanPath || cleanPath.startsWith('.git/') || cleanPath.includes('node_modules/')) continue;

        try {
          const binary = isBinaryFile(cleanPath);
          const content = await readFilePayload(file, binary);
          processed.push({
            path: cleanPath,
            content,
            size: file.size,
            isBinary: binary,
            mimeType: getMimeType(cleanPath),
          });
        } catch {
          // skip unreadable file
        }
      }

      finalizeProcessedFiles(processed, detectedDirName);
    } finally {
      setIsReadingFiles(false);
    }
  };

  const finalizeProcessedFiles = (processed: ParsedLocalFile[], detectedDirName: string) => {
    if (processed.length === 0) {
      setDeployError(lang === 'bn' ? 'ফোল্ডারে কোনো রিড-যোগ্য ফাইল পাওয়া যায়নি।' : 'No readable files found in folder.');
      return;
    }

    setParsedFiles(processed);
    setTrimSummary(null);
    const audit = auditFolderFiles(
      processed.map(f => ({ path: f.path, content: f.isBinary ? '[binary]' : f.content, size: f.size }))
    );
    setScanResult(audit);

    const initialName = detectedDirName || 'my-web-project';
    setProjectName(initialName.replace(/[-_]/g, ' ').toUpperCase());
    const suggestedSlug = slugify(initialName);
    setCustomSlug(suggestedSlug);

    // Preview auto-repair synthesis
    const previewMap: Record<string, SiteFile> = {};
    for (const f of processed) {
      previewMap[f.path] = {
        path: f.path,
        content: f.content,
        size: f.size,
        isHidden: isPathHidden(f.path),
        isBinary: f.isBinary,
        mimeType: f.mimeType,
        type: getFileType(f.path),
      };
    }
    const repairPreview = autoRepairSiteFiles(previewMap);
    setRepairPreviewNotes(repairPreview.repairLogs);
  };

  const applyRunnableTrim = (): { files: ParsedLocalFile[]; audit: ReturnType<typeof auditFolderFiles> } | null => {
    if (parsedFiles.length === 0) return null;
    const trimmed = optimizeProjectToRunnableCore(parsedFiles);
    const nextAudit = auditFolderFiles(
      trimmed.files.map(f => ({ path: f.path, content: f.isBinary ? '[binary]' : f.content, size: f.size }))
    );
    setParsedFiles(trimmed.files);
    setScanResult(nextAudit);
    setTrimSummary(lang === 'bn' ? trimmed.summaryBn : trimmed.summaryEn);
    setDeployError(null);
    return { files: trimmed.files, audit: nextAudit };
  };

  const handleStartDeploy = async (override?: { files: ParsedLocalFile[]; audit: ReturnType<typeof auditFolderFiles> }) => {
    const activeFiles = override ? override.files : parsedFiles;
    const activeScan = override ? override.audit : scanResult;
    if (!activeScan || activeScan.errors.length > 0) return;
    setDeployError(null);
    if (!projectName.trim()) {
      setDeployError(lang === 'bn' ? 'অনুগ্রহ করে প্রজেক্টের একটি নাম লিখুন।' : 'Please enter a project name.');
      return;
    }

    const finalSlug = slugify(customSlug || projectName);
    if (storage.isSlugTaken(finalSlug)) {
      setDeployError(
        lang === 'bn'
          ? `স্লাগ '${finalSlug}' ইতিমধ্যে ব্যবহৃত! অনুগ্রহ করে ইউনিক লিংক নাম নির্বাচন করুন।`
          : `Slug '${finalSlug}' is already taken. Please pick another URL.`
      );
      return;
    }

    const totalMb = activeScan.totalSizeBytes / (1024 * 1024);
    if (!isOwner && user.storageUsedMb + totalMb > user.storageLimitMb) {
      const rem = Math.max(0, user.storageLimitMb - user.storageUsedMb);
      setDeployError(
        lang === 'bn'
          ? `স্টোরেজ সীমা অতিক্রম করেছে! আপনার অবশিষ্ট স্টোরেজ আছে ${formatStorageFromMb(rem)}, কিন্তু ফোল্ডারের আকার ${formatStorageFromMb(totalMb)}।`
          : `Storage quota exceeded! Remaining quota is ${formatStorageFromMb(rem)}, folder is ${formatStorageFromMb(totalMb)}.`
      );
      return;
    }

    setScanProgress(6);
    setScanStage(lang === 'bn' ? 'ফাইল প্যাকেজ ও অটো-রিপেয়ার প্রস্তুত করা হচ্ছে...' : 'Preparing bundle & auto-repair checks...');
    setIsScanning(true);
    setIsDeploying(true);

    const filesRecord: Record<string, SiteFile> = {};
    for (const f of activeFiles) {
      filesRecord[f.path] = {
        path: f.path,
        content: f.content,
        size: f.size,
        isHidden: isPathHidden(f.path),
        isBinary: f.isBinary,
        mimeType: f.mimeType,
        type: getFileType(f.path),
      };
    }

    const res = await storage.createSiteWithProgressAsync(
      {
        userId: user.id,
        username: user.username,
        ownerSubdomain: user.subdomain,
        name: projectName,
        slug: finalSlug,
        customPath: finalSlug,
        description: description || 'Folder-deployed high performance web app',
        type: 'folder',
        status: 'online',
        rootFile: activeScan.entryPointFound || 'index.html',
        runtimeType: activeScan.detectedRuntime || 'static',
        totalFiles: activeScan.fileCount,
        totalSizeKb: Math.max(1, Math.ceil(activeScan.totalSizeBytes / 1024)),
        hiddenFilesCount: activeScan.hiddenCount,
        deploymentLogs: [
          {
            timestamp: new Date().toISOString(),
            level: 'info',
            message: `Full folder package unpacked: ${activeScan.fileCount} total files.`,
          },
          {
            timestamp: new Date().toISOString(),
            level: 'info',
            message: `Runtime environment detected: ${(activeScan.detectedRuntime || 'static').toUpperCase()}`,
          },
          {
            timestamp: new Date().toISOString(),
            level: 'info',
            message: `Preserved ${activeScan.hiddenCount} hidden configuration files.`,
          },
          {
            timestamp: new Date().toISOString(),
            level: 'success',
            message: `Root entry '${activeScan.entryPointFound}' live at ${
              user.subdomain ? `/u/${user.subdomain}/${finalSlug} & ` : ''
            }/site/${finalSlug}`,
          },
        ],
        files: filesRecord,
      },
      (pct, stageMsg) => {
        setScanProgress(pct);
        if (stageMsg) setScanStage(stageMsg);
      }
    );

    if (res.success && res.site) {
      setScanProgress(100);
      setIsDeploying(false);
      await new Promise((r) => setTimeout(r, 180));
      setIsScanning(false);
      onDeploySuccess(res.site);
    } else {
      setIsDeploying(false);
      setIsScanning(false);
      setDeployError(res.message || 'ডিপ্লয় করতে সমস্যা হয়েছে।');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-3 animate-panel-enter">
      {isScanning && scanResult ? (
        <CyberScanner
          mode="deploy"
          title="DEEP CODE INTEGRITY SCAN & DEPLOYMENT"
          subtitle="Verifying folder structure, hidden files, auto-repair stubs & edge routes..."
          progress={scanProgress}
          currentStepMessage={scanStage}
          checksum={scanResult.checksum}
          filesCount={scanResult.fileCount}
          hiddenCount={scanResult.hiddenCount}
          isBusy={isDeploying}
          busyMessage={
            lang === 'bn'
              ? 'সার্ভারে ফাইল আপলোড ও প্রজেক্ট রানটাইম চালু হচ্ছে...'
              : 'Uploading project files & booting live runtime...'
          }
        />
      ) : (
        <>
          <div className="flex flex-wrap justify-between items-center gap-3 p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="min-w-0">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cyan-50 dark:bg-cyan-950/80 border border-cyan-200 dark:border-cyan-500/30 text-cyan-700 dark:text-cyan-300 text-[11px] font-semibold mb-1">
                <FolderUp className="w-3 h-3" />
                {lang === 'bn' ? 'সম্পূর্ণ ফোল্ডার হোস্টিং' : 'Full Folder Deployment'}
              </div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-snug">
                {lang === 'bn' ? 'ফোল্ডার নির্বাচন করে ওয়েবসাইট চালু করুন' : 'Select Folder & Launch Live Website'}
              </h2>
            </div>

            <button
              type="button"
              onClick={onCancel}
              className="text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 shrink-0"
            >
              {lang === 'bn' ? 'বাতিল' : 'Cancel'}
            </button>
          </div>

          {deployError && (
            <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-500/40 text-rose-700 dark:text-rose-300 text-xs space-y-2.5">
              <div className="flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-500 mt-0.5" />
                <div>
                  <strong className="block font-semibold">
                    {lang === 'bn' ? 'ত্রুটি (Deployment Error):' : 'Deployment Error:'}
                  </strong>
                  <span>{deployError}</span>
                </div>
              </div>
              {parsedFiles.length > 0 && /502|503|504|413|রিস্টার্ট|টাইমআউট|সীমা|পার্চ|সমস্যা/i.test(deployError) && (
                <div className="pl-6">
                  <button
                    type="button"
                    onClick={() => {
                      const next = applyRunnableTrim();
                      if (next) handleStartDeploy(next);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-[11px] font-bold shadow-sm transition"
                  >
                    <Minimize2 className="w-3.5 h-3.5" />
                    <span>
                      {lang === 'bn'
                        ? 'হ্যাঁ, অপ্রয়োজনীয় ফাইল বাদ দিয়ে ছোট করে রান করুন'
                        : 'Trim & Launch Runnable Core'}
                    </span>
                  </button>
                </div>
              )}
            </div>
          )}

          {parsedFiles.length === 0 ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              className={`relative p-10 sm:p-12 rounded-2xl border-2 border-dashed transition-all cursor-pointer flex flex-col items-center justify-center text-center group ${
                isDragging
                  ? 'border-cyan-500 bg-cyan-50/70 dark:bg-cyan-950/30'
                  : 'border-slate-300 dark:border-slate-700 hover:border-cyan-500 bg-white dark:bg-slate-900/40 hover:bg-slate-50 dark:hover:bg-slate-900/70'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                // @ts-expect-error webkitdirectory is standard in browser engines
                webkitdirectory=""
                directory=""
                multiple
                onChange={handleFolderSelect}
                className="hidden"
              />

              <div className="w-16 h-16 rounded-2xl bg-cyan-50 dark:bg-cyan-950/60 border border-cyan-200 dark:border-cyan-500/40 flex items-center justify-center text-cyan-600 dark:text-cyan-400 mb-4 group-hover:scale-110 transition-transform">
                {isReadingFiles ? <Loader2 className="w-8 h-8 animate-spin" /> : <FolderUp className="w-8 h-8" />}
              </div>

              <h3 className="text-base font-semibold text-slate-900 dark:text-white group-hover:text-cyan-600 dark:group-hover:text-cyan-300 transition-colors">
                {isReadingFiles
                  ? lang === 'bn'
                    ? 'ফোল্ডার ও ফাইল স্ক্যান করা হচ্ছে...'
                    : 'Reading & auditing folder files...'
                  : lang === 'bn'
                  ? 'এখানে ক্লিক বা ফোল্ডার ড্র্যাগ-ড্রপ করুন'
                  : 'Click or Drag & Drop Project Folder'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mt-2 leading-relaxed">
                {lang === 'bn'
                  ? 'ফোল্ডারের ভেতরে থাকা index.html, index.php, Python (Flask), Node.js, CSS, JS, ইমেজ ও হিডেন ফাইলগুলো সরাসরি লাইভ হবে।'
                  : 'Select your folder. HTML, PHP, Python, Node.js, CSS, JS, images, and hidden files will be deployed live.'}
              </p>

              <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
                <span className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] text-slate-700 dark:text-slate-300 font-mono">
                  index.html / app.py / server.js
                </span>
                <span className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] text-slate-700 dark:text-slate-300 font-mono">
                  index.php
                </span>
                <span className="px-2.5 py-1 rounded-md bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-700/50 text-[11px] text-emerald-700 dark:text-emerald-300 font-mono">
                  {lang === 'bn' ? '.env & .htaccess (সমর্থিত)' : '.env & .htaccess (Supported)'}
                </span>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Top Settings & Launch CTA Card */}
              <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 space-y-3.5 shadow-sm">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-slate-100 dark:border-slate-800">
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                    <span>{lang === 'bn' ? 'ওয়েবসাইট কনফিগারেশন' : 'Website Settings'}</span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => {
                      setParsedFiles([]);
                      setScanResult(null);
                      setShowFileList(false);
                    }}
                    className="text-xs text-slate-500 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 font-medium"
                  >
                    {lang === 'bn' ? 'অন্য ফোল্ডার বাছুন' : 'Choose another folder'}
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'bn' ? 'প্রজেক্টের নাম' : 'Project Name'}
                    </label>
                    <input
                      type="text"
                      value={projectName}
                      onChange={(e) => {
                        setProjectName(e.target.value);
                        if (!customSlug) setCustomSlug(slugify(e.target.value));
                      }}
                      placeholder="My Web Project"
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500 font-sans"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'bn' ? 'কাস্টম লিঙ্ক / সাবপাথ স্লাগ' : 'Custom Link / Slug'}
                    </label>
                    <div className="flex items-center rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3 py-2 text-sm">
                      <span className="text-slate-500 dark:text-slate-400 font-mono text-xs">/site/</span>
                      <input
                        type="text"
                        value={customSlug}
                        onChange={(e) => setCustomSlug(e.target.value)}
                        placeholder="my-portfolio"
                        className="w-full bg-transparent text-cyan-700 dark:text-cyan-400 focus:outline-none font-mono text-sm ml-1"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {lang === 'bn' ? 'বিবরণ (ঐচ্ছিক)' : 'Description (Optional)'}
                  </label>
                  <input
                    type="text"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Short description of your project..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-cyan-500 font-sans"
                  />
                </div>
                {user.subdomain && (
                  <div className="p-2.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-500/30 text-[11px] font-mono text-emerald-700 dark:text-emerald-300 space-y-0.5 truncate">
                    <div className="flex items-center gap-2 truncate font-bold">
                      <Globe className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">
                        https://{user.subdomain}.{storage.getConfig().primaryDomain || 'nighthostcloud.dpdns.org'}/{slugify(customSlug || projectName || 'my-app')}
                      </span>
                    </div>
                    <div className="pl-5 text-[10px] opacity-80 truncate">
                      /u/{user.subdomain}/{slugify(customSlug || projectName || 'my-app')}
                    </div>
                  </div>
                )}

                {trimSummary && (
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-500/40 text-xs text-emerald-800 dark:text-emerald-200 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    <span className="font-semibold">{trimSummary}</span>
                  </div>
                )}

                {footprint?.needsOptimization && (
                  <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-500/40 text-xs text-amber-900 dark:text-amber-200 space-y-2.5">
                    <div className="font-bold flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                      <span>
                        {lang === 'bn'
                          ? `প্রজেক্ট প্ল্যান সতর্কতা (~${footprint.estimatedRuntimeMb} MB+ সম্ভাব্য ব্যবহার)`
                          : `Plan Resource Advisory (~${footprint.estimatedRuntimeMb} MB+ Estimated Runtime)`}
                      </span>
                    </div>
                    <p className="text-[11px] leading-relaxed opacity-95">
                      {lang === 'bn' ? footprint.reasonBn : footprint.reasonEn}{' '}
                      {lang === 'bn'
                        ? 'চাইলে অপ্রয়োজনীয় ফাইল বাদ দিয়ে শুধু মেইন রানেবল কোর ছোট করে চালু করতে পারবেন।'
                        : 'You can strip non-essential files and launch only the runnable core cleanly.'}
                    </p>
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          const next = applyRunnableTrim();
                          if (next) handleStartDeploy(next);
                        }}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-[11px] font-bold shadow-sm transition"
                      >
                        <Minimize2 className="w-3.5 h-3.5" />
                        <span>
                          {lang === 'bn'
                            ? 'হ্যাঁ, ছোট করে চালু করুন (Trim & Run Core)'
                            : 'Trim & Launch Core'}
                        </span>
                      </button>
                      <button
                        type="button"
                        onClick={() => applyRunnableTrim()}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-500/40 text-amber-800 dark:text-amber-200 text-[11px] font-semibold hover:bg-amber-100/60 dark:hover:bg-amber-900/30 transition"
                      >
                        <span>{lang === 'bn' ? 'শুধু ছোট করে প্রিভিউ দেখুন' : 'Trim & Preview Only'}</span>
                      </button>
                    </div>
                  </div>
                )}

                <div className="pt-2 flex flex-wrap items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={onCancel}
                    className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white text-xs font-medium"
                  >
                    {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                  </button>

                  <button
                    type="button"
                    onClick={() => handleStartDeploy()}
                    disabled={!scanResult || scanResult.errors.length > 0}
                    className={`inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold shadow-lg transition flex-1 sm:flex-initial ${
                      !scanResult || scanResult.errors.length > 0
                        ? 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed'
                        : 'bg-gradient-to-r from-cyan-600 via-indigo-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white'
                    }`}
                  >
                    <span>{lang === 'bn' ? 'স্ক্যান ও হোস্টিং সম্পন্ন করুন' : 'Scan & Launch Website'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Audit Overview & Collapsible File List */}
              <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <FileCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span className="font-semibold text-xs sm:text-sm text-slate-900 dark:text-white">
                      {lang === 'bn' ? 'ফোল্ডার অডিট সম্পন্ন' : 'Folder Audit Overview'}
                    </span>
                    {scanResult?.detectedRuntime && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-500/30 text-indigo-700 dark:text-indigo-300 text-[10px] font-mono font-bold uppercase">
                        <Cpu className="w-3 h-3" />
                        {scanResult.detectedRuntime}
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowFileList(!showFileList)}
                    aria-expanded={showFileList}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 transition"
                  >
                    <span>
                      {lang === 'bn'
                        ? `ফাইল তালিকা (${parsedFiles.length})`
                        : `Files (${parsedFiles.length})`}
                    </span>
                    {showFileList ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono">
                      {lang === 'bn' ? 'মোট ফাইল' : 'Total Files'}
                    </span>
                    <p className="text-base font-bold text-slate-900 dark:text-white font-mono">{scanResult?.fileCount}</p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono">
                      {lang === 'bn' ? 'হিডেন ফাইল' : 'Hidden Files'}
                    </span>
                    <p className="text-base font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                      {scanResult?.hiddenCount}
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono">
                      {lang === 'bn' ? 'আকার' : 'Size'}
                    </span>
                    <p className="text-base font-bold text-cyan-600 dark:text-cyan-400 font-mono">
                      {formatStorageFromKb((scanResult?.totalSizeBytes || 0) / 1024)}
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono">
                      {lang === 'bn' ? 'এন্ট্রি পেজ' : 'Entry Page'}
                    </span>
                    <p className="text-xs font-semibold text-indigo-600 dark:text-indigo-300 font-mono truncate mt-1">
                      {scanResult?.entryPointFound || (lang === 'bn' ? 'পাওয়া যায়নি' : 'Not Found')}
                    </p>
                  </div>
                </div>

                {scanResult && scanResult.errors.length > 0 && (
                  <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-500/40 text-xs text-rose-700 dark:text-rose-300 space-y-1">
                    <div className="font-semibold text-rose-800 dark:text-rose-200">
                      {lang === 'bn' ? '⚠️ সমাধানের জন্য নির্দেশিকা (Diagnostics):' : '⚠️ Diagnostics & Fix Guide:'}
                    </div>
                    {scanResult.errors.map((err, idx) => (
                      <p key={idx}>• {err}</p>
                    ))}
                  </div>
                )}

                {repairPreviewNotes.length > 0 && (
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-500/30 text-xs text-emerald-800 dark:text-emerald-300 space-y-1">
                    <div className="font-bold flex items-center gap-1.5">
                      <Wrench className="w-3.5 h-3.5" />
                      <span>
                        {lang === 'bn'
                          ? `অটো-রিপেয়ার সক্রিয় (${repairPreviewNotes.length}টি মিসিং রেফারেন্স/সার্ভারলেস হ্যান্ডলার যুক্ত হবে):`
                          : `Auto-Repair Active (${repairPreviewNotes.length} missing files/serverless handlers will be synthesized):`}
                      </span>
                    </div>
                    {repairPreviewNotes.slice(0, 4).map((note, idx) => (
                      <p key={idx} className="text-[11px] font-mono">• {note}</p>
                    ))}
                  </div>
                )}

                {scanResult && scanResult.warnings.length > 0 && (
                  <div className="p-3 rounded-xl bg-cyan-50 dark:bg-cyan-950/40 border border-cyan-200 dark:border-cyan-800/40 text-xs text-cyan-800 dark:text-cyan-300 space-y-1">
                    {scanResult.warnings.map((warn, idx) => (
                      <p key={idx}>💡 {warn}</p>
                    ))}
                  </div>
                )}

                {showFileList && (
                  <div className="max-h-48 overflow-y-auto rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-2.5 space-y-1 font-mono text-xs">
                    {parsedFiles.slice(0, 40).map((f, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between px-2 py-1 rounded hover:bg-slate-100 dark:hover:bg-slate-900 text-slate-700 dark:text-slate-300"
                      >
                        <span className="flex items-center gap-2 truncate">
                          {isPathHidden(f.path) ? (
                            <Lock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                          ) : (
                            <FileCode className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400 flex-shrink-0" />
                          )}
                          <span className={isPathHidden(f.path) ? 'text-emerald-700 dark:text-emerald-300' : ''}>
                            {f.path}
                          </span>
                        </span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                          {(f.size / 1024).toFixed(1)} KB
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
